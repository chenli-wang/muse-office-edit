# UI 3D Targeted Fix — NOT RELEASE READY

Fixes from UI_INTERACTIVE_AUDIT.md (avatar pick + camera focus-on-select only).

## Changed files

1. `src/components/office/3d/office-state.ts` — pure helpers: pick resolution, click threshold, camera look target / radius, lerp
2. `src/components/office/3d/office-scene-three.tsx` — larger invisible hit volumes, employeeId on meshes, click-vs-drag, camera orbits around lerped look target
3. `src/components/office/office-shell.tsx` — "Clear selection · camera overview" control
4. `src/components/office/3d/office-state.test.ts` — unit tests for helpers

## Verification (this package)

- typecheck: exit 0
- npm test: 341/341 pass
- build: exit 0

Real-GPU 60 FPS and interactive browser pick still need manual verification.
