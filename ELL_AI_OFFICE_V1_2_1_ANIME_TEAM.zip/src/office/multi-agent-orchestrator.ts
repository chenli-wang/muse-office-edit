/**
 * MultiAgentOrchestrator — Phase 3 collaboration core.
 * Deterministic static plan, parallel independent steps, dependency-aware synthesis.
 */

import { randomUUID } from "node:crypto";
import { planMultiAgent } from "./planner.ts";
import { AgentExecutor, type AgentResult, type AgentTask } from "./agent-executor.ts";
import type { ProviderRouter } from "./provider-router.ts";
import { sanitizePublicErrorMessage } from "./provider-router.ts";
import type {
  AgentOutput,
  Employee,
  FinalResult,
  OfficeEvent,
  OfficeEventType,
  Task,
  TaskStatus,
} from "./types.ts";
import { MOCK_MODEL_ID } from "./providers.ts";
import { CollaborationManager } from "./collaboration/collaboration-manager.ts";

export type MultiTaskStatus =
  | "pending"
  | "planned"
  | "running"
  | "waiting"
  | "completed"
  | "failed"
  | "cancelled";

export interface MultiAgentTask {
  id: string;
  title: string;
  objective: string;
  mode: "multi";
  status: MultiTaskStatus;
  createdAt: string;
  updatedAt: string;
  startedAt: string | null;
  completedAt: string | null;
  cancelledAt: string | null;
  agentTasks: AgentTask[];
  results: AgentResult[];
  finalResult: FinalResult | null;
  error: { class: string; message: string; retryable: boolean } | null;
  planRationale: string;
  /** Employee → provider/model bindings used for this run. */
  bindings: Array<{ employeeId: string; providerId: string; modelId: string }>;
}

export interface MultiAgentOrchestratorOptions {
  employees: Employee[];
  router: ProviderRouter;
  now?: () => number;
  /** Default model id when binding missing (deterministic mock). */
  modelId?: string;
  defaultTimeoutMs?: number;
  bindings?: Array<{ employeeId: string; providerId: string; modelId: string }>;
  /** Bounded project context text for synthesis agents. */
  contextPromptBlock?: string;
  /** Optional collaboration manager for structured handoffs/reviews. */
  collaboration?: CollaborationManager;
  projectId?: string;
  /** Manager cost/routing constraints forwarded to ProviderRouter. */
  routingPolicy?: {
    allowedProviderIds?: string[];
    maxAttempts?: number;
    mode?: "primary-only" | "free-first";
    excludeMockInFreeFirst?: boolean;
  };
}

function iso(ms: number): string {
  return new Date(ms).toISOString();
}

function titleFrom(objective: string): string {
  const oneLine = objective.replace(/\s+/g, " ").trim();
  return oneLine.length <= 72 ? oneLine : `${oneLine.slice(0, 69).trimEnd()}…`;
}

function toAgentOutput(result: AgentResult): AgentOutput {
  return {
    employeeId: result.employeeId,
    summary: result.summary,
    findings: result.findings,
    evidence: result.evidence,
    risks: result.risks,
    recommendations: result.recommendations,
    questions: result.questions,
    confidence: result.confidence,
    provider: result.providerId,
    model: result.model,
    createdAt: result.createdAt,
  };
}

function synthesizeFromResults(
  results: AgentResult[],
  synthesis: AgentResult | undefined,
): FinalResult {
  const failed = results.filter((r) => r.status === "failed");
  const succeeded = results.filter((r) => r.status === "completed");

  if (synthesis && synthesis.status === "completed") {
    return {
      summary: synthesis.summary,
      findings: [
        ...synthesis.findings,
        ...(failed.length
          ? [`Missing/failed agents: ${failed.map((f) => f.employeeId).join(", ")}`]
          : []),
      ],
      evidence: synthesis.evidence,
      risks: synthesis.risks,
      recommendations: synthesis.recommendations,
      questions: synthesis.questions,
      synthesizedBy: "orchestrator",
    };
  }

  // Graceful degradation when GPT synthesis unavailable.
  return {
    summary:
      succeeded.length > 0
        ? `Partial synthesis from ${succeeded.map((s) => s.employeeId).join(", ")} (final reviewer unavailable or failed).`
        : "No agent results available for synthesis.",
    findings: succeeded.flatMap((s) => s.findings).slice(0, 20),
    evidence: succeeded.flatMap((s) => s.evidence).slice(0, 20),
    risks: [
      ...succeeded.flatMap((s) => s.risks),
      ...(failed.length
        ? [`Agents failed: ${failed.map((f) => f.employeeId).join(", ")}`]
        : ["Final reviewer did not produce a result."]),
    ].slice(0, 20),
    recommendations: succeeded.flatMap((s) => s.recommendations).slice(0, 20),
    questions: succeeded.flatMap((s) => s.questions).slice(0, 10),
    synthesizedBy: "orchestrator",
  };
}

export class MultiAgentOrchestrator {
  private readonly employees: Employee[];
  private readonly router: ProviderRouter;
  private readonly now: () => number;
  private readonly modelId: string;
  private readonly defaultTimeoutMs: number;
  private readonly bindings: Array<{ employeeId: string; providerId: string; modelId: string }>;
  private contextPromptBlock: string;
  private readonly collaboration?: CollaborationManager;
  private readonly projectId: string;
  private readonly routingPolicy?: MultiAgentOrchestratorOptions["routingPolicy"];
  private readonly executor = new AgentExecutor();
  private readonly tasks = new Map<string, MultiAgentTask>();
  private readonly abortControllers = new Map<string, AbortController>();
  private readonly runPromises = new Map<string, Promise<void>>();
  private readonly events: OfficeEvent[] = [];

  constructor(options: MultiAgentOrchestratorOptions) {
    this.employees = options.employees;
    this.router = options.router;
    this.now = options.now ?? (() => Date.now());
    this.modelId = options.modelId ?? MOCK_MODEL_ID;
    this.defaultTimeoutMs = options.defaultTimeoutMs ?? 20_000;
    this.bindings = options.bindings ?? [];
    this.contextPromptBlock = options.contextPromptBlock ?? "";
    this.collaboration = options.collaboration;
    this.projectId = options.projectId ?? "default";
    this.routingPolicy = options.routingPolicy;
  }

  private bindingFor(employeeId: string) {
    return (
      this.bindings.find((b) => b.employeeId === employeeId) ?? {
        employeeId,
        providerId: "mock",
        modelId: this.modelId,
      }
    );
  }

  private emit(
    type: OfficeEventType,
    message: string,
    taskId: string | null,
    employeeId: string | null = null,
  ) {
    this.events.push({
      id: `evt_${randomUUID()}`,
      type,
      taskId,
      employeeId,
      message,
      createdAt: iso(this.now()),
    });
  }

  listEvents(): OfficeEvent[] {
    return this.events.map((e) => ({ ...e }));
  }

  getTask(id: string): MultiAgentTask | undefined {
    const t = this.tasks.get(id);
    return t ? structuredClone(t) : undefined;
  }

  listTasks(): MultiAgentTask[] {
    return [...this.tasks.values()]
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
      .map((t) => structuredClone(t));
  }

  /**
   * Create and register a multi-agent task, then start background execution.
   * Returns promptly without waiting for completion.
   */
  create(objective: string): MultiAgentTask {
    const trimmed = objective.trim();
    if (!trimmed) throw new Error("objective is required");

    const t0 = this.now();
    const id = `task_${randomUUID()}`;
    const plan = planMultiAgent(trimmed, this.employees);
    const controller = new AbortController();
    this.abortControllers.set(id, controller);

    const agentTasks: AgentTask[] = plan.steps.map((step) => {
      const emp = this.employees.find((e) => e.id === step.employeeId);
      return {
        id: step.id,
        parentTaskId: id,
        employeeId: step.employeeId,
        role: emp?.role ?? step.employeeId,
        objective: step.objective,
        status: "pending",
        dependsOn: [...step.dependsOn],
        required: step.required,
        kind: step.kind,
        timeoutMs: this.defaultTimeoutMs,
        upstreamResults: [],
        result: null,
        error: null,
        createdAt: iso(t0),
        startedAt: null,
        completedAt: null,
      };
    });

    const task: MultiAgentTask = {
      id,
      title: titleFrom(trimmed),
      objective: trimmed,
      mode: "multi",
      status: "planned",
      createdAt: iso(t0),
      updatedAt: iso(t0),
      startedAt: null,
      completedAt: null,
      cancelledAt: null,
      agentTasks,
      results: [],
      finalResult: null,
      error: null,
      planRationale: plan.rationale,
      bindings: this.bindings.map((b) => ({ ...b })),
    };
    this.tasks.set(id, task);
    this.emit("task.created", `Multi-agent task created: ${task.title}`, id);
    this.emit("task.assigned", plan.rationale, id);

    // Background orchestration — never leave unhandled rejection.
    const run = this.runWaves(task, controller.signal).catch((err) => {
      const current = this.tasks.get(id);
      if (!current || current.status === "cancelled") return;
      current.status = "failed";
      current.error = {
        class: "UNKNOWN",
        message: sanitizePublicErrorMessage(err),
        retryable: false,
      };
      current.updatedAt = iso(this.now());
      this.emit("task.failed", "Background multi-agent run failed.", id);
    });
    this.runPromises.set(id, run);

    return structuredClone(task);
  }

  /** Await background completion (tests / internal). */
  async waitFor(id: string): Promise<MultiAgentTask> {
    const run = this.runPromises.get(id);
    if (run) await run;
    const task = this.tasks.get(id);
    if (!task) throw new Error("Task not found");
    return structuredClone(task);
  }

  /** Backward-compatible helper: create + wait. */
  async createAndRun(objective: string): Promise<MultiAgentTask> {
    const created = this.create(objective);
    return this.waitFor(created.id);
  }

  async cancel(id: string): Promise<MultiAgentTask> {
    const task = this.tasks.get(id);
    if (!task) throw new Error("Task not found");
    if (task.status === "cancelled") return structuredClone(task);
    if (task.status === "completed" || task.status === "failed") {
      throw new Error(`Cannot cancel a ${task.status} task`);
    }

    const controller = this.abortControllers.get(id);
    controller?.abort();

    const t = this.now();
    task.status = "cancelled";
    task.cancelledAt = iso(t);
    task.updatedAt = task.cancelledAt;
    for (const at of task.agentTasks) {
      if (at.status === "pending" || at.status === "running" || at.status === "blocked") {
        at.status = "cancelled";
        at.completedAt = iso(t);
      }
    }
    this.emit("task.cancelled", "Multi-agent task cancelled by the user.", id);
    return structuredClone(task);
  }

  private employee(id: string): Employee {
    const e = this.employees.find((row) => row.id === id);
    if (!e) throw new Error(`Employee ${id} missing`);
    return e;
  }

  private async runWaves(task: MultiAgentTask, signal: AbortSignal): Promise<void> {
    if (signal.aborted || task.status === "cancelled") {
      task.status = "cancelled";
      return;
    }
    task.status = "running";
    task.startedAt = iso(this.now());
    task.updatedAt = task.startedAt;

    const byId = new Map(task.agentTasks.map((a) => [a.id, a]));
    const completed = new Set<string>();

    // Safety: finite waves only (no infinite loop).
    for (let wave = 0; wave < task.agentTasks.length + 2; wave++) {
      // Status may be set to cancelled concurrently via cancel(); signal is the primary abort path.
      if (signal.aborted || (task.status as MultiTaskStatus) === "cancelled") {
        task.status = "cancelled";
        return;
      }

      const runnable = task.agentTasks.filter((at) => {
        if (at.status !== "pending") return false;
        return at.dependsOn.every((dep) => completed.has(dep));
      });

      if (runnable.length === 0) {
        const pending = task.agentTasks.filter((at) => at.status === "pending");
        if (pending.length === 0) break;
        // Remaining pending but deps not satisfied → block them.
        for (const at of pending) {
          const failedDep = at.dependsOn.some((dep) => {
            const d = byId.get(dep);
            return d && (d.status === "failed" || d.status === "cancelled");
          });
          if (failedDep && at.required) {
            at.status = "blocked";
            at.completedAt = iso(this.now());
            at.error = {
              class: "UNKNOWN",
              message: "Blocked: required upstream dependency failed or cancelled.",
              retryable: false,
            };
            this.emit("agent.failed", `Agent ${at.employeeId} blocked.`, task.id, at.employeeId);
          } else if (failedDep) {
            at.status = "blocked";
            at.completedAt = iso(this.now());
          }
        }
        break;
      }

      // Parallel execution of independent runnable tasks.
      await Promise.all(
        runnable.map(async (at) => {
          if (signal.aborted) {
            at.status = "cancelled";
            return;
          }
          // Attach upstream results for dependents.
          at.upstreamResults = at.dependsOn
            .map((dep) => byId.get(dep)?.result)
            .filter((r): r is AgentResult => Boolean(r));

          at.status = "running";
          at.startedAt = iso(this.now());
          this.emit("agent.started", `${at.employeeId} started (${at.kind}).`, task.id, at.employeeId);

          // Phase 11: before synthesis, collect structured collaboration from parallel results
          if (at.kind === "synthesis" && this.collaboration && !signal.aborted) {
            try {
              const collab = this.collaboration.start({
                taskId: task.id,
                projectId: this.projectId,
              });
              const parallelDone = task.agentTasks.filter(
                (a) => a.kind === "parallel" && a.status === "completed" && a.result,
              );
              for (const p of parallelDone) {
                this.collaboration.postMessage({
                  collaborationId: collab.id,
                  type: "finding",
                  senderEmployeeId: p.employeeId,
                  recipientEmployeeId: "*",
                  content: p.result!.summary.slice(0, 1500),
                  tags: [p.employeeId],
                });
              }
              const grok = parallelDone.find((a) => a.employeeId === "grok");
              if (grok) {
                this.collaboration.postMessage({
                  collaborationId: collab.id,
                  type: "challenge",
                  senderEmployeeId: "grok",
                  recipientEmployeeId: "claude",
                  content: `Challenge: ${grok.result!.summary.slice(0, 800)}`,
                  tags: ["challenge"],
                });
              }
              this.collaboration.postMessage({
                collaborationId: collab.id,
                type: "review_request",
                senderEmployeeId: "claude",
                recipientEmployeeId: "gpt",
                content: "Synthesize findings and challenges into a decision.",
                tags: ["review_request"],
              });
              const ctx = this.collaboration.getContextFor(collab.id, "gpt");
              if (ctx.promptBlock) {
                this.contextPromptBlock =
                  `${this.contextPromptBlock}\n\n${ctx.promptBlock}`.trim();
              }
              this.collaboration.postMessage({
                collaborationId: collab.id,
                type: "decision",
                senderEmployeeId: "gpt",
                recipientEmployeeId: "*",
                content: "Synthesis review requested with collaboration context.",
                tags: ["decision"],
              });
            } catch {
              /* best-effort */
            }
          }

          const emp = this.employee(at.employeeId);
          const binding = this.bindingFor(at.employeeId);
          const systemPrompt =
            at.kind === "synthesis" && this.contextPromptBlock
              ? `${emp.systemPrompt}\n\n${this.contextPromptBlock}`
              : emp.systemPrompt;
          const result = await this.executor.execute(at, task.objective, {
            router: this.router,
            modelId: binding.modelId,
            systemPrompt,
            timeoutMs: at.timeoutMs,
            signal,
            providerId: binding.providerId,
            allowedProviderIds: this.routingPolicy?.allowedProviderIds,
            routingMode: this.routingPolicy?.mode,
            maxRoutingAttempts: this.routingPolicy?.maxAttempts,
            excludeMockInFreeFirst: this.routingPolicy?.excludeMockInFreeFirst,
          });

          if (signal.aborted || task.status === "cancelled") {
            at.status = "cancelled";
            at.completedAt = iso(this.now());
            this.emit("agent.failed", `${at.employeeId} cancelled.`, task.id, at.employeeId);
            return;
          }

          at.result = result;
          at.completedAt = iso(this.now());
          task.results.push(result);

          if (result.status === "failed") {
            at.status = "failed";
            at.error = {
              class: result.errorClass ?? "UNKNOWN",
              message: sanitizePublicErrorMessage(new Error(result.summary)),
              retryable: false,
            };
            this.emit("agent.failed", `${at.employeeId} failed.`, task.id, at.employeeId);
          } else {
            at.status = "completed";
            this.emit("agent.completed", `${at.employeeId} completed.`, task.id, at.employeeId);
          }
          completed.add(at.id);
        }),
      );
    }

    if (signal.aborted || (task.status as MultiTaskStatus) === "cancelled") {
      task.status = "cancelled";
      task.cancelledAt = task.cancelledAt ?? iso(this.now());
      task.updatedAt = task.cancelledAt;
      return;
    }

    const synthesisTask = task.agentTasks.find((a) => a.kind === "synthesis");
    const synthesisResult = synthesisTask?.result;
    const parallelResults = task.results.filter((r) => r.employeeId !== "gpt");

    task.finalResult = synthesizeFromResults(parallelResults, synthesisResult ?? undefined);
    task.status = "completed";
    task.completedAt = iso(this.now());
    task.updatedAt = task.completedAt;
    this.emit("task.completed", "Multi-agent synthesis stored.", task.id);
  }

  /** Map multi-agent task into legacy Task shape for API compatibility. */
  toLegacyTask(multi: MultiAgentTask): Task {
    const outputs = multi.results
      .filter((r) => r.status === "completed")
      .map(toAgentOutput);

    let status: TaskStatus = "completed";
    if (multi.status === "cancelled") status = "cancelled";
    else if (multi.status === "failed") status = "failed";
    else if (multi.status === "running" || multi.status === "waiting") status = "running";
    else if (multi.status === "planned" || multi.status === "pending") status = "planning";

    return {
      id: multi.id,
      title: multi.title,
      objective: multi.objective,
      status,
      priority: "normal",
      createdAt: multi.createdAt,
      updatedAt: multi.updatedAt,
      completedAt: multi.completedAt,
      cancelledAt: multi.cancelledAt,
      parentTaskId: null,
      subtasks: multi.agentTasks.map((at) => ({
        id: at.id,
        employeeId: at.employeeId,
        objective: at.objective,
        status:
          at.status === "completed"
            ? "completed"
            : at.status === "failed"
              ? "failed"
              : at.status === "cancelled"
                ? "cancelled"
                : at.status === "running"
                  ? "running"
                  : "assigned",
        expectedOutputFormat: "summary, findings, evidence, risks, recommendations, questions",
        dependencies: at.dependsOn,
        timeoutMs: at.timeoutMs,
      })),
      assignedEmployeeIds: [...new Set(multi.agentTasks.map((a) => a.employeeId))],
      contextRefs: [],
      outputs,
      plan: {
        strategy: "multi-agent-static",
        employeeId: "gpt",
        rationale: multi.planRationale,
      },
      finalResult: multi.finalResult,
      error: multi.error
        ? {
            class: multi.error.class as import("./types.ts").ProviderErrorClass,
            message: multi.error.message,
            retryable: multi.error.retryable,
          }
        : null,
      approvalRequired: false,
      simulateError: false,
    };
  }
}
