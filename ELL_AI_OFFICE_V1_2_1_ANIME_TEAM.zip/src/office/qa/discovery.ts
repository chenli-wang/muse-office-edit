/**
 * Safe validation metadata discovery — reads project files, never executes scripts.
 */

import { existsSync, readFileSync } from "node:fs";
import { join } from "node:path";
import type { WorkspaceScope } from "../tools/workspace-scope.ts";
import { sanitizeQAText } from "./qa-types.ts";

export interface DiscoveredValidationMeta {
  packageScripts: string[];
  hasPackageJson: boolean;
  hasTestConfig: boolean;
  testConfigFiles: string[];
  /** Informational only — never auto-run. */
  notes: string[];
}

const KNOWN_TEST_CONFIGS = [
  "vitest.config.ts",
  "vitest.config.js",
  "jest.config.js",
  "jest.config.ts",
  "playwright.config.ts",
  ".mocharc.json",
];

/** Explicit allowlist of script *names* that may be considered for controlled runs. */
export const DEFAULT_SCRIPT_ALLOWLIST = new Set([
  "test",
  "test:unit",
  "typecheck",
  "lint",
]);

/**
 * Discover validation metadata without executing anything.
 */
export function discoverValidationMeta(scope: WorkspaceScope): DiscoveredValidationMeta {
  const notes: string[] = [];
  const packageScripts: string[] = [];
  let hasPackageJson = false;
  const testConfigFiles: string[] = [];

  const pkgPath = join(scope.root, "package.json");
  if (existsSync(pkgPath)) {
    hasPackageJson = true;
    try {
      const raw = readFileSync(pkgPath, "utf8");
      const pkg = JSON.parse(raw) as { scripts?: Record<string, string> };
      if (pkg.scripts && typeof pkg.scripts === "object") {
        for (const name of Object.keys(pkg.scripts)) {
          packageScripts.push(name);
        }
        packageScripts.sort((a, b) => a.localeCompare(b));
      }
    } catch {
      notes.push("package.json present but unreadable/invalid JSON");
    }
  } else {
    notes.push("No package.json found");
  }

  for (const file of KNOWN_TEST_CONFIGS) {
    if (existsSync(join(scope.root, file))) {
      testConfigFiles.push(file);
    }
  }

  return {
    packageScripts,
    hasPackageJson,
    hasTestConfig: testConfigFiles.length > 0,
    testConfigFiles,
    notes: notes.map((n) => sanitizeQAText(n, 200)),
  };
}

export function filterAllowlistedScripts(
  scripts: string[],
  allowlist: Set<string> = DEFAULT_SCRIPT_ALLOWLIST,
): string[] {
  return scripts.filter((s) => allowlist.has(s));
}
