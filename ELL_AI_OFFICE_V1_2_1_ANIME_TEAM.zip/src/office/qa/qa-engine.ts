/**
 * QAEngine — bounded verification of project changes.
 * Does NOT provide unrestricted shell. Command-based tests → INCONCLUSIVE
 * unless a safe allowlisted runner is configured (default: none).
 */

import { randomUUID } from "node:crypto";
import type { WorkspaceScope } from "../tools/workspace-scope.ts";
import { StaticProjectValidator } from "../tools/validation.ts";
import {
  type QAReport,
  type QAPlan,
  type QACheckResult,
  type QAStatus,
  type ValidationLevel,
  type QALimits,
  DEFAULT_QA_LIMITS,
  QAError,
  sanitizeQAText,
  failureFingerprint,
} from "./qa-types.ts";
import {
  discoverValidationMeta,
  filterAllowlistedScripts,
  DEFAULT_SCRIPT_ALLOWLIST,
} from "./discovery.ts";

export type QAEventType =
  | "qa.started"
  | "qa.validation_started"
  | "qa.validation_completed"
  | "qa.failed"
  | "qa.passed"
  | "qa.inconclusive"
  | "qa.repair_requested"
  | "qa.completed";

export interface QAEvent {
  id: string;
  type: QAEventType;
  taskId: string | null;
  changeSetId: string | null;
  reportId: string | null;
  message: string;
  createdAt: string;
}

export interface ControlledCommandRunner {
  /**
   * Optional safe runner. Must enforce allowlist, workspace cwd, timeout, no network.
   * Default installation does not implement unrestricted shell — returns unsupported.
   */
  run(input: {
    scriptName: string;
    cwd: string;
    timeoutMs: number;
    signal?: AbortSignal;
  }): Promise<{ exitCode: number; stdout: string; stderr: string }>;
}

export interface QAEngineOptions {
  scope: WorkspaceScope;
  limits?: Partial<QALimits>;
  commandRunner?: ControlledCommandRunner;
  scriptAllowlist?: Set<string>;
  now?: () => number;
}

export class QAEngine {
  private readonly scope: WorkspaceScope;
  private readonly limits: QALimits;
  private readonly runner: ControlledCommandRunner | undefined;
  private readonly allowlist: Set<string>;
  private readonly now: () => number;
  private readonly staticValidator = new StaticProjectValidator();
  private readonly reports = new Map<string, QAReport>();
  private readonly baselines = new Map<string, QAReport>();
  private readonly events: QAEvent[] = [];
  private validationRuns = 0;
  private readonly maxEvents = 300;

  constructor(options: QAEngineOptions) {
    this.scope = options.scope;
    this.limits = { ...DEFAULT_QA_LIMITS, ...options.limits };
    this.runner = options.commandRunner;
    this.allowlist = options.scriptAllowlist ?? DEFAULT_SCRIPT_ALLOWLIST;
    this.now = options.now ?? (() => Date.now());
  }

  createPlan(input: {
    taskId?: string | null;
    changeSetId?: string | null;
    levels?: ValidationLevel[];
  }): QAPlan {
    const meta = discoverValidationMeta(this.scope);
    const allowlisted = filterAllowlistedScripts(meta.packageScripts, this.allowlist);
    const levels: ValidationLevel[] = input.levels ?? [
      "static",
      "project",
      "change",
      "regression",
    ];
    const reason = this.runner
      ? `Allowlisted scripts available: ${allowlisted.join(", ") || "none"}`
      : "No controlled command runner configured; script-based checks will be INCONCLUSIVE";

    return {
      id: `qaplan_${randomUUID()}`,
      taskId: input.taskId ?? null,
      changeSetId: input.changeSetId ?? null,
      levels,
      discoveredScripts: meta.packageScripts,
      allowlistedScripts: allowlisted,
      reason: sanitizeQAText(reason, 400),
      createdAt: new Date(this.now()).toISOString(),
    };
  }

  getReport(id: string): QAReport | undefined {
    const r = this.reports.get(id);
    return r ? structuredClone(r) : undefined;
  }

  listEvents(): QAEvent[] {
    return this.events.map((e) => ({ ...e }));
  }

  setBaseline(key: string, report: QAReport): void {
    this.baselines.set(key, structuredClone(report));
  }

  /**
   * Run QA according to plan. Never claims PASS solely from static if other
   * requested levels cannot be executed safely.
   */
  async run(input: {
    plan: QAPlan;
    paths?: string[];
    attempt?: number;
    signal?: AbortSignal;
    baselineKey?: string;
  }): Promise<QAReport> {
    if (this.validationRuns >= this.limits.maxValidationRuns) {
      throw new QAError("LIMIT", "Max validation runs reached");
    }
    this.validationRuns += 1;

    const attempt = input.attempt ?? 1;
    if (attempt > this.limits.maxAttempts) {
      throw new QAError("LIMIT", "Max QA attempts reached");
    }

    const started = this.now();
    this.emit("qa.started", input.plan.taskId, input.plan.changeSetId, null, "QA started");

    const checks: QACheckResult[] = [];

    for (const level of input.plan.levels) {
      if (input.signal?.aborted) {
        throw new QAError("CANCELLED", "QA cancelled");
      }
      this.emit(
        "qa.validation_started",
        input.plan.taskId,
        input.plan.changeSetId,
        null,
        `Validation level: ${level}`,
      );

      if (level === "static" || level === "change") {
        checks.push(await this.runStatic(input.paths, input.signal));
      } else if (level === "project") {
        checks.push(await this.runProjectScripts(input.plan, input.signal));
      } else if (level === "regression") {
        checks.push(
          this.runRegression(
            checks,
            input.baselineKey ? this.baselines.get(input.baselineKey) : undefined,
          ),
        );
      }

      const last = checks[checks.length - 1];
      if (last) {
        this.emit(
          "qa.validation_completed",
          input.plan.taskId,
          input.plan.changeSetId,
          null,
          `${level}: ${last.status}`,
        );
      }
    }

    const status = aggregateStatus(checks);
    const failures = checks.flatMap((c) => c.failures);
    const warnings = checks.flatMap((c) => c.warnings);
    const report: QAReport = {
      id: `qarpt_${randomUUID()}`,
      taskId: input.plan.taskId,
      changeSetId: input.plan.changeSetId,
      status,
      summary: summarize(status, checks),
      checks,
      failures,
      warnings,
      durationMs: Math.max(1, this.now() - started),
      attempt,
      createdAt: new Date(this.now()).toISOString(),
      failureFingerprint: failureFingerprint(failures),
    };

    this.reports.set(report.id, report);

    if (status === "PASS") {
      this.emit("qa.passed", report.taskId, report.changeSetId, report.id, report.summary);
    } else if (status === "FAIL") {
      this.emit("qa.failed", report.taskId, report.changeSetId, report.id, report.summary);
    } else {
      this.emit("qa.inconclusive", report.taskId, report.changeSetId, report.id, report.summary);
    }
    this.emit("qa.completed", report.taskId, report.changeSetId, report.id, `QA ${status}`);

    return structuredClone(report);
  }

  /** Build structured feedback string for agent tool-loop (bounded). */
  formatRepairFeedback(report: QAReport): string {
    const lines = [
      `QA ${report.status} (report ${report.id}, attempt ${report.attempt})`,
      report.summary,
    ];
    for (const f of report.failures.slice(0, 8)) {
      lines.push(`FAIL: ${sanitizeQAText(f, 200)}`);
    }
    for (const w of report.warnings.slice(0, 4)) {
      lines.push(`WARN: ${sanitizeQAText(w, 160)}`);
    }
    return sanitizeQAText(lines.join("\n"), this.limits.maxOutputChars);
  }

  private async runStatic(
    paths: string[] | undefined,
    signal?: AbortSignal,
  ): Promise<QACheckResult> {
    const t0 = this.now();
    try {
      const result = await this.staticValidator.validate(this.scope, {
        paths,
        signal,
        timeoutMs: this.limits.timeoutMs,
      });
      const failures = result.issues
        .filter((i) => i.severity === "error")
        .map((i) => sanitizeQAText(`${i.path ?? "?"}: ${i.message}`, 200));
      const warnings = result.issues
        .filter((i) => i.severity === "warning")
        .map((i) => sanitizeQAText(`${i.path ?? "?"}: ${i.message}`, 160));
      let status: QAStatus = "PASS";
      if (result.status === "fail") status = "FAIL";
      if (result.status === "error") status = "INCONCLUSIVE";
      return {
        checkId: `chk_static_${randomUUID().slice(0, 8)}`,
        level: "static",
        name: "static-project",
        status,
        summary: `Static validation ${status} (${result.checkedFiles} files)`,
        failures,
        warnings,
        durationMs: Math.max(1, this.now() - t0),
        output: sanitizeQAText(failures.join("\n") || "ok", 800),
      };
    } catch (err) {
      return {
        checkId: `chk_static_${randomUUID().slice(0, 8)}`,
        level: "static",
        name: "static-project",
        status: "INCONCLUSIVE",
        summary: sanitizeQAText(
          err instanceof Error ? err.message : "Static validation error",
          200,
        ),
        failures: [],
        warnings: [],
        durationMs: Math.max(1, this.now() - t0),
        output: "",
      };
    }
  }

  private async runProjectScripts(
    plan: QAPlan,
    signal?: AbortSignal,
  ): Promise<QACheckResult> {
    const t0 = this.now();
    if (!this.runner) {
      return {
        checkId: `chk_project_${randomUUID().slice(0, 8)}`,
        level: "project",
        name: "project-scripts",
        status: "INCONCLUSIVE",
        summary:
          "Project script validation unavailable: no controlled command runner configured (not claiming PASS)",
        failures: [],
        warnings: plan.discoveredScripts.length
          ? [
              sanitizeQAText(
                `Discovered scripts (not executed): ${plan.discoveredScripts.slice(0, 12).join(", ")}`,
                300,
              ),
            ]
          : [],
        durationMs: Math.max(1, this.now() - t0),
        output: sanitizeQAText(plan.reason, 400),
      };
    }

    if (plan.allowlistedScripts.length === 0) {
      return {
        checkId: `chk_project_${randomUUID().slice(0, 8)}`,
        level: "project",
        name: "project-scripts",
        status: "INCONCLUSIVE",
        summary: "No allowlisted package scripts to run",
        failures: [],
        warnings: [],
        durationMs: Math.max(1, this.now() - t0),
        output: "",
      };
    }

    const failures: string[] = [];
    const warnings: string[] = [];
    let anyFail = false;

    for (const script of plan.allowlistedScripts.slice(0, 3)) {
      if (signal?.aborted) break;
      try {
        const result = await this.runner.run({
          scriptName: script,
          cwd: this.scope.root,
          timeoutMs: this.limits.timeoutMs,
          signal,
        });
        if (result.exitCode !== 0) {
          anyFail = true;
          failures.push(
            sanitizeQAText(
              `script:${script} exit ${result.exitCode}: ${result.stderr || result.stdout}`,
              300,
            ),
          );
        }
      } catch (err) {
        warnings.push(
          sanitizeQAText(
            `script:${script} error: ${err instanceof Error ? err.message : "failed"}`,
            200,
          ),
        );
      }
    }

    return {
      checkId: `chk_project_${randomUUID().slice(0, 8)}`,
      level: "project",
      name: "project-scripts",
      status: anyFail ? "FAIL" : warnings.length && !anyFail ? "INCONCLUSIVE" : "PASS",
      summary: anyFail
        ? "Allowlisted project scripts reported failures"
        : "Allowlisted project scripts completed",
      failures,
      warnings,
      durationMs: Math.max(1, this.now() - t0),
      output: sanitizeQAText(failures.join("\n"), 800),
    };
  }

  private runRegression(
    currentChecks: QACheckResult[],
    baseline: QAReport | undefined,
  ): QACheckResult {
    const t0 = this.now();
    if (!baseline) {
      return {
        checkId: `chk_reg_${randomUUID().slice(0, 8)}`,
        level: "regression",
        name: "regression",
        status: "INCONCLUSIVE",
        summary: "No baseline QA report available for regression comparison",
        failures: [],
        warnings: ["Baseline missing"],
        durationMs: Math.max(1, this.now() - t0),
        output: "",
      };
    }

    const currentFails = new Set(
      currentChecks.flatMap((c) => c.failures).map((f) => f.toLowerCase()),
    );
    const baseFails = new Set(baseline.failures.map((f) => f.toLowerCase()));
    const newlyFailing: string[] = [];
    for (const f of currentFails) {
      if (!baseFails.has(f)) newlyFailing.push(f);
    }
    const stillFailing = [...currentFails].filter((f) => baseFails.has(f));

    const status: QAStatus =
      newlyFailing.length > 0 ? "FAIL" : currentFails.size > 0 ? "FAIL" : "PASS";

    return {
      checkId: `chk_reg_${randomUUID().slice(0, 8)}`,
      level: "regression",
      name: "regression",
      status,
      summary:
        newlyFailing.length > 0
          ? `Regression: ${newlyFailing.length} new failure(s)`
          : stillFailing.length > 0
            ? "Prior failures still present"
            : "No new regressions detected vs baseline",
      failures: newlyFailing.map((f) => sanitizeQAText(f, 200)),
      warnings: stillFailing.slice(0, 5).map((f) => sanitizeQAText(`unchanged: ${f}`, 160)),
      durationMs: Math.max(1, this.now() - t0),
      output: sanitizeQAText(newlyFailing.join("\n"), 600),
    };
  }

  private emit(
    type: QAEventType,
    taskId: string | null | undefined,
    changeSetId: string | null | undefined,
    reportId: string | null,
    message: string,
  ): void {
    this.events.push({
      id: `qevt_${randomUUID()}`,
      type,
      taskId: taskId ?? null,
      changeSetId: changeSetId ?? null,
      reportId,
      message: sanitizeQAText(message, 300),
      createdAt: new Date(this.now()).toISOString(),
    });
    if (this.events.length > this.maxEvents) {
      this.events.splice(0, this.events.length - this.maxEvents);
    }
  }
}

function aggregateStatus(checks: QACheckResult[]): QAStatus {
  if (checks.some((c) => c.status === "FAIL")) return "FAIL";
  if (checks.length === 0) return "INCONCLUSIVE";
  if (checks.every((c) => c.status === "PASS")) return "PASS";
  // Mix of PASS + INCONCLUSIVE without FAIL
  if (checks.some((c) => c.status === "INCONCLUSIVE")) return "INCONCLUSIVE";
  return "PASS";
}

function summarize(status: QAStatus, checks: QACheckResult[]): string {
  const parts = checks.map((c) => `${c.level}:${c.status}`);
  return sanitizeQAText(`QA ${status} [${parts.join(", ")}]`, 300);
}
