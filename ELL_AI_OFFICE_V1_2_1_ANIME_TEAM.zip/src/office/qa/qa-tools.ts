/**
 * ToolRegistry bindings for QA engine.
 */

import type { ToolDefinition, ToolRegistry } from "../tools/tool-registry.ts";
import type { QAEngine } from "./qa-engine.ts";
import type { ValidationLevel } from "./qa-types.ts";

export function createQATools(engine: QAEngine): ToolDefinition[] {
  const planTool: ToolDefinition = {
    name: "qa.plan",
    description: "Create a QA plan for the workspace/change set (discovery only, no script execution).",
    permission: "read",
    inputSchema: {
      type: "object",
      properties: {
        changeSetId: { type: "string" },
        levels: { type: "array", items: { type: "string" } },
      },
    },
    async execute(input, ctx) {
      const body = (input ?? {}) as { changeSetId?: string; levels?: string[] };
      const levels = body.levels?.filter((l): l is ValidationLevel =>
        ["static", "project", "change", "regression"].includes(l),
      );
      return engine.createPlan({
        taskId: ctx.taskId ?? null,
        changeSetId: body.changeSetId ?? null,
        levels,
      });
    },
  };

  const runTool: ToolDefinition = {
    name: "qa.run",
    description:
      "Run QA verification. Script-based project checks are INCONCLUSIVE unless a controlled runner is configured. Never claims PASS from static alone when project level is requested and unavailable.",
    permission: "read",
    inputSchema: {
      type: "object",
      properties: {
        changeSetId: { type: "string" },
        paths: { type: "array", items: { type: "string" } },
        levels: { type: "array", items: { type: "string" } },
        attempt: { type: "number" },
        baselineKey: { type: "string" },
      },
    },
    async execute(input, ctx) {
      const body = (input ?? {}) as {
        changeSetId?: string;
        paths?: string[];
        levels?: string[];
        attempt?: number;
        baselineKey?: string;
      };
      const levels = body.levels?.filter((l): l is ValidationLevel =>
        ["static", "project", "change", "regression"].includes(l),
      );
      const plan = engine.createPlan({
        taskId: ctx.taskId ?? null,
        changeSetId: body.changeSetId ?? null,
        levels,
      });
      return engine.run({
        plan,
        paths: body.paths,
        attempt: body.attempt,
        baselineKey: body.baselineKey,
      });
    },
  };

  const reportTool: ToolDefinition = {
    name: "qa.report",
    description: "Fetch a prior QA report by id.",
    permission: "read",
    inputSchema: {
      type: "object",
      properties: { reportId: { type: "string" } },
      required: ["reportId"],
    },
    async execute(input) {
      const id = String((input as { reportId?: string })?.reportId ?? "");
      const report = engine.getReport(id);
      if (!report) throw new Error("QA report not found");
      return report;
    },
  };

  return [planTool, runTool, reportTool];
}

export function registerQATools(registry: ToolRegistry, engine: QAEngine): void {
  for (const tool of createQATools(engine)) {
    registry.register(tool);
  }
}
