/**
 * QA / verification types (Phase 12).
 * Provider-neutral; no unrestricted shell.
 */

export type QAStatus = "PASS" | "FAIL" | "INCONCLUSIVE";

export type ValidationLevel = "static" | "project" | "change" | "regression";

export interface QACheckResult {
  checkId: string;
  level: ValidationLevel;
  name: string;
  status: QAStatus;
  summary: string;
  failures: string[];
  warnings: string[];
  durationMs: number;
  /** Bounded, sanitized output excerpt. */
  output: string;
}

export interface QAReport {
  id: string;
  taskId: string | null;
  changeSetId: string | null;
  status: QAStatus;
  summary: string;
  checks: QACheckResult[];
  failures: string[];
  warnings: string[];
  durationMs: number;
  attempt: number;
  createdAt: string;
  /** Fingerprint of failure set for duplicate detection. */
  failureFingerprint: string | null;
}

export interface QAPlan {
  id: string;
  taskId: string | null;
  changeSetId: string | null;
  levels: ValidationLevel[];
  discoveredScripts: string[];
  /** Scripts are never auto-executed unless explicitly allowlisted. */
  allowlistedScripts: string[];
  reason: string;
  createdAt: string;
}

export interface QALimits {
  maxAttempts: number;
  maxRepairCycles: number;
  maxValidationRuns: number;
  maxOutputChars: number;
  timeoutMs: number;
}

export const DEFAULT_QA_LIMITS: QALimits = {
  maxAttempts: 3,
  maxRepairCycles: 2,
  maxValidationRuns: 8,
  maxOutputChars: 4_000,
  timeoutMs: 8_000,
};

export class QAError extends Error {
  readonly code:
    | "LIMIT"
    | "TIMEOUT"
    | "CANCELLED"
    | "UNSUPPORTED"
    | "PERMISSION"
    | "INVALID"
    | "STALE";

  constructor(code: QAError["code"], message: string) {
    super(message);
    this.name = "QAError";
    this.code = code;
  }
}

export function sanitizeQAText(raw: string, maxLen: number): string {
  let text = String(raw ?? "");
  text = text
    .replace(/Bearer\s+[A-Za-z0-9._\-]+/gi, "Bearer [REDACTED]")
    .replace(/\b(sk|xai|AIza)[-_A-Za-z0-9]{8,}/g, "[REDACTED_KEY]")
    .replace(/secret-api-key-[A-Za-z0-9\-]+/gi, "[REDACTED_KEY]")
    .replace(/api[_-]?key["\s:=]+[A-Za-z0-9._\-]+/gi, "api_key=[REDACTED]")
    .replace(/\/home\/[^\s"']+/g, "[PATH]")
    .replace(/\/Users\/[^\s"']+/g, "[PATH]")
    .replace(/[A-Za-z]:\\[^\s"']+/g, "[PATH]");
  if (text.length > maxLen) text = `${text.slice(0, maxLen - 1)}…`;
  return text;
}

export function failureFingerprint(failures: string[]): string | null {
  if (failures.length === 0) return null;
  const norm = failures
    .map((f) => f.toLowerCase().replace(/\s+/g, " ").trim())
    .sort()
    .join("|");
  let h = 0;
  for (let i = 0; i < norm.length; i++) h = (h * 31 + norm.charCodeAt(i)) >>> 0;
  return `qa_${h.toString(16)}`;
}
