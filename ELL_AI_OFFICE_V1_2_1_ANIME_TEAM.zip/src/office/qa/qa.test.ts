import assert from "node:assert/strict";
import { describe, it, beforeEach, afterEach } from "node:test";
import { mkdtempSync, rmSync, writeFileSync, mkdirSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { WorkspaceScope } from "../tools/workspace-scope.ts";
import { QAEngine } from "./qa-engine.ts";
import { discoverValidationMeta, filterAllowlistedScripts } from "./discovery.ts";
import { sanitizeQAText, failureFingerprint } from "./qa-types.ts";
import { ToolRegistry } from "../tools/tool-registry.ts";
import { registerProjectTools } from "../tools/project-tools.ts";
import { registerQATools } from "./qa-tools.ts";
import { createOfficeRuntime } from "../runtime.ts";

describe("QA discovery", () => {
  let root: string;
  beforeEach(() => {
    root = mkdtempSync(join(tmpdir(), "ell-qa-"));
  });
  afterEach(() => rmSync(root, { recursive: true, force: true }));

  it("discovers package scripts without executing", () => {
    writeFileSync(
      join(root, "package.json"),
      JSON.stringify({
        scripts: { test: "node --test", build: "echo no", "test:unit": "node --test" },
      }),
      "utf8",
    );
    const meta = discoverValidationMeta(new WorkspaceScope({ root }));
    assert.equal(meta.hasPackageJson, true);
    assert.ok(meta.packageScripts.includes("test"));
    assert.deepEqual(
      filterAllowlistedScripts(meta.packageScripts).sort(),
      ["test", "test:unit"].sort(),
    );
  });

  it("handles missing package.json", () => {
    const meta = discoverValidationMeta(new WorkspaceScope({ root }));
    assert.equal(meta.hasPackageJson, false);
  });
});

describe("QAEngine", () => {
  let root: string;
  let engine: QAEngine;

  beforeEach(() => {
    root = mkdtempSync(join(tmpdir(), "ell-qa2-"));
    writeFileSync(join(root, "ok.ts"), "export const x = 1;\n", "utf8");
    engine = new QAEngine({ scope: new WorkspaceScope({ root }) });
  });
  afterEach(() => rmSync(root, { recursive: true, force: true }));

  it("creates QA plan", () => {
    writeFileSync(
      join(root, "package.json"),
      JSON.stringify({ scripts: { test: "node --test" } }),
      "utf8",
    );
    const plan = engine.createPlan({ taskId: "t1", changeSetId: "cs1" });
    assert.ok(plan.id);
    assert.ok(plan.discoveredScripts.includes("test"));
    assert.match(plan.reason, /INCONCLUSIVE|No controlled/i);
  });

  it("static validation PASS", async () => {
    const plan = engine.createPlan({ levels: ["static"] });
    const report = await engine.run({ plan, paths: ["ok.ts"] });
    assert.equal(report.status, "PASS");
    assert.ok(report.checks.some((c) => c.level === "static"));
  });

  it("static validation FAIL", async () => {
    writeFileSync(join(root, "bad.ts"), "export const y = {\n", "utf8");
    const plan = engine.createPlan({ levels: ["static"] });
    const report = await engine.run({ plan, paths: ["bad.ts"] });
    assert.equal(report.status, "FAIL");
    assert.ok(report.failures.length >= 1);
  });

  it("project scripts without runner are INCONCLUSIVE not PASS", async () => {
    writeFileSync(
      join(root, "package.json"),
      JSON.stringify({ scripts: { test: "node --test" } }),
      "utf8",
    );
    const plan = engine.createPlan({ levels: ["project"] });
    const report = await engine.run({ plan });
    assert.equal(report.status, "INCONCLUSIVE");
    assert.ok(!report.checks.every((c) => c.status === "PASS") || report.status === "INCONCLUSIVE");
  });

  it("combined static+project yields INCONCLUSIVE when scripts unavailable", async () => {
    const plan = engine.createPlan({ levels: ["static", "project"] });
    const report = await engine.run({ plan, paths: ["ok.ts"] });
    // Static may PASS but project INCONCLUSIVE → aggregate INCONCLUSIVE
    assert.equal(report.status, "INCONCLUSIVE");
  });

  it("regression detection with baseline", async () => {
    const plan1 = engine.createPlan({ levels: ["static"] });
    const base = await engine.run({ plan: plan1, paths: ["ok.ts"] });
    engine.setBaseline("main", base);
    writeFileSync(join(root, "ok.ts"), "export const x = {\n", "utf8");
    const plan2 = engine.createPlan({ levels: ["static", "regression"] });
    const report = await engine.run({
      plan: plan2,
      paths: ["ok.ts"],
      baselineKey: "main",
    });
    assert.equal(report.status, "FAIL");
  });

  it("cancellation", async () => {
    const plan = engine.createPlan({ levels: ["static"] });
    const c = new AbortController();
    c.abort();
    await assert.rejects(() => engine.run({ plan, signal: c.signal }));
  });

  it("repair feedback is bounded and sanitized", async () => {
    writeFileSync(join(root, "bad.ts"), "export const z = {\n", "utf8");
    const plan = engine.createPlan({ levels: ["static"] });
    const report = await engine.run({ plan, paths: ["bad.ts"] });
    const fb = engine.formatRepairFeedback(report);
    assert.ok(fb.includes("FAIL") || fb.includes("QA"));
    assert.equal(fb.includes("secret-api-key"), false);
  });

  it("events emitted", async () => {
    const plan = engine.createPlan({ levels: ["static"] });
    await engine.run({ plan, paths: ["ok.ts"] });
    const types = engine.listEvents().map((e) => e.type);
    assert.ok(types.includes("qa.started"));
    assert.ok(types.includes("qa.completed"));
  });

  it("sanitize strips paths and secrets", () => {
    const s = sanitizeQAText(
      "err /home/workdir/secret secret-api-key-123 Bearer tok",
      200,
    );
    assert.equal(s.includes("secret-api-key-123"), false);
    assert.equal(s.includes("/home/workdir"), false);
  });

  it("failure fingerprint stable", () => {
    const a = failureFingerprint(["B", "A"]);
    const b = failureFingerprint(["A", "B"]);
    assert.equal(a, b);
  });
});

describe("QA tools + runtime", () => {
  let root: string;
  beforeEach(() => {
    root = mkdtempSync(join(tmpdir(), "ell-qa3-"));
    writeFileSync(join(root, "a.ts"), "export const a = 1;\n", "utf8");
  });
  afterEach(() => rmSync(root, { recursive: true, force: true }));

  it("registers qa tools on registry", async () => {
    const scope = new WorkspaceScope({ root });
    const engine = new QAEngine({ scope });
    const reg = new ToolRegistry();
    registerProjectTools(reg, scope);
    registerQATools(reg, engine);
    assert.ok(reg.get("qa.plan"));
    assert.ok(reg.get("qa.run"));
    const plan = await reg.invoke("qa.plan", {}, { taskId: "t" });
    assert.equal(plan.ok, true);
    const run = await reg.invoke(
      "qa.run",
      { levels: ["static"], paths: ["a.ts"] },
      { taskId: "t" },
    );
    assert.equal(run.ok, true);
    assert.equal((run.result as { status: string }).status, "PASS");
  });

  it("runtime lists qa tools", () => {
    const rt = createOfficeRuntime({ workspaceRoot: root });
    const names = rt.listTools().map((t) => t.name);
    assert.ok(names.includes("qa.run"));
    assert.ok(names.includes("qa.plan"));
  });

  it("memory can record important QA outcome explicitly", () => {
    const rt = createOfficeRuntime({
      workspaceRoot: root,
      projectId: "qa-mem",
    });
    const e = rt.addProjectContext({
      type: "issue",
      content: "QA confirmed regression in parser",
      tags: ["qa", "regression"],
    });
    assert.equal(e.type, "issue");
  });
});
