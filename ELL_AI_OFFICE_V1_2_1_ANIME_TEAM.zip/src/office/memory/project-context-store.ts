/**
 * ProjectContextStore — bounded, structured project memory (in-memory).
 * Interface is storage-agnostic for a future persistent backend.
 */

import { randomUUID } from "node:crypto";

export type ContextEntryType =
  | "decision"
  | "finding"
  | "issue"
  | "note"
  | "task_summary";

export interface ContextEntry {
  id: string;
  projectId: string;
  type: ContextEntryType;
  content: string;
  sourceEmployeeId: string | null;
  taskId: string | null;
  tags: string[];
  /** Monotonic order within the store (deterministic for tests). */
  order: number;
  createdAt: string;
}

export interface ProjectContext {
  projectId: string;
  title: string;
  createdAt: string;
  updatedAt: string;
  entryCount: number;
}

export interface AddEntryInput {
  projectId: string;
  type: ContextEntryType;
  content: string;
  sourceEmployeeId?: string | null;
  taskId?: string | null;
  tags?: string[];
}

export interface RetrieveOptions {
  projectId: string;
  type?: ContextEntryType;
  tags?: string[];
  /** Max entries to return (capped by store limits). */
  limit?: number;
  /** Retrieve most recent first (default true). */
  recentFirst?: boolean;
}

export interface ProjectContextLimits {
  maxEntriesPerProject: number;
  maxContentLength: number;
  maxRetrieval: number;
  maxTagsPerEntry: number;
  maxTagLength: number;
}

export const DEFAULT_CONTEXT_LIMITS: ProjectContextLimits = {
  maxEntriesPerProject: 200,
  maxContentLength: 4_000,
  maxRetrieval: 40,
  maxTagsPerEntry: 8,
  maxTagLength: 40,
};

/** Strip secrets/credentials before persistence. */
export function sanitizeContextContent(raw: string, maxLen: number): string {
  let text = String(raw ?? "");
  text = text
    .replace(/Bearer\s+[A-Za-z0-9._\-]+/gi, "Bearer [REDACTED]")
    .replace(/\b(sk|xai|AIza)[-_A-Za-z0-9]{8,}/g, "[REDACTED_KEY]")
    .replace(/secret-api-key-[A-Za-z0-9\-]+/gi, "[REDACTED_KEY]")
    .replace(/api[_-]?key["\s:=]+[A-Za-z0-9._\-]+/gi, "api_key=[REDACTED]")
    .replace(/Authorization["\s:=]+[^\s,;]+/gi, "Authorization=[REDACTED]");
  if (text.length > maxLen) text = `${text.slice(0, maxLen - 1)}…`;
  return text;
}

export interface ProjectContextStore {
  createProject(projectId: string, title?: string): ProjectContext;
  getProject(projectId: string): ProjectContext | undefined;
  listProjects(): ProjectContext[];
  addEntry(input: AddEntryInput): ContextEntry;
  getEntries(options: RetrieveOptions): ContextEntry[];
  getSnapshot(projectId: string, limit?: number): {
    project: ProjectContext | undefined;
    entries: ContextEntry[];
  };
  clearProject(projectId: string): void;
}

export class InMemoryProjectContextStore implements ProjectContextStore {
  private readonly projects = new Map<string, ProjectContext>();
  private readonly entries = new Map<string, ContextEntry[]>();
  private orderCounter = 0;
  private readonly limits: ProjectContextLimits;
  private readonly now: () => number;

  constructor(options?: {
    limits?: Partial<ProjectContextLimits>;
    now?: () => number;
  }) {
    this.limits = { ...DEFAULT_CONTEXT_LIMITS, ...options?.limits };
    this.now = options?.now ?? (() => Date.now());
  }

  createProject(projectId: string, title?: string): ProjectContext {
    const id = projectId.trim();
    if (!id) throw new Error("projectId is required");
    const existing = this.projects.get(id);
    if (existing) return { ...existing };
    const ts = new Date(this.now()).toISOString();
    const ctx: ProjectContext = {
      projectId: id,
      title: (title ?? id).slice(0, 120),
      createdAt: ts,
      updatedAt: ts,
      entryCount: 0,
    };
    this.projects.set(id, ctx);
    this.entries.set(id, []);
    return { ...ctx };
  }

  getProject(projectId: string): ProjectContext | undefined {
    const p = this.projects.get(projectId);
    return p ? { ...p } : undefined;
  }

  listProjects(): ProjectContext[] {
    return [...this.projects.values()]
      .map((p) => ({ ...p }))
      .sort((a, b) => a.projectId.localeCompare(b.projectId));
  }

  addEntry(input: AddEntryInput): ContextEntry {
    const projectId = input.projectId.trim();
    if (!projectId) throw new Error("projectId is required");
    if (!this.projects.has(projectId)) {
      this.createProject(projectId);
    }
    const content = sanitizeContextContent(
      input.content,
      this.limits.maxContentLength,
    );
    if (!content.trim()) throw new Error("content is required after sanitization");

    const tags = (input.tags ?? [])
      .map((t) => String(t).trim().slice(0, this.limits.maxTagLength))
      .filter(Boolean)
      .slice(0, this.limits.maxTagsPerEntry);

    const entry: ContextEntry = {
      id: `ctx_${randomUUID()}`,
      projectId,
      type: input.type,
      content,
      sourceEmployeeId: input.sourceEmployeeId ?? null,
      taskId: input.taskId ?? null,
      tags,
      order: ++this.orderCounter,
      createdAt: new Date(this.now()).toISOString(),
    };

    const list = this.entries.get(projectId) ?? [];
    list.push(entry);
    // Bound growth: drop oldest when over limit
    while (list.length > this.limits.maxEntriesPerProject) {
      list.shift();
    }
    this.entries.set(projectId, list);

    const project = this.projects.get(projectId)!;
    project.entryCount = list.length;
    project.updatedAt = entry.createdAt;

    return { ...entry, tags: [...entry.tags] };
  }

  getEntries(options: RetrieveOptions): ContextEntry[] {
    const list = this.entries.get(options.projectId) ?? [];
    let filtered = list;
    if (options.type) {
      filtered = filtered.filter((e) => e.type === options.type);
    }
    if (options.tags && options.tags.length > 0) {
      const wanted = new Set(options.tags.map((t) => t.trim()).filter(Boolean));
      filtered = filtered.filter((e) => e.tags.some((t) => wanted.has(t)));
    }
    const recentFirst = options.recentFirst !== false;
    const sorted = [...filtered].sort((a, b) =>
      recentFirst ? b.order - a.order : a.order - b.order,
    );
    const limit = Math.min(
      Math.max(1, options.limit ?? this.limits.maxRetrieval),
      this.limits.maxRetrieval,
    );
    return sorted.slice(0, limit).map((e) => ({ ...e, tags: [...e.tags] }));
  }

  getSnapshot(projectId: string, limit?: number) {
    return {
      project: this.getProject(projectId),
      entries: this.getEntries({
        projectId,
        limit: limit ?? this.limits.maxRetrieval,
        recentFirst: true,
      }),
    };
  }

  clearProject(projectId: string): void {
    this.projects.delete(projectId);
    this.entries.delete(projectId);
  }
}
