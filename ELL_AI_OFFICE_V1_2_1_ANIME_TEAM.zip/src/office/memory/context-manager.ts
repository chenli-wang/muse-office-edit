/**
 * ContextManager — project memory façade for tasks and agents.
 */

import {
  InMemoryProjectContextStore,
  type AddEntryInput,
  type ContextEntry,
  type ContextEntryType,
  type ProjectContext,
  type ProjectContextStore,
  type RetrieveOptions,
} from "./project-context-store.ts";

export type ContextEventType =
  | "context.created"
  | "context.updated"
  | "context.retrieved";

export interface ContextEvent {
  id: string;
  type: ContextEventType;
  projectId: string;
  taskId: string | null;
  employeeId: string | null;
  message: string;
  createdAt: string;
}

export interface ContextSnapshot {
  projectId: string;
  title: string;
  entryCount: number;
  /** Bounded recent entries for prompts. */
  entries: ContextEntry[];
  /** Compact text block for agent prompts (bounded). */
  promptBlock: string;
}

let eventSeq = 0;

export class ContextManager {
  private readonly store: ProjectContextStore;
  private readonly events: ContextEvent[] = [];
  private readonly maxEvents = 300;
  private readonly now: () => number;
  private readonly defaultProjectId: string;

  constructor(options?: {
    store?: ProjectContextStore;
    defaultProjectId?: string;
    now?: () => number;
  }) {
    this.store = options?.store ?? new InMemoryProjectContextStore({ now: options?.now });
    this.defaultProjectId = options?.defaultProjectId ?? "default";
    this.now = options?.now ?? (() => Date.now());
    // Ensure default project exists
    this.store.createProject(this.defaultProjectId, "Default project");
  }

  getStore(): ProjectContextStore {
    return this.store;
  }

  getDefaultProjectId(): string {
    return this.defaultProjectId;
  }

  ensureProject(projectId: string, title?: string): ProjectContext {
    const existing = this.store.getProject(projectId);
    if (existing) return existing;
    const created = this.store.createProject(projectId, title);
    this.emit("context.created", projectId, null, null, `Project context created: ${projectId}`);
    return created;
  }

  addEntry(
    input: AddEntryInput,
    meta?: { taskId?: string | null; employeeId?: string | null },
  ): ContextEntry {
    this.ensureProject(input.projectId);
    const entry = this.store.addEntry(input);
    this.emit(
      "context.updated",
      input.projectId,
      meta?.taskId ?? input.taskId ?? null,
      meta?.employeeId ?? input.sourceEmployeeId ?? null,
      `Added ${entry.type}: ${entry.id}`,
    );
    return entry;
  }

  retrieve(options: RetrieveOptions): ContextEntry[] {
    const entries = this.store.getEntries(options);
    this.emit(
      "context.retrieved",
      options.projectId,
      null,
      null,
      `Retrieved ${entries.length} context entries`,
    );
    return entries;
  }

  /**
   * Bounded snapshot for task start / synthesis prompts.
   * Prefer findings + decisions + issues; include recent notes last.
   */
  snapshotForTask(
    projectId: string,
    options?: { limit?: number; taskId?: string | null },
  ): ContextSnapshot {
    const project = this.ensureProject(projectId);
    const limit = options?.limit ?? 20;
    const entries = this.store.getEntries({
      projectId,
      limit,
      recentFirst: true,
    });
    this.emit(
      "context.retrieved",
      projectId,
      options?.taskId ?? null,
      null,
      `Task snapshot (${entries.length} entries)`,
    );
    return {
      projectId: project.projectId,
      title: project.title,
      entryCount: project.entryCount,
      entries,
      promptBlock: formatPromptBlock(entries, 2_500),
    };
  }

  /** Record a structured finding from an agent result summary. */
  recordAgentContribution(input: {
    projectId: string;
    taskId: string;
    employeeId: string;
    type: ContextEntryType;
    content: string;
    tags?: string[];
  }): ContextEntry {
    return this.addEntry(
      {
        projectId: input.projectId,
        type: input.type,
        content: input.content,
        sourceEmployeeId: input.employeeId,
        taskId: input.taskId,
        tags: input.tags,
      },
      { taskId: input.taskId, employeeId: input.employeeId },
    );
  }

  listEvents(): ContextEvent[] {
    return this.events.map((e) => ({ ...e }));
  }

  private emit(
    type: ContextEventType,
    projectId: string,
    taskId: string | null,
    employeeId: string | null,
    message: string,
  ): void {
    this.events.push({
      id: `cevt_${++eventSeq}`,
      type,
      projectId,
      taskId,
      employeeId,
      message,
      createdAt: new Date(this.now()).toISOString(),
    });
    if (this.events.length > this.maxEvents) {
      this.events.splice(0, this.events.length - this.maxEvents);
    }
  }
}

function formatPromptBlock(entries: ContextEntry[], maxChars: number): string {
  if (entries.length === 0) return "";
  const lines: string[] = ["PROJECT CONTEXT (recent, bounded):"];
  let used = lines[0]!.length;
  for (const e of entries) {
    const line = `- [${e.type}] ${e.content.slice(0, 400)}${e.sourceEmployeeId ? ` (${e.sourceEmployeeId})` : ""}`;
    if (used + line.length + 1 > maxChars) break;
    lines.push(line);
    used += line.length + 1;
  }
  return lines.join("\n");
}
