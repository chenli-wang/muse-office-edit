/**
 * Long-term project knowledge types (Phase 13).
 */

export type KnowledgeType =
  | "architecture"
  | "decision"
  | "lesson"
  | "convention"
  | "finding"
  | "known_issue"
  | "project_fact"
  | "agent_insight";

export type KnowledgeStatus = "active" | "superseded" | "invalidated";

export type KnowledgeProvenance =
  | "user"
  | "gpt"
  | "claude"
  | "gemini"
  | "grok"
  | "qa"
  | "project_execution"
  | "collaboration"
  | "system";

export interface KnowledgeItem {
  id: string;
  projectId: string;
  type: KnowledgeType;
  title: string;
  content: string;
  provenance: KnowledgeProvenance;
  sourceEmployeeId: string | null;
  confidence: "low" | "medium" | "high";
  status: KnowledgeStatus;
  tags: string[];
  /** Id of item this supersedes (if any). */
  supersedesId: string | null;
  /** Id of item that superseded this (if superseded). */
  supersededById: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface KnowledgeQuery {
  projectId: string;
  type?: KnowledgeType;
  status?: KnowledgeStatus;
  tags?: string[];
  search?: string;
  limit?: number;
}

export interface KnowledgeLimits {
  maxItemsPerProject: number;
  maxTitleLength: number;
  maxContentLength: number;
  maxTags: number;
  maxQueryResults: number;
  maxContextChars: number;
}

export const DEFAULT_KNOWLEDGE_LIMITS: KnowledgeLimits = {
  maxItemsPerProject: 500,
  maxTitleLength: 160,
  maxContentLength: 4_000,
  maxTags: 12,
  maxQueryResults: 20,
  maxContextChars: 3_000,
};

export class KnowledgeError extends Error {
  readonly code:
    | "NOT_FOUND"
    | "LIMIT"
    | "INVALID"
    | "PERMISSION"
    | "ISOLATION"
    | "CORRUPT"
    | "CONFLICT";

  constructor(code: KnowledgeError["code"], message: string) {
    super(message);
    this.name = "KnowledgeError";
    this.code = code;
  }
}

export function sanitizeKnowledgeText(raw: string, maxLen: number): string {
  let text = String(raw ?? "");
  text = text
    .replace(/Bearer\s+[A-Za-z0-9._\-]+/gi, "Bearer [REDACTED]")
    .replace(/\b(sk|xai|AIza)[-_A-Za-z0-9]{8,}/g, "[REDACTED_KEY]")
    .replace(/secret-api-key-[A-Za-z0-9\-]+/gi, "[REDACTED_KEY]")
    .replace(/api[_-]?key["\s:=]+[A-Za-z0-9._\-]+/gi, "api_key=[REDACTED]")
    .replace(/\/home\/[^\s"']+/g, "[PATH]")
    .replace(/\/Users\/[^\s"']+/g, "[PATH]");
  if (text.length > maxLen) text = `${text.slice(0, maxLen - 1)}…`;
  return text;
}

export function isKnowledgeType(v: string): v is KnowledgeType {
  return [
    "architecture",
    "decision",
    "lesson",
    "convention",
    "finding",
    "known_issue",
    "project_fact",
    "agent_insight",
  ].includes(v);
}

export function isProvenance(v: string): v is KnowledgeProvenance {
  return [
    "user",
    "gpt",
    "claude",
    "gemini",
    "grok",
    "qa",
    "project_execution",
    "collaboration",
    "system",
  ].includes(v);
}
