/**
 * Persistent KnowledgeStore — JSON file per project under a knowledge root.
 * Provider-neutral; survives process restart.
 */

import {
  existsSync,
  mkdirSync,
  readFileSync,
  writeFileSync,
  renameSync,
  unlinkSync,
  readdirSync,
} from "node:fs";
import { join, basename } from "node:path";
import { randomUUID } from "node:crypto";
import {
  type KnowledgeItem,
  type KnowledgeQuery,
  type KnowledgeLimits,
  type KnowledgeType,
  type KnowledgeProvenance,
  type KnowledgeStatus,
  DEFAULT_KNOWLEDGE_LIMITS,
  KnowledgeError,
  sanitizeKnowledgeText,
  isKnowledgeType,
  isProvenance,
} from "./knowledge-types.ts";

export interface KnowledgeStore {
  add(input: AddKnowledgeInput): KnowledgeItem;
  get(projectId: string, id: string): KnowledgeItem | undefined;
  update(
    projectId: string,
    id: string,
    patch: Partial<Pick<KnowledgeItem, "title" | "content" | "tags" | "confidence">>,
  ): KnowledgeItem;
  supersede(
    projectId: string,
    oldId: string,
    input: Omit<AddKnowledgeInput, "projectId">,
  ): KnowledgeItem;
  invalidate(projectId: string, id: string): KnowledgeItem;
  query(q: KnowledgeQuery): KnowledgeItem[];
  list(projectId: string): KnowledgeItem[];
}

export interface AddKnowledgeInput {
  projectId: string;
  type: KnowledgeType;
  title: string;
  content: string;
  provenance: KnowledgeProvenance;
  sourceEmployeeId?: string | null;
  confidence?: "low" | "medium" | "high";
  tags?: string[];
}

interface ProjectFile {
  version: 1;
  projectId: string;
  items: KnowledgeItem[];
}

function safeProjectFileName(projectId: string): string {
  const id = String(projectId ?? "")
    .replace(/[^a-zA-Z0-9._-]/g, "_")
    .slice(0, 80);
  if (!id || id === "." || id === "..") {
    throw new KnowledgeError("INVALID", "Invalid projectId");
  }
  if (id.includes("..") || id.includes("/") || id.includes("\\")) {
    throw new KnowledgeError("ISOLATION", "Path traversal rejected");
  }
  return `${id}.json`;
}

export class FileKnowledgeStore implements KnowledgeStore {
  private readonly root: string;
  private readonly limits: KnowledgeLimits;
  private readonly now: () => number;
  /** In-memory cache; reloaded from disk on construction and after writes. */
  private cache = new Map<string, KnowledgeItem[]>();

  constructor(options: {
    root: string;
    limits?: Partial<KnowledgeLimits>;
    now?: () => number;
  }) {
    this.root = options.root;
    this.limits = { ...DEFAULT_KNOWLEDGE_LIMITS, ...options.limits };
    this.now = options.now ?? (() => Date.now());
    if (!existsSync(this.root)) {
      mkdirSync(this.root, { recursive: true });
    }
  }

  add(input: AddKnowledgeInput): KnowledgeItem {
    const projectId = this.assertProjectId(input.projectId);
    const items = this.load(projectId);
    if (items.length >= this.limits.maxItemsPerProject) {
      throw new KnowledgeError("LIMIT", "Max knowledge items for project");
    }
    const item = this.buildItem(projectId, input);
    items.push(item);
    this.save(projectId, items);
    return { ...item, tags: [...item.tags] };
  }

  get(projectId: string, id: string): KnowledgeItem | undefined {
    const pid = this.assertProjectId(projectId);
    const item = this.load(pid).find((i) => i.id === id);
    return item ? { ...item, tags: [...item.tags] } : undefined;
  }

  update(
    projectId: string,
    id: string,
    patch: Partial<Pick<KnowledgeItem, "title" | "content" | "tags" | "confidence">>,
  ): KnowledgeItem {
    const pid = this.assertProjectId(projectId);
    const items = this.load(pid);
    const idx = items.findIndex((i) => i.id === id);
    if (idx < 0) throw new KnowledgeError("NOT_FOUND", "Knowledge item not found");
    const cur = items[idx]!;
    if (cur.status !== "active") {
      throw new KnowledgeError("INVALID", `Cannot update ${cur.status} item`);
    }
    const next: KnowledgeItem = {
      ...cur,
      title:
        patch.title !== undefined
          ? sanitizeKnowledgeText(patch.title, this.limits.maxTitleLength)
          : cur.title,
      content:
        patch.content !== undefined
          ? sanitizeKnowledgeText(patch.content, this.limits.maxContentLength)
          : cur.content,
      tags: patch.tags
        ? patch.tags.map((t) => sanitizeKnowledgeText(t, 40)).slice(0, this.limits.maxTags)
        : cur.tags,
      confidence: patch.confidence ?? cur.confidence,
      updatedAt: new Date(this.now()).toISOString(),
    };
    items[idx] = next;
    this.save(pid, items);
    return { ...next, tags: [...next.tags] };
  }

  supersede(
    projectId: string,
    oldId: string,
    input: Omit<AddKnowledgeInput, "projectId">,
  ): KnowledgeItem {
    const pid = this.assertProjectId(projectId);
    const items = this.load(pid);
    const old = items.find((i) => i.id === oldId);
    if (!old) throw new KnowledgeError("NOT_FOUND", "Knowledge item not found");
    if (old.status !== "active") {
      throw new KnowledgeError("INVALID", "Only active items can be superseded");
    }
    if (items.length >= this.limits.maxItemsPerProject) {
      throw new KnowledgeError("LIMIT", "Max knowledge items for project");
    }
    const newer = this.buildItem(pid, { ...input, projectId: pid });
    newer.supersedesId = oldId;
    old.status = "superseded";
    old.supersededById = newer.id;
    old.updatedAt = newer.createdAt;
    items.push(newer);
    this.save(pid, items);
    return { ...newer, tags: [...newer.tags] };
  }

  invalidate(projectId: string, id: string): KnowledgeItem {
    const pid = this.assertProjectId(projectId);
    const items = this.load(pid);
    const item = items.find((i) => i.id === id);
    if (!item) throw new KnowledgeError("NOT_FOUND", "Knowledge item not found");
    item.status = "invalidated";
    item.updatedAt = new Date(this.now()).toISOString();
    this.save(pid, items);
    return { ...item, tags: [...item.tags] };
  }

  query(q: KnowledgeQuery): KnowledgeItem[] {
    const pid = this.assertProjectId(q.projectId);
    let items = this.load(pid).filter((i) => i.status === (q.status ?? "active"));
    if (q.type) items = items.filter((i) => i.type === q.type);
    if (q.tags?.length) {
      const tags = new Set(q.tags.map((t) => t.toLowerCase()));
      items = items.filter((i) => i.tags.some((t) => tags.has(t.toLowerCase())));
    }
    if (q.search?.trim()) {
      const s = q.search.trim().toLowerCase();
      items = items
        .map((i) => ({
          item: i,
          score: rank(i, s),
        }))
        .filter((r) => r.score > 0)
        .sort((a, b) => b.score - a.score || b.item.updatedAt.localeCompare(a.item.updatedAt))
        .map((r) => r.item);
    } else {
      items = [...items].sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
    }
    const limit = Math.min(q.limit ?? this.limits.maxQueryResults, this.limits.maxQueryResults);
    return items.slice(0, limit).map((i) => ({ ...i, tags: [...i.tags] }));
  }

  list(projectId: string): KnowledgeItem[] {
    return this.query({ projectId, status: "active", limit: this.limits.maxQueryResults });
  }

  /** Force reload from disk (for tests / multi-process). */
  reload(): void {
    this.cache.clear();
  }

  private buildItem(projectId: string, input: AddKnowledgeInput): KnowledgeItem {
    if (!isKnowledgeType(input.type)) {
      throw new KnowledgeError("INVALID", "Invalid knowledge type");
    }
    if (!isProvenance(input.provenance)) {
      throw new KnowledgeError("INVALID", "Invalid provenance");
    }
    const title = sanitizeKnowledgeText(input.title, this.limits.maxTitleLength);
    const content = sanitizeKnowledgeText(input.content, this.limits.maxContentLength);
    if (!title.trim() || !content.trim()) {
      throw new KnowledgeError("INVALID", "Title and content are required");
    }
    const ts = new Date(this.now()).toISOString();
    return {
      id: `k_${randomUUID()}`,
      projectId,
      type: input.type,
      title,
      content,
      provenance: input.provenance,
      sourceEmployeeId: input.sourceEmployeeId ?? null,
      confidence: input.confidence ?? "medium",
      status: "active",
      tags: (input.tags ?? [])
        .map((t) => sanitizeKnowledgeText(String(t), 40))
        .filter(Boolean)
        .slice(0, this.limits.maxTags),
      supersedesId: null,
      supersededById: null,
      createdAt: ts,
      updatedAt: ts,
    };
  }

  private assertProjectId(projectId: string): string {
    const id = String(projectId ?? "").trim();
    if (!id) throw new KnowledgeError("INVALID", "projectId required");
    safeProjectFileName(id); // path check
    return id;
  }

  private filePath(projectId: string): string {
    return join(this.root, safeProjectFileName(projectId));
  }

  private load(projectId: string): KnowledgeItem[] {
    if (this.cache.has(projectId)) {
      return this.cache.get(projectId)!;
    }
    const path = this.filePath(projectId);
    if (!existsSync(path)) {
      this.cache.set(projectId, []);
      return this.cache.get(projectId)!;
    }
    try {
      const raw = readFileSync(path, "utf8");
      const data = JSON.parse(raw) as ProjectFile;
      if (data.version !== 1 || data.projectId !== projectId || !Array.isArray(data.items)) {
        throw new Error("shape mismatch");
      }
      // Isolation: drop items that claim wrong projectId
      const items = data.items.filter(
        (i) => i && i.projectId === projectId && typeof i.id === "string",
      );
      this.cache.set(projectId, items);
      return items;
    } catch {
      // Corrupt file: quarantine and start empty
      try {
        const bad = `${path}.corrupt.${Date.now()}`;
        renameSync(path, bad);
      } catch {
        try {
          unlinkSync(path);
        } catch {
          /* ignore */
        }
      }
      this.cache.set(projectId, []);
      return this.cache.get(projectId)!;
    }
  }

  private save(projectId: string, items: KnowledgeItem[]): void {
    const path = this.filePath(projectId);
    const payload: ProjectFile = { version: 1, projectId, items };
    const tmp = `${path}.${process.pid}.${Date.now()}.tmp`;
    writeFileSync(tmp, JSON.stringify(payload, null, 2), "utf8");
    renameSync(tmp, path);
    this.cache.set(projectId, items);
  }
}

function rank(item: KnowledgeItem, search: string): number {
  let score = 0;
  const title = item.title.toLowerCase();
  const content = item.content.toLowerCase();
  if (title === search) score += 100;
  if (title.includes(search)) score += 40;
  if (content.includes(search)) score += 10;
  for (const t of item.tags) {
    if (t.toLowerCase().includes(search)) score += 15;
  }
  if (item.type.includes(search)) score += 5;
  return score;
}

/** In-memory store for tests that do not need disk. */
export class InMemoryKnowledgeStore implements KnowledgeStore {
  private readonly inner: FileKnowledgeStore;
  constructor(limits?: Partial<KnowledgeLimits>, now?: () => number) {
    const root = join(
      process.cwd(),
      ".ell-knowledge-mem",
      `t_${process.pid}_${Date.now()}`,
    );
    this.inner = new FileKnowledgeStore({ root, limits, now });
  }
  add(input: AddKnowledgeInput) {
    return this.inner.add(input);
  }
  get(projectId: string, id: string) {
    return this.inner.get(projectId, id);
  }
  update(
    projectId: string,
    id: string,
    patch: Partial<Pick<KnowledgeItem, "title" | "content" | "tags" | "confidence">>,
  ) {
    return this.inner.update(projectId, id, patch);
  }
  supersede(
    projectId: string,
    oldId: string,
    input: Omit<AddKnowledgeInput, "projectId">,
  ) {
    return this.inner.supersede(projectId, oldId, input);
  }
  invalidate(projectId: string, id: string) {
    return this.inner.invalidate(projectId, id);
  }
  query(q: KnowledgeQuery) {
    return this.inner.query(q);
  }
  list(projectId: string) {
    return this.inner.list(projectId);
  }
}
