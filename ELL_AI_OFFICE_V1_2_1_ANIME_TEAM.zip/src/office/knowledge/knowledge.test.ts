import assert from "node:assert/strict";
import { describe, it, beforeEach, afterEach } from "node:test";
import { mkdtempSync, rmSync, writeFileSync, existsSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { FileKnowledgeStore } from "./knowledge-store.ts";
import { KnowledgeManager } from "./knowledge-manager.ts";
import { KnowledgeError, sanitizeKnowledgeText } from "./knowledge-types.ts";
import { ToolRegistry } from "../tools/tool-registry.ts";
import { registerKnowledgeTools } from "./knowledge-tools.ts";
import { createOfficeRuntime } from "../runtime.ts";

describe("KnowledgeStore persistence", () => {
  let root: string;

  beforeEach(() => {
    root = mkdtempSync(join(tmpdir(), "ell-know-"));
  });
  afterEach(() => rmSync(root, { recursive: true, force: true }));

  it("persists across process restart (new store instance)", () => {
    const s1 = new FileKnowledgeStore({ root });
    const item = s1.add({
      projectId: "p1",
      type: "decision",
      title: "Use SSE",
      content: "Prefer SSE for dashboard events",
      provenance: "gpt",
      tags: ["dashboard"],
    });
    // new instance = "restart"
    const s2 = new FileKnowledgeStore({ root });
    const got = s2.get("p1", item.id);
    assert.ok(got);
    assert.equal(got.title, "Use SSE");
    assert.equal(got.projectId, "p1");
  });

  it("project isolation", () => {
    const s = new FileKnowledgeStore({ root });
    s.add({
      projectId: "alpha",
      type: "finding",
      title: "A",
      content: "only alpha",
      provenance: "claude",
    });
    s.add({
      projectId: "beta",
      type: "finding",
      title: "B",
      content: "only beta",
      provenance: "claude",
    });
    assert.equal(s.list("alpha").length, 1);
    assert.equal(s.list("alpha")[0]?.content, "only alpha");
    assert.equal(s.list("beta")[0]?.content, "only beta");
    assert.equal(s.get("alpha", s.list("beta")[0]!.id), undefined);
  });

  it("CRUD + search + filter", () => {
    const s = new FileKnowledgeStore({ root });
    const a = s.add({
      projectId: "p",
      type: "architecture",
      title: "Hexagonal layout",
      content: "Ports and adapters",
      provenance: "user",
      tags: ["arch"],
    });
    s.update("p", a.id, { content: "Ports and adapters refined" });
    const found = s.query({ projectId: "p", search: "hexagonal" });
    assert.equal(found.length, 1);
    const byType = s.query({ projectId: "p", type: "architecture" });
    assert.equal(byType.length, 1);
  });

  it("supersession keeps history", () => {
    const s = new FileKnowledgeStore({ root });
    const old = s.add({
      projectId: "p",
      type: "decision",
      title: "Poll",
      content: "Use polling",
      provenance: "claude",
    });
    const newer = s.supersede("p", old.id, {
      type: "decision",
      title: "SSE",
      content: "Use SSE instead",
      provenance: "gpt",
    });
    assert.equal(s.get("p", old.id)?.status, "superseded");
    assert.equal(s.get("p", old.id)?.supersededById, newer.id);
    assert.equal(newer.supersedesId, old.id);
    assert.equal(s.list("p").length, 1); // active only
  });

  it("invalidation", () => {
    const s = new FileKnowledgeStore({ root });
    const item = s.add({
      projectId: "p",
      type: "known_issue",
      title: "Bug",
      content: "flaky test",
      provenance: "qa",
    });
    s.invalidate("p", item.id);
    assert.equal(s.get("p", item.id)?.status, "invalidated");
    assert.equal(s.list("p").length, 0);
  });

  it("secret sanitization on write", () => {
    const s = new FileKnowledgeStore({ root });
    const item = s.add({
      projectId: "p",
      type: "project_fact",
      title: "Key note",
      content: "never store secret-api-key-123 or Bearer tok_abc",
      provenance: "system",
    });
    assert.equal(item.content.includes("secret-api-key-123"), false);
  });

  it("rejects path traversal projectId", () => {
    const s = new FileKnowledgeStore({ root });
    assert.throws(
      () =>
        s.add({
          projectId: "../escape",
          type: "finding",
          title: "x",
          content: "y",
          provenance: "user",
        }),
      KnowledgeError,
    );
  });

  it("corrupted persistence recovers empty", () => {
    const s1 = new FileKnowledgeStore({ root });
    s1.add({
      projectId: "p",
      type: "lesson",
      title: "L",
      content: "learn",
      provenance: "system",
    });
    const file = join(root, "p.json");
    writeFileSync(file, "{not-json", "utf8");
    const s2 = new FileKnowledgeStore({ root });
    assert.equal(s2.list("p").length, 0);
  });

  it("bounded query results", () => {
    const s = new FileKnowledgeStore({
      root,
      limits: { maxQueryResults: 3 },
    });
    for (let i = 0; i < 10; i++) {
      s.add({
        projectId: "p",
        type: "finding",
        title: `T${i}`,
        content: `c${i}`,
        provenance: "system",
      });
    }
    assert.equal(s.query({ projectId: "p", limit: 100 }).length, 3);
  });
});

describe("KnowledgeManager", () => {
  let root: string;
  let mgr: KnowledgeManager;

  beforeEach(() => {
    root = mkdtempSync(join(tmpdir(), "ell-km-"));
    mgr = new KnowledgeManager({
      store: new FileKnowledgeStore({ root }),
    });
  });
  afterEach(() => rmSync(root, { recursive: true, force: true }));

  it("prompt block is bounded and deterministic", () => {
    mgr.add({
      projectId: "p",
      type: "convention",
      title: "Lint",
      content: "Always run lint",
      provenance: "user",
    });
    const a = mgr.buildPromptBlock("p");
    const b = mgr.buildPromptBlock("p");
    assert.equal(a, b);
    assert.match(a, /PROJECT KNOWLEDGE/);
  });

  it("events emitted", () => {
    const item = mgr.add({
      projectId: "p",
      type: "decision",
      title: "D",
      content: "Decide",
      provenance: "collaboration",
    });
    mgr.invalidate("p", item.id);
    const types = mgr.listEvents().map((e) => e.type);
    assert.ok(types.includes("knowledge.created"));
    assert.ok(types.includes("knowledge.invalidated"));
  });
});

describe("Knowledge tools permissions", () => {
  let root: string;
  let reg: ToolRegistry;

  beforeEach(() => {
    root = mkdtempSync(join(tmpdir(), "ell-kt-"));
    const mgr = new KnowledgeManager({
      store: new FileKnowledgeStore({ root }),
    });
    reg = new ToolRegistry();
    registerKnowledgeTools(reg, mgr, "default");
  });
  afterEach(() => rmSync(root, { recursive: true, force: true }));

  it("gemini cannot write knowledge", async () => {
    const r = await reg.invoke(
      "knowledge.add",
      {
        type: "finding",
        title: "x",
        content: "y",
      },
      { employeeId: "gemini" },
    );
    assert.equal(r.ok, false);
  });

  it("claude can write knowledge", async () => {
    const r = await reg.invoke(
      "knowledge.add",
      {
        type: "finding",
        title: "Valid",
        content: "from claude",
      },
      { employeeId: "claude" },
    );
    assert.equal(r.ok, true);
  });

  it("all can list/search", async () => {
    await reg.invoke(
      "knowledge.add",
      { type: "project_fact", title: "F", content: "fact" },
      { employeeId: "claude" },
    );
    const list = await reg.invoke("knowledge.list", {}, { employeeId: "gemini" });
    assert.equal(list.ok, true);
  });
});

describe("Runtime knowledge integration", () => {
  let root: string;
  beforeEach(() => {
    root = mkdtempSync(join(tmpdir(), "ell-rk-"));
  });
  afterEach(() => rmSync(root, { recursive: true, force: true }));

  it("runtime exposes knowledge tools and Phase 6 memory coexists", () => {
    const rt = createOfficeRuntime({
      workspaceRoot: root,
      projectId: "demo",
    });
    const names = rt.listTools().map((t) => t.name);
    assert.ok(names.includes("knowledge.add"));
    assert.ok(names.includes("knowledge.search"));
    rt.addProjectContext({
      type: "note",
      content: "short-term note",
      tags: ["phase6"],
    });
    rt.addKnowledge({
      type: "decision",
      title: "Long-term",
      content: "durable decision",
      provenance: "user",
    });
    const snap = rt.getProjectContextSnapshot();
    assert.ok(snap.entries.some((e) => e.content.includes("short-term")));
    const block = rt.buildKnowledgePromptBlock();
    assert.match(block, /Long-term|durable/);
  });

  it("sanitize helper strips secrets", () => {
    assert.equal(
      sanitizeKnowledgeText("Bearer abc secret-api-key-9", 100).includes("secret-api-key"),
      false,
    );
  });
});
