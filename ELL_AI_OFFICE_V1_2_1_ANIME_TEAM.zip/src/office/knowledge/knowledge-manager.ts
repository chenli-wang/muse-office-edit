/**
 * KnowledgeManager — façade over KnowledgeStore + events + prompt blocks.
 */

import { randomUUID } from "node:crypto";
import type { KnowledgeStore, AddKnowledgeInput } from "./knowledge-store.ts";
import type {
  KnowledgeItem,
  KnowledgeQuery,
  KnowledgeLimits,
} from "./knowledge-types.ts";
import { DEFAULT_KNOWLEDGE_LIMITS, sanitizeKnowledgeText } from "./knowledge-types.ts";

export type KnowledgeEventType =
  | "knowledge.created"
  | "knowledge.updated"
  | "knowledge.superseded"
  | "knowledge.invalidated"
  | "knowledge.retrieved";

export interface KnowledgeEvent {
  id: string;
  type: KnowledgeEventType;
  projectId: string;
  knowledgeId: string | null;
  message: string;
  createdAt: string;
}

export class KnowledgeManager {
  private readonly store: KnowledgeStore;
  private readonly limits: KnowledgeLimits;
  private readonly now: () => number;
  private readonly events: KnowledgeEvent[] = [];
  private readonly maxEvents = 300;

  constructor(options: {
    store: KnowledgeStore;
    limits?: Partial<KnowledgeLimits>;
    now?: () => number;
  }) {
    this.store = options.store;
    this.limits = { ...DEFAULT_KNOWLEDGE_LIMITS, ...options.limits };
    this.now = options.now ?? (() => Date.now());
  }

  add(input: AddKnowledgeInput): KnowledgeItem {
    const item = this.store.add(input);
    this.emit("knowledge.created", item.projectId, item.id, `${item.type}: ${item.title}`);
    return item;
  }

  get(projectId: string, id: string): KnowledgeItem | undefined {
    const item = this.store.get(projectId, id);
    if (item) {
      this.emit("knowledge.retrieved", projectId, id, `get ${id}`);
    }
    return item;
  }

  update(
    projectId: string,
    id: string,
    patch: Partial<Pick<KnowledgeItem, "title" | "content" | "tags" | "confidence">>,
  ): KnowledgeItem {
    const item = this.store.update(projectId, id, patch);
    this.emit("knowledge.updated", projectId, id, `updated ${item.title}`);
    return item;
  }

  supersede(
    projectId: string,
    oldId: string,
    input: Omit<AddKnowledgeInput, "projectId">,
  ): KnowledgeItem {
    const item = this.store.supersede(projectId, oldId, input);
    this.emit(
      "knowledge.superseded",
      projectId,
      item.id,
      `superseded ${oldId} → ${item.id}`,
    );
    return item;
  }

  invalidate(projectId: string, id: string): KnowledgeItem {
    const item = this.store.invalidate(projectId, id);
    this.emit("knowledge.invalidated", projectId, id, `invalidated ${id}`);
    return item;
  }

  query(q: KnowledgeQuery): KnowledgeItem[] {
    const items = this.store.query(q);
    this.emit(
      "knowledge.retrieved",
      q.projectId,
      null,
      `query returned ${items.length}`,
    );
    return items;
  }

  list(projectId: string): KnowledgeItem[] {
    return this.store.list(projectId);
  }

  /**
   * Bounded PROJECT KNOWLEDGE block for agent prompts.
   * Coexists with Phase 6 short-term context — does not replace it.
   */
  buildPromptBlock(projectId: string, limit = 8): string {
    const items = this.store.query({
      projectId,
      status: "active",
      limit,
    });
    if (items.length === 0) return "";
    const lines = ["PROJECT KNOWLEDGE (long-term, bounded):"];
    let used = lines[0]!.length;
    for (const item of items) {
      const line = `- [${item.type}/${item.confidence}] ${item.title}: ${item.content.slice(0, 220)}`;
      if (used + line.length + 1 > this.limits.maxContextChars) break;
      lines.push(line);
      used += line.length + 1;
    }
    return sanitizeKnowledgeText(lines.join("\n"), this.limits.maxContextChars);
  }

  listEvents(): KnowledgeEvent[] {
    return this.events.map((e) => ({ ...e }));
  }

  private emit(
    type: KnowledgeEventType,
    projectId: string,
    knowledgeId: string | null,
    message: string,
  ): void {
    this.events.push({
      id: `kevt_${randomUUID()}`,
      type,
      projectId,
      knowledgeId,
      message: sanitizeKnowledgeText(message, 300),
      createdAt: new Date(this.now()).toISOString(),
    });
    if (this.events.length > this.maxEvents) {
      this.events.splice(0, this.events.length - this.maxEvents);
    }
  }
}
