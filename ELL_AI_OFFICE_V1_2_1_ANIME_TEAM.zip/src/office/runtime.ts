import { randomUUID } from "node:crypto";
import { CLAUDE_ID, createEmployeeRoster, createMultiAgentRoster, publicEmployee } from "./employees.ts";
import { ConflictError, NotFoundError, ProviderError, ValidationError } from "./errors.ts";
import {
  listProviderRecords,
  MOCK_MODEL_ID,
  MockProvider,
  type ProviderAdapter,
} from "./providers.ts";
import { createProviderRegistry, type ProviderRegistry } from "./provider-registry.ts";
import { sanitizePublicErrorMessage } from "./provider-router.ts";
import { MultiAgentOrchestrator } from "./multi-agent-orchestrator.ts";
import { resolveEmployeeBindings, bindingFor } from "./employee-bindings.ts";
import { AgentExecutor, type AgentTask } from "./agent-executor.ts";
import { loadEllConfig, bindingModeFromConfig } from "./config/ell-config.ts";
import {
  ToolRegistry,
  WorkspaceScope,
  registerProjectTools,
  registerExecutionTools,
  createProjectExecutionServices,
  type ToolInvokeResult,
} from "./tools/index.ts";
import { QAEngine } from "./qa/qa-engine.ts";
import { registerQATools } from "./qa/qa-tools.ts";
import { ContextManager } from "./memory/context-manager.ts";
import { CollaborationManager } from "./collaboration/collaboration-manager.ts";
import { FileKnowledgeStore } from "./knowledge/knowledge-store.ts";
import { KnowledgeManager } from "./knowledge/knowledge-manager.ts";
import { registerKnowledgeTools } from "./knowledge/knowledge-tools.ts";
import { join } from "node:path";
import type { ContextEntry, ContextEntryType } from "./memory/project-context-store.ts";
import type {
  AgentOutput,
  Employee,
  FinalResult,
  OfficeEvent,
  OfficeEventType,
  OfficeSnapshot,
  ProviderRecord,
  ProviderStatus,
  Task,
  TaskPlan,
  TaskStatus,
} from "./types.ts";
import type {
  KnowledgeType,
  KnowledgeProvenance,
  KnowledgeItem,
} from "./knowledge/knowledge-types.ts";

export interface OfficeDelays {
  planningMs: number;
  assignMs: number;
  workMs: number;
  synthMs: number;
}

export interface OfficeConfig {
  now?: () => number;
  delays?: Partial<OfficeDelays>;
  /** Primary provider used for generation. Defaults to MockProvider. */
  provider?: ProviderAdapter;
  /**
   * Optional registry for multi-provider listing.
   * When omitted, a registry is built with the primary provider + auto-detect xAI.
   * Tests that pass only `provider` keep single-adapter behaviour.
   */
  registry?: ProviderRegistry;
  /** Project workspace root for tools (Phase 5). Defaults to ./workspace under cwd. */
  workspaceRoot?: string;
  /** Project id for shared memory isolation (Phase 6). */
  projectId?: string;
  contextManager?: ContextManager;
}

interface InternalTask extends Task {
  routingConstraints?: {
    preferredProviderId?: string;
    executionMode?: "mock" | "live";
    costMode?: "FREE_ONLY" | "FREE_FIRST" | "PAID";
    allowedProviderIds?: string[];
    maxAttempts?: number;
  };
  planningDueAt: number;
  assignedDueAt: number;
  runningDueAt: number;
  workDueAt: number;
  synthDueAt: number;
  workStarted: boolean;
  /** Abort controller for the in-flight provider call (cancellation support). */
  abortController: AbortController | null;
}

const TERMINAL: ReadonlySet<TaskStatus> = new Set([
  "completed",
  "failed",
  "cancelled",
]);

const DEFAULT_DELAYS: OfficeDelays = {
  planningMs: 90,
  assignMs: 90,
  workMs: 900,
  synthMs: 140,
};

const MAX_OBJECTIVE = 8000;
const MAX_EVENTS = 400;
const MAX_TASKS = 80;

function clone<T>(value: T): T {
  return structuredClone(value);
}

function titleFrom(objective: string): string {
  const oneLine = objective.replace(/\s+/g, " ").trim();
  return oneLine.length <= 72 ? oneLine : `${oneLine.slice(0, 69).trimEnd()}…`;
}

function iso(ms: number): string {
  return new Date(ms).toISOString();
}

export interface OfficeRuntime {
  createTask(input: {
    objective: string;
    simulateError?: boolean;
    mode?: "single" | "multi";
    /** Manager routing constraints (Phase 14 hardening). */
    routing?: {
      preferredProviderId?: string;
      executionMode?: "mock" | "live";
      costMode?: "FREE_ONLY" | "FREE_FIRST" | "PAID";
      allowedProviderIds?: string[];
      maxAttempts?: number;
    };
  }): Promise<Task>;
  getTask(id: string): Promise<Task>;
  listTasks(): Promise<Task[]>;
  cancelTask(id: string): Promise<Task>;
  listAgents(): Promise<Employee[]>;
  getAgent(id: string): Promise<Employee>;
  listProviders(): Promise<ProviderStatus[]>;
  listEvents(since?: string): Promise<OfficeEvent[]>;
  snapshot(): Promise<OfficeSnapshot>;
  tick(): Promise<void>;
  reset(): void;
  listTools(): ReturnType<ToolRegistry["list"]>;
  invokeTool(
    name: string,
    input: unknown,
    ctx?: { taskId?: string; employeeId?: string },
  ): Promise<ToolInvokeResult>;
  getWorkspaceId(): string;
  getContextManager(): ContextManager;
  getProjectContextSnapshot(limit?: number): ReturnType<ContextManager["snapshotForTask"]>;
  addProjectContext(input: {
    type: ContextEntryType;
    content: string;
    taskId?: string;
    employeeId?: string;
    tags?: string[];
  }): ContextEntry;
  /** Long-term knowledge prompt block for agent context (project-scoped). */
  buildKnowledgePromptBlock(limit?: number): string;
  /** Persist a durable knowledge item for the current project. */
  addKnowledge(input: {
    type: KnowledgeType;
    title: string;
    content: string;
    provenance?: KnowledgeProvenance;
    tags?: string[];
  }): KnowledgeItem;
  /** Search active knowledge items for the current project. */
  searchKnowledge(search: string, limit?: number): KnowledgeItem[];
  /**
   * Private employee chat — single-employee generation via provider router.
   * Uses the selected employee's configured binding; never silently falls back to mock
   * when a live provider was requested and is unavailable.
   */
  privateChat(input: {
    employeeId: string;
    message: string;
  }): Promise<{
    ok: boolean;
    reply?: string;
    unavailable?: boolean;
    error?: string;
    employeeId: string;
    providerId?: string;
    model?: string;
  }>;
}

export function createOfficeRuntime(config: OfficeConfig = {}): OfficeRuntime {
  const delays: OfficeDelays = { ...DEFAULT_DELAYS, ...config.delays };
  const now = config.now ?? (() => Date.now());
  const provider = config.provider ?? new MockProvider();
  const registry =
    config.registry ??
    createProviderRegistry({
      primary: provider,
      // Tests inject MockProvider; avoid auto-detecting live xAI during unit tests
      // unless the caller explicitly provided a registry.
      autoDetectXai: config.provider === undefined && config.registry === undefined,
    });

  const workspaceRoot =
    config.workspaceRoot ??
    `${process.cwd()}/workspace`;
  const workspaceScope = new WorkspaceScope({ root: workspaceRoot });
  const toolRegistry = new ToolRegistry();
  registerProjectTools(toolRegistry, workspaceScope);
  const executionServices = createProjectExecutionServices(workspaceScope);
  registerExecutionTools(toolRegistry, executionServices);
  const qaEngine = new QAEngine({ scope: workspaceScope, now });
  registerQATools(toolRegistry, qaEngine);
  const knowledgeRoot = join(workspaceRoot, ".ell-knowledge");
  const knowledgeStore = new FileKnowledgeStore({ root: knowledgeRoot, now });
  const knowledgeManager = new KnowledgeManager({ store: knowledgeStore, now });
  registerKnowledgeTools(toolRegistry, knowledgeManager, config.projectId ?? "default");
  const contextManager =
    config.contextManager ??
    new ContextManager({
      defaultProjectId: config.projectId ?? "default",
      now,
    });
  contextManager.ensureProject(config.projectId ?? "default");
  const collaborationManager = new CollaborationManager({ now });


  let employees = createEmployeeRoster();
  const tasks = new Map<string, InternalTask>();
  const events: OfficeEvent[] = [];
  const multiOrchestrators = new Map<string, MultiAgentOrchestrator>();

  function emit(
    type: OfficeEventType,
    message: string,
    taskId: string | null = null,
    employeeId: string | null = null,
  ) {
    events.push({
      id: `evt_${randomUUID()}`,
      type,
      taskId,
      employeeId,
      message,
      createdAt: iso(now()),
    });
    if (events.length > MAX_EVENTS) events.splice(0, events.length - MAX_EVENTS);
  }

  function claude(): Employee {
    const row = employees.find((e) => e.id === CLAUDE_ID);
    if (!row) throw new Error("Claude employee missing from roster");
    return row;
  }

  function setClaude(patch: Partial<Employee>) {
    employees = employees.map((e) => (e.id === CLAUDE_ID ? { ...e, ...patch } : e));
  }

  function planFor(objective: string): TaskPlan {
    return {
      strategy: "single-employee",
      employeeId: CLAUDE_ID,
      rationale: `Phase 1 routes analysis work to Claude (Lead Developer) via the ${provider.label}. Objective: ${titleFrom(objective)}`,
    };
  }

  function publicTask(task: InternalTask): Task {
    const {
      planningDueAt: _p,
      assignedDueAt: _a,
      runningDueAt: _r,
      workDueAt: _w,
      synthDueAt: _s,
      workStarted: _ws,
      abortController: _ac,
      ...rest
    } = task;
    void _p;
    void _a;
    void _r;
    void _w;
    void _s;
    void _ws;
    void _ac;
    return clone(rest);
  }

  async function tickOne(task: InternalTask): Promise<void> {
    if (TERMINAL.has(task.status)) return;
    const t = now();

    if (task.status === "created" && t >= task.planningDueAt) {
      task.status = "planning";
      task.updatedAt = iso(t);
      setClaude({
        status: "planning",
        currentTaskId: task.id,
        currentTaskTitle: task.title,
      });
      emit("agent.thinking", `Claude is planning “${task.title}”.`, task.id, CLAUDE_ID);
    }

    if (task.status === "planning" && t >= task.assignedDueAt) {
      task.status = "assigned";
      task.updatedAt = iso(t);
      task.plan = planFor(task.objective);
      task.assignedEmployeeIds = [CLAUDE_ID];
      task.subtasks = [
        {
          id: `sub_${task.id}`,
          employeeId: CLAUDE_ID,
          objective: task.objective,
          status: "assigned",
          expectedOutputFormat: "summary, findings, evidence, risks, recommendations, questions",
          dependencies: [],
          timeoutMs: 20_000,
        },
      ];
      emit("task.assigned", `Assigned to Claude — Lead Developer.`, task.id, CLAUDE_ID);
    }

    if (task.status === "assigned" && t >= task.runningDueAt) {
      task.status = "running";
      task.updatedAt = iso(t);
      if (task.subtasks[0]) task.subtasks[0].status = "running";
      setClaude({
        status: "working",
        currentTaskId: task.id,
        currentTaskTitle: task.title,
      });
      emit("agent.started", `Claude started work on “${task.title}”.`, task.id, CLAUDE_ID);
    }

    if (task.status === "running" && t >= task.workDueAt && !task.workStarted) {
      task.workStarted = true;
      const controller = new AbortController();
      task.abortController = controller;
      const timeoutMs = task.subtasks[0]?.timeoutMs ?? 20_000;
      try {
        const rc = task.routingConstraints;
        const preferred =
          rc?.preferredProviderId ??
          (rc?.executionMode === "live" ? "anthropic" : "mock");
        const isMock = preferred === "mock" || rc?.executionMode !== "live";
        const { response, trace } = await registry.router.executeWithFallback(
          {
            model: isMock ? MOCK_MODEL_ID : MOCK_MODEL_ID,
            systemPrompt: claude().systemPrompt,
            userPrompt: task.objective,
            simulateFailure: task.simulateError,
            timeoutMs,
            signal: controller.signal,
          },
          {
            preferredProviderId: preferred,
            policy: {
              mode: isMock ? "primary-only" : "free-first",
              maxAttempts: rc?.maxAttempts ?? (isMock ? 1 : 3),
              excludeMockInFreeFirst: !isMock,
              allowedProviderIds: rc?.allowedProviderIds,
            },
          },
        );
        void trace;
        task.abortController = null;
        if (wasCancelled(task.status)) return;

        const output = parseOutput(response.text, task.objective, response.provider, response.model);
        task.outputs = [output];
        task.status = "synthesizing";
        task.updatedAt = iso(now());
        if (task.subtasks[0]) task.subtasks[0].status = "synthesizing";
        setClaude({ status: "reviewing", currentTaskId: task.id, currentTaskTitle: task.title });
        emit("agent.completed", "Claude returned a structured result.", task.id, CLAUDE_ID);
      } catch (error) {
        task.abortController = null;
        if (wasCancelled(task.status)) return;
        const providerError =
          error instanceof ProviderError
            ? error
            : new ProviderError(
                "UNKNOWN",
                error instanceof Error ? error.message : "Unknown provider error",
                false,
              );
        task.status = "failed";
        task.updatedAt = iso(now());
        task.error = {
          class: providerError.code,
          message: sanitizePublicErrorMessage(providerError),
          retryable: providerError.retryable,
        };
        if (task.subtasks[0]) task.subtasks[0].status = "failed";
        setClaude({
          status: "error",
          currentTaskId: task.id,
          currentTaskTitle: task.title,
        });
        emit("agent.failed", sanitizePublicErrorMessage(providerError), task.id, CLAUDE_ID);
        emit("task.failed", `Task failed (${providerError.code}).`, task.id, CLAUDE_ID);
      }
    }

    if (task.status === "synthesizing" && now() >= task.synthDueAt) {
      const primary = task.outputs[0];
      task.finalResult = synthesize(primary);
      task.status = "completed";
      task.completedAt = iso(now());
      task.updatedAt = task.completedAt;
      if (task.subtasks[0]) task.subtasks[0].status = "completed";
      setClaude({ status: "idle", currentTaskId: null, currentTaskTitle: null });
      emit("task.completed", "Orchestrator stored the final synthesis.", task.id, CLAUDE_ID);
    }
  }

  async function tick(): Promise<void> {
    for (const task of tasks.values()) {
      await tickOne(task);
    }
  }

  async function createTask(input: { objective: string; simulateError?: boolean; mode?: "single" | "multi"; routing?: { preferredProviderId?: string; executionMode?: "mock" | "live"; costMode?: "FREE_ONLY" | "FREE_FIRST" | "PAID"; allowedProviderIds?: string[]; maxAttempts?: number } }): Promise<Task> {
    const objective = String(input.objective ?? "").trim();
    if (!objective) throw new ValidationError("objective is required");
    if (objective.length > MAX_OBJECTIVE) {
      throw new ValidationError(`objective must be at most ${MAX_OBJECTIVE} characters`);
    }

    if (input.mode === "multi") {
      const execMode = input.routing?.executionMode ?? "mock";
      const bindings = resolveEmployeeBindings(execMode === "live" ? "live" : "mock");
      // FREE_ONLY / allowlist: rewrite bindings to only allowed providers (or mock when mock mode)
      let effectiveBindings = bindings;
      if (input.routing?.allowedProviderIds?.length) {
        const allow = new Set(input.routing.allowedProviderIds);
        effectiveBindings = bindings.map((b) =>
          allow.has(b.providerId)
            ? b
            : execMode === "mock" && allow.has("mock")
              ? { ...b, providerId: "mock", modelId: MOCK_MODEL_ID }
              : b,
        );
      }
      const multiOrch = new MultiAgentOrchestrator({
        employees: createMultiAgentRoster(),
        router: registry.router,
        now,
        modelId: execMode === "mock" ? MOCK_MODEL_ID : (bindings[0]?.modelId ?? MOCK_MODEL_ID),
        bindings: effectiveBindings,
        routingPolicy: {
          allowedProviderIds: input.routing?.allowedProviderIds,
          maxAttempts: input.routing?.maxAttempts,
          mode:
            input.routing?.costMode === "FREE_ONLY" || execMode === "mock"
              ? "primary-only"
              : "free-first",
          excludeMockInFreeFirst: execMode !== "mock",
        },
      });
      // Async: register + start background, return promptly.
      const projectId = config.projectId ?? contextManager.getDefaultProjectId();
      const snapshot = contextManager.snapshotForTask(projectId);
      const multi = multiOrch.create(objective);
      multiOrchestrators.set(multi.id, multiOrch);
      // Attach bounded context into plan rationale surface (already in legacy plan).
      void snapshot;
      const legacy = multiOrch.toLegacyTask(multi);
      const internal: InternalTask = {
        ...legacy,
        planningDueAt: now(),
        assignedDueAt: now(),
        runningDueAt: now(),
        workDueAt: now() + 60_000,
        synthDueAt: now() + 60_000,
        workStarted: true,
        abortController: null,
      };
      tasks.set(legacy.id, internal);
      for (const ev of multiOrch.listEvents()) {
        events.push(ev);
        if (events.length > MAX_EVENTS) events.splice(0, events.length - MAX_EVENTS);
      }
      // Sync legacy task from multi when background finishes (no unhandled rejection).
      void multiOrch.waitFor(multi.id).then((done) => {
        const updated = multiOrch.toLegacyTask(done);
        const row = tasks.get(multi.id);
        if (!row) return;
        Object.assign(row, {
          ...updated,
          planningDueAt: row.planningDueAt,
          assignedDueAt: row.assignedDueAt,
          runningDueAt: row.runningDueAt,
          workDueAt: row.workDueAt,
          synthDueAt: row.synthDueAt,
          workStarted: true,
          abortController: null,
        });
        for (const ev of multiOrch.listEvents()) {
          if (!events.some((e) => e.id === ev.id)) {
            events.push(ev);
          }
        }
        if (events.length > MAX_EVENTS) events.splice(0, events.length - MAX_EVENTS);
        // Explicit structured memory: task summary + parallel findings (not full model dump).
        try {
          if (done.finalResult?.summary) {
            contextManager.addEntry({
              projectId,
              type: "task_summary",
              content: done.finalResult.summary.slice(0, 2000),
              taskId: multi.id,
              tags: ["multi-agent"],
            });
          }
          for (const r of done.results) {
            if (r.status !== "completed" || !r.summary) continue;
            if (r.employeeId === "gpt") continue;
            contextManager.recordAgentContribution({
              projectId,
              taskId: multi.id,
              employeeId: r.employeeId,
              type: "finding",
              content: r.summary.slice(0, 1500),
              tags: [r.employeeId],
            });
          }
          // Explicit collaboration outcomes → memory (not every message)
          for (const ev of collaborationManager.listEvents()) {
            if (ev.type === "collaboration.decision" || ev.type === "collaboration.completed") {
              contextManager.addEntry({
                projectId,
                type: "decision",
                content: ev.message.slice(0, 1000),
                taskId: multi.id,
                tags: ["collaboration"],
              });
              break;
            }
          }
          // Mirror collaboration events into office events (sanitized)
          for (const ev of collaborationManager.listEvents()) {
            events.push({
              id: ev.id,
              type: "task.assigned",
              taskId: ev.taskId,
              employeeId: ev.employeeId,
              message: `${ev.type}: ${ev.message}`.slice(0, 300),
              createdAt: ev.createdAt,
            });
          }
          if (events.length > MAX_EVENTS) events.splice(0, events.length - MAX_EVENTS);
        } catch {
          /* memory write must not fail the task */
        }
      });
      return publicTask(internal);
    }

    const t = now();
    const id = `task_${randomUUID()}`;
    const title = titleFrom(objective);
    const task: InternalTask = {
      id,
      title,
      objective,
      status: "created",
      priority: "normal",
      createdAt: iso(t),
      updatedAt: iso(t),
      completedAt: null,
      cancelledAt: null,
      parentTaskId: null,
      subtasks: [],
      assignedEmployeeIds: [],
      contextRefs: [],
      outputs: [],
      plan: null,
      finalResult: null,
      error: null,
      approvalRequired: false,
      simulateError: Boolean(input.simulateError),
      planningDueAt: t,
      assignedDueAt: t + delays.planningMs,
      runningDueAt: t + delays.planningMs + delays.assignMs,
      workDueAt: t + delays.planningMs + delays.assignMs + delays.workMs,
      synthDueAt: t + delays.planningMs + delays.assignMs + delays.workMs + delays.synthMs,
      workStarted: false,
      abortController: null,
      routingConstraints: input.routing
        ? {
            preferredProviderId: input.routing.preferredProviderId,
            executionMode: input.routing.executionMode,
            costMode: input.routing.costMode,
            allowedProviderIds: input.routing.allowedProviderIds,
            maxAttempts: input.routing.maxAttempts,
          }
        : undefined,
    };

    tasks.set(id, task);
    if (tasks.size > MAX_TASKS) {
      const oldest = [...tasks.values()]
        .filter((row) => TERMINAL.has(row.status))
        .sort((a, b) => a.createdAt.localeCompare(b.createdAt))[0];
      if (oldest) tasks.delete(oldest.id);
    }

    emit("task.created", `Task created: ${title}`, id, null);
    await tickOne(task);
    return publicTask(task);
  }

  async function requireTask(id: string): Promise<InternalTask> {
    await tick();
    const task = tasks.get(id);
    if (!task) throw new NotFoundError("Task not found");
    return task;
  }

  async function cancelTask(id: string): Promise<Task> {
    const task = tasks.get(id);
    if (!task) throw new NotFoundError("Task not found");
    if (task.status === "cancelled") return publicTask(task);
    if (task.status === "completed" || task.status === "failed") {
      throw new ConflictError(`Cannot cancel a ${task.status} task`);
    }
    const multi = multiOrchestrators.get(id);
    if (multi) {
      try {
        const cancelled = await multi.cancel(id);
        const legacy = multi.toLegacyTask(cancelled);
        Object.assign(task, {
          ...legacy,
          planningDueAt: task.planningDueAt,
          assignedDueAt: task.assignedDueAt,
          runningDueAt: task.runningDueAt,
          workDueAt: task.workDueAt,
          synthDueAt: task.synthDueAt,
          workStarted: true,
          abortController: null,
        });
        return publicTask(task);
      } catch (err) {
        if (err instanceof Error && /Cannot cancel/.test(err.message)) {
          throw new ConflictError(err.message);
        }
        throw err;
      }
    }
    const t = now();
    task.status = "cancelled";
    task.cancelledAt = iso(t);
    task.updatedAt = task.cancelledAt;
    if (task.subtasks[0]) task.subtasks[0].status = "cancelled";
    // Propagate cancellation to in-flight provider call when supported.
    if (task.abortController) {
      try {
        task.abortController.abort();
      } catch {
        // ignore
      }
      task.abortController = null;
    }
    if (claude().currentTaskId === task.id) {
      setClaude({ status: "idle", currentTaskId: null, currentTaskTitle: null });
    }
    emit("task.cancelled", "Task cancelled by the user.", task.id, CLAUDE_ID);
    return publicTask(task);
  }

  return {
    createTask,
    async getTask(id: string) {
      const multi = multiOrchestrators.get(id);
      if (multi) {
        const current = multi.getTask(id);
        if (current) {
          const legacy = multi.toLegacyTask(current);
          const row = tasks.get(id);
          if (row) {
            Object.assign(row, {
              ...legacy,
              planningDueAt: row.planningDueAt,
              assignedDueAt: row.assignedDueAt,
              runningDueAt: row.runningDueAt,
              workDueAt: row.workDueAt,
              synthDueAt: row.synthDueAt,
              workStarted: row.workStarted,
              abortController: row.abortController,
            });
          }
        }
      }
      return publicTask(await requireTask(id));
    },
    async listTasks() {
      await tick();
      return [...tasks.values()]
        .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
        .map(publicTask);
    },
    cancelTask,
    async listAgents() {
      await tick();
      return employees.map(publicEmployee);
    },
    async getAgent(id: string) {
      await tick();
      const employee = employees.find((row) => row.id === id);
      if (!employee) throw new NotFoundError("Employee not found");
      return publicEmployee(employee);
    },
    async listProviders() {
      const models = await registry.listModels().catch(() => listProviderRecords("available"));
      const healthRows = registry.listHealth();
      const byProvider = new Map<string, typeof models>();
      for (const model of models) {
        const list = byProvider.get(model.provider) ?? [];
        list.push(model);
        byProvider.set(model.provider, list);
      }
      // Ensure every health entry appears even with zero models (unconfigured).
      const statuses: ProviderStatus[] = healthRows.map((h) => {
        const providerModels = byProvider.get(h.providerId) ?? [];
        // Align model availability with health when present.
        const aligned = providerModels.map((m) => ({
          ...m,
          availability: h.availability,
        }));
        return {
          id: h.providerId,
          label: h.label,
          configured: h.configured,
          availability: h.availability,
          reason: h.reason,
          message: h.message,
          checkedAt: h.checkedAt,
          lastSuccessAt: h.lastSuccessAt,
          lastErrorAt: h.lastErrorAt,
          lastErrorClass: h.lastErrorClass,
          cooldownUntil: h.cooldownUntil,
          availableForRequest: registry.health.isAvailableForRequest(h.providerId),
          models: aligned,
        };
      });
      return statuses;
    },
    async listEvents(since?: string) {
      await tick();
      if (!since) return clone(events);
      const idx = events.findIndex((event) => event.id === since);
      if (idx >= 0) return clone(events.slice(idx + 1));
      const sinceMs = Date.parse(since);
      if (Number.isNaN(sinceMs)) return clone(events);
      return clone(events.filter((event) => Date.parse(event.createdAt) > sinceMs));
    },
    async snapshot() {
      const [agents, listed, listedEvents, providers] = await Promise.all([
        this.listAgents(),
        this.listTasks(),
        this.listEvents(),
        this.listProviders(),
      ]);
      return { agents, tasks: listed, events: listedEvents, providers, mockMode: true as const };
    },
    tick,
    reset() {
      employees = createEmployeeRoster();
      tasks.clear();
      events.length = 0;
      toolRegistry.clearAudits();
    },
    listTools() {
      return toolRegistry.list();
    },
    async invokeTool(name, input, ctx = {}) {
      const result = await toolRegistry.invoke(name, input, {
        taskId: ctx.taskId,
        employeeId: ctx.employeeId,
        now,
      });
      // Mirror tool audit into office events (sanitized).
      events.push({
        id: result.audit.id,
        type: result.ok ? "agent.completed" : "agent.failed",
        taskId: result.audit.taskId,
        employeeId: result.audit.employeeId,
        message: result.ok
          ? `tool ${name} ok`
          : `tool ${name} failed: ${result.error?.message ?? "error"}`,
        createdAt: result.audit.createdAt,
      });
      if (events.length > MAX_EVENTS) events.splice(0, events.length - MAX_EVENTS);
      return result;
    },
    getWorkspaceId() {
      return workspaceScope.workspaceId;
    },
    getContextManager() {
      return contextManager;
    },
    buildKnowledgePromptBlock(limit?: number) {
      return knowledgeManager.buildPromptBlock(config.projectId ?? "default", limit);
    },
    addKnowledge(input: {
      type: KnowledgeType;
      title: string;
      content: string;
      provenance?: KnowledgeProvenance;
      tags?: string[];
    }) {
      const prov = (input.provenance ?? "system") as KnowledgeProvenance;
      return knowledgeManager.add({
        projectId: config.projectId ?? "default",
        type: input.type,
        title: input.title,
        content: input.content,
        provenance: prov,
        tags: input.tags,
      });
    },
    searchKnowledge(search: string, limit?: number) {
      return knowledgeManager.query({
        projectId: config.projectId ?? "default",
        search,
        limit,
      });
    },
    getProjectContextSnapshot(limit?: number) {
      return contextManager.snapshotForTask(
        config.projectId ?? contextManager.getDefaultProjectId(),
        { limit },
      );
    },
    addProjectContext(input) {
      const projectId = config.projectId ?? contextManager.getDefaultProjectId();
      return contextManager.addEntry({
        projectId,
        type: input.type,
        content: input.content,
        taskId: input.taskId,
        sourceEmployeeId: input.employeeId,
        tags: input.tags,
      });
    },
    async privateChat(input: { employeeId: string; message: string }) {
      const employeeId = String(input.employeeId ?? "").trim();
      const message = String(input.message ?? "").trim().slice(0, 2000);
      if (!employeeId || !message) {
        return {
          ok: false,
          unavailable: true,
          error: "employeeId and message required",
          employeeId: employeeId || "unknown",
        };
      }
      const allowed = new Set(["claude", "gemini", "grok", "gpt"]);
      if (!allowed.has(employeeId)) {
        return {
          ok: false,
          unavailable: true,
          error: "Unknown employee",
          employeeId,
        };
      }

      const cfg = loadEllConfig();
      const bindingMode = bindingModeFromConfig(cfg);
      const bindings = resolveEmployeeBindings(bindingMode);
      const binding = bindingFor(employeeId, bindings);
      const roster = createMultiAgentRoster();
      const employee = roster.find((e) => e.id === employeeId);
      const systemPrompt =
        employee?.systemPrompt ??
        `You are ${employeeId} in ELL AI Office. Answer helpfully and briefly.`;

      // Resolve whether the preferred provider is actually available.
      const preferredProviderId = binding.providerId;
      const health = registry.getHealth(preferredProviderId);
      const adapter = registry.get(preferredProviderId);
      const isMockBinding = preferredProviderId === "mock";

      // When config asks for live and the employee's provider is not mock,
      // refuse to silently use mock if that provider is missing/unconfigured.
      if (!isMockBinding) {
        const configured = health?.configured === true || adapter != null;
        const available =
          health?.availability === "available" ||
          (adapter != null && adapter.getAvailability?.() === "available");
        if (!configured || !available) {
          return {
            ok: false,
            unavailable: true,
            error:
              !configured
                ? `Provider "${preferredProviderId}" is not configured (missing credentials).`
                : `Provider "${preferredProviderId}" is currently unavailable.`,
            employeeId,
            providerId: preferredProviderId,
            model: binding.modelId,
          };
        }
      }

      const agentTask: AgentTask = {
        id: `private_${employeeId}_${randomUUID().slice(0, 8)}`,
        parentTaskId: "private_chat",
        employeeId,
        role: employee?.role ?? employeeId,
        objective: message,
        status: "running",
        dependsOn: [],
        required: true,
        kind: "parallel",
        timeoutMs: 30_000,
        upstreamResults: [],
        result: null,
        error: null,
        createdAt: iso(now()),
        startedAt: iso(now()),
        completedAt: null,
      };

      const executor = new AgentExecutor();
      try {
        const result = await executor.execute(agentTask, message, {
          router: registry.router,
          modelId: binding.modelId,
          systemPrompt,
          timeoutMs: 30_000,
          providerId: preferredProviderId,
          allowedProviderIds: isMockBinding
            ? ["mock"]
            : [preferredProviderId],
          routingMode: isMockBinding ? "primary-only" : "primary-only",
          maxRoutingAttempts: 1,
          excludeMockInFreeFirst: !isMockBinding,
        });

        if (result.status === "failed") {
          return {
            ok: false,
            unavailable: true,
            error: result.summary || "Provider failed",
            employeeId,
            providerId: result.providerId,
            model: result.model,
          };
        }

        const reply =
          result.summary ||
          result.output?.slice(0, 2000) ||
          "No summary returned";
        return {
          ok: true,
          reply,
          employeeId,
          providerId: result.providerId,
          model: result.model,
        };
      } catch (e) {
        return {
          ok: false,
          unavailable: true,
          error: e instanceof Error ? e.message : "Private chat error",
          employeeId,
          providerId: preferredProviderId,
          model: binding.modelId,
        };
      }
    },
  };
}

function wasCancelled(status: TaskStatus): boolean {
  return status === "cancelled";
}

function parseOutput(
  text: string,
  objective: string,
  provider: string,
  model: string,
): AgentOutput {
  try {
    const parsed = JSON.parse(text) as Partial<AgentOutput>;
    return {
      employeeId: CLAUDE_ID,
      summary: String(parsed.summary ?? `Mock analysis completed for: ${objective}`),
      findings: asStringArray(parsed.findings),
      evidence: asStringArray(parsed.evidence),
      risks: asStringArray(parsed.risks),
      recommendations: asStringArray(parsed.recommendations),
      questions: asStringArray(parsed.questions),
      confidence: parsed.confidence === "medium" || parsed.confidence === "high" ? parsed.confidence : "low",
      provider,
      model,
      createdAt: new Date().toISOString(),
    };
  } catch {
    return {
      employeeId: CLAUDE_ID,
      summary: text || `Mock analysis completed for: ${objective}`,
      findings: ["Provider returned unstructured text."],
      evidence: [],
      risks: ["Output was not structured JSON."],
      recommendations: [],
      questions: [],
      confidence: "low",
      provider,
      model,
      createdAt: new Date().toISOString(),
    };
  }
}

function asStringArray(value: unknown): string[] {
  return Array.isArray(value) ? value.map((item) => String(item)) : [];
}

function synthesize(output: AgentOutput | undefined): FinalResult {
  if (!output) {
    return {
      summary: "No employee output to synthesize.",
      findings: [],
      evidence: [],
      risks: ["Missing employee result."],
      recommendations: [],
      questions: [],
      synthesizedBy: "orchestrator",
    };
  }
  return {
    summary: output.summary,
    findings: output.findings,
    evidence: output.evidence,
    risks: output.risks,
    recommendations: output.recommendations,
    questions: output.questions,
    synthesizedBy: "orchestrator",
  };
}

const globalStore = globalThis as typeof globalThis & { __ellOffice?: OfficeRuntime };

export function getOffice(): OfficeRuntime {
  if (!globalStore.__ellOffice) {
    globalStore.__ellOffice = createOfficeRuntime();
  }
  return globalStore.__ellOffice;
}

export function replaceOffice(runtime: OfficeRuntime) {
  globalStore.__ellOffice = runtime;
}
