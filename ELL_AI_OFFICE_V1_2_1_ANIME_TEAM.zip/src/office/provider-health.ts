/**
 * Provider health & availability store (Phase 2C).
 *
 * Tracks configuration vs observed request outcomes.
 * Does NOT route, fallback, or call live APIs just to "ping" health.
 * Does NOT invent cooldowns or claim API-healthy without a real check.
 */

import type { ProviderAdapter } from "./providers.ts";
import { ProviderError } from "./errors.ts";
import type { ProviderAvailability, ProviderErrorClass } from "./types.ts";

/** Why the provider is in its current availability state. */
export type ProviderHealthReason =
  | "ok"
  | "configuration_error"
  | "authentication_error"
  | "rate_limited"
  | "network_error"
  | "timeout"
  | "provider_error"
  | "degraded"
  | "disabled"
  | "unknown"
  | "not_checked";

/**
 * Public, secret-free health snapshot safe for UI / API.
 *
 * Semantics:
 * - configured: credentials present (or mock which needs none)
 * - availability: operational state for routing decisions later
 * - checkedAt: last time a real generate() outcome updated state; null if never
 * - cooldownUntil: only set when explicitly known; never invented
 */
export interface ProviderHealth {
  providerId: string;
  label: string;
  configured: boolean;
  availability: ProviderAvailability;
  reason: ProviderHealthReason;
  message: string;
  checkedAt: string | null;
  lastSuccessAt: string | null;
  lastErrorAt: string | null;
  lastErrorClass: ProviderErrorClass | null;
  cooldownUntil: string | null;
}

export interface ProviderHealthSeed {
  providerId: string;
  label: string;
  configured: boolean;
  /** Initial availability before any live request. */
  availability?: ProviderAvailability;
  message?: string;
}

function iso(ms = Date.now()): string {
  return new Date(ms).toISOString();
}

function reasonFromAvailability(
  availability: ProviderAvailability,
  configured: boolean,
): ProviderHealthReason {
  if (!configured) return "configuration_error";
  switch (availability) {
    case "available":
      return "ok";
    case "rate_limited":
    case "daily_limit_reached":
    case "monthly_limit_reached":
      return "rate_limited";
    case "auth_error":
      return "authentication_error";
    case "disabled":
    case "offline":
      return "disabled";
    case "degraded":
      return "degraded";
    case "provider_error":
      return "provider_error";
    case "unknown":
      return "unknown";
    default:
      return "unknown";
  }
}

function messageFor(seed: {
  configured: boolean;
  availability: ProviderAvailability;
  reason: ProviderHealthReason;
  custom?: string;
}): string {
  if (seed.custom) return seed.custom;
  if (!seed.configured) {
    return "Not configured: API key missing. Provider cannot accept requests.";
  }
  switch (seed.reason) {
    case "ok":
      return seed.availability === "available"
        ? "Configured and available for requests."
        : "Configured.";
    case "not_checked":
      return "Configured; no live request observed yet.";
    case "rate_limited":
      return "Rate limited by the provider. Do not bypass; wait for cooldown or quota reset.";
    case "authentication_error":
      return "Authentication/authorization failed. Check API key permissions.";
    case "network_error":
      return "Network error talking to the provider.";
    case "timeout":
      return "Provider request timed out or was cancelled.";
    case "provider_error":
      return "Provider returned a server error.";
    case "degraded":
      return "Provider is degraded after recent failures.";
    case "configuration_error":
      return "Not configured: API key missing.";
    case "disabled":
      return "Provider is disabled.";
    default:
      return "Status unknown.";
  }
}

export class ProviderHealthStore {
  private readonly states = new Map<string, ProviderHealth>();

  /** Seed or replace config-based state. Does not invent live health. */
  register(seed: ProviderHealthSeed): void {
    const availability =
      seed.availability ?? (seed.configured ? "available" : "disabled");
    const reason = seed.configured
      ? availability === "available"
        ? "not_checked"
        : reasonFromAvailability(availability, seed.configured)
      : "configuration_error";

    const existing = this.states.get(seed.providerId);
    this.states.set(seed.providerId, {
      providerId: seed.providerId,
      label: seed.label,
      configured: seed.configured,
      availability,
      reason,
      message: messageFor({
        configured: seed.configured,
        availability,
        reason,
        custom: seed.message,
      }),
      // Preserve observation history across re-register when same id.
      checkedAt: existing?.checkedAt ?? null,
      lastSuccessAt: existing?.lastSuccessAt ?? null,
      lastErrorAt: existing?.lastErrorAt ?? null,
      lastErrorClass: existing?.lastErrorClass ?? null,
      cooldownUntil: existing?.cooldownUntil ?? null,
    });
  }

  get(providerId: string): ProviderHealth | undefined {
    return this.states.get(providerId)
      ? { ...this.states.get(providerId)! }
      : undefined;
  }

  list(): ProviderHealth[] {
    return [...this.states.values()].map((row) => ({ ...row }));
  }

  /**
   * Record a successful generate(). Marks available.
   * Clears cooldown and error class.
   */
  recordSuccess(providerId: string, atMs = Date.now()): void {
    const row = this.states.get(providerId);
    if (!row) return;
    const at = iso(atMs);
    this.states.set(providerId, {
      ...row,
      configured: true,
      availability: "available",
      reason: "ok",
      message: messageFor({
        configured: true,
        availability: "available",
        reason: "ok",
      }),
      checkedAt: at,
      lastSuccessAt: at,
      cooldownUntil: null,
    });
  }

  /**
   * Record a failed generate() using normalized ProviderError when possible.
   * Does not invent cooldown durations.
   */
  recordFailure(
    providerId: string,
    error: unknown,
    options?: { cooldownUntilMs?: number; atMs?: number },
  ): void {
    const row = this.states.get(providerId);
    if (!row) return;
    const atMs = options?.atMs ?? Date.now();
    const at = iso(atMs);

    let availability: ProviderAvailability = "provider_error";
    let reason: ProviderHealthReason = "provider_error";
    let errorClass: ProviderErrorClass = "UNKNOWN";
    let detail: string | undefined;

    if (error instanceof ProviderError) {
      errorClass = error.code;
      detail = error.message;
      switch (error.code) {
        case "AUTH":
          availability = "auth_error";
          reason = "authentication_error";
          break;
        case "RATE_LIMIT":
          availability = "rate_limited";
          reason = "rate_limited";
          break;
        case "TIMEOUT":
          availability = "degraded";
          reason = "timeout";
          break;
        case "NETWORK":
          availability = "degraded";
          reason = "network_error";
          break;
        case "INVALID_REQUEST":
        case "CONTENT_ERROR":
          // Request problem — provider itself may still be usable.
          availability = "available";
          reason = "ok";
          break;
        case "SERVER_ERROR":
          availability = "provider_error";
          reason = "provider_error";
          break;
        default:
          availability = "degraded";
          reason = "degraded";
      }
    } else if (error instanceof Error) {
      detail = error.message;
      availability = "degraded";
      reason = "degraded";
    }

    // Only set cooldown when explicitly provided — never invent one.
    const cooldownUntil =
      options?.cooldownUntilMs !== undefined
        ? iso(options.cooldownUntilMs)
        : reason === "rate_limited"
          ? row.cooldownUntil
          : null;

    // Public message: fixed catalog text only — never append raw provider error
    // bodies (may contain key fragments). Classification lives in lastErrorClass.
    this.states.set(providerId, {
      ...row,
      availability,
      reason,
      message: messageFor({
        configured: row.configured,
        availability,
        reason,
      }),
      checkedAt: at,
      lastErrorAt: at,
      lastErrorClass: errorClass,
      cooldownUntil,
    });
    void detail;
  }

  /**
   * Apply cooldown only when the caller has an authoritative expiry (e.g. Retry-After).
   * Passing null clears cooldown.
   */
  setCooldown(providerId: string, cooldownUntilMs: number | null): void {
    const row = this.states.get(providerId);
    if (!row) return;
    this.states.set(providerId, {
      ...row,
      cooldownUntil: cooldownUntilMs === null ? null : iso(cooldownUntilMs),
      availability:
        cooldownUntilMs !== null && cooldownUntilMs > Date.now()
          ? "rate_limited"
          : row.availability,
      reason:
        cooldownUntilMs !== null && cooldownUntilMs > Date.now()
          ? "rate_limited"
          : row.reason,
    });
  }

  /** Whether a request may be attempted (no router — informational only). */
  isAvailableForRequest(providerId: string, nowMs = Date.now()): boolean {
    const row = this.states.get(providerId);
    if (!row || !row.configured) return false;
    if (row.availability === "auth_error" || row.availability === "disabled") {
      return false;
    }
    if (row.availability === "offline") return false;
    if (
      row.availability === "rate_limited" ||
      row.availability === "daily_limit_reached" ||
      row.availability === "monthly_limit_reached"
    ) {
      if (row.cooldownUntil) {
        const until = Date.parse(row.cooldownUntil);
        if (!Number.isNaN(until) && until > nowMs) return false;
        // Cooldown expired — treat as available for attempt again.
        return true;
      }
      return false;
    }
    return (
      row.availability === "available" ||
      row.availability === "degraded" ||
      row.availability === "unknown" ||
      row.availability === "provider_error"
    );
  }

  /** Clear all state (tests). */
  reset(): void {
    this.states.clear();
  }
}

/**
 * Wrap an adapter so successful/failed generate() updates the health store.
 * Preserves all other adapter behaviour.
 */
export function withHealthTracking(
  adapter: ProviderAdapter,
  store: ProviderHealthStore,
): ProviderAdapter {
  return {
    id: adapter.id,
    label: adapter.label,
    capabilities: adapter.capabilities,
    getAvailability: () => {
      const health = store.get(adapter.id);
      if (health) return health.availability;
      return adapter.getAvailability();
    },
    listModels: () => adapter.listModels(),
    async generate(request) {
      try {
        const result = await adapter.generate(request);
        store.recordSuccess(adapter.id);
        return result;
      } catch (error) {
        store.recordFailure(adapter.id, error);
        throw error;
      }
    },
  };
}

/** Seed store for mock + known cloud providers (config-based, no live probes). */
export function seedDefaultProviderHealth(
  store: ProviderHealthStore,
  options: {
    xaiConfigured: boolean;
    geminiConfigured: boolean;
    anthropicConfigured?: boolean;
    openaiConfigured?: boolean;
    mockLabel?: string;
  },
): void {
  store.register({
    providerId: "mock",
    label: options.mockLabel ?? "Mock provider (Phase 1)",
    configured: true,
    availability: "available",
    message: "Mock provider is always configured; no API key required.",
  });
  store.register({
    providerId: "xai",
    label: "xAI (Grok)",
    configured: options.xaiConfigured,
    availability: options.xaiConfigured ? "available" : "disabled",
  });
  store.register({
    providerId: "gemini",
    label: "Google Gemini",
    configured: options.geminiConfigured,
    availability: options.geminiConfigured ? "available" : "disabled",
  });
  store.register({
    providerId: "anthropic",
    label: "Anthropic (Claude)",
    configured: Boolean(options.anthropicConfigured),
    availability: options.anthropicConfigured ? "available" : "disabled",
  });
  store.register({
    providerId: "openai",
    label: "OpenAI",
    configured: Boolean(options.openaiConfigured),
    availability: options.openaiConfigured ? "available" : "disabled",
  });
}
