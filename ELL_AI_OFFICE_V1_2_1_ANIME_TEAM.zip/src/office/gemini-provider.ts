/**
 * Official Google Gemini provider adapter.
 *
 * Uses the documented generateContent REST API:
 *   https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent
 * Auth: x-goog-api-key header (GEMINI_API_KEY).
 *
 * Never scrapes the Gemini web UI, never uses unofficial endpoints,
 * never fabricates usage or text.
 */

import {
  DEFAULT_CAPABILITIES,
  httpStatusToErrorClass,
  normalizeProviderError,
  withTimeoutAndSignal,
  type GenerateRequest,
  type GenerateResponse,
  type ProviderAdapter,
  type ProviderCapabilities,
} from "./providers.ts";
import { ProviderError } from "./errors.ts";
import type { ProviderAvailability, ProviderRecord } from "./types.ts";

const GEMINI_BASE_URL = "https://generativelanguage.googleapis.com/v1beta";

/**
 * Default model when GEMINI_MODEL is unset.
 * Documented and easy to override via env — do not treat as permanent.
 * Prefer setting GEMINI_MODEL explicitly in production.
 */
export const GEMINI_DEFAULT_MODEL = "gemini-2.5-flash";
export const GEMINI_MODEL_ID = "gemini:default";

export interface GeminiProviderOptions {
  /** Server-side API key. Prefer reading from process.env at construction time. */
  apiKey?: string;
  /** Model id sent to the API (e.g. gemini-2.5-flash). */
  model?: string;
  /** Override base URL only for testing against a mock HTTP server. */
  baseUrl?: string;
  /** Optional fetch implementation (tests). */
  fetchImpl?: typeof fetch;
}

export class GeminiProvider implements ProviderAdapter {
  readonly id = "gemini";
  readonly label = "Google Gemini";
  readonly capabilities: ProviderCapabilities = {
    ...DEFAULT_CAPABILITIES,
    text: true,
    code: true,
    // This adapter uses non-streaming generateContent only.
    streaming: false,
    tools: false,
    // Vision is supported by the API but not wired in this adapter's request mapping.
    vision: false,
    jsonMode: false,
  };

  private readonly apiKey: string | undefined;
  private readonly apiModel: string;
  private readonly baseUrl: string;
  private readonly fetchImpl: typeof fetch;
  private availability: ProviderAvailability;

  constructor(options: GeminiProviderOptions = {}) {
    this.apiKey = options.apiKey?.trim() || undefined;
    this.apiModel = (options.model?.trim() || GEMINI_DEFAULT_MODEL).replace(/^models\//, "");
    this.baseUrl = (options.baseUrl ?? GEMINI_BASE_URL).replace(/\/$/, "");
    this.fetchImpl = options.fetchImpl ?? fetch;
    this.availability = this.apiKey ? "available" : "disabled";
  }

  isConfigured(): boolean {
    return Boolean(this.apiKey);
  }

  /** Model name used in official API paths. */
  getApiModel(): string {
    return this.apiModel;
  }

  setAvailability(state: ProviderAvailability): void {
    this.availability = state;
  }

  getAvailability(): ProviderAvailability {
    if (!this.apiKey) return "disabled";
    return this.availability;
  }

  listModels(): ProviderRecord[] {
    const availability = this.getAvailability();
    return [
      {
        id: GEMINI_MODEL_ID,
        provider: this.id,
        capabilities: ["text", "code"],
        contextWindow: null,
        costClass: "paid",
        availability,
        label: `Gemini (${this.apiModel})`,
      },
    ];
  }

  async generate(request: GenerateRequest): Promise<GenerateResponse> {
    if (!this.apiKey) {
      throw new ProviderError(
        "AUTH",
        "Gemini provider is not configured (missing GEMINI_API_KEY). Secrets stay server-side.",
        false,
      );
    }

    const availability = this.getAvailability();
    if (availability === "disabled" || availability === "offline") {
      throw new ProviderError("AUTH", `Gemini provider is ${availability}.`, false);
    }
    if (
      availability === "rate_limited" ||
      availability === "daily_limit_reached" ||
      availability === "monthly_limit_reached"
    ) {
      throw new ProviderError("RATE_LIMIT", `Gemini provider is ${availability}.`, true);
    }

    // Allow request.model to override when it looks like a Gemini API model name.
    let apiModel = this.apiModel;
    if (request.model && request.model !== GEMINI_MODEL_ID) {
      if (request.model.startsWith("gemini:")) {
        const stripped = request.model.slice("gemini:".length).trim();
        if (stripped && stripped !== "default") apiModel = stripped;
      } else if (request.model.startsWith("gemini-") || request.model.startsWith("models/")) {
        apiModel = request.model.replace(/^models\//, "");
      }
    }

    const started = Date.now();
    const url = `${this.baseUrl}/models/${encodeURIComponent(apiModel)}:generateContent`;

    const body: Record<string, unknown> = {
      contents: [
        {
          role: "user",
          parts: [{ text: request.userPrompt }],
        },
      ],
    };

    if (request.systemPrompt?.trim()) {
      body.systemInstruction = {
        parts: [{ text: request.systemPrompt }],
      };
    }

    const work = (async (): Promise<GenerateResponse> => {
      let response: Response;
      try {
        response = await this.fetchImpl(url, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-goog-api-key": this.apiKey as string,
          },
          body: JSON.stringify(body),
          signal: request.signal,
        });
      } catch (error) {
        throw normalizeProviderError(error, "Gemini network request failed");
      }

      if (!response.ok) {
        let detail = `Gemini API HTTP ${response.status}`;
        try {
          const errJson = (await response.json()) as {
            error?: { message?: string; status?: string };
            message?: string;
          };
          detail = errJson?.error?.message || errJson?.message || detail;
        } catch {
          // ignore body parse failure
        }

        const { code, retryable } = httpStatusToErrorClass(response.status);
        if (code === "RATE_LIMIT") {
          this.availability = "rate_limited";
        } else if (code === "AUTH") {
          this.availability = "auth_error";
        } else if (code === "SERVER_ERROR") {
          this.availability = "provider_error";
        }
        throw new ProviderError(code, detail, retryable);
      }

      if (
        this.availability === "rate_limited" ||
        this.availability === "provider_error" ||
        this.availability === "auth_error"
      ) {
        this.availability = "available";
      }

      const data = (await response.json()) as {
        candidates?: Array<{
          content?: { parts?: Array<{ text?: string }> };
          finishReason?: string;
        }>;
        usageMetadata?: {
          promptTokenCount?: number;
          candidatesTokenCount?: number;
          totalTokenCount?: number;
        };
        modelVersion?: string;
      };

      const parts = data.candidates?.[0]?.content?.parts ?? [];
      const text = parts
        .map((p) => p.text ?? "")
        .filter(Boolean)
        .join("");

      if (!text) {
        throw new ProviderError(
          "CONTENT_ERROR",
          "Gemini API returned an empty completion.",
          false,
        );
      }

      const usageMeta = data.usageMetadata;
      return {
        text,
        model: data.modelVersion ?? apiModel,
        provider: this.id,
        latencyMs: Math.max(1, Date.now() - started),
        usage: usageMeta
          ? {
              promptTokens: usageMeta.promptTokenCount,
              completionTokens: usageMeta.candidatesTokenCount,
              totalTokens: usageMeta.totalTokenCount,
            }
          : undefined,
        finishReason: data.candidates?.[0]?.finishReason,
      };
    })();

    try {
      return await withTimeoutAndSignal(work, {
        timeoutMs: request.timeoutMs,
        signal: request.signal,
        label: "Gemini provider",
      });
    } catch (error) {
      throw normalizeProviderError(error, "Gemini generate failed");
    }
  }
}

/** Build a GeminiProvider from process.env (server-only). */
export function createGeminiProviderFromEnv(
  options: Omit<GeminiProviderOptions, "apiKey" | "model"> = {},
): GeminiProvider {
  const apiKey = process.env.GEMINI_API_KEY?.trim() || undefined;
  const model = process.env.GEMINI_MODEL?.trim() || undefined;
  return new GeminiProvider({ ...options, apiKey, model });
}
