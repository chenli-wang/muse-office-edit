/**
 * Official xAI (Grok) provider adapter.
 *
 * Uses the documented OpenAI-compatible Chat Completions API at https://api.x.ai/v1
 * Only activates when XAI_API_KEY is present in the server environment.
 * Never scrapes web chat, never uses unofficial endpoints, never fabricates responses.
 */

import {
  DEFAULT_CAPABILITIES,
  httpStatusToErrorClass,
  normalizeProviderError,
  withTimeoutAndSignal,
  type GenerateRequest,
  type GenerateResponse,
  type ProviderAdapter,
  type ProviderCapabilities,
} from "./providers.ts";
import { ProviderError } from "./errors.ts";
import type { ProviderAvailability, ProviderRecord } from "./types.ts";

const XAI_BASE_URL = "https://api.x.ai/v1";
/** Default model per xAI docs / platform skill — override via request.model when needed. */
export const XAI_DEFAULT_MODEL = "grok-4.5";
export const XAI_MODEL_ID = "xai:grok-4.5";

export interface XaiProviderOptions {
  /** Server-side API key. Prefer reading from process.env at construction time. */
  apiKey?: string;
  /** Override base URL only for testing against a mock HTTP server. */
  baseUrl?: string;
  /** Optional fetch implementation (tests). */
  fetchImpl?: typeof fetch;
  /** Default model id sent to the API when request.model is a registry id. */
  defaultModel?: string;
}

export class XaiProvider implements ProviderAdapter {
  readonly id = "xai";
  readonly label = "xAI (Grok)";
  readonly capabilities: ProviderCapabilities = {
    ...DEFAULT_CAPABILITIES,
    text: true,
    code: true,
    streaming: false,
    jsonMode: true,
  };

  private readonly apiKey: string | undefined;
  private readonly baseUrl: string;
  private readonly fetchImpl: typeof fetch;
  private readonly defaultModel: string;
  private availability: ProviderAvailability;

  constructor(options: XaiProviderOptions = {}) {
    this.apiKey = options.apiKey?.trim() || undefined;
    this.baseUrl = (options.baseUrl ?? XAI_BASE_URL).replace(/\/$/, "");
    this.fetchImpl = options.fetchImpl ?? fetch;
    this.defaultModel = options.defaultModel ?? XAI_DEFAULT_MODEL;
    this.availability = this.apiKey ? "available" : "disabled";
  }

  /** Whether this adapter has a usable key and is not disabled. */
  isConfigured(): boolean {
    return Boolean(this.apiKey);
  }

  setAvailability(state: ProviderAvailability): void {
    this.availability = state;
  }

  getAvailability(): ProviderAvailability {
    if (!this.apiKey) return "disabled";
    return this.availability;
  }

  listModels(): ProviderRecord[] {
    const availability = this.getAvailability();
    return [
      {
        id: XAI_MODEL_ID,
        provider: this.id,
        capabilities: ["text", "code"],
        contextWindow: null,
        costClass: "paid",
        availability,
        label: "Grok 4.5 (xAI)",
      },
    ];
  }

  async generate(request: GenerateRequest): Promise<GenerateResponse> {
    if (!this.apiKey) {
      throw new ProviderError(
        "AUTH",
        "xAI provider is not configured (missing XAI_API_KEY). Secrets stay server-side.",
        false,
      );
    }

    const availability = this.getAvailability();
    if (availability === "disabled" || availability === "offline") {
      throw new ProviderError("AUTH", `xAI provider is ${availability}.`, false);
    }
    if (
      availability === "rate_limited" ||
      availability === "daily_limit_reached" ||
      availability === "monthly_limit_reached"
    ) {
      throw new ProviderError("RATE_LIMIT", `xAI provider is ${availability}.`, true);
    }

    // Map registry model ids to API model names.
    const apiModel =
      request.model === XAI_MODEL_ID || request.model.startsWith("xai:")
        ? request.model.replace(/^xai:/, "") || this.defaultModel
        : request.model || this.defaultModel;

    const started = Date.now();
    const body = {
      model: apiModel,
      messages: [
        { role: "system", content: request.systemPrompt },
        { role: "user", content: request.userPrompt },
      ],
      temperature: 0.2,
    };

    const work = (async (): Promise<GenerateResponse> => {
      let response: Response;
      try {
        response = await this.fetchImpl(`${this.baseUrl}/chat/completions`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${this.apiKey}`,
          },
          body: JSON.stringify(body),
          signal: request.signal,
        });
      } catch (error) {
        throw normalizeProviderError(error, "xAI network request failed");
      }

      if (!response.ok) {
        let detail = `xAI API HTTP ${response.status}`;
        try {
          const errJson = (await response.json()) as {
            error?: { message?: string };
            message?: string;
          };
          detail = errJson?.error?.message || errJson?.message || detail;
        } catch {
          // ignore body parse failure
        }

        const { code, retryable } = httpStatusToErrorClass(response.status);
        if (code === "RATE_LIMIT") {
          this.availability = "rate_limited";
        } else if (code === "AUTH") {
          this.availability = "auth_error";
        } else if (code === "SERVER_ERROR") {
          this.availability = "provider_error";
        }
        throw new ProviderError(code, detail, retryable);
      }

      // Successful response restores availability if previously degraded.
      if (
        this.availability === "rate_limited" ||
        this.availability === "provider_error" ||
        this.availability === "auth_error"
      ) {
        this.availability = "available";
      }

      const data = (await response.json()) as {
        choices?: Array<{ message?: { content?: string }; finish_reason?: string }>;
        model?: string;
        usage?: {
          prompt_tokens?: number;
          completion_tokens?: number;
          total_tokens?: number;
        };
      };

      const text = data.choices?.[0]?.message?.content ?? "";
      if (!text) {
        throw new ProviderError(
          "CONTENT_ERROR",
          "xAI API returned an empty completion.",
          false,
        );
      }

      return {
        text,
        model: data.model ?? apiModel,
        provider: this.id,
        latencyMs: Math.max(1, Date.now() - started),
        usage: data.usage
          ? {
              promptTokens: data.usage.prompt_tokens,
              completionTokens: data.usage.completion_tokens,
              totalTokens: data.usage.total_tokens,
            }
          : undefined,
        finishReason: data.choices?.[0]?.finish_reason,
      };
    })();

    try {
      return await withTimeoutAndSignal(work, {
        timeoutMs: request.timeoutMs,
        signal: request.signal,
        label: "xAI provider",
      });
    } catch (error) {
      throw normalizeProviderError(error, "xAI generate failed");
    }
  }
}

/** Build an XaiProvider from process.env (server-only). */
export function createXaiProviderFromEnv(
  options: Omit<XaiProviderOptions, "apiKey"> = {},
): XaiProvider {
  const apiKey = process.env.XAI_API_KEY?.trim() || undefined;
  return new XaiProvider({ ...options, apiKey });
}
