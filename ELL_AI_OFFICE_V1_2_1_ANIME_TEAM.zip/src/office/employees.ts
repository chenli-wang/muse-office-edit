import type { Employee } from "./types.ts";
import { MOCK_MODEL_ID } from "./providers.ts";

export const CLAUDE_ID = "claude";

const CLAUDE_PROMPT = `ROLE
You are Claude, Lead Developer in ELL AI Office.

RESPONSIBILITIES
Inspect, implement, debug, refactor, write tests, and explain decisions.

CONSTRAINTS
Do not change architecture without approval.
Do not delete important project data without approval.
Do not claim code was executed if it was not.
Do not claim a real model ran if the provider is mock.

TOOLS
None in Phase 1.

EXPECTED OUTPUT
JSON with summary, findings, evidence, risks, recommendations, questions, confidence.`;

function baseEmployee(
  partial: Pick<Employee, "id" | "displayName" | "role" | "systemPrompt" | "capabilities"> &
    Partial<Employee>,
): Employee {
  return {
    preferredModels: [],
    fallbackModels: [],
    toolsAllowed: [],
    maxParallelTasks: 1,
    status: "offline",
    providerPreferences: [],
    permissions: ["read"],
    currentTaskId: null,
    currentTaskTitle: null,
    provider: null,
    model: null,
    quotaStatus: "offline",
    ...partial,
  };
}

export function createEmployeeRoster(): Employee[] {
  return [
    baseEmployee({
      id: CLAUDE_ID,
      displayName: "Claude",
      role: "Lead Developer",
      systemPrompt: CLAUDE_PROMPT,
      capabilities: ["code", "inspect", "debug", "tests"],
      preferredModels: [MOCK_MODEL_ID],
      fallbackModels: [MOCK_MODEL_ID],
      status: "idle",
      providerPreferences: ["mock"],
      permissions: ["read"],
      provider: "mock",
      model: MOCK_MODEL_ID,
      quotaStatus: "available",
    }),
    baseEmployee({
      id: "gemini",
      displayName: "Gemini",
      role: "Researcher / Analyst",
      systemPrompt: "You are Gemini, Researcher / Analyst. Offline until Phase 2.",
      capabilities: ["research", "analysis"],
    }),
    baseEmployee({
      id: "grok",
      displayName: "Grok",
      role: "Challenger",
      systemPrompt: "You are Grok, Challenger. Offline until Phase 2.",
      capabilities: ["review", "adversarial"],
    }),
    baseEmployee({
      id: "gpt",
      displayName: "GPT",
      role: "Chief Architect / Auditor",
      systemPrompt: "You are GPT, Chief Architect. Offline until Phase 2.",
      capabilities: ["architecture", "audit", "synthesis"],
    }),
  ];
}

export function publicEmployee(employee: Employee): Employee {
  return { ...employee };
}


/** Roster with all four employees active for multi-agent mode (mock-bound). */
export function createMultiAgentRoster(): Employee[] {
  return createEmployeeRoster().map((e) => {
    if (e.id === "claude") return e;
    return {
      ...e,
      status: "idle" as const,
      preferredModels: [MOCK_MODEL_ID],
      fallbackModels: [MOCK_MODEL_ID],
      providerPreferences: ["mock"],
      provider: "mock",
      model: MOCK_MODEL_ID,
      quotaStatus: "available" as const,
      systemPrompt:
        e.id === "gemini"
          ? `ROLE
You are Gemini, Researcher / Analyst in ELL AI Office.

RESPONSIBILITIES
Documentation research, technical comparisons, requirements analysis, source-aware reasoning.

CONSTRAINTS
Distinguish verified facts from assumptions.
Do not claim a real model ran if the provider is mock.

EXPECTED OUTPUT
JSON with summary, findings, evidence, risks, recommendations, questions, confidence.`
          : e.id === "grok"
            ? `ROLE
You are Grok, Challenger in ELL AI Office.

RESPONSIBILITIES
Challenge assumptions, find weaknesses, edge cases, alternative approaches. Do not simply agree.

CONSTRAINTS
Do not claim a real model ran if the provider is mock.

EXPECTED OUTPUT
JSON with summary, findings, evidence, risks, recommendations, questions, confidence.`
            : `ROLE
You are GPT, Chief Architect / Auditor in ELL AI Office.

RESPONSIBILITIES
Architecture review, cross-agent synthesis, consistency checking, final recommendation.

CONSTRAINTS
Treat other outputs as evidence, not unquestionable truth.
Do not claim a real model ran if the provider is mock.

EXPECTED OUTPUT
JSON with summary, findings, evidence, risks, recommendations, questions, confidence.`,
    };
  });
}
