/**
 * Provider Router (Phase 2D–2F)
 *
 * Selects providers deterministically (free-first when requested) and runs
 * controlled fallback on recoverable errors. Does not live inside adapters.
 *
 * MockProvider is a test/mock engine — never used as a fake "real AI" fallback
 * in free-first mode.
 */

import type { ProviderAdapter, GenerateRequest, GenerateResponse } from "./providers.ts";
import { ProviderError } from "./errors.ts";
import type { ProviderHealthStore } from "./provider-health.ts";
import type { ProviderAvailability, ProviderErrorClass } from "./types.ts";

export type RoutingMode = "primary-only" | "free-first";

export interface RoutingPolicy {
  mode: RoutingMode;
  /** Max distinct providers to attempt (inclusive). Default 3. */
  maxAttempts: number;
  /** Required capability flags (adapter.capabilities). */
  requiredCapabilities?: Array<keyof ProviderAdapter["capabilities"]>;
  /**
   * When true (default in free-first), exclude the mock adapter from candidates.
   * Mock is only for primary-only / explicit testing — not a real-AI substitute.
   */
  excludeMockInFreeFirst?: boolean;
  /**
   * Hard allowlist from Manager cost policy (e.g. FREE_ONLY).
   * When set, only these provider ids may be selected or used as fallback.
   */
  allowedProviderIds?: string[];
}

export const DEFAULT_ROUTING_POLICY: RoutingPolicy = {
  mode: "primary-only",
  maxAttempts: 3,
  requiredCapabilities: ["text"],
  excludeMockInFreeFirst: true,
};

export interface RouteAttempt {
  providerId: string;
  label: string;
  outcome: "success" | "failure" | "skipped";
  errorClass?: ProviderErrorClass;
  /** Sanitized, secret-free reason (never raw provider bodies). */
  reason?: string;
}

export interface RouteTrace {
  mode: RoutingMode;
  preferredProviderId: string | null;
  selectedProviderId: string | null;
  selectionReason: string;
  candidates: string[];
  attempts: RouteAttempt[];
  fallbackUsed: boolean;
  finalProviderId: string | null;
  success: boolean;
}

export interface RouterSelectInput {
  policy?: Partial<RoutingPolicy>;
  /** Optional explicit capability override. */
  requiredCapabilities?: Array<keyof ProviderAdapter["capabilities"]>;
  /**
   * Preferred provider id from employee binding (e.g. "anthropic").
   * Attempted first when configured and available. Fallback follows policy.
   * When preferred is "mock", only mock is used (mock mode).
   * When preferred is a real provider, MockProvider is never used as silent substitute.
   */
  preferredProviderId?: string;
}

export interface RouterExecuteResult {
  response: GenerateResponse;
  trace: RouteTrace;
}

const RECOVERABLE: ReadonlySet<ProviderErrorClass> = new Set([
  "RATE_LIMIT",
  "TIMEOUT",
  "NETWORK",
  "SERVER_ERROR",
]);

const COST_RANK: Record<string, number> = {
  free: 0,
  unknown: 1,
  paid: 2,
};

function costRank(adapter: ProviderAdapter): number {
  // Prefer listModels costClass when available (sync path).
  try {
    const models = adapter.listModels();
    if (Array.isArray(models) && models[0]?.costClass) {
      return COST_RANK[models[0].costClass] ?? 1;
    }
  } catch {
    // ignore
  }
  if (adapter.id === "mock") return COST_RANK.free;
  return COST_RANK.paid;
}

function hasCapabilities(
  adapter: ProviderAdapter,
  required: Array<keyof ProviderAdapter["capabilities"]>,
): boolean {
  for (const key of required) {
    if (!adapter.capabilities[key]) return false;
  }
  return true;
}

function isBlockedAvailability(a: ProviderAvailability): boolean {
  return (
    a === "disabled" ||
    a === "offline" ||
    a === "auth_error" ||
    a === "rate_limited" ||
    a === "daily_limit_reached" ||
    a === "monthly_limit_reached"
  );
}

/** Public, deterministic sanitizer for error text. Never returns secrets. */
export function sanitizePublicErrorMessage(
  error: unknown,
  fallback = "Provider request failed",
): string {
  if (!(error instanceof Error)) return fallback;
  const msg = error.message || fallback;
  // Strip anything that looks like a key, bearer token, or long secret token.
  let cleaned = msg
    .replace(/Bearer\s+[A-Za-z0-9._\-]+/gi, "Bearer [REDACTED]")
    .replace(/\b(sk|xai|AIza)[-_A-Za-z0-9]{8,}/g, "[REDACTED_KEY]")
    .replace(/secret-api-key-[A-Za-z0-9\-]+/gi, "[REDACTED_KEY]")
    .replace(/api[_-]?key["\s:=]+[A-Za-z0-9._\-]+/gi, "api_key=[REDACTED]");
  // Cap length to avoid dumping large bodies.
  if (cleaned.length > 240) cleaned = `${cleaned.slice(0, 237)}…`;
  return cleaned;
}

export function isRecoverableProviderError(error: unknown): boolean {
  if (error instanceof ProviderError) {
    return RECOVERABLE.has(error.code);
  }
  return false;
}

export interface ProviderRouterOptions {
  adapters: ProviderAdapter[];
  primary: ProviderAdapter;
  health: ProviderHealthStore;
  now?: () => number;
}

export class ProviderRouter {
  private readonly adapters: ProviderAdapter[];
  private readonly primary: ProviderAdapter;
  private readonly health: ProviderHealthStore;
  private readonly now: () => number;

  constructor(options: ProviderRouterOptions) {
    this.adapters = options.adapters;
    this.primary = options.primary;
    this.health = options.health;
    this.now = options.now ?? (() => Date.now());
  }

  /**
   * Deterministic candidate ordering.
   * free-first: free costClass first, then unknown, then paid; stable by id.
   * primary-only: just the primary adapter.
   */
  selectCandidates(input: RouterSelectInput = {}): {
    candidates: ProviderAdapter[];
    selectionReason: string;
    policy: RoutingPolicy;
  } {
    const policy: RoutingPolicy = {
      ...DEFAULT_ROUTING_POLICY,
      ...input.policy,
      requiredCapabilities:
        input.requiredCapabilities ??
        input.policy?.requiredCapabilities ??
        DEFAULT_ROUTING_POLICY.requiredCapabilities,
    };

    const preferredId = input.preferredProviderId?.trim() || undefined;
    const required = policy.requiredCapabilities ?? ["text"];
    const allowlist = policy.allowedProviderIds;
    const inAllowlist = (id: string) =>
      !allowlist || allowlist.length === 0 || allowlist.includes(id);

    // --- Preferred provider path (employee binding) ---
    if (preferredId) {
      // Hard cost-policy allowlist: preferred outside allowlist is treated as unavailable.
      if (!inAllowlist(preferredId)) {
        if (policy.mode === "free-first" && policy.maxAttempts > 1) {
          // fall through to free-first with allowlist only
        } else {
          return {
            candidates: [],
            selectionReason: `preferred provider "${preferredId}" blocked by allowedProviderIds policy`,
            policy,
          };
        }
      } else
      // Mock mode binding: only mock, never claim a real provider.
      if (preferredId === "mock") {
        const mock = this.adapters.find((a) => a.id === "mock") ?? this.primary;
        return {
          candidates: [mock],
          selectionReason: `preferred: mock (employee binding mock mode)`,
          policy,
        };
      }

      const preferred = this.adapters.find((a) => a.id === preferredId);
      const preferredOk =
        preferred &&
        inAllowlist(preferredId) &&
        hasCapabilities(preferred, required) &&
        (() => {
          const health = this.health.get(preferred.id);
          if (health) {
            return health.configured && this.health.isAvailableForRequest(preferred.id, this.now());
          }
          const availability = preferred.getAvailability();
          const a = typeof availability === "string" ? availability : "unknown";
          return !isBlockedAvailability(a);
        })();

      if (preferredOk && preferred) {
        // Build fallback chain after preferred (never include mock as silent substitute).
        const fallbacks: ProviderAdapter[] = [];
        if (policy.mode !== "primary-only" && policy.maxAttempts > 1) {
          const excludeMock = true;
          const others = this.adapters.filter((adapter) => {
            if (adapter.id === preferred.id) return false;
            if (!inAllowlist(adapter.id)) return false;
            if (excludeMock && adapter.id === "mock") return false;
            if (!hasCapabilities(adapter, required)) return false;
            const health = this.health.get(adapter.id);
            if (health) {
              if (!health.configured) return false;
              if (!this.health.isAvailableForRequest(adapter.id, this.now())) return false;
            } else {
              const availability = adapter.getAvailability();
              const a = typeof availability === "string" ? availability : "unknown";
              if (isBlockedAvailability(a)) return false;
            }
            return true;
          });
          others.sort((a, b) => {
            const cost = costRank(a) - costRank(b);
            if (cost !== 0) return cost;
            return a.id.localeCompare(b.id);
          });
          fallbacks.push(...others.slice(0, Math.max(0, policy.maxAttempts - 1)));
        }
        const candidates = [preferred, ...fallbacks];
        return {
          candidates,
          selectionReason: `preferred: ${preferredId} first${fallbacks.length ? ` then ${fallbacks.map((f) => f.id).join(" → ")}` : ""}`,
          policy,
        };
      }

      // Preferred missing/unconfigured — do NOT silently use mock.
      // If free-first allows other real providers as fallback when maxAttempts > 1, use them.
      if (policy.mode === "free-first" && policy.maxAttempts > 1) {
        // fall through to free-first below, but force exclude mock
      } else {
        return {
          candidates: [],
          selectionReason: `preferred provider "${preferredId}" is not configured or unavailable (no silent mock substitute)`,
          policy,
        };
      }
    }

    if (policy.mode === "primary-only") {
      return {
        candidates: [this.primary],
        selectionReason: `primary-only: using ${this.primary.id}`,
        policy,
      };
    }

    const excludeMock = policy.excludeMockInFreeFirst !== false || Boolean(preferredId);

    const eligible = this.adapters.filter((adapter) => {
      if (!inAllowlist(adapter.id)) return false;
      if (excludeMock && adapter.id === "mock") return false;
      if (!hasCapabilities(adapter, required)) return false;

      const health = this.health.get(adapter.id);
      if (health) {
        if (!health.configured) return false;
        if (!this.health.isAvailableForRequest(adapter.id, this.now())) return false;
      } else {
        const availability = adapter.getAvailability();
        const a = typeof availability === "string" ? availability : "unknown";
        if (isBlockedAvailability(a)) return false;
      }
      return true;
    });

    eligible.sort((a, b) => {
      const cost = costRank(a) - costRank(b);
      if (cost !== 0) return cost;
      return a.id.localeCompare(b.id);
    });

    const limited = eligible.slice(0, Math.max(1, policy.maxAttempts));
    const reason =
      limited.length === 0
        ? preferredId
          ? `preferred "${preferredId}" unavailable; no alternate real providers`
          : "free-first: no eligible providers (configured + available + capabilities)"
        : preferredId
          ? `preferred "${preferredId}" unavailable; free-first alternates: ${limited.map((a) => a.id).join(" → ")}`
          : `free-first: ordered by costClass then id (${limited.map((a) => a.id).join(" → ")})`;

    return { candidates: limited, selectionReason: reason, policy };
  }

  /**
   * Execute generate with controlled fallback across candidates.
   * Never retries the same provider twice; never infinite loops.
   */
  async executeWithFallback(
    request: GenerateRequest,
    input: RouterSelectInput = {},
  ): Promise<RouterExecuteResult> {
    const { candidates, selectionReason, policy } = this.selectCandidates(input);
    const trace: RouteTrace = {
      mode: policy.mode,
      preferredProviderId: input.preferredProviderId ?? null,
      selectedProviderId: candidates[0]?.id ?? null,
      selectionReason,
      candidates: candidates.map((c) => c.id),
      attempts: [],
      fallbackUsed: false,
      finalProviderId: null,
      success: false,
    };

    if (candidates.length === 0) {
      throw new ProviderError(
        "AUTH",
        "No eligible providers for this request (check configuration and health).",
        false,
      );
    }

    const attempted = new Set<string>();
    let lastError: unknown;

    for (let i = 0; i < candidates.length; i++) {
      const adapter = candidates[i]!;
      if (attempted.has(adapter.id)) continue;
      attempted.add(adapter.id);

      if (i > 0) trace.fallbackUsed = true;

      // Re-check availability (cooldown may apply).
      if (!this.health.isAvailableForRequest(adapter.id, this.now())) {
        const health = this.health.get(adapter.id);
        trace.attempts.push({
          providerId: adapter.id,
          label: adapter.label,
          outcome: "skipped",
          reason: health?.reason ?? "unavailable",
        });
        continue;
      }

      try {
        const response = await adapter.generate(request);
        // Health tracking wrapper may already record success; ensure consistency.
        this.health.recordSuccess(adapter.id, this.now());
        trace.attempts.push({
          providerId: adapter.id,
          label: adapter.label,
          outcome: "success",
        });
        trace.finalProviderId = adapter.id;
        trace.success = true;
        return { response, trace };
      } catch (error) {
        lastError = error;
        const errorClass =
          error instanceof ProviderError ? error.code : ("UNKNOWN" as ProviderErrorClass);
        const recoverable = isRecoverableProviderError(error);

        // Health wrapper may have recorded; ensure failure is stored with sanitization path.
        this.health.recordFailure(adapter.id, error, { atMs: this.now() });

        trace.attempts.push({
          providerId: adapter.id,
          label: adapter.label,
          outcome: "failure",
          errorClass,
          reason: sanitizePublicErrorMessage(error),
        });

        if (!recoverable) {
          // Auth / invalid request / config — stop the chain.
          throw error instanceof ProviderError
            ? error
            : new ProviderError(
                "UNKNOWN",
                sanitizePublicErrorMessage(error),
                false,
              );
        }
        // else continue to next candidate
      }
    }

    // All candidates exhausted.
    if (lastError instanceof ProviderError) throw lastError;
    throw new ProviderError(
      "SERVER_ERROR",
      sanitizePublicErrorMessage(lastError, "All provider attempts failed"),
      true,
    );
  }
}
