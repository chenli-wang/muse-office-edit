/**
 * ToolRegistry — typed tool definitions, permissions, and execution.
 */

export type ToolPermissionLevel = "read" | "write";

export interface ToolContext {
  taskId?: string | null;
  employeeId?: string | null;
  /** Optional clock for deterministic tests. */
  now?: () => number;
}

export interface ToolDefinition<TInput = unknown, TOutput = unknown> {
  name: string;
  description: string;
  permission: ToolPermissionLevel;
  /** JSON-schema-like description for agents (not enforced by ajv — validated in handler). */
  inputSchema: Record<string, unknown>;
  execute(input: TInput, ctx: ToolContext): Promise<TOutput>;
}

export interface ToolAuditEvent {
  id: string;
  type: "tool.invoked";
  taskId: string | null;
  employeeId: string | null;
  toolName: string;
  action: "execute";
  success: boolean;
  /** Relative paths or sanitized summaries only — never secrets/host roots. */
  meta: Record<string, unknown>;
  error?: string;
  createdAt: string;
}

export interface ToolInvokeResult<T = unknown> {
  ok: boolean;
  toolName: string;
  result?: T;
  error?: { code: string; message: string };
  audit: ToolAuditEvent;
}

let auditSeq = 0;

export class ToolRegistry {
  private readonly tools = new Map<string, ToolDefinition>();
  private readonly audits: ToolAuditEvent[] = [];
  private readonly maxAudits = 500;

  register<TInput, TOutput>(def: ToolDefinition<TInput, TOutput>): void {
    if (this.tools.has(def.name)) {
      throw new Error(`Tool already registered: ${def.name}`);
    }
    this.tools.set(def.name, def as ToolDefinition);
  }

  get(name: string): ToolDefinition | undefined {
    return this.tools.get(name);
  }

  list(): Array<{
    name: string;
    description: string;
    permission: ToolPermissionLevel;
    inputSchema: Record<string, unknown>;
  }> {
    return [...this.tools.values()].map((t) => ({
      name: t.name,
      description: t.description,
      permission: t.permission,
      inputSchema: t.inputSchema,
    }));
  }

  listAudits(): ToolAuditEvent[] {
    return this.audits.map((a) => ({ ...a, meta: { ...a.meta } }));
  }

  clearAudits(): void {
    this.audits.length = 0;
  }

  async invoke<T = unknown>(
    name: string,
    input: unknown,
    ctx: ToolContext = {},
  ): Promise<ToolInvokeResult<T>> {
    const tool = this.tools.get(name);
    const createdAt = new Date(ctx.now?.() ?? Date.now()).toISOString();
    const baseAudit = {
      id: `tool_${++auditSeq}`,
      type: "tool.invoked" as const,
      taskId: ctx.taskId ?? null,
      employeeId: ctx.employeeId ?? null,
      toolName: name,
      action: "execute" as const,
      createdAt,
    };

    if (!tool) {
      const audit: ToolAuditEvent = {
        ...baseAudit,
        success: false,
        meta: {},
        error: `Unknown tool: ${name}`,
      };
      this.pushAudit(audit);
      return {
        ok: false,
        toolName: name,
        error: { code: "UNKNOWN_TOOL", message: `Unknown tool: ${name}` },
        audit,
      };
    }

    try {
      const result = (await tool.execute(input, ctx)) as T;
      const audit: ToolAuditEvent = {
        ...baseAudit,
        success: true,
        meta: summarizeResult(name, result),
      };
      this.pushAudit(audit);
      return { ok: true, toolName: name, result, audit };
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Tool execution failed";
      const code =
        error && typeof error === "object" && "code" in error
          ? String((error as { code: string }).code)
          : "TOOL_ERROR";
      const audit: ToolAuditEvent = {
        ...baseAudit,
        success: false,
        meta: {},
        error: message.slice(0, 240),
      };
      this.pushAudit(audit);
      return {
        ok: false,
        toolName: name,
        error: { code, message: message.slice(0, 240) },
        audit,
      };
    }
  }

  private pushAudit(event: ToolAuditEvent): void {
    this.audits.push(event);
    if (this.audits.length > this.maxAudits) {
      this.audits.splice(0, this.audits.length - this.maxAudits);
    }
  }
}

function summarizeResult(toolName: string, result: unknown): Record<string, unknown> {
  if (!result || typeof result !== "object") return {};
  const r = result as Record<string, unknown>;
  switch (toolName) {
    case "project.list":
      return {
        count: Array.isArray(r.entries) ? r.entries.length : 0,
        path: typeof r.path === "string" ? r.path : undefined,
      };
    case "project.read":
      return {
        path: typeof r.path === "string" ? r.path : undefined,
        bytes: typeof r.bytes === "number" ? r.bytes : undefined,
      };
    case "project.search":
      return {
        matchCount: Array.isArray(r.matches) ? r.matches.length : 0,
        query: typeof r.query === "string" ? r.query.slice(0, 80) : undefined,
      };
    case "project.write":
      return {
        path: typeof r.path === "string" ? r.path : undefined,
        bytesWritten: typeof r.bytesWritten === "number" ? r.bytesWritten : undefined,
        created: r.created === true,
      };
    case "project.metadata":
      return {
        workspaceId: typeof r.workspaceId === "string" ? r.workspaceId : undefined,
        fileCount: typeof r.fileCount === "number" ? r.fileCount : undefined,
      };
    default:
      return {};
  }
}
