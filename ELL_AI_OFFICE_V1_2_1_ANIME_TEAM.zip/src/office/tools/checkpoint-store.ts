/**
 * In-memory checkpoints for controlled mutation batches (not a fake Git).
 */

import { randomUUID } from "node:crypto";
import {
  existsSync,
  readFileSync,
  writeFileSync,
  unlinkSync,
  mkdirSync,
  renameSync,
  statSync,
} from "node:fs";
import { dirname, join, basename } from "node:path";
import type { WorkspaceScope } from "./workspace-scope.ts";
import { WorkspaceError } from "./workspace-scope.ts";
import {
  type ChangeSet,
  type FileChange,
  type FileDiffSummary,
  buildDiffPreview,
  contentHash,
  ChangeSetError,
  DEFAULT_CHANGE_SET_LIMITS,
} from "./change-set.ts";

export interface CheckpointFileSnapshot {
  path: string;
  existed: boolean;
  content: string | null;
  hash: string | null;
}

export interface Checkpoint {
  id: string;
  changeSetId: string;
  taskId: string | null;
  employeeId: string | null;
  createdAt: string;
  snapshots: CheckpointFileSnapshot[];
  status: "open" | "committed" | "rolled_back";
}

export interface ApplyResult {
  changeSet: ChangeSet;
  checkpoint: Checkpoint;
  diffs: FileDiffSummary[];
}

export class CheckpointStore {
  private readonly checkpoints = new Map<string, Checkpoint>();
  private readonly changeSets = new Map<string, ChangeSet>();
  private readonly now: () => number;

  constructor(options?: { now?: () => number }) {
    this.now = options?.now ?? (() => Date.now());
  }

  getChangeSet(id: string): ChangeSet | undefined {
    const cs = this.changeSets.get(id);
    return cs ? structuredClone(cs) : undefined;
  }

  getCheckpoint(id: string): Checkpoint | undefined {
    const cp = this.checkpoints.get(id);
    return cp ? structuredClone(cp) : undefined;
  }

  listChangeSets(): ChangeSet[] {
    return [...this.changeSets.values()].map((c) => structuredClone(c));
  }

  /**
   * Snapshot current file state for paths in the change set, then apply mutations.
   */
  applyChangeSet(
    scope: WorkspaceScope,
    input: {
      changes: FileChange[];
      taskId?: string | null;
      employeeId?: string | null;
      label?: string;
    },
  ): ApplyResult {
    const ts = new Date(this.now()).toISOString();
    const changeSetId = `cs_${randomUUID()}`;
    const checkpointId = `cp_${randomUUID()}`;

    const changeSet: ChangeSet = {
      id: changeSetId,
      taskId: input.taskId ?? null,
      employeeId: input.employeeId ?? null,
      label: input.label ?? "change-set",
      changes: input.changes.map((c) => ({ ...c })),
      status: "draft",
      createdAt: ts,
      appliedAt: null,
      error: null,
    };

    const snapshots: CheckpointFileSnapshot[] = [];
    const diffs: FileDiffSummary[] = [];

    // Phase 1: validate all paths + capture snapshots (no writes yet)
    for (const change of input.changes) {
      let abs: string;
      try {
        abs = scope.resolveSafe(change.path);
      } catch (err) {
        const msg =
          err instanceof WorkspaceError ? err.message : "Path outside workspace";
        throw new ChangeSetError("BOUNDARY", msg);
      }

      const existed = existsSync(abs);
      let before: string | null = null;
      if (existed) {
        const st = statSync(abs);
        if (st.isDirectory()) {
          throw new ChangeSetError("CONFLICT", `Path is a directory: ${change.path}`);
        }
        before = readFileSync(abs, "utf8");
      }

      if (change.operation === "create" && existed) {
        throw new ChangeSetError(
          "CONFLICT",
          `Cannot create; file already exists: ${change.path}`,
        );
      }
      if ((change.operation === "update" || change.operation === "delete") && !existed) {
        throw new ChangeSetError("NOT_FOUND", `File not found: ${change.path}`);
      }

      snapshots.push({
        path: change.path,
        existed,
        content: before,
        hash: before != null ? contentHash(before) : null,
      });
    }

    const checkpoint: Checkpoint = {
      id: checkpointId,
      changeSetId,
      taskId: input.taskId ?? null,
      employeeId: input.employeeId ?? null,
      createdAt: ts,
      snapshots,
      status: "open",
    };

    // Phase 2: apply writes atomically per file
    try {
      for (const change of input.changes) {
        const abs = scope.resolveSafe(change.path);
        const snap = snapshots.find((s) => s.path === change.path)!;
        if (change.operation === "delete") {
          unlinkSync(abs);
          diffs.push({
            path: change.path,
            operation: "delete",
            beforeHash: snap.hash,
            afterHash: null,
            beforeBytes: snap.content != null ? Buffer.byteLength(snap.content) : null,
            afterBytes: null,
            preview: buildDiffPreview(snap.content, null),
          });
          continue;
        }

        const content = change.content ?? "";
        const parent = dirname(abs);
        if (!existsSync(parent)) {
          scope.toRelative(parent === scope.root ? scope.root : parent);
          mkdirSync(parent, { recursive: true });
        }
        const tmp = join(parent, `.${basename(abs)}.${process.pid}.${Date.now()}.tmp`);
        try {
          writeFileSync(tmp, content, { encoding: "utf8", flag: "w" });
          renameSync(tmp, abs);
        } catch (err) {
          try {
            if (existsSync(tmp)) unlinkSync(tmp);
          } catch {
            /* ignore */
          }
          throw err;
        }
        diffs.push({
          path: change.path,
          operation: change.operation,
          beforeHash: snap.hash,
          afterHash: contentHash(content),
          beforeBytes: snap.content != null ? Buffer.byteLength(snap.content) : null,
          afterBytes: Buffer.byteLength(content),
          preview: buildDiffPreview(snap.content, content),
        });
      }
    } catch (err) {
      // Best-effort rollback of partial apply
      try {
        this.restoreSnapshots(scope, snapshots);
      } catch {
        /* report original */
      }
      changeSet.status = "failed";
      changeSet.error =
        err instanceof Error ? err.message.slice(0, 240) : "apply failed";
      this.changeSets.set(changeSetId, changeSet);
      throw err instanceof ChangeSetError
        ? err
        : new ChangeSetError("INVALID", changeSet.error);
    }

    changeSet.status = "applied";
    changeSet.appliedAt = new Date(this.now()).toISOString();
    checkpoint.status = "committed";
    this.changeSets.set(changeSetId, changeSet);
    this.checkpoints.set(checkpointId, checkpoint);

    return {
      changeSet: structuredClone(changeSet),
      checkpoint: structuredClone(checkpoint),
      diffs,
    };
  }

  rollback(scope: WorkspaceScope, checkpointId: string): Checkpoint {
    const cp = this.checkpoints.get(checkpointId);
    if (!cp) throw new ChangeSetError("NOT_FOUND", "Checkpoint not found");
    if (cp.status === "rolled_back") return structuredClone(cp);

    this.restoreSnapshots(scope, cp.snapshots);
    cp.status = "rolled_back";
    const cs = this.changeSets.get(cp.changeSetId);
    if (cs) {
      cs.status = "rolled_back";
    }
    return structuredClone(cp);
  }

  private restoreSnapshots(
    scope: WorkspaceScope,
    snapshots: CheckpointFileSnapshot[],
  ): void {
    for (const snap of snapshots) {
      const abs = scope.resolveSafe(snap.path);
      if (!snap.existed) {
        if (existsSync(abs)) unlinkSync(abs);
        continue;
      }
      const parent = dirname(abs);
      if (!existsSync(parent)) mkdirSync(parent, { recursive: true });
      const tmp = join(parent, `.${basename(abs)}.rollback.${Date.now()}.tmp`);
      writeFileSync(tmp, snap.content ?? "", "utf8");
      renameSync(tmp, abs);
    }
  }
}

export { DEFAULT_CHANGE_SET_LIMITS };
