export { WorkspaceScope, WorkspaceError } from "./workspace-scope.ts";
export {
  ToolRegistry,
  type ToolDefinition,
  type ToolContext,
  type ToolAuditEvent,
  type ToolInvokeResult,
  type ToolPermissionLevel,
} from "./tool-registry.ts";
export {
  createProjectTools,
  registerProjectTools,
  DEFAULT_PROJECT_LIMITS,
  type ProjectToolLimits,
} from "./project-tools.ts";

export {
  runToolLoop,
  parseAssistantTurn,
  sanitizeToolResultPayload,
  DEFAULT_TOOL_LOOP_LIMITS,
  DEFAULT_EMPLOYEE_PERMISSIONS,
  type ToolLoopOptions,
  type ToolLoopResult,
  type ToolLoopLimits,
  type EmployeeToolPermissions,
  type ToolCallRequest,
  type ParsedAssistantTurn,
} from "./tool-loop.ts";

export * from "./change-set.ts";
export * from "./checkpoint-store.ts";
export * from "./validation.ts";
export * from "./project-execution.ts";
