/**
 * Project workspace tools: list, read, search, write, metadata.
 * All paths confined to WorkspaceScope.
 */

import {
  readdirSync,
  readFileSync,
  writeFileSync,
  renameSync,
  statSync,
  existsSync,
  unlinkSync,
  mkdirSync,
} from "node:fs";
import { join, dirname, basename } from "node:path";
import { WorkspaceScope, WorkspaceError } from "./workspace-scope.ts";
import type { ToolDefinition, ToolRegistry } from "./tool-registry.ts";

export interface ProjectToolLimits {
  maxListEntries: number;
  maxListDepth: number;
  maxReadBytes: number;
  maxWriteBytes: number;
  maxSearchMatches: number;
  maxSearchFileBytes: number;
}

export const DEFAULT_PROJECT_LIMITS: ProjectToolLimits = {
  maxListEntries: 200,
  maxListDepth: 4,
  maxReadBytes: 256_000,
  maxWriteBytes: 256_000,
  maxSearchMatches: 50,
  maxSearchFileBytes: 128_000,
};

export interface ListEntry {
  path: string;
  type: "file" | "directory";
  size: number | null;
}

function isTextish(buf: Buffer): boolean {
  // Reject if too many nulls in first 512 bytes.
  const sample = buf.subarray(0, Math.min(512, buf.length));
  let nulls = 0;
  for (const b of sample) if (b === 0) nulls++;
  return nulls < 4;
}

export function createProjectTools(
  scope: WorkspaceScope,
  limits: ProjectToolLimits = DEFAULT_PROJECT_LIMITS,
): ToolDefinition[] {
  const listTool: ToolDefinition = {
    name: "project.list",
    description: "List files and directories under a relative path inside the project workspace.",
    permission: "read",
    inputSchema: {
      type: "object",
      properties: {
        path: { type: "string", description: "Relative path (default: workspace root)" },
        depth: { type: "number", description: "Max depth (default 1, capped)" },
      },
    },
    async execute(input: unknown) {
      const body = (input ?? {}) as { path?: string; depth?: number };
      const rel = body.path?.trim() || ".";
      const abs = scope.resolveSafe(rel);
      if (!existsSync(abs)) {
        throw new WorkspaceError("NOT_FOUND", `Path not found: ${scope.toRelative(abs)}`);
      }
      const st = statSync(abs);
      if (!st.isDirectory()) {
        return {
          path: scope.toRelative(abs),
          entries: [
            {
              path: scope.toRelative(abs),
              type: "file" as const,
              size: st.size,
            },
          ],
        };
      }
      const maxDepth = Math.min(
        Math.max(1, Number(body.depth) || 1),
        limits.maxListDepth,
      );
      const entries: ListEntry[] = [];
      const walk = (dir: string, depth: number) => {
        if (entries.length >= limits.maxListEntries) return;
        let names: string[];
        try {
          names = readdirSync(dir).sort((a, b) => a.localeCompare(b));
        } catch {
          return;
        }
        for (const name of names) {
          if (entries.length >= limits.maxListEntries) break;
          if (name === ".git" || name === "node_modules") continue;
          const full = join(dir, name);
          let s;
          try {
            s = statSync(full);
          } catch {
            continue;
          }
          const relPath = scope.toRelative(full);
          if (s.isDirectory()) {
            entries.push({ path: relPath, type: "directory", size: null });
            if (depth < maxDepth) walk(full, depth + 1);
          } else if (s.isFile()) {
            entries.push({ path: relPath, type: "file", size: s.size });
          }
        }
      };
      walk(abs, 1);
      entries.sort((a, b) => a.path.localeCompare(b.path));
      return {
        path: scope.toRelative(abs),
        entries,
        truncated: entries.length >= limits.maxListEntries,
      };
    },
  };

  const readTool: ToolDefinition = {
    name: "project.read",
    description: "Read a text file inside the project workspace.",
    permission: "read",
    inputSchema: {
      type: "object",
      properties: {
        path: { type: "string", description: "Relative file path" },
        maxBytes: { type: "number" },
      },
      required: ["path"],
    },
    async execute(input: unknown) {
      const body = (input ?? {}) as { path?: string; maxBytes?: number };
      if (!body.path?.trim()) {
        throw new WorkspaceError("INVALID_PATH", "path is required");
      }
      const abs = scope.resolveSafe(body.path);
      if (!existsSync(abs)) {
        throw new WorkspaceError("NOT_FOUND", `File not found: ${body.path}`);
      }
      const st = statSync(abs);
      if (st.isDirectory()) {
        throw new WorkspaceError("IS_DIRECTORY", "Cannot read a directory; use project.list");
      }
      const maxBytes = Math.min(
        Math.max(1, Number(body.maxBytes) || limits.maxReadBytes),
        limits.maxReadBytes,
      );
      if (st.size > maxBytes) {
        throw new WorkspaceError(
          "TOO_LARGE",
          `File exceeds max read size (${maxBytes} bytes).`,
        );
      }
      const buf = readFileSync(abs);
      if (!isTextish(buf)) {
        throw new WorkspaceError("INVALID_PATH", "File appears binary; read is text-only.");
      }
      const content = buf.toString("utf8");
      return {
        path: scope.toRelative(abs),
        bytes: buf.length,
        content,
      };
    },
  };

  const searchTool: ToolDefinition = {
    name: "project.search",
    description:
      "Search filenames and/or text content under the workspace. Results are bounded and ordered.",
    permission: "read",
    inputSchema: {
      type: "object",
      properties: {
        query: { type: "string" },
        path: { type: "string", description: "Subtree root (relative)" },
        inContent: { type: "boolean", description: "Search file contents (default true)" },
        inNames: { type: "boolean", description: "Search file names (default true)" },
      },
      required: ["query"],
    },
    async execute(input: unknown) {
      const body = (input ?? {}) as {
        query?: string;
        path?: string;
        inContent?: boolean;
        inNames?: boolean;
      };
      const query = (body.query ?? "").trim();
      if (!query) throw new WorkspaceError("INVALID_PATH", "query is required");
      if (query.length > 200) {
        throw new WorkspaceError("LIMIT", "query too long (max 200)");
      }
      const inContent = body.inContent !== false;
      const inNames = body.inNames !== false;
      const start = scope.resolveSafe(body.path?.trim() || ".");
      if (!existsSync(start)) {
        throw new WorkspaceError("NOT_FOUND", "Search path not found");
      }

      const q = query.toLowerCase();
      const matches: Array<{ path: string; kind: "name" | "content"; line?: number; snippet?: string }> =
        [];

      const walk = (dir: string) => {
        if (matches.length >= limits.maxSearchMatches) return;
        let names: string[];
        try {
          names = readdirSync(dir).sort((a, b) => a.localeCompare(b));
        } catch {
          return;
        }
        for (const name of names) {
          if (matches.length >= limits.maxSearchMatches) break;
          if (name === ".git" || name === "node_modules") continue;
          const full = join(dir, name);
          let s;
          try {
            s = statSync(full);
          } catch {
            continue;
          }
          const relPath = scope.toRelative(full);
          if (s.isDirectory()) {
            walk(full);
            continue;
          }
          if (!s.isFile()) continue;
          if (inNames && name.toLowerCase().includes(q)) {
            matches.push({ path: relPath, kind: "name" });
          }
          if (inContent && s.size <= limits.maxSearchFileBytes && matches.length < limits.maxSearchMatches) {
            try {
              const buf = readFileSync(full);
              if (!isTextish(buf)) continue;
              const text = buf.toString("utf8");
              const lines = text.split(/\r?\n/);
              for (let i = 0; i < lines.length; i++) {
                if (matches.length >= limits.maxSearchMatches) break;
                if (lines[i]!.toLowerCase().includes(q)) {
                  matches.push({
                    path: relPath,
                    kind: "content",
                    line: i + 1,
                    snippet: lines[i]!.slice(0, 160),
                  });
                }
              }
            } catch {
              /* skip unreadable */
            }
          }
        }
      };

      const rootStat = statSync(start);
      if (rootStat.isFile()) {
        // Search exactly the requested file; do not broaden to its parent directory.
        const relPath = scope.toRelative(start);
        const fileName = basename(start);
        if (inNames && fileName.toLowerCase().includes(q)) {
          matches.push({ path: relPath, kind: "name" });
        }
        if (inContent && rootStat.size <= limits.maxSearchFileBytes && matches.length < limits.maxSearchMatches) {
          try {
            const buf = readFileSync(start);
            if (isTextish(buf)) {
              const text = buf.toString("utf8");
              const lines = text.split(/\r?\n/);
              for (let i = 0; i < lines.length && matches.length < limits.maxSearchMatches; i++) {
                if (lines[i]!.toLowerCase().includes(q)) {
                  matches.push({
                    path: relPath,
                    kind: "content",
                    line: i + 1,
                    snippet: lines[i]!.slice(0, 160),
                  });
                }
              }
            }
          } catch {
            /* skip unreadable */
          }
        }
      } else {
        walk(start);
      }

      matches.sort((a, b) => {
        const p = a.path.localeCompare(b.path);
        if (p !== 0) return p;
        return (a.line ?? 0) - (b.line ?? 0);
      });

      return {
        query,
        matches,
        truncated: matches.length >= limits.maxSearchMatches,
      };
    },
  };

  const writeTool: ToolDefinition = {
    name: "project.write",
    description: "Create or update a text file inside the project workspace (atomic write).",
    permission: "write",
    inputSchema: {
      type: "object",
      properties: {
        path: { type: "string" },
        content: { type: "string" },
      },
      required: ["path", "content"],
    },
    async execute(input: unknown) {
      const body = (input ?? {}) as { path?: string; content?: string };
      if (!body.path?.trim()) {
        throw new WorkspaceError("INVALID_PATH", "path is required");
      }
      if (typeof body.content !== "string") {
        throw new WorkspaceError("INVALID_PATH", "content must be a string");
      }
      const content = body.content;
      const bytes = Buffer.byteLength(content, "utf8");
      if (bytes > limits.maxWriteBytes) {
        throw new WorkspaceError(
          "TOO_LARGE",
          `Content exceeds max write size (${limits.maxWriteBytes} bytes).`,
        );
      }
      const abs = scope.resolveSafe(body.path);
      const parent = dirname(abs);
      // Parent must stay inside workspace (resolveSafe on relative form).
      if (parent !== scope.root) {
        scope.toRelative(parent);
      }
      if (!existsSync(parent)) {
        mkdirSync(parent, { recursive: true });
        // Re-validate after mkdir
        scope.toRelative(parent);
      }
      const created = !existsSync(abs);
      if (!created) {
        const st = statSync(abs);
        if (st.isDirectory()) {
          throw new WorkspaceError("IS_DIRECTORY", "Cannot write to a directory path");
        }
      }
      // Atomic write: temp in same directory then rename
      const tmp = join(parent, `.${basename(abs)}.${process.pid}.${Date.now()}.tmp`);
      try {
        writeFileSync(tmp, content, { encoding: "utf8", flag: "w" });
        renameSync(tmp, abs);
      } catch (err) {
        try {
          if (existsSync(tmp)) unlinkSync(tmp);
        } catch {
          /* ignore */
        }
        throw err;
      }
      return {
        path: scope.toRelative(abs),
        bytesWritten: bytes,
        created,
      };
    },
  };

  const metadataTool: ToolDefinition = {
    name: "project.metadata",
    description: "Return workspace identifier, limits, and basic file statistics.",
    permission: "read",
    inputSchema: { type: "object", properties: {} },
    async execute() {
      let fileCount = 0;
      let dirCount = 0;
      let totalBytes = 0;
      const walk = (dir: string) => {
        let names: string[];
        try {
          names = readdirSync(dir);
        } catch {
          return;
        }
        for (const name of names) {
          if (name === ".git" || name === "node_modules") continue;
          const full = join(dir, name);
          let s;
          try {
            s = statSync(full);
          } catch {
            continue;
          }
          if (s.isDirectory()) {
            dirCount++;
            walk(full);
          } else if (s.isFile()) {
            fileCount++;
            totalBytes += s.size;
          }
        }
      };
      if (existsSync(scope.root)) walk(scope.root);
      return {
        workspaceId: scope.workspaceId,
        fileCount,
        directoryCount: dirCount,
        totalBytes,
        limits: { ...limits },
        capabilities: ["list", "read", "search", "write", "metadata"],
      };
    },
  };

  return [listTool, readTool, searchTool, writeTool, metadataTool];
}

function relativeSafe(scope: WorkspaceScope, abs: string): string {
  try {
    return scope.toRelative(abs);
  } catch {
    throw new WorkspaceError("OUTSIDE_WORKSPACE", "Parent path outside workspace");
  }
}

export function registerProjectTools(
  registry: ToolRegistry,
  scope: WorkspaceScope,
  limits?: Partial<ProjectToolLimits>,
): void {
  const merged = { ...DEFAULT_PROJECT_LIMITS, ...limits };
  for (const tool of createProjectTools(scope, merged)) {
    registry.register(tool);
  }
}
