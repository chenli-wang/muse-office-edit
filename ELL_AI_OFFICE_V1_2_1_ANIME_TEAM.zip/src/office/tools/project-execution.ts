/**
 * Project execution façade: change sets, checkpoints, validation, diffs.
 */

import type { WorkspaceScope } from "./workspace-scope.ts";
import type { ToolDefinition, ToolRegistry } from "./tool-registry.ts";
import {
  CheckpointStore,
} from "./checkpoint-store.ts";
import {
  validateChangeSetShape,
  DEFAULT_CHANGE_SET_LIMITS,
  ChangeSetError,
} from "./change-set.ts";
import { StaticProjectValidator, type ValidationResult } from "./validation.ts";

export interface ProjectExecutionServices {
  scope: WorkspaceScope;
  checkpoints: CheckpointStore;
  validator: StaticProjectValidator;
}

export function createProjectExecutionServices(
  scope: WorkspaceScope,
): ProjectExecutionServices {
  return {
    scope,
    checkpoints: new CheckpointStore(),
    validator: new StaticProjectValidator(),
  };
}

export function createExecutionTools(
  services: ProjectExecutionServices,
): ToolDefinition[] {
  const { scope, checkpoints, validator } = services;

  const applyTool: ToolDefinition = {
    name: "project.changeset.apply",
    description:
      "Apply a structured change set (create/update/delete) with automatic checkpoint. Paths must be workspace-relative.",
    permission: "write",
    inputSchema: {
      type: "object",
      properties: {
        changes: {
          type: "array",
          items: {
            type: "object",
            properties: {
              path: { type: "string" },
              operation: { type: "string", enum: ["create", "update", "delete"] },
              content: { type: "string" },
            },
          },
        },
        label: { type: "string" },
      },
      required: ["changes"],
    },
    async execute(input, ctx) {
      try {
        const changes = validateChangeSetShape(input, DEFAULT_CHANGE_SET_LIMITS);
        const result = checkpoints.applyChangeSet(scope, {
          changes,
          taskId: ctx.taskId ?? null,
          employeeId: ctx.employeeId ?? null,
          label:
            input && typeof input === "object" && "label" in input
              ? String((input as { label?: string }).label ?? "agent-change")
              : "agent-change",
        });
        return {
          changeSetId: result.changeSet.id,
          checkpointId: result.checkpoint.id,
          status: result.changeSet.status,
          diffs: result.diffs.map((d) => ({
            path: d.path,
            operation: d.operation,
            beforeHash: d.beforeHash,
            afterHash: d.afterHash,
            beforeBytes: d.beforeBytes,
            afterBytes: d.afterBytes,
            preview: d.preview.slice(0, 800),
          })),
        };
      } catch (err) {
        if (err instanceof ChangeSetError) throw err;
        throw err;
      }
    },
  };

  const rollbackTool: ToolDefinition = {
    name: "project.checkpoint.rollback",
    description: "Roll back a change set using its checkpoint id.",
    permission: "write",
    inputSchema: {
      type: "object",
      properties: { checkpointId: { type: "string" } },
      required: ["checkpointId"],
    },
    async execute(input) {
      const body = (input ?? {}) as { checkpointId?: string };
      if (!body.checkpointId?.trim()) {
        throw new ChangeSetError("INVALID", "checkpointId is required");
      }
      const cp = checkpoints.rollback(scope, body.checkpointId.trim());
      return {
        checkpointId: cp.id,
        changeSetId: cp.changeSetId,
        status: cp.status,
      };
    },
  };

  const diffTool: ToolDefinition = {
    name: "project.changeset.get",
    description: "Get change set status and metadata by id.",
    permission: "read",
    inputSchema: {
      type: "object",
      properties: { changeSetId: { type: "string" } },
      required: ["changeSetId"],
    },
    async execute(input) {
      const id = String((input as { changeSetId?: string })?.changeSetId ?? "").trim();
      const cs = checkpoints.getChangeSet(id);
      if (!cs) throw new ChangeSetError("NOT_FOUND", "Change set not found");
      return cs;
    },
  };

  const validateTool: ToolDefinition = {
    name: "project.validate",
    description:
      "Run safe static project validation (no shell). Optional paths limit scope.",
    permission: "read",
    inputSchema: {
      type: "object",
      properties: {
        paths: { type: "array", items: { type: "string" } },
        timeoutMs: { type: "number" },
      },
    },
    async execute(input, ctx) {
      const body = (input ?? {}) as { paths?: string[]; timeoutMs?: number };
      // Wire abort if parent provided via now-only context — tools don't get signal yet;
      // timeout is enforced inside validator.
      const result: ValidationResult = await validator.validate(scope, {
        paths: body.paths,
        timeoutMs: body.timeoutMs,
      });
      void ctx;
      return result;
    },
  };

  return [applyTool, rollbackTool, diffTool, validateTool];
}

export function registerExecutionTools(
  registry: ToolRegistry,
  services: ProjectExecutionServices,
): void {
  for (const tool of createExecutionTools(services)) {
    registry.register(tool);
  }
}
