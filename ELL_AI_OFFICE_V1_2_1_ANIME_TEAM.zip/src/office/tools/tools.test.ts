import assert from "node:assert/strict";
import { describe, it, beforeEach, afterEach } from "node:test";
import { mkdtempSync, rmSync, writeFileSync, mkdirSync, readFileSync, existsSync, symlinkSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { WorkspaceScope, WorkspaceError } from "./workspace-scope.ts";
import { ToolRegistry } from "./tool-registry.ts";
import { registerProjectTools } from "./project-tools.ts";
import { createOfficeRuntime } from "../runtime.ts";

describe("WorkspaceScope", () => {
  let root: string;
  let scope: WorkspaceScope;

  beforeEach(() => {
    root = mkdtempSync(join(tmpdir(), "ell-ws-"));
    scope = new WorkspaceScope({ root });
  });

  afterEach(() => {
    rmSync(root, { recursive: true, force: true });
  });

  it("normalizes relative paths", () => {
    const abs = scope.resolveSafe("src/app.ts");
    assert.ok(abs.startsWith(root));
    assert.equal(scope.toRelative(abs), "src/app.ts");
  });

  it("rejects path traversal", () => {
    assert.throws(() => scope.resolveSafe("../outside"), WorkspaceError);
    assert.throws(() => scope.resolveSafe("foo/../../etc/passwd"), WorkspaceError);
  });

  it("rejects absolute paths", () => {
    assert.throws(() => scope.resolveSafe("/etc/passwd"), WorkspaceError);
  });
});

describe("project tools", () => {
  let root: string;
  let registry: ToolRegistry;

  beforeEach(() => {
    root = mkdtempSync(join(tmpdir(), "ell-proj-"));
    mkdirSync(join(root, "src"));
    writeFileSync(join(root, "src", "main.ts"), "export const x = 1;\n// findme\n", "utf8");
    writeFileSync(join(root, "README.md"), "# Hello\n", "utf8");
    registry = new ToolRegistry();
    registerProjectTools(registry, new WorkspaceScope({ root }), {
      maxListEntries: 50,
      maxReadBytes: 10_000,
      maxWriteBytes: 5_000,
      maxSearchMatches: 20,
    });
  });

  afterEach(() => {
    rmSync(root, { recursive: true, force: true });
  });

  it("registry registration/lookup", () => {
    assert.ok(registry.get("project.list"));
    assert.ok(registry.get("project.read"));
    assert.ok(registry.get("project.search"));
    assert.ok(registry.get("project.write"));
    assert.ok(registry.get("project.metadata"));
    assert.equal(registry.list().length, 5);
  });

  it("list", async () => {
    const r = await registry.invoke("project.list", { path: ".", depth: 2 });
    assert.equal(r.ok, true);
    const entries = (r.result as { entries: Array<{ path: string }> }).entries;
    assert.ok(entries.some((e) => e.path === "README.md"));
    assert.ok(entries.some((e) => e.path === "src/main.ts" || e.path === "src"));
  });

  it("read", async () => {
    const r = await registry.invoke("project.read", { path: "src/main.ts" });
    assert.equal(r.ok, true);
    assert.match((r.result as { content: string }).content, /export const x/);
  });

  it("search name and content", async () => {
    const byName = await registry.invoke("project.search", {
      query: "main",
      inContent: false,
      inNames: true,
    });
    assert.equal(byName.ok, true);
    assert.ok(
      ((byName.result as { matches: unknown[] }).matches.length as number) >= 1,
    );

    const byContent = await registry.invoke("project.search", {
      query: "findme",
      inNames: false,
      inContent: true,
    });
    assert.equal(byContent.ok, true);
    assert.ok((byContent.result as { matches: unknown[] }).matches.length >= 1);
  });

  it("write creates file atomically inside workspace", async () => {
    const r = await registry.invoke("project.write", {
      path: "src/new.ts",
      content: "export const y = 2;\n",
    });
    assert.equal(r.ok, true);
    assert.equal((r.result as { created: boolean }).created, true);
    assert.equal(readFileSync(join(root, "src/new.ts"), "utf8"), "export const y = 2;\n");
  });

  it("write rejects outside workspace", async () => {
    const r = await registry.invoke("project.write", {
      path: "../escape.ts",
      content: "nope",
    });
    assert.equal(r.ok, false);
    assert.equal(r.error?.code, "OUTSIDE_WORKSPACE");
  });

  it("read rejects outside workspace", async () => {
    const r = await registry.invoke("project.read", { path: "../../etc/passwd" });
    assert.equal(r.ok, false);
  });

  it("file-size limits on write", async () => {
    const big = "x".repeat(6_000);
    const r = await registry.invoke("project.write", { path: "big.txt", content: big });
    assert.equal(r.ok, false);
    assert.equal(r.error?.code, "TOO_LARGE");
  });

  it("audit events recorded", async () => {
    registry.clearAudits();
    await registry.invoke("project.metadata", {}, { taskId: "t1", employeeId: "claude" });
    const audits = registry.listAudits();
    assert.equal(audits.length, 1);
    assert.equal(audits[0].toolName, "project.metadata");
    assert.equal(audits[0].success, true);
    assert.equal(audits[0].taskId, "t1");
    assert.equal(audits[0].employeeId, "claude");
  });

  it("metadata does not expose absolute host path as required field", async () => {
    const r = await registry.invoke("project.metadata", {});
    assert.equal(r.ok, true);
    const meta = r.result as Record<string, unknown>;
    assert.ok(typeof meta.workspaceId === "string");
    assert.equal("root" in meta, false);
    const blob = JSON.stringify(meta);
    assert.equal(blob.includes(root), false);
  });
});

describe("runtime tool integration", () => {
  let root: string;

  beforeEach(() => {
    root = mkdtempSync(join(tmpdir(), "ell-rt-"));
    writeFileSync(join(root, "note.txt"), "hello office\n", "utf8");
  });

  afterEach(() => {
    rmSync(root, { recursive: true, force: true });
  });

  it("office runtime exposes listTools and invokeTool", async () => {
    const runtime = createOfficeRuntime({
      workspaceRoot: root,
      delays: { planningMs: 0, assignMs: 0, workMs: 0, synthMs: 0 },
    });
    const tools = runtime.listTools();
    assert.ok(tools.some((t) => t.name === "project.read"));
    const read = await runtime.invokeTool(
      "project.read",
      { path: "note.txt" },
      { taskId: "task_x", employeeId: "claude" },
    );
    assert.equal(read.ok, true);
    assert.match((read.result as { content: string }).content, /hello office/);
    assert.ok(runtime.getWorkspaceId());
  });
});

describe("workspace symlink hardening", () => {
  let root: string;
  let outside: string;

  beforeEach(() => {
    root = mkdtempSync(join(tmpdir(), "ell-symlink-root-"));
    outside = mkdtempSync(join(tmpdir(), "ell-symlink-out-"));
    writeFileSync(join(outside, "secret.txt"), "outside-secret\n", "utf8");
    mkdirSync(join(root, "src"));
  });

  afterEach(() => {
    rmSync(root, { recursive: true, force: true });
    rmSync(outside, { recursive: true, force: true });
  });

  it("rejects an outside file symlink", () => {
    try {
      symlinkSync(join(outside, "secret.txt"), join(root, "src", "secret-link.txt"));
    } catch (err) {
      if ((err as NodeJS.ErrnoException).code === "EPERM" || (err as NodeJS.ErrnoException).code === "EACCES") return;
      throw err;
    }
    const scope = new WorkspaceScope({ root });
    assert.throws(() => scope.resolveSafe("src/secret-link.txt"), WorkspaceError);
  });

  it("rejects an outside directory symlink", () => {
    try {
      symlinkSync(outside, join(root, "outside-link"), "junction");
    } catch (err) {
      if ((err as NodeJS.ErrnoException).code === "EPERM" || (err as NodeJS.ErrnoException).code === "EACCES") return;
      throw err;
    }
    const scope = new WorkspaceScope({ root });
    assert.throws(() => scope.resolveSafe("outside-link/secret.txt"), WorkspaceError);
  });

  it("rejects creating a file through a symlinked parent", async () => {
    try {
      symlinkSync(outside, join(root, "linked"), "junction");
    } catch (err) {
      if ((err as NodeJS.ErrnoException).code === "EPERM" || (err as NodeJS.ErrnoException).code === "EACCES") return;
      throw err;
    }
    const registry = new ToolRegistry();
    registerProjectTools(registry, new WorkspaceScope({ root }));
    const result = await registry.invoke("project.write", {
      path: "linked/new.txt",
      content: "must-not-escape",
    });
    assert.equal(result.ok, false);
    assert.equal(result.error?.code, "OUTSIDE_WORKSPACE");
    assert.equal(existsSync(join(outside, "new.txt")), false);
  });

  it("single-file search does not search its parent directory", async () => {
    writeFileSync(join(root, "src", "target.txt"), "target-content\n", "utf8");
    writeFileSync(join(root, "src", "other.txt"), "target-content\n", "utf8");
    const registry = new ToolRegistry();
    registerProjectTools(registry, new WorkspaceScope({ root }));
    const result = await registry.invoke("project.search", {
      query: "target-content",
      path: "src/target.txt",
      inNames: false,
      inContent: true,
    });
    assert.equal(result.ok, true);
    const matches = (result.result as { matches: Array<{ path: string }> }).matches;
    assert.ok(matches.length > 0);
    assert.ok(matches.every((m) => m.path === "src/target.txt"));
  });
});
