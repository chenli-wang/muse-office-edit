/**
 * WorkspaceScope — single explicit project root with path traversal protection.
 */

import { mkdirSync, existsSync, lstatSync, realpathSync } from "node:fs";
import { resolve, relative, isAbsolute, normalize, sep, join } from "node:path";

export class WorkspaceError extends Error {
  readonly code:
    | "OUTSIDE_WORKSPACE"
    | "INVALID_PATH"
    | "NOT_FOUND"
    | "IS_DIRECTORY"
    | "TOO_LARGE"
    | "LIMIT";

  constructor(
    code: WorkspaceError["code"],
    message: string,
  ) {
    super(message);
    this.name = "WorkspaceError";
    this.code = code;
  }
}

export interface WorkspaceScopeOptions {
  /** Absolute or relative root; resolved once at construction. */
  root: string;
  /** Create root if missing (default true). */
  createIfMissing?: boolean;
}

export class WorkspaceScope {
  readonly root: string;
  /** Opaque id for public metadata (basename only — no full host path). */
  readonly workspaceId: string;

  constructor(options: WorkspaceScopeOptions) {
    const resolved = resolve(options.root);
    if (options.createIfMissing !== false && !existsSync(resolved)) {
      mkdirSync(resolved, { recursive: true });
    }
    this.root = realpathSync(resolved);
    this.workspaceId = resolved.split(sep).filter(Boolean).pop() ?? "workspace";
  }

  /**
   * Resolve a user-supplied relative path into an absolute path inside the workspace.
   * Rejects absolute paths, null bytes, and any result outside the root.
   */
  resolveSafe(userPath: string): string {
    if (userPath == null || typeof userPath !== "string") {
      throw new WorkspaceError("INVALID_PATH", "Path must be a string.");
    }
    const trimmed = userPath.trim();
    if (!trimmed || trimmed === ".") {
      return this.root;
    }
    if (trimmed.includes("\0")) {
      throw new WorkspaceError("INVALID_PATH", "Path contains null byte.");
    }
    // Disallow absolute inputs (unix and windows-ish).
    if (isAbsolute(trimmed) || /^[A-Za-z]:[\\/]/.test(trimmed)) {
      throw new WorkspaceError(
        "OUTSIDE_WORKSPACE",
        "Absolute paths are not allowed; use paths relative to the workspace.",
      );
    }
    // Normalize and resolve under root, then enforce the *filesystem* boundary
    // as well. Lexical checks alone are insufficient because symlinks can point
    // outside the workspace.
    const normalized = normalize(trimmed);
    const candidate = resolve(this.root, normalized);
    const rel = relative(this.root, candidate);
    if (rel.startsWith("..") || isAbsolute(rel)) {
      throw new WorkspaceError(
        "OUTSIDE_WORKSPACE",
        "Path escapes the configured workspace.",
      );
    }

    // Existing paths: reject symlinks and verify their real path is contained.
    if (existsSync(candidate)) {
      try {
        const stat = lstatSync(candidate);
        if (stat.isSymbolicLink()) {
          throw new WorkspaceError(
            "OUTSIDE_WORKSPACE",
            "Symbolic links are not allowed in the workspace tool boundary.",
          );
        }
        const real = realpathSync(candidate);
        const realRel = relative(this.root, real);
        if (realRel.startsWith("..") || isAbsolute(realRel)) {
          throw new WorkspaceError(
            "OUTSIDE_WORKSPACE",
            "Path resolves outside the configured workspace.",
          );
        }
        return real;
      } catch (err) {
        if (err instanceof WorkspaceError) throw err;
        throw new WorkspaceError("OUTSIDE_WORKSPACE", "Path cannot be safely resolved.");
      }
    }

    // New paths: resolve the nearest existing ancestor so a symlinked parent
    // cannot be used to create a file outside the workspace.
    let ancestor = candidate;
    while (!existsSync(ancestor)) {
      const parent = resolve(ancestor, "..");
      if (parent === ancestor) {
        throw new WorkspaceError("OUTSIDE_WORKSPACE", "Path cannot be safely resolved.");
      }
      ancestor = parent;
    }
    try {
      const ancestorStat = lstatSync(ancestor);
      if (ancestorStat.isSymbolicLink()) {
        throw new WorkspaceError(
          "OUTSIDE_WORKSPACE",
          "Symbolic link parent is not allowed.",
        );
      }
      const realAncestor = realpathSync(ancestor);
      const ancestorRel = relative(this.root, realAncestor);
      if (ancestorRel.startsWith("..") || isAbsolute(ancestorRel)) {
        throw new WorkspaceError(
          "OUTSIDE_WORKSPACE",
          "Path resolves outside the configured workspace.",
        );
      }
    } catch (err) {
      if (err instanceof WorkspaceError) throw err;
      throw new WorkspaceError("OUTSIDE_WORKSPACE", "Path cannot be safely resolved.");
    }
    return candidate;
  }

  /** Relative path from workspace root (posix-style separators for stability). */
  toRelative(absolutePath: string): string {
    const rel = relative(this.root, absolutePath);
    if (rel.startsWith("..") || isAbsolute(rel)) {
      throw new WorkspaceError("OUTSIDE_WORKSPACE", "Path is outside workspace.");
    }
    return rel.split(sep).join("/") || ".";
  }

  join(...parts: string[]): string {
    return this.resolveSafe(join(...parts));
  }
}
