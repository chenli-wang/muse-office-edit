/**
 * Structured change-set abstraction for controlled project mutation.
 */

import { createHash } from "node:crypto";

export type ChangeOperation = "create" | "update" | "delete";

export interface FileChange {
  /** Relative path inside workspace only. */
  path: string;
  operation: ChangeOperation;
  /** New content for create/update; omitted for delete. */
  content?: string;
}

export interface ChangeSet {
  id: string;
  taskId: string | null;
  employeeId: string | null;
  label: string;
  changes: FileChange[];
  status: "draft" | "applied" | "rolled_back" | "rejected" | "failed";
  createdAt: string;
  appliedAt: string | null;
  error: string | null;
}

export interface ChangeSetLimits {
  maxFiles: number;
  maxContentBytes: number;
  maxPathLength: number;
}

export const DEFAULT_CHANGE_SET_LIMITS: ChangeSetLimits = {
  maxFiles: 20,
  maxContentBytes: 256_000,
  maxPathLength: 240,
};

export class ChangeSetError extends Error {
  readonly code:
    | "INVALID"
    | "TOO_LARGE"
    | "EMPTY"
    | "BAD_PATH"
    | "CONFLICT"
    | "NOT_FOUND"
    | "PERMISSION"
    | "BOUNDARY";

  constructor(code: ChangeSetError["code"], message: string) {
    super(message);
    this.name = "ChangeSetError";
    this.code = code;
  }
}

export function validateChangeSetShape(
  input: unknown,
  limits: ChangeSetLimits = DEFAULT_CHANGE_SET_LIMITS,
): FileChange[] {
  if (!input || typeof input !== "object") {
    throw new ChangeSetError("INVALID", "Change set must be an object");
  }
  const body = input as { changes?: unknown; files?: unknown };
  const raw = body.changes ?? body.files;
  if (!Array.isArray(raw) || raw.length === 0) {
    throw new ChangeSetError("EMPTY", "Change set must include at least one change");
  }
  if (raw.length > limits.maxFiles) {
    throw new ChangeSetError(
      "TOO_LARGE",
      `Too many files in change set (max ${limits.maxFiles})`,
    );
  }

  const changes: FileChange[] = [];
  const seen = new Set<string>();

  for (const item of raw) {
    if (!item || typeof item !== "object") {
      throw new ChangeSetError("INVALID", "Each change must be an object");
    }
    const row = item as {
      path?: unknown;
      operation?: unknown;
      content?: unknown;
    };
    const path = typeof row.path === "string" ? row.path.trim() : "";
    if (!path || path.length > limits.maxPathLength) {
      throw new ChangeSetError("BAD_PATH", "Invalid or oversized relative path");
    }
    if (path.includes("\0") || path.startsWith("/") || path.includes("..")) {
      // Soft pre-check; WorkspaceScope still enforces hard boundary.
      throw new ChangeSetError("BAD_PATH", "Path must be relative and non-escaping");
    }
    if (seen.has(path)) {
      throw new ChangeSetError("CONFLICT", `Duplicate path in change set: ${path}`);
    }
    seen.add(path);

    const op = row.operation;
    if (op !== "create" && op !== "update" && op !== "delete") {
      throw new ChangeSetError("INVALID", `Invalid operation for ${path}`);
    }
    if (op === "delete") {
      changes.push({ path, operation: "delete" });
      continue;
    }
    if (typeof row.content !== "string") {
      throw new ChangeSetError("INVALID", `Content required for ${op} on ${path}`);
    }
    const bytes = Buffer.byteLength(row.content, "utf8");
    if (bytes > limits.maxContentBytes) {
      throw new ChangeSetError(
        "TOO_LARGE",
        `Content for ${path} exceeds max ${limits.maxContentBytes} bytes`,
      );
    }
    changes.push({ path, operation: op, content: row.content });
  }

  return changes;
}

export function contentHash(content: string): string {
  return createHash("sha256").update(content, "utf8").digest("hex").slice(0, 16);
}

export interface FileDiffSummary {
  path: string;
  operation: ChangeOperation;
  beforeHash: string | null;
  afterHash: string | null;
  beforeBytes: number | null;
  afterBytes: number | null;
  /** Bounded unified-ish preview (not a full git diff). */
  preview: string;
}

export function buildDiffPreview(
  before: string | null,
  after: string | null,
  maxLines = 40,
): string {
  const bLines = (before ?? "").split(/\r?\n/);
  const aLines = (after ?? "").split(/\r?\n/);
  const lines: string[] = [];
  const max = Math.max(bLines.length, aLines.length);
  for (let i = 0; i < max && lines.length < maxLines; i++) {
    const b = bLines[i];
    const a = aLines[i];
    if (b === a) continue;
    if (b !== undefined && a === undefined) lines.push(`- ${b.slice(0, 120)}`);
    else if (b === undefined && a !== undefined) lines.push(`+ ${a.slice(0, 120)}`);
    else {
      lines.push(`- ${(b ?? "").slice(0, 120)}`);
      if (lines.length < maxLines) lines.push(`+ ${(a ?? "").slice(0, 120)}`);
    }
  }
  if (lines.length === 0) return "(no line-level changes)";
  if (max > maxLines) lines.push("…");
  return lines.join("\n");
}
