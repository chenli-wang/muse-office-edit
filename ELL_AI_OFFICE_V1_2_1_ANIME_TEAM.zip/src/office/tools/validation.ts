/**
 * Provider-neutral project validation — NO unrestricted shell.
 * Safe static checks only (existence, encoding, simple syntax heuristics).
 */

import { existsSync, readFileSync, readdirSync, statSync } from "node:fs";
import { join, extname } from "node:path";
import type { WorkspaceScope } from "./workspace-scope.ts";
import { WorkspaceError } from "./workspace-scope.ts";

export type ValidationStatus = "pass" | "fail" | "error";

export interface ValidationIssue {
  path: string | null;
  severity: "error" | "warning";
  message: string;
}

export interface ValidationResult {
  status: ValidationStatus;
  issues: ValidationIssue[];
  checkedFiles: number;
  durationMs: number;
  validator: string;
}

export interface Validator {
  id: string;
  validate(
    scope: WorkspaceScope,
    options?: { paths?: string[]; signal?: AbortSignal; timeoutMs?: number },
  ): Promise<ValidationResult>;
}

function isTextish(buf: Buffer): boolean {
  const sample = buf.subarray(0, Math.min(512, buf.length));
  let nulls = 0;
  for (const b of sample) if (b === 0) nulls++;
  return nulls < 4;
}

/** Balanced bracket heuristic for TS/JS/JSON — not a full parser. */
function bracketBalance(text: string): string | null {
  const stack: string[] = [];
  const pairs: Record<string, string> = { ")": "(", "]": "[", "}": "{" };
  let inStr: string | null = null;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i]!;
    if (inStr) {
      if (ch === "\\" && inStr !== "`") {
        i++;
        continue;
      }
      if (ch === inStr) inStr = null;
      continue;
    }
    if (ch === '"' || ch === "'" || ch === "`") {
      inStr = ch;
      continue;
    }
    if (ch === "(" || ch === "[" || ch === "{") stack.push(ch);
    if (ch === ")" || ch === "]" || ch === "}") {
      if (stack.pop() !== pairs[ch]) return `Unbalanced '${ch}' near offset ${i}`;
    }
  }
  if (stack.length) return `Unclosed '${stack[stack.length - 1]}'`;
  return null;
}

export class StaticProjectValidator implements Validator {
  readonly id = "static-project";

  async validate(
    scope: WorkspaceScope,
    options?: { paths?: string[]; signal?: AbortSignal; timeoutMs?: number },
  ): Promise<ValidationResult> {
    const started = Date.now();
    const timeoutMs = options?.timeoutMs ?? 5_000;
    const issues: ValidationIssue[] = [];
    let checked = 0;

    const timedOut = () => Date.now() - started > timeoutMs;
    const aborted = () => options?.signal?.aborted;

    const targets: string[] = [];
    if (options?.paths?.length) {
      for (const p of options.paths) {
        try {
          targets.push(scope.resolveSafe(p));
        } catch (err) {
          issues.push({
            path: p,
            severity: "error",
            message:
              err instanceof WorkspaceError
                ? err.message
                : "Path outside workspace",
          });
        }
      }
    } else {
      const walk = (dir: string) => {
        if (timedOut() || aborted()) return;
        let names: string[];
        try {
          names = readdirSync(dir);
        } catch {
          return;
        }
        for (const name of names) {
          if (name === ".git" || name === "node_modules") continue;
          const full = join(dir, name);
          let st;
          try {
            st = statSync(full);
          } catch {
            continue;
          }
          if (st.isDirectory()) walk(full);
          else if (st.isFile()) targets.push(full);
        }
      };
      walk(scope.root);
    }

    for (const abs of targets) {
      if (aborted()) {
        return {
          status: "error",
          issues: [...issues, { path: null, severity: "error", message: "Validation cancelled" }],
          checkedFiles: checked,
          durationMs: Date.now() - started,
          validator: this.id,
        };
      }
      if (timedOut()) {
        return {
          status: "error",
          issues: [...issues, { path: null, severity: "error", message: "Validation timeout" }],
          checkedFiles: checked,
          durationMs: Date.now() - started,
          validator: this.id,
        };
      }
      if (!existsSync(abs)) {
        issues.push({
          path: scope.toRelative(abs),
          severity: "error",
          message: "File missing",
        });
        continue;
      }
      const st = statSync(abs);
      if (!st.isFile()) continue;
      if (st.size > 256_000) {
        issues.push({
          path: scope.toRelative(abs),
          severity: "warning",
          message: "Skipped large file (>256KB)",
        });
        continue;
      }
      let buf: Buffer;
      try {
        buf = readFileSync(abs);
      } catch {
        issues.push({
          path: scope.toRelative(abs),
          severity: "error",
          message: "Unreadable file",
        });
        continue;
      }
      checked++;
      if (!isTextish(buf)) continue;
      const text = buf.toString("utf8");
      const ext = extname(abs).toLowerCase();
      if ([".ts", ".tsx", ".js", ".jsx", ".json", ".mjs", ".cjs"].includes(ext)) {
        const bal = bracketBalance(text);
        if (bal) {
          issues.push({
            path: scope.toRelative(abs),
            severity: "error",
            message: bal,
          });
        }
      }
      if (ext === ".json") {
        try {
          JSON.parse(text);
        } catch (e) {
          issues.push({
            path: scope.toRelative(abs),
            severity: "error",
            message: e instanceof Error ? `JSON: ${e.message}` : "Invalid JSON",
          });
        }
      }
    }

    const hasError = issues.some((i) => i.severity === "error");
    return {
      status: hasError ? "fail" : "pass",
      issues,
      checkedFiles: checked,
      durationMs: Date.now() - started,
      validator: this.id,
    };
  }
}
