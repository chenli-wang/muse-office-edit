import assert from "node:assert/strict";
import { describe, it } from "node:test";
import {
  CollaborationManager,
} from "./collaboration-manager.ts";
import {
  CollaborationError,
  sanitizeCollaborationContent,
} from "./protocol.ts";
import { createOfficeRuntime, replaceOffice } from "../runtime.ts";
import { createProviderRegistry } from "../provider-registry.ts";
import { MockProvider } from "../providers.ts";
import { MultiAgentOrchestrator } from "../multi-agent-orchestrator.ts";
import { createMultiAgentRoster } from "../employees.ts";

describe("collaboration protocol", () => {
  it("basic agent message and broadcast", () => {
    const cm = new CollaborationManager();
    const s = cm.start({ taskId: "t1", projectId: "p1" });
    const m = cm.postMessage({
      collaborationId: s.id,
      type: "finding",
      senderEmployeeId: "claude",
      recipientEmployeeId: "*",
      content: "Found N+1 query",
    });
    assert.equal(m.type, "finding");
    assert.equal(m.recipientEmployeeId, "*");
    const ctx = cm.getContextFor(s.id, "gpt");
    assert.ok(ctx.messages.length >= 1);
  });

  it("handoff with reason", () => {
    const cm = new CollaborationManager();
    const s = cm.start({ taskId: "t1", projectId: "p1" });
    const h = cm.postMessage({
      collaborationId: s.id,
      type: "handoff",
      senderEmployeeId: "claude",
      recipientEmployeeId: "gemini",
      content: "Need research on auth patterns",
      handoffReason: "missing domain context",
    });
    assert.equal(h.type, "handoff");
    assert.ok(h.handoffReason);
  });

  it("review request and response with verdict", () => {
    const cm = new CollaborationManager();
    const s = cm.start({ taskId: "t1", projectId: "p1" });
    cm.postMessage({
      collaborationId: s.id,
      type: "artifact",
      senderEmployeeId: "claude",
      content: "PR proposal",
      changeSetId: "cs_1",
      artifactRef: "art_1",
    });
    cm.postMessage({
      collaborationId: s.id,
      type: "review_request",
      senderEmployeeId: "claude",
      recipientEmployeeId: "gpt",
      content: "Please review",
      artifactRef: "art_1",
      changeSetId: "cs_1",
    });
    const review = cm.postMessage({
      collaborationId: s.id,
      type: "review",
      senderEmployeeId: "gpt",
      recipientEmployeeId: "claude",
      content: "Looks good with minor notes",
      artifactRef: "art_1",
      changeSetId: "cs_1",
      reviewVerdict: "approve_with_changes",
    });
    assert.equal(review.reviewVerdict, "approve_with_changes");
  });

  it("challenge and disagreement preserved", () => {
    const cm = new CollaborationManager();
    const s = cm.start({ taskId: "t1", projectId: "p1" });
    cm.postMessage({
      collaborationId: s.id,
      type: "proposal",
      senderEmployeeId: "claude",
      content: "Use polling",
    });
    const ch = cm.postMessage({
      collaborationId: s.id,
      type: "challenge",
      senderEmployeeId: "grok",
      recipientEmployeeId: "claude",
      content: "Polling will miss events under load",
    });
    assert.equal(ch.type, "challenge");
    const msgs = cm.listMessages(s.id);
    assert.ok(msgs.some((m) => m.type === "proposal"));
    assert.ok(msgs.some((m) => m.type === "challenge"));
  });

  it("GPT decision completes collaboration", () => {
    const cm = new CollaborationManager();
    const s = cm.start({ taskId: "t1", projectId: "p1" });
    cm.postMessage({
      collaborationId: s.id,
      type: "decision",
      senderEmployeeId: "gpt",
      content: "Prefer SSE over polling",
    });
    assert.equal(cm.getSession(s.id)?.status, "completed");
  });

  it("artifact/change-set reference without full content", () => {
    const cm = new CollaborationManager();
    const s = cm.start({ taskId: "t1", projectId: "p1" });
    const m = cm.postMessage({
      collaborationId: s.id,
      type: "artifact",
      senderEmployeeId: "claude",
      content: "Change set ready for review",
      changeSetId: "cs_abc",
      artifactRef: "cs_abc",
    });
    assert.equal(m.changeSetId, "cs_abc");
    assert.ok(!m.content.includes("export function"));
  });

  it("message size limits", () => {
    const cm = new CollaborationManager({
      limits: { maxContentLength: 50 },
    });
    const s = cm.start({ taskId: "t1", projectId: "p1" });
    const m = cm.postMessage({
      collaborationId: s.id,
      type: "finding",
      senderEmployeeId: "claude",
      content: "x".repeat(200),
    });
    assert.ok(m.content.length <= 50);
  });

  it("duplicate detection", () => {
    const cm = new CollaborationManager();
    const s = cm.start({ taskId: "t1", projectId: "p1" });
    const input = {
      collaborationId: s.id,
      type: "finding" as const,
      senderEmployeeId: "claude",
      content: "same finding",
    };
    cm.postMessage(input);
    assert.throws(() => cm.postMessage(input), CollaborationError);
  });

  it("message limit", () => {
    const cm = new CollaborationManager({ limits: { maxMessages: 2 } });
    const s = cm.start({ taskId: "t1", projectId: "p1" });
    cm.postMessage({
      collaborationId: s.id,
      type: "finding",
      senderEmployeeId: "claude",
      content: "one",
    });
    cm.postMessage({
      collaborationId: s.id,
      type: "finding",
      senderEmployeeId: "gemini",
      content: "two",
    });
    assert.throws(
      () =>
        cm.postMessage({
          collaborationId: s.id,
          type: "finding",
          senderEmployeeId: "grok",
          content: "three",
        }),
      (e: unknown) => e instanceof CollaborationError && e.code === "LIMIT",
    );
  });

  it("handoff limit", () => {
    const cm = new CollaborationManager({ limits: { maxHandoffs: 1 } });
    const s = cm.start({ taskId: "t1", projectId: "p1" });
    cm.postMessage({
      collaborationId: s.id,
      type: "handoff",
      senderEmployeeId: "claude",
      recipientEmployeeId: "gemini",
      content: "h1",
      handoffReason: "r1",
    });
    assert.throws(
      () =>
        cm.postMessage({
          collaborationId: s.id,
          type: "handoff",
          senderEmployeeId: "gemini",
          recipientEmployeeId: "grok",
          content: "h2",
          handoffReason: "r2",
        }),
      CollaborationError,
    );
  });

  it("cancellation", () => {
    const cm = new CollaborationManager();
    const s = cm.start({ taskId: "t1", projectId: "p1" });
    cm.cancel(s.id);
    assert.equal(cm.getSession(s.id)?.status, "cancelled");
    assert.throws(
      () =>
        cm.postMessage({
          collaborationId: s.id,
          type: "finding",
          senderEmployeeId: "claude",
          content: "after cancel",
        }),
      CollaborationError,
    );
  });

  it("sanitization strips secrets", () => {
    const cleaned = sanitizeCollaborationContent(
      "token secret-api-key-123 Bearer abc",
      200,
    );
    assert.equal(cleaned.includes("secret-api-key-123"), false);
  });

  it("events emitted for dashboard", () => {
    const cm = new CollaborationManager();
    const s = cm.start({ taskId: "t1", projectId: "p1" });
    cm.postMessage({
      collaborationId: s.id,
      type: "challenge",
      senderEmployeeId: "grok",
      content: "disagree",
    });
    const types = cm.listEvents().map((e) => e.type);
    assert.ok(types.includes("collaboration.started"));
    assert.ok(types.includes("collaboration.challenge"));
  });

  it("context isolation by collaboration id", () => {
    const cm = new CollaborationManager();
    const a = cm.start({ taskId: "t1", projectId: "p1" });
    const b = cm.start({ taskId: "t2", projectId: "p2" });
    cm.postMessage({
      collaborationId: a.id,
      type: "finding",
      senderEmployeeId: "claude",
      content: "only-a",
    });
    cm.postMessage({
      collaborationId: b.id,
      type: "finding",
      senderEmployeeId: "claude",
      content: "only-b",
    });
    assert.equal(cm.listMessages(a.id)[0]?.content, "only-a");
    assert.equal(cm.listMessages(b.id)[0]?.content, "only-b");
  });
});

describe("multi-agent collaboration integration", () => {
  it("multi-agent run produces collaboration events", async () => {
    const registry = createProviderRegistry({
      primary: new MockProvider(),
      autoDetectXai: false,
      autoDetectGemini: false,
      autoDetectAnthropic: false,
      autoDetectOpenAI: false,
    });
    const collab = new CollaborationManager();
    const orch = new MultiAgentOrchestrator({
      employees: createMultiAgentRoster(),
      router: registry.router,
      collaboration: collab,
      projectId: "collab-demo",
    });
    const task = await orch.createAndRun("Collaborate on architecture");
    assert.equal(task.status, "completed");
    const types = collab.listEvents().map((e) => e.type);
    assert.ok(types.includes("collaboration.started"));
    assert.ok(
      types.includes("collaboration.challenge") ||
        types.includes("collaboration.message") ||
        types.includes("collaboration.decision"),
    );
  });

  it("runtime multi path still completes with collaboration", async () => {
    replaceOffice(
      createOfficeRuntime({
        delays: { planningMs: 0, assignMs: 0, workMs: 0, synthMs: 0 },
        projectId: "rt-collab",
      }),
    );
    const runtime = createOfficeRuntime({
      delays: { planningMs: 0, assignMs: 0, workMs: 0, synthMs: 0 },
      projectId: "rt-collab-2",
    });
    const task = await runtime.createTask({
      objective: "Collab integration",
      mode: "multi",
    });
    for (let i = 0; i < 40; i++) {
      const t = await runtime.getTask(task.id);
      if (t.status === "completed" || t.status === "failed") break;
      await new Promise((r) => setTimeout(r, 20));
    }
    const done = await runtime.getTask(task.id);
    assert.equal(done.status, "completed");
  });
});
