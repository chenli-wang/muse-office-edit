/**
 * Provider-neutral collaboration message / artifact protocol (Phase 11).
 */

import { createHash } from "node:crypto";

export type CollaborationMessageType =
  | "finding"
  | "proposal"
  | "artifact"
  | "review_request"
  | "review"
  | "challenge"
  | "handoff"
  | "decision"
  | "final";

export type ReviewVerdict =
  | "approve"
  | "approve_with_changes"
  | "reject"
  | "needs_more_information";

export type CollaborationRecipient = string | "*"; // employeeId or broadcast

export interface CollaborationMessage {
  id: string;
  collaborationId: string;
  taskId: string;
  type: CollaborationMessageType;
  senderEmployeeId: string;
  /** Specific employee or "*" broadcast */
  recipientEmployeeId: CollaborationRecipient;
  content: string;
  /** Optional change-set / artifact reference (id only, not full content). */
  artifactRef: string | null;
  changeSetId: string | null;
  /** For review messages */
  reviewVerdict: ReviewVerdict | null;
  /** For handoff */
  handoffReason: string | null;
  tags: string[];
  createdAt: string;
  order: number;
  fingerprint: string;
}

export interface CollaborationLimits {
  maxRounds: number;
  maxMessages: number;
  maxReviewsPerArtifact: number;
  maxHandoffs: number;
  maxContentLength: number;
  maxContextMessages: number;
}

export const DEFAULT_COLLABORATION_LIMITS: CollaborationLimits = {
  maxRounds: 4,
  maxMessages: 24,
  maxReviewsPerArtifact: 3,
  maxHandoffs: 6,
  maxContentLength: 2_000,
  maxContextMessages: 12,
};

export class CollaborationError extends Error {
  readonly code:
    | "LIMIT"
    | "INVALID"
    | "DUPLICATE"
    | "PERMISSION"
    | "NOT_FOUND"
    | "TIMEOUT"
    | "CANCELLED"
    | "STALE"
    | "PROVIDER";

  constructor(code: CollaborationError["code"], message: string) {
    super(message);
    this.name = "CollaborationError";
    this.code = code;
  }
}

export function sanitizeCollaborationContent(raw: string, maxLen: number): string {
  let text = String(raw ?? "");
  text = text
    .replace(/Bearer\s+[A-Za-z0-9._\-]+/gi, "Bearer [REDACTED]")
    .replace(/\b(sk|xai|AIza)[-_A-Za-z0-9]{8,}/g, "[REDACTED_KEY]")
    .replace(/secret-api-key-[A-Za-z0-9\-]+/gi, "[REDACTED_KEY]")
    .replace(/api[_-]?key["\s:=]+[A-Za-z0-9._\-]+/gi, "api_key=[REDACTED]");
  if (text.length > maxLen) text = `${text.slice(0, maxLen - 1)}…`;
  return text;
}

export function messageFingerprint(input: {
  type: CollaborationMessageType;
  senderEmployeeId: string;
  recipientEmployeeId: CollaborationRecipient;
  content: string;
  artifactRef?: string | null;
}): string {
  const base = [
    input.type,
    input.senderEmployeeId,
    input.recipientEmployeeId,
    input.content.slice(0, 400),
    input.artifactRef ?? "",
  ].join("|");
  return createHash("sha256").update(base).digest("hex").slice(0, 20);
}

export interface CollaborationSession {
  id: string;
  taskId: string;
  projectId: string;
  status:
    | "active"
    | "completed"
    | "failed"
    | "cancelled"
    | "limit_reached";
  round: number;
  messageCount: number;
  handoffCount: number;
  createdAt: string;
  updatedAt: string;
  completedAt: string | null;
  limitReason: string | null;
}
