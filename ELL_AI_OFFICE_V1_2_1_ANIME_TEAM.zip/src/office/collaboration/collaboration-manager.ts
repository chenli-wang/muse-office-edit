/**
 * CollaborationManager — bounded shared context, handoffs, reviews, challenges.
 * Extends existing multi-agent architecture; not a second orchestrator.
 */

import { randomUUID } from "node:crypto";
import {
  type CollaborationMessage,
  type CollaborationMessageType,
  type CollaborationRecipient,
  type CollaborationSession,
  type CollaborationLimits,
  type ReviewVerdict,
  DEFAULT_COLLABORATION_LIMITS,
  CollaborationError,
  sanitizeCollaborationContent,
  messageFingerprint,
} from "./protocol.ts";

export type CollaborationEventType =
  | "collaboration.started"
  | "collaboration.message"
  | "collaboration.handoff"
  | "collaboration.review_requested"
  | "collaboration.review_completed"
  | "collaboration.challenge"
  | "collaboration.decision"
  | "collaboration.completed"
  | "collaboration.limit_reached";

export interface CollaborationEvent {
  id: string;
  type: CollaborationEventType;
  collaborationId: string;
  taskId: string;
  employeeId: string | null;
  message: string;
  createdAt: string;
}

export interface PostMessageInput {
  collaborationId: string;
  type: CollaborationMessageType;
  senderEmployeeId: string;
  recipientEmployeeId?: CollaborationRecipient;
  content: string;
  artifactRef?: string | null;
  changeSetId?: string | null;
  reviewVerdict?: ReviewVerdict | null;
  handoffReason?: string | null;
  tags?: string[];
}

export interface CollaborationContextView {
  collaborationId: string;
  taskId: string;
  projectId: string;
  round: number;
  status: CollaborationSession["status"];
  messages: CollaborationMessage[];
  /** Compact block for agent prompts. */
  promptBlock: string;
}

export class CollaborationManager {
  private readonly sessions = new Map<string, CollaborationSession>();
  private readonly messages = new Map<string, CollaborationMessage[]>();
  private readonly fingerprints = new Map<string, Set<string>>();
  private readonly reviewsByArtifact = new Map<string, number>();
  private readonly events: CollaborationEvent[] = [];
  private readonly limits: CollaborationLimits;
  private readonly now: () => number;
  private orderCounter = 0;
  private readonly maxEvents = 400;

  constructor(options?: {
    limits?: Partial<CollaborationLimits>;
    now?: () => number;
  }) {
    this.limits = { ...DEFAULT_COLLABORATION_LIMITS, ...options?.limits };
    this.now = options?.now ?? (() => Date.now());
  }

  start(input: {
    taskId: string;
    projectId: string;
  }): CollaborationSession {
    const id = `collab_${randomUUID()}`;
    const ts = new Date(this.now()).toISOString();
    const session: CollaborationSession = {
      id,
      taskId: input.taskId,
      projectId: input.projectId,
      status: "active",
      round: 1,
      messageCount: 0,
      handoffCount: 0,
      createdAt: ts,
      updatedAt: ts,
      completedAt: null,
      limitReason: null,
    };
    this.sessions.set(id, session);
    this.messages.set(id, []);
    this.fingerprints.set(id, new Set());
    this.emit("collaboration.started", id, input.taskId, null, "Collaboration started");
    return { ...session };
  }

  getSession(id: string): CollaborationSession | undefined {
    const s = this.sessions.get(id);
    return s ? { ...s } : undefined;
  }

  postMessage(input: PostMessageInput): CollaborationMessage {
    const session = this.sessions.get(input.collaborationId);
    if (!session) throw new CollaborationError("NOT_FOUND", "Collaboration not found");
    if (session.status !== "active") {
      throw new CollaborationError(
        "INVALID",
        `Collaboration is ${session.status}; cannot post messages`,
      );
    }

    if (session.messageCount >= this.limits.maxMessages) {
      return this.hitLimit(session, "max messages");
    }

    const content = sanitizeCollaborationContent(
      input.content,
      this.limits.maxContentLength,
    );
    if (!content.trim()) {
      throw new CollaborationError("INVALID", "Message content is required");
    }

    const recipient = input.recipientEmployeeId ?? "*";
    const fp = messageFingerprint({
      type: input.type,
      senderEmployeeId: input.senderEmployeeId,
      recipientEmployeeId: recipient,
      content,
      artifactRef: input.artifactRef,
    });
    const seen = this.fingerprints.get(session.id)!;
    if (seen.has(fp)) {
      throw new CollaborationError("DUPLICATE", "Duplicate collaboration message");
    }
    seen.add(fp);

    if (input.type === "handoff") {
      if (session.handoffCount >= this.limits.maxHandoffs) {
        return this.hitLimit(session, "max handoffs");
      }
      if (!input.handoffReason?.trim()) {
        throw new CollaborationError("INVALID", "Handoff requires a reason");
      }
      session.handoffCount += 1;
    }

    if (input.type === "review" || input.type === "review_request") {
      const artifactKey = input.artifactRef ?? input.changeSetId ?? "none";
      const key = `${session.id}:${artifactKey}`;
      const count = this.reviewsByArtifact.get(key) ?? 0;
      if (count >= this.limits.maxReviewsPerArtifact) {
        return this.hitLimit(session, "max reviews per artifact");
      }
      this.reviewsByArtifact.set(key, count + 1);
    }

    if (input.type === "review" && input.reviewVerdict) {
      const valid: ReviewVerdict[] = [
        "approve",
        "approve_with_changes",
        "reject",
        "needs_more_information",
      ];
      if (!valid.includes(input.reviewVerdict)) {
        throw new CollaborationError("INVALID", "Invalid review verdict");
      }
    }

    // Round advances on handoff back to original parallel wave or every 4 messages
    if (input.type === "handoff" || session.messageCount % 4 === 3) {
      if (session.round >= this.limits.maxRounds) {
        return this.hitLimit(session, "max rounds");
      }
      session.round += 1;
    }

    const msg: CollaborationMessage = {
      id: `cmsg_${randomUUID()}`,
      collaborationId: session.id,
      taskId: session.taskId,
      type: input.type,
      senderEmployeeId: input.senderEmployeeId,
      recipientEmployeeId: recipient,
      content,
      artifactRef: input.artifactRef ?? null,
      changeSetId: input.changeSetId ?? null,
      reviewVerdict: input.reviewVerdict ?? null,
      handoffReason: input.handoffReason
        ? sanitizeCollaborationContent(input.handoffReason, 400)
        : null,
      tags: (input.tags ?? []).map((t) => String(t).slice(0, 40)).slice(0, 8),
      createdAt: new Date(this.now()).toISOString(),
      order: ++this.orderCounter,
      fingerprint: fp,
    };

    const list = this.messages.get(session.id)!;
    list.push(msg);
    session.messageCount = list.length;
    session.updatedAt = msg.createdAt;

    this.emitEventForMessage(msg);

    if (input.type === "final" || input.type === "decision") {
      session.status = "completed";
      session.completedAt = msg.createdAt;
      this.emit(
        "collaboration.completed",
        session.id,
        session.taskId,
        input.senderEmployeeId,
        "Collaboration completed",
      );
    }

    return { ...msg, tags: [...msg.tags] };
  }

  /**
   * Bounded context for an employee: messages addressed to them or broadcast,
   * newest first, capped.
   */
  getContextFor(
    collaborationId: string,
    employeeId: string,
    limit?: number,
  ): CollaborationContextView {
    const session = this.sessions.get(collaborationId);
    if (!session) throw new CollaborationError("NOT_FOUND", "Collaboration not found");
    const all = this.messages.get(collaborationId) ?? [];
    const relevant = all.filter(
      (m) =>
        m.recipientEmployeeId === "*" ||
        m.recipientEmployeeId === employeeId ||
        m.senderEmployeeId === employeeId,
    );
    const capped = [...relevant]
      .sort((a, b) => b.order - a.order)
      .slice(0, limit ?? this.limits.maxContextMessages)
      .map((m) => ({ ...m, tags: [...m.tags] }));

    this.emit(
      "collaboration.message",
      collaborationId,
      session.taskId,
      employeeId,
      `Context retrieved (${capped.length} messages)`,
    );

    return {
      collaborationId,
      taskId: session.taskId,
      projectId: session.projectId,
      round: session.round,
      status: session.status,
      messages: capped,
      promptBlock: formatCollabPrompt(capped, 2_000),
    };
  }

  cancel(collaborationId: string): CollaborationSession {
    const session = this.sessions.get(collaborationId);
    if (!session) throw new CollaborationError("NOT_FOUND", "Collaboration not found");
    if (session.status === "cancelled") return { ...session };
    session.status = "cancelled";
    session.updatedAt = new Date(this.now()).toISOString();
    session.completedAt = session.updatedAt;
    this.emit(
      "collaboration.completed",
      session.id,
      session.taskId,
      null,
      "Collaboration cancelled",
    );
    return { ...session };
  }

  listEvents(): CollaborationEvent[] {
    return this.events.map((e) => ({ ...e }));
  }

  listMessages(collaborationId: string): CollaborationMessage[] {
    return (this.messages.get(collaborationId) ?? []).map((m) => ({
      ...m,
      tags: [...m.tags],
    }));
  }

  private hitLimit(session: CollaborationSession, reason: string): never {
    session.status = "limit_reached";
    session.limitReason = reason;
    session.updatedAt = new Date(this.now()).toISOString();
    session.completedAt = session.updatedAt;
    this.emit(
      "collaboration.limit_reached",
      session.id,
      session.taskId,
      null,
      `Collaboration limit: ${reason}`,
    );
    throw new CollaborationError("LIMIT", `Collaboration limit reached: ${reason}`);
  }

  private emitEventForMessage(msg: CollaborationMessage): void {
    let type: CollaborationEventType = "collaboration.message";
    if (msg.type === "handoff") type = "collaboration.handoff";
    else if (msg.type === "review_request") type = "collaboration.review_requested";
    else if (msg.type === "review") type = "collaboration.review_completed";
    else if (msg.type === "challenge") type = "collaboration.challenge";
    else if (msg.type === "decision") type = "collaboration.decision";
    this.emit(
      type,
      msg.collaborationId,
      msg.taskId,
      msg.senderEmployeeId,
      `${msg.type} from ${msg.senderEmployeeId}`,
    );
  }

  private emit(
    type: CollaborationEventType,
    collaborationId: string,
    taskId: string,
    employeeId: string | null,
    message: string,
  ): void {
    this.events.push({
      id: `cevt_${randomUUID()}`,
      type,
      collaborationId,
      taskId,
      employeeId,
      message: sanitizeCollaborationContent(message, 300),
      createdAt: new Date(this.now()).toISOString(),
    });
    if (this.events.length > this.maxEvents) {
      this.events.splice(0, this.events.length - this.maxEvents);
    }
  }
}

function formatCollabPrompt(messages: CollaborationMessage[], maxChars: number): string {
  if (messages.length === 0) return "";
  const lines = ["COLLABORATION CONTEXT (bounded, recent):"];
  let used = lines[0]!.length;
  // Show oldest-of-window first for reading order
  for (const m of [...messages].reverse()) {
    const line = `- [${m.type}] ${m.senderEmployeeId}→${m.recipientEmployeeId}: ${m.content.slice(0, 280)}${m.reviewVerdict ? ` (${m.reviewVerdict})` : ""}${m.changeSetId ? ` cs:${m.changeSetId}` : ""}`;
    if (used + line.length + 1 > maxChars) break;
    lines.push(line);
    used += line.length + 1;
  }
  return lines.join("\n");
}
