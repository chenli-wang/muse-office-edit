export type TaskStatus =
  | "created"
  | "planning"
  | "assigned"
  | "running"
  | "synthesizing"
  | "completed"
  | "failed"
  | "cancelled"
  | "blocked"
  | "waiting_for_user"
  | "waiting_for_quota";

export type AgentStatus =
  | "idle"
  | "planning"
  | "working"
  | "thinking"
  | "using_tool"
  | "waiting"
  | "reviewing"
  | "completed"
  | "error"
  | "offline";

export type ProviderAvailability =
  | "available"
  | "degraded"
  | "rate_limited"
  | "daily_limit_reached"
  | "monthly_limit_reached"
  | "auth_error"
  | "provider_error"
  | "disabled"
  | "unknown"
  | "offline";

export type ProviderErrorClass =
  | "AUTH"
  | "RATE_LIMIT"
  | "INVALID_REQUEST"
  | "TIMEOUT"
  | "SERVER_ERROR"
  | "NETWORK"
  | "CONTENT_ERROR"
  | "UNKNOWN";

export type Confidence = "low" | "medium" | "high";

export type OfficeEventType =
  | "task.created"
  | "task.assigned"
  | "agent.started"
  | "agent.thinking"
  | "agent.completed"
  | "agent.failed"
  | "provider.rate_limited"
  | "provider.recovered"
  | "review.started"
  | "approval.requested"
  | "approval.granted"
  | "task.cancelled"
  | "task.failed"
  | "task.completed";

export interface Employee {
  id: string;
  displayName: string;
  role: string;
  systemPrompt: string;
  capabilities: string[];
  preferredModels: string[];
  fallbackModels: string[];
  toolsAllowed: string[];
  maxParallelTasks: number;
  status: AgentStatus;
  providerPreferences: string[];
  permissions: string[];
  currentTaskId: string | null;
  currentTaskTitle: string | null;
  provider: string | null;
  model: string | null;
  quotaStatus: ProviderAvailability;
}

export interface Subtask {
  id: string;
  employeeId: string;
  objective: string;
  status: TaskStatus;
  expectedOutputFormat: string;
  dependencies: string[];
  timeoutMs: number;
}

export interface AgentOutput {
  employeeId: string;
  summary: string;
  findings: string[];
  evidence: string[];
  risks: string[];
  recommendations: string[];
  questions: string[];
  confidence: Confidence;
  provider: string;
  model: string;
  createdAt: string;
}

export interface TaskError {
  class: ProviderErrorClass;
  message: string;
  retryable: boolean;
}

export interface TaskPlan {
  strategy: string;
  employeeId: string;
  rationale: string;
}

export interface FinalResult {
  summary: string;
  findings: string[];
  evidence: string[];
  risks: string[];
  recommendations: string[];
  questions: string[];
  synthesizedBy: "orchestrator";
}

export interface Task {
  id: string;
  title: string;
  objective: string;
  status: TaskStatus;
  priority: "normal";
  createdAt: string;
  updatedAt: string;
  completedAt: string | null;
  cancelledAt: string | null;
  parentTaskId: string | null;
  subtasks: Subtask[];
  assignedEmployeeIds: string[];
  contextRefs: string[];
  outputs: AgentOutput[];
  plan: TaskPlan | null;
  finalResult: FinalResult | null;
  error: TaskError | null;
  approvalRequired: boolean;
  simulateError: boolean;
}

export interface OfficeEvent {
  id: string;
  type: OfficeEventType;
  taskId: string | null;
  employeeId: string | null;
  message: string;
  createdAt: string;
}

export interface ProviderRecord {
  id: string;
  provider: string;
  capabilities: string[];
  contextWindow: number | null;
  costClass: "free" | "paid" | "unknown";
  availability: ProviderAvailability;
  label: string;
}

/**
 * Provider status for API / UI (Phase 2C).
 * Combines model registry rows with secret-free health metadata.
 * Safe to expose — never includes API keys.
 */
export interface ProviderStatus {
  id: string;
  label: string;
  configured: boolean;
  availability: ProviderAvailability;
  reason: string;
  message: string;
  checkedAt: string | null;
  lastSuccessAt: string | null;
  lastErrorAt: string | null;
  lastErrorClass: string | null;
  cooldownUntil: string | null;
  availableForRequest: boolean;
  models: ProviderRecord[];
}

export interface OfficeSnapshot {
  agents: Employee[];
  tasks: Task[];
  events: OfficeEvent[];
  providers: ProviderStatus[];
  mockMode: true;
}
