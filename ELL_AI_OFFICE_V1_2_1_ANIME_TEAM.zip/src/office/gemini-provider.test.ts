import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { ProviderError } from "./errors.ts";
import {
  GeminiProvider,
  GEMINI_MODEL_ID,
  GEMINI_DEFAULT_MODEL,
  createGeminiProviderFromEnv,
} from "./gemini-provider.ts";
import { createProviderRegistry } from "./provider-registry.ts";

function jsonResponse(status: number, body: unknown): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

function successBody(overrides: Record<string, unknown> = {}) {
  return {
    candidates: [
      {
        content: { parts: [{ text: "Hello from Gemini" }] },
        finishReason: "STOP",
      },
    ],
    usageMetadata: {
      promptTokenCount: 12,
      candidatesTokenCount: 4,
      totalTokenCount: 16,
    },
    modelVersion: "gemini-2.5-flash",
    ...overrides,
  };
}

describe("GeminiProvider", () => {
  it("is disabled without an API key", async () => {
    const gemini = new GeminiProvider({ apiKey: undefined });
    assert.equal(gemini.isConfigured(), false);
    assert.equal(gemini.getAvailability(), "disabled");
    const models = gemini.listModels();
    assert.equal(models[0].id, GEMINI_MODEL_ID);
    assert.equal(models[0].availability, "disabled");
    assert.equal(models[0].provider, "gemini");

    await assert.rejects(
      () =>
        gemini.generate({
          model: GEMINI_MODEL_ID,
          systemPrompt: "sys",
          userPrompt: "hello",
        }),
      (err: unknown) => {
        assert.ok(err instanceof ProviderError);
        assert.equal(err.code, "AUTH");
        return true;
      },
    );
  });

  it("advertises accurate capabilities (no false streaming/tools/vision)", () => {
    const gemini = new GeminiProvider({ apiKey: "k" });
    assert.equal(gemini.capabilities.text, true);
    assert.equal(gemini.capabilities.code, true);
    assert.equal(gemini.capabilities.streaming, false);
    assert.equal(gemini.capabilities.tools, false);
    assert.equal(gemini.capabilities.vision, false);
  });

  it("calls official generateContent with x-goog-api-key and systemInstruction", async () => {
    let sawUrl = "";
    let sawKey = "";
    let sawBody: unknown;
    const gemini = new GeminiProvider({
      apiKey: "test-gemini-key",
      model: "gemini-2.5-flash",
      fetchImpl: (async (input, init) => {
        sawUrl = String(input);
        const headers = init?.headers as Record<string, string>;
        sawKey = headers?.["x-goog-api-key"] ?? "";
        sawBody = JSON.parse(String(init?.body ?? "{}"));
        return jsonResponse(200, successBody());
      }) as typeof fetch,
    });

    const result = await gemini.generate({
      model: GEMINI_MODEL_ID,
      systemPrompt: "You are a tester.",
      userPrompt: "Say hello",
    });

    assert.match(sawUrl, /generativelanguage\.googleapis\.com\/v1beta\/models\/gemini-2\.5-flash:generateContent/);
    assert.equal(sawKey, "test-gemini-key");
    const body = sawBody as {
      contents: Array<{ role: string; parts: Array<{ text: string }> }>;
      systemInstruction: { parts: Array<{ text: string }> };
    };
    assert.equal(body.contents[0].parts[0].text, "Say hello");
    assert.equal(body.systemInstruction.parts[0].text, "You are a tester.");
    assert.equal(result.provider, "gemini");
    assert.equal(result.text, "Hello from Gemini");
    assert.equal(result.finishReason, "STOP");
    assert.equal(result.usage?.promptTokens, 12);
    assert.equal(result.usage?.completionTokens, 4);
    assert.equal(result.usage?.totalTokens, 16);
    assert.equal(result.model, "gemini-2.5-flash");
  });

  it("omits usage when usageMetadata is absent", async () => {
    const gemini = new GeminiProvider({
      apiKey: "k",
      fetchImpl: (async () =>
        jsonResponse(200, {
          candidates: [{ content: { parts: [{ text: "ok" }] }, finishReason: "STOP" }],
        })) as typeof fetch,
    });
    const result = await gemini.generate({
      model: GEMINI_MODEL_ID,
      systemPrompt: "",
      userPrompt: "hi",
    });
    assert.equal(result.text, "ok");
    assert.equal(result.usage, undefined);
  });

  it("maps 400 to INVALID_REQUEST", async () => {
    const gemini = new GeminiProvider({
      apiKey: "k",
      fetchImpl: (async () =>
        jsonResponse(400, { error: { message: "bad request body" } })) as typeof fetch,
    });
    await assert.rejects(
      () =>
        gemini.generate({ model: GEMINI_MODEL_ID, systemPrompt: "s", userPrompt: "u" }),
      (err: unknown) => {
        assert.ok(err instanceof ProviderError);
        assert.equal(err.code, "INVALID_REQUEST");
        assert.match(err.message, /bad request/);
        return true;
      },
    );
  });

  it("maps 401/403 to AUTH", async () => {
    for (const status of [401, 403]) {
      const gemini = new GeminiProvider({
        apiKey: "k",
        fetchImpl: (async () =>
          jsonResponse(status, { error: { message: "auth failed" } })) as typeof fetch,
      });
      await assert.rejects(
        () =>
          gemini.generate({ model: GEMINI_MODEL_ID, systemPrompt: "s", userPrompt: "u" }),
        (err: unknown) => {
          assert.ok(err instanceof ProviderError);
          assert.equal(err.code, "AUTH");
          return true;
        },
      );
      assert.equal(gemini.getAvailability(), "auth_error");
    }
  });

  it("maps 404 to UNKNOWN (not found)", async () => {
    const gemini = new GeminiProvider({
      apiKey: "k",
      fetchImpl: (async () =>
        jsonResponse(404, { error: { message: "model not found" } })) as typeof fetch,
    });
    await assert.rejects(
      () =>
        gemini.generate({ model: GEMINI_MODEL_ID, systemPrompt: "s", userPrompt: "u" }),
      (err: unknown) => {
        assert.ok(err instanceof ProviderError);
        assert.equal(err.code, "UNKNOWN");
        return true;
      },
    );
  });

  it("maps 429 to RATE_LIMIT and updates availability", async () => {
    const gemini = new GeminiProvider({
      apiKey: "k",
      fetchImpl: (async () =>
        jsonResponse(429, { error: { message: "Resource exhausted" } })) as typeof fetch,
    });
    await assert.rejects(
      () =>
        gemini.generate({ model: GEMINI_MODEL_ID, systemPrompt: "s", userPrompt: "u" }),
      (err: unknown) => {
        assert.ok(err instanceof ProviderError);
        assert.equal(err.code, "RATE_LIMIT");
        assert.equal(err.retryable, true);
        return true;
      },
    );
    assert.equal(gemini.getAvailability(), "rate_limited");
  });

  it("maps 500/503 to SERVER_ERROR", async () => {
    for (const status of [500, 503]) {
      const gemini = new GeminiProvider({
        apiKey: "k",
        fetchImpl: (async () =>
          jsonResponse(status, { error: { message: "backend error" } })) as typeof fetch,
      });
      await assert.rejects(
        () =>
          gemini.generate({ model: GEMINI_MODEL_ID, systemPrompt: "s", userPrompt: "u" }),
        (err: unknown) => {
          assert.ok(err instanceof ProviderError);
          assert.equal(err.code, "SERVER_ERROR");
          assert.equal(err.retryable, true);
          return true;
        },
      );
      assert.equal(gemini.getAvailability(), "provider_error");
    }
  });

  it("maps network failure to NETWORK", async () => {
    const gemini = new GeminiProvider({
      apiKey: "k",
      fetchImpl: (async () => {
        throw new Error("fetch failed: ECONNREFUSED");
      }) as typeof fetch,
    });
    await assert.rejects(
      () =>
        gemini.generate({ model: GEMINI_MODEL_ID, systemPrompt: "s", userPrompt: "u" }),
      (err: unknown) => {
        assert.ok(err instanceof ProviderError);
        assert.equal(err.code, "NETWORK");
        return true;
      },
    );
  });

  it("respects AbortSignal cancellation", async () => {
    const controller = new AbortController();
    controller.abort();
    const gemini = new GeminiProvider({
      apiKey: "k",
      fetchImpl: (async () => jsonResponse(200, successBody())) as typeof fetch,
    });
    await assert.rejects(
      () =>
        gemini.generate({
          model: GEMINI_MODEL_ID,
          systemPrompt: "s",
          userPrompt: "u",
          signal: controller.signal,
        }),
      (err: unknown) => {
        assert.ok(err instanceof ProviderError);
        assert.equal(err.code, "TIMEOUT");
        return true;
      },
    );
  });

  it("respects timeoutMs", async () => {
    const gemini = new GeminiProvider({
      apiKey: "k",
      fetchImpl: (async () =>
        new Promise<Response>((resolve) => {
          setTimeout(() => resolve(jsonResponse(200, successBody())), 200);
        })) as typeof fetch,
    });
    await assert.rejects(
      () =>
        gemini.generate({
          model: GEMINI_MODEL_ID,
          systemPrompt: "s",
          userPrompt: "u",
          timeoutMs: 20,
        }),
      (err: unknown) => {
        assert.ok(err instanceof ProviderError);
        assert.equal(err.code, "TIMEOUT");
        assert.match(err.message, /timed out/);
        return true;
      },
    );
  });

  it("ignores simulateFailure (mock-only flag)", async () => {
    let called = false;
    const gemini = new GeminiProvider({
      apiKey: "k",
      fetchImpl: (async () => {
        called = true;
        return jsonResponse(200, successBody());
      }) as typeof fetch,
    });
    const result = await gemini.generate({
      model: GEMINI_MODEL_ID,
      systemPrompt: "s",
      userPrompt: "u",
      simulateFailure: true,
    });
    assert.equal(called, true);
    assert.equal(result.text, "Hello from Gemini");
  });

  it("uses GEMINI_DEFAULT_MODEL when model env unset", () => {
    const gemini = new GeminiProvider({ apiKey: "k" });
    assert.equal(gemini.getApiModel(), GEMINI_DEFAULT_MODEL);
  });

  it("createGeminiProviderFromEnv reads GEMINI_API_KEY and GEMINI_MODEL", () => {
    const prevKey = process.env.GEMINI_API_KEY;
    const prevModel = process.env.GEMINI_MODEL;
    try {
      process.env.GEMINI_API_KEY = "env-key";
      process.env.GEMINI_MODEL = "gemini-2.0-flash";
      const gemini = createGeminiProviderFromEnv();
      assert.equal(gemini.isConfigured(), true);
      assert.equal(gemini.getApiModel(), "gemini-2.0-flash");
    } finally {
      if (prevKey === undefined) delete process.env.GEMINI_API_KEY;
      else process.env.GEMINI_API_KEY = prevKey;
      if (prevModel === undefined) delete process.env.GEMINI_MODEL;
      else process.env.GEMINI_MODEL = prevModel;
    }
  });
});

describe("Gemini registry registration", () => {
  it("does not register Gemini without key", async () => {
    const prev = process.env.GEMINI_API_KEY;
    try {
      delete process.env.GEMINI_API_KEY;
      const registry = createProviderRegistry({
        autoDetectXai: false,
        autoDetectGemini: true,
      });
      assert.equal(registry.get("gemini"), undefined);
      assert.equal(registry.primary.id, "mock");
    } finally {
      if (prev !== undefined) process.env.GEMINI_API_KEY = prev;
    }
  });

  it("registers Gemini when key is present; primary stays mock", async () => {
    const prev = process.env.GEMINI_API_KEY;
    try {
      process.env.GEMINI_API_KEY = "registry-test-key";
      const registry = createProviderRegistry({
        autoDetectXai: false,
        autoDetectGemini: true,
      });
      assert.ok(registry.get("gemini"));
      assert.equal(registry.primary.id, "mock");
      const models = await registry.listModels();
      assert.ok(models.some((m) => m.provider === "mock"));
      assert.ok(models.some((m) => m.provider === "gemini"));
    } finally {
      if (prev === undefined) delete process.env.GEMINI_API_KEY;
      else process.env.GEMINI_API_KEY = prev;
    }
  });

  it("accepts Gemini via extra without env", async () => {
    const gemini = new GeminiProvider({ apiKey: "extra-key" });
    const registry = createProviderRegistry({
      autoDetectXai: false,
      autoDetectGemini: false,
      extra: [gemini],
    });
    assert.ok(registry.get("gemini"));
  });
});
