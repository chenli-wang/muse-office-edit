/**
 * Deterministic static task planner (Phase 3 MVP).
 * Does NOT call an LLM to decompose tasks.
 */

import type { Employee } from "./types.ts";

export type PlanStepKind = "parallel" | "synthesis";

export interface PlanStep {
  id: string;
  employeeId: string;
  kind: PlanStepKind;
  /** Assignment for this employee. */
  objective: string;
  /** Step ids that must complete before this step may run. */
  dependsOn: string[];
  /** If true, failure of this step blocks dependents. */
  required: boolean;
}

export interface ExecutionPlan {
  strategy: "single-employee" | "multi-agent-static";
  rationale: string;
  steps: PlanStep[];
}

const PARALLEL_OBJECTIVES: Record<string, string> = {
  claude:
    "Inspect the implementation and identify engineering issues, bugs, and maintainability risks related to the user objective.",
  gemini:
    "Research relevant technical requirements, constraints, and alternative approaches related to the user objective. Distinguish verified facts from assumptions.",
  grok:
    "Independently challenge the approach and findings. Search for weaknesses, edge cases, and alternative interpretations. Do not simply agree.",
  gpt:
    "Review all upstream agent findings. Synthesize a final recommendation, note disagreements, and cite which agent contributed major claims.",
};

/**
 * Build a deterministic multi-agent plan for the given roster.
 * Parallel: Claude, Gemini, Grok. Synthesis: GPT depends on all three.
 */
export function planMultiAgent(objective: string, employees: Employee[]): ExecutionPlan {
  const byId = new Map(employees.map((e) => [e.id, e]));
  const parallelIds = ["claude", "gemini", "grok"].filter((id) => byId.has(id));
  const steps: PlanStep[] = parallelIds.map((employeeId) => ({
    id: `step_${employeeId}`,
    employeeId,
    kind: "parallel",
    objective: `${PARALLEL_OBJECTIVES[employeeId] ?? "Analyze the objective."}\n\nUser objective:\n${objective}`,
    dependsOn: [],
    required: false,
  }));

  if (byId.has("gpt")) {
    steps.push({
      id: "step_gpt",
      employeeId: "gpt",
      kind: "synthesis",
      objective: `${PARALLEL_OBJECTIVES.gpt}\n\nUser objective:\n${objective}`,
      dependsOn: parallelIds.map((id) => `step_${id}`),
      required: true,
    });
  }

  return {
    strategy: "multi-agent-static",
    rationale:
      "Static Phase 3 plan: Claude + Gemini + Grok in parallel, then GPT synthesis over collected results.",
    steps,
  };
}

export function planSingleEmployee(
  objective: string,
  employeeId: string,
): ExecutionPlan {
  return {
    strategy: "single-employee",
    rationale: `Phase 1 single-employee path via ${employeeId}.`,
    steps: [
      {
        id: `step_${employeeId}`,
        employeeId,
        kind: "parallel",
        objective,
        dependsOn: [],
        required: true,
      },
    ],
  };
}
