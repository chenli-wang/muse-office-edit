import { ProviderError } from "./errors.ts";
import type { ProviderAvailability, ProviderErrorClass, ProviderRecord } from "./types.ts";

/** Capability flags a provider may advertise. */
export interface ProviderCapabilities {
  text: boolean;
  code: boolean;
  streaming: boolean;
  tools: boolean;
  vision: boolean;
  jsonMode: boolean;
}

export const DEFAULT_CAPABILITIES: ProviderCapabilities = {
  text: true,
  code: false,
  streaming: false,
  tools: false,
  vision: false,
  jsonMode: false,
};

export interface GenerateRequest {
  model: string;
  systemPrompt: string;
  userPrompt: string;
  /** Soft timeout; adapters must race against this when set. */
  timeoutMs?: number;
  /** Cooperative cancellation. Adapters must respect abort. */
  signal?: AbortSignal;
  /**
   * Mock-only test hook. Real adapters must ignore this field.
   * Kept so Phase 1 tests continue to pass without branching in the runtime.
   */
  simulateFailure?: boolean;
}

export interface TokenUsage {
  promptTokens?: number;
  completionTokens?: number;
  totalTokens?: number;
}

export interface GenerateResponse {
  text: string;
  model: string;
  provider: string;
  latencyMs: number;
  usage?: TokenUsage;
  finishReason?: string;
}

/**
 * Clean provider adapter contract.
 * Every provider (mock or real) implements this interface.
 * Secrets stay inside the adapter constructor / env — never on this public surface.
 */
export interface ProviderAdapter {
  readonly id: string;
  readonly label: string;
  readonly capabilities: ProviderCapabilities;
  /** Current availability; may be dynamic (quota, auth). */
  getAvailability(): ProviderAvailability | Promise<ProviderAvailability>;
  /** Models this adapter can serve. */
  listModels(): ProviderRecord[] | Promise<ProviderRecord[]>;
  generate(request: GenerateRequest): Promise<GenerateResponse>;
}

export const MOCK_MODEL_ID = "mock:phase1";

const MOCK_ANALYSIS = {
  findings: [
    "Phase 1 is using the mock provider adapter, not a live model.",
    "The orchestrator assigned a single employee (Claude — Lead Developer).",
    "No files, network, or tools were used to produce this result.",
  ],
  evidence: [
    "Provider id is `mock`. Generate() returns a template keyed to the objective.",
    "No API key was read and no outbound HTTP call was made.",
  ],
  risks: [
    "Treat this output as a pipeline proof, not as a real audit or implementation.",
  ],
  recommendations: [
    "After Phase 1 is accepted, connect one real provider adapter at a time.",
    "Keep secrets on the server; do not add keys to the dashboard.",
  ],
  questions: [
    "Ready to add a real adapter, or stay on mock until the task engine is reviewed?",
  ],
};

function assertNotAborted(signal?: AbortSignal): void {
  if (signal?.aborted) {
    throw new ProviderError("TIMEOUT", "Provider request was cancelled.", true);
  }
}

/**
 * Race a promise against timeout and AbortSignal.
 * Used by adapters so timeout/cancel behaviour is consistent.
 */
export async function withTimeoutAndSignal<T>(
  work: Promise<T>,
  options: { timeoutMs?: number; signal?: AbortSignal; label?: string },
): Promise<T> {
  const { timeoutMs, signal, label = "provider request" } = options;
  assertNotAborted(signal);

  if (!timeoutMs && !signal) return work;

  return new Promise<T>((resolve, reject) => {
    let settled = false;
    let timer: ReturnType<typeof setTimeout> | undefined;

    const finish = (fn: () => void) => {
      if (settled) return;
      settled = true;
      if (timer !== undefined) clearTimeout(timer);
      signal?.removeEventListener("abort", onAbort);
      fn();
    };

    const onAbort = () => {
      finish(() =>
        reject(new ProviderError("TIMEOUT", `${label} was cancelled.`, true)),
      );
    };

    if (signal) {
      if (signal.aborted) {
        onAbort();
        return;
      }
      signal.addEventListener("abort", onAbort, { once: true });
    }

    if (timeoutMs !== undefined && timeoutMs > 0) {
      timer = setTimeout(() => {
        finish(() =>
          reject(
            new ProviderError(
              "TIMEOUT",
              `${label} timed out after ${timeoutMs}ms.`,
              true,
            ),
          ),
        );
      }, timeoutMs);
    }

    work.then(
      (value) => finish(() => resolve(value)),
      (err) => finish(() => reject(err)),
    );
  });
}

/** Map HTTP / fetch failures into normalized ProviderError. */
export function normalizeProviderError(
  error: unknown,
  fallbackMessage = "Provider request failed",
): ProviderError {
  if (error instanceof ProviderError) return error;

  if (error instanceof Error) {
    const msg = error.message || fallbackMessage;
    const name = error.name || "";

    if (name === "AbortError" || /aborted|cancelled/i.test(msg)) {
      return new ProviderError("TIMEOUT", msg, true);
    }
    if (/timeout/i.test(msg)) {
      return new ProviderError("TIMEOUT", msg, true);
    }
    if (/network|fetch failed|ECONNREFUSED|ENOTFOUND/i.test(msg)) {
      return new ProviderError("NETWORK", msg, true);
    }
    if (/401|unauthorized|invalid.?api.?key|authentication/i.test(msg)) {
      return new ProviderError("AUTH", msg, false);
    }
    if (/429|rate.?limit|quota/i.test(msg)) {
      return new ProviderError("RATE_LIMIT", msg, true);
    }
    if (/400|invalid.?request|bad.?request/i.test(msg)) {
      return new ProviderError("INVALID_REQUEST", msg, false);
    }
    if (/5\d\d|server.?error|internal/i.test(msg)) {
      return new ProviderError("SERVER_ERROR", msg, true);
    }
    return new ProviderError("UNKNOWN", msg, false);
  }

  return new ProviderError("UNKNOWN", fallbackMessage, false);
}

/** Classify an HTTP status from an official provider API into ProviderErrorClass. */
export function httpStatusToErrorClass(status: number): {
  code: ProviderErrorClass;
  retryable: boolean;
} {
  if (status === 401 || status === 403) return { code: "AUTH", retryable: false };
  if (status === 429) return { code: "RATE_LIMIT", retryable: true };
  if (status === 400 || status === 422) return { code: "INVALID_REQUEST", retryable: false };
  if (status === 408 || status === 504) return { code: "TIMEOUT", retryable: true };
  if (status >= 500) return { code: "SERVER_ERROR", retryable: true };
  if (status >= 400) return { code: "UNKNOWN", retryable: false };
  return { code: "UNKNOWN", retryable: false };
}

export class MockProvider implements ProviderAdapter {
  readonly id = "mock";
  readonly label = "Mock provider (Phase 1)";
  readonly capabilities: ProviderCapabilities = {
    text: true,
    code: true,
    streaming: false,
    tools: false,
    vision: false,
    jsonMode: true,
  };

  private availability: ProviderAvailability = "available";

  setAvailability(state: ProviderAvailability): void {
    this.availability = state;
  }

  getAvailability(): ProviderAvailability {
    return this.availability;
  }

  listModels(): ProviderRecord[] {
    return [
      {
        id: MOCK_MODEL_ID,
        provider: this.id,
        capabilities: ["text", "code"],
        contextWindow: null,
        costClass: "free",
        availability: this.availability,
        label: "Phase 1 mock",
      },
    ];
  }

  async generate(request: GenerateRequest): Promise<GenerateResponse> {
    const started = Date.now();
    assertNotAborted(request.signal);

    if (this.availability === "disabled" || this.availability === "offline") {
      throw new ProviderError(
        "AUTH",
        `Mock provider is ${this.availability}.`,
        false,
      );
    }
    if (
      this.availability === "rate_limited" ||
      this.availability === "daily_limit_reached" ||
      this.availability === "monthly_limit_reached"
    ) {
      throw new ProviderError(
        "RATE_LIMIT",
        `Mock provider is ${this.availability}.`,
        true,
      );
    }

    const work = (async () => {
      // Tiny yield so AbortSignal can fire in tests without real delay.
      await Promise.resolve();
      assertNotAborted(request.signal);

      if (request.simulateFailure) {
        throw new ProviderError(
          "SERVER_ERROR",
          "Mock provider was instructed to fail. No external API was called.",
          false,
        );
      }

      const payload = {
        summary: `Mock analysis completed for: ${request.userPrompt}`,
        ...MOCK_ANALYSIS,
        confidence: "low" as const,
      };

      return {
        text: JSON.stringify(payload),
        model: request.model,
        provider: this.id,
        latencyMs: Math.max(1, Date.now() - started),
        finishReason: "stop",
      } satisfies GenerateResponse;
    })();

    try {
      return await withTimeoutAndSignal(work, {
        timeoutMs: request.timeoutMs,
        signal: request.signal,
        label: "Mock provider",
      });
    } catch (error) {
      throw normalizeProviderError(error);
    }
  }
}

/** Collect model records from one or more adapters. */
export async function listProviderRecordsFrom(
  adapters: ProviderAdapter[],
): Promise<ProviderRecord[]> {
  const rows: ProviderRecord[] = [];
  for (const adapter of adapters) {
    const models = await adapter.listModels();
    rows.push(...models);
  }
  return rows;
}

/**
 * Backward-compatible helper used by Phase 1 runtime / tests.
 * Prefer listProviderRecordsFrom(registry) for multi-provider setups.
 */
export function listProviderRecords(
  availability: ProviderAvailability = "available",
): ProviderRecord[] {
  return [
    {
      id: MOCK_MODEL_ID,
      provider: "mock",
      capabilities: ["text", "code"],
      contextWindow: null,
      costClass: "free",
      availability,
      label: "Phase 1 mock",
    },
  ];
}
