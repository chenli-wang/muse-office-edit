import type { ProviderErrorClass } from "./types.ts";

export class OfficeError extends Error {
  readonly status: number;
  readonly code: string;

  constructor(status: number, code: string, message: string) {
    super(message);
    this.name = "OfficeError";
    this.status = status;
    this.code = code;
  }
}

export class ValidationError extends OfficeError {
  constructor(message: string) {
    super(400, "VALIDATION", message);
    this.name = "ValidationError";
  }
}

export class NotFoundError extends OfficeError {
  constructor(message: string) {
    super(404, "NOT_FOUND", message);
    this.name = "NotFoundError";
  }
}

export class ConflictError extends OfficeError {
  constructor(message: string) {
    super(409, "CONFLICT", message);
    this.name = "ConflictError";
  }
}

export class ProviderError extends Error {
  readonly code: ProviderErrorClass;
  readonly retryable: boolean;

  constructor(code: ProviderErrorClass, message: string, retryable: boolean) {
    super(message);
    this.name = "ProviderError";
    this.code = code;
    this.retryable = retryable;
  }
}

export function isOfficeError(error: unknown): error is OfficeError {
  return error instanceof OfficeError;
}
