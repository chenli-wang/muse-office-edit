/**
 * AgentExecutor — runs one agent task through the Provider Router.
 * No provider-specific logic; no tools; structured result normalization.
 */

import type { ProviderRouter } from "./provider-router.ts";
import { sanitizePublicErrorMessage } from "./provider-router.ts";
import { ProviderError } from "./errors.ts";
import type { AgentOutput, Confidence, ProviderErrorClass } from "./types.ts";
import type { ToolRegistry } from "./tools/tool-registry.ts";
import { runToolLoop, DEFAULT_EMPLOYEE_PERMISSIONS } from "./tools/tool-loop.ts";

export type AgentTaskStatus =
  | "pending"
  | "running"
  | "completed"
  | "failed"
  | "cancelled"
  | "blocked";

export interface AgentTask {
  id: string;
  parentTaskId: string;
  employeeId: string;
  role: string;
  objective: string;
  status: AgentTaskStatus;
  dependsOn: string[];
  required: boolean;
  kind: "parallel" | "synthesis";
  timeoutMs: number;
  upstreamResults: AgentResult[];
  result: AgentResult | null;
  error: { class: ProviderErrorClass; message: string; retryable: boolean } | null;
  createdAt: string;
  startedAt: string | null;
  completedAt: string | null;
}

export interface AgentResult {
  taskId: string;
  employeeId: string;
  /** Preferred provider from employee binding. */
  preferredProviderId: string;
  /** Actual provider that produced the result (may differ after fallback). */
  providerId: string;
  model: string;
  status: "completed" | "failed";
  summary: string;
  findings: string[];
  evidence: string[];
  risks: string[];
  recommendations: string[];
  questions: string[];
  confidence: Confidence;
  output: string;
  usage?: { promptTokens?: number; completionTokens?: number; totalTokens?: number };
  errorClass?: ProviderErrorClass;
  /** Secret-free route trace summary. */
  routeTrace?: {
    preferredProviderId: string | null;
    finalProviderId: string | null;
    fallbackUsed: boolean;
    selectionReason: string;
    candidates: string[];
  };
  createdAt: string;
}

export interface AgentExecutorOptions {
  /** Hard provider allowlist from Manager cost policy. */
  allowedProviderIds?: string[];
  routingMode?: "primary-only" | "free-first";
  maxRoutingAttempts?: number;
  excludeMockInFreeFirst?: boolean;
  router: ProviderRouter;
  /** Bound model id for the employee (e.g. mock:phase1). */
  modelId: string;
  systemPrompt: string;
  timeoutMs?: number;
  signal?: AbortSignal;
  /**
   * Optional provider id for routing. When set, free-first is filtered to this
   * provider only (with primary-only fallback if it is the primary).
   */
  providerId?: string;
  /** Enable Phase 9 tool-calling loop when registry is provided. */
  tools?: ToolRegistry;
  contextBlock?: string;
  enableToolLoop?: boolean;
}

function asStringArray(value: unknown): string[] {
  return Array.isArray(value) ? value.map((item) => String(item)) : [];
}

function normalizeFromText(
  text: string,
  task: AgentTask,
  providerId: string,
  model: string,
  preferredProviderId: string,
  routeTrace?: AgentResult["routeTrace"],
): AgentResult {
  const createdAt = new Date().toISOString();
  try {
    const parsed = JSON.parse(text) as Partial<AgentOutput> & { summary?: string };
    return {
      taskId: task.id,
      employeeId: task.employeeId,
      preferredProviderId,
      providerId,
      model,
      status: "completed",
      summary: String(parsed.summary ?? text.slice(0, 400)),
      findings: asStringArray(parsed.findings),
      evidence: asStringArray(parsed.evidence),
      risks: asStringArray(parsed.risks),
      recommendations: asStringArray(parsed.recommendations),
      questions: asStringArray(parsed.questions),
      confidence:
        parsed.confidence === "medium" || parsed.confidence === "high"
          ? parsed.confidence
          : "low",
      output: text,
      routeTrace,
      createdAt,
    };
  } catch {
    return {
      taskId: task.id,
      employeeId: task.employeeId,
      preferredProviderId,
      providerId,
      model,
      status: "completed",
      summary: text.slice(0, 400) || `Completed by ${task.employeeId}`,
      findings: text ? [text.slice(0, 500)] : [],
      evidence: [],
      risks: [],
      recommendations: [],
      questions: [],
      confidence: "low",
      output: text,
      routeTrace,
      createdAt,
    };
  }
}

function buildUserPrompt(task: AgentTask, originalObjective: string): string {
  const parts: string[] = [
    `ROLE: ${task.role}`,
    `ASSIGNMENT:\n${task.objective}`,
    `ORIGINAL USER OBJECTIVE:\n${originalObjective}`,
  ];
  if (task.upstreamResults.length > 0) {
    parts.push("UPSTREAM AGENT RESULTS:");
    for (const up of task.upstreamResults) {
      parts.push(
        [
          `--- ${up.employeeId} (${up.status}) ---`,
          `summary: ${up.summary}`,
          up.findings.length ? `findings: ${JSON.stringify(up.findings)}` : "",
          up.risks.length ? `risks: ${JSON.stringify(up.risks)}` : "",
          up.recommendations.length
            ? `recommendations: ${JSON.stringify(up.recommendations)}`
            : "",
        ]
          .filter(Boolean)
          .join("\n"),
      );
    }
  }
  parts.push(
    "Respond with JSON keys: summary, findings, evidence, risks, recommendations, questions, confidence.",
  );
  return parts.join("\n\n");
}

export class AgentExecutor {
  async execute(
    task: AgentTask,
    originalObjective: string,
    options: AgentExecutorOptions,
  ): Promise<AgentResult> {
    if (options.signal?.aborted) {
      throw new ProviderError("TIMEOUT", "Agent task was cancelled.", true);
    }

    const userPrompt = buildUserPrompt(task, originalObjective);
    const preferredProviderId = options.providerId ?? "mock";
    const isMockBinding = preferredProviderId === "mock";
    try {
      if (options.enableToolLoop && options.tools) {
        const loop = await runToolLoop({
          router: options.router,
          tools: options.tools,
          modelId: options.modelId,
          systemPrompt: options.systemPrompt,
          userObjective: userPrompt,
          contextBlock: options.contextBlock,
          employeeId: task.employeeId,
          taskId: task.id,
          permissions: DEFAULT_EMPLOYEE_PERMISSIONS[task.employeeId],
          signal: options.signal,
          timeoutMs: options.timeoutMs ?? task.timeoutMs,
          providerId: preferredProviderId,
        });
        if (loop.stoppedReason === "cancelled") {
          throw new ProviderError("TIMEOUT", "Agent task was cancelled.", true);
        }
        const result = normalizeFromText(
          loop.finalText || `stopped:${loop.stoppedReason}`,
          task,
          preferredProviderId,
          options.modelId,
          preferredProviderId,
        );
        if (loop.usage) result.usage = loop.usage;
        return result;
      }

      const { response, trace } = await options.router.executeWithFallback(
        {
          model: options.modelId,
          systemPrompt: options.systemPrompt,
          userPrompt,
          timeoutMs: options.timeoutMs ?? task.timeoutMs,
          signal: options.signal,
        },
        {
          preferredProviderId,
          policy: {
            mode: options.routingMode ?? (isMockBinding ? "primary-only" : "free-first"),
            maxAttempts: options.maxRoutingAttempts ?? (isMockBinding ? 1 : 3),
            excludeMockInFreeFirst: options.excludeMockInFreeFirst ?? !isMockBinding,
            allowedProviderIds: options.allowedProviderIds,
          },
        },
      );

      const routeTrace = {
        preferredProviderId: trace.preferredProviderId,
        finalProviderId: trace.finalProviderId,
        fallbackUsed: trace.fallbackUsed,
        selectionReason: trace.selectionReason,
        candidates: trace.candidates,
      };
      const result = normalizeFromText(
        response.text,
        task,
        response.provider,
        response.model,
        preferredProviderId,
        routeTrace,
      );
      if (response.usage) result.usage = response.usage;
      return result;
    } catch (error) {
      const providerError =
        error instanceof ProviderError
          ? error
          : new ProviderError(
              "UNKNOWN",
              error instanceof Error ? error.message : "Agent execution failed",
              false,
            );
      return {
        taskId: task.id,
        employeeId: task.employeeId,
        preferredProviderId,
        providerId: "unknown",
        model: options.modelId,
        status: "failed",
        summary: sanitizePublicErrorMessage(providerError),
        findings: [],
        evidence: [],
        risks: [],
        recommendations: [],
        questions: [],
        confidence: "low",
        output: "",
        errorClass: providerError.code,
        createdAt: new Date().toISOString(),
      };
    }
  }
}
