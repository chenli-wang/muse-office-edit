import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { ProviderError } from "./errors.ts";
import {
  MockProvider,
  httpStatusToErrorClass,
  normalizeProviderError,
  withTimeoutAndSignal,
  MOCK_MODEL_ID,
} from "./providers.ts";
import { XaiProvider, XAI_MODEL_ID } from "./xai-provider.ts";
import { createProviderRegistry } from "./provider-registry.ts";

describe("MockProvider contract", () => {
  it("advertises capabilities and models", async () => {
    const mock = new MockProvider();
    assert.equal(mock.id, "mock");
    assert.equal(mock.getAvailability(), "available");
    assert.equal(mock.capabilities.text, true);
    assert.equal(mock.capabilities.code, true);
    const models = mock.listModels();
    assert.equal(models.length, 1);
    assert.equal(models[0].id, MOCK_MODEL_ID);
    assert.equal(models[0].costClass, "free");
  });

  it("returns structured mock analysis", async () => {
    const mock = new MockProvider();
    const result = await mock.generate({
      model: MOCK_MODEL_ID,
      systemPrompt: "sys",
      userPrompt: "Audit the pipeline",
    });
    assert.equal(result.provider, "mock");
    assert.match(result.text, /Mock analysis completed/);
    assert.ok(result.latencyMs >= 1);
  });

  it("honours simulateFailure without external calls", async () => {
    const mock = new MockProvider();
    await assert.rejects(
      () =>
        mock.generate({
          model: MOCK_MODEL_ID,
          systemPrompt: "sys",
          userPrompt: "fail",
          simulateFailure: true,
        }),
      (err: unknown) => {
        assert.ok(err instanceof ProviderError);
        assert.equal(err.code, "SERVER_ERROR");
        assert.equal(err.retryable, false);
        return true;
      },
    );
  });

  it("respects AbortSignal cancellation", async () => {
    const mock = new MockProvider();
    const controller = new AbortController();
    controller.abort();
    await assert.rejects(
      () =>
        mock.generate({
          model: MOCK_MODEL_ID,
          systemPrompt: "sys",
          userPrompt: "cancel me",
          signal: controller.signal,
        }),
      (err: unknown) => {
        assert.ok(err instanceof ProviderError);
        assert.equal(err.code, "TIMEOUT");
        assert.equal(err.retryable, true);
        return true;
      },
    );
  });

  it("respects timeoutMs", async () => {
    const mock = new MockProvider();
    const ok = await mock.generate({
      model: MOCK_MODEL_ID,
      systemPrompt: "sys",
      userPrompt: "ok",
      timeoutMs: 5_000,
    });
    assert.equal(ok.provider, "mock");
  });

  it("maps availability to rate-limit errors", async () => {
    const mock = new MockProvider();
    mock.setAvailability("rate_limited");
    await assert.rejects(
      () =>
        mock.generate({
          model: MOCK_MODEL_ID,
          systemPrompt: "sys",
          userPrompt: "limited",
        }),
      (err: unknown) => {
        assert.ok(err instanceof ProviderError);
        assert.equal(err.code, "RATE_LIMIT");
        return true;
      },
    );
  });
});

describe("withTimeoutAndSignal", () => {
  it("rejects when aborted before start", async () => {
    const controller = new AbortController();
    controller.abort();
    await assert.rejects(
      () =>
        withTimeoutAndSignal(Promise.resolve("x"), {
          signal: controller.signal,
          label: "test",
        }),
      (err: unknown) => {
        assert.ok(err instanceof ProviderError);
        assert.equal(err.code, "TIMEOUT");
        return true;
      },
    );
  });

  it("rejects on timeout", async () => {
    await assert.rejects(
      () =>
        withTimeoutAndSignal(
          new Promise((resolve) => setTimeout(() => resolve("late"), 200)),
          { timeoutMs: 20, label: "slow" },
        ),
      (err: unknown) => {
        assert.ok(err instanceof ProviderError);
        assert.equal(err.code, "TIMEOUT");
        assert.match(err.message, /timed out/);
        return true;
      },
    );
  });
});

describe("normalizeProviderError / httpStatusToErrorClass", () => {
  it("classifies HTTP statuses", () => {
    assert.deepEqual(httpStatusToErrorClass(401), { code: "AUTH", retryable: false });
    assert.deepEqual(httpStatusToErrorClass(429), { code: "RATE_LIMIT", retryable: true });
    assert.deepEqual(httpStatusToErrorClass(500), { code: "SERVER_ERROR", retryable: true });
    assert.deepEqual(httpStatusToErrorClass(400), {
      code: "INVALID_REQUEST",
      retryable: false,
    });
  });

  it("preserves ProviderError instances", () => {
    const original = new ProviderError("AUTH", "bad key", false);
    const mapped = normalizeProviderError(original);
    assert.equal(mapped, original);
  });

  it("maps network-like messages", () => {
    const mapped = normalizeProviderError(new Error("fetch failed: ECONNREFUSED"));
    assert.equal(mapped.code, "NETWORK");
    assert.equal(mapped.retryable, true);
  });
});

describe("XaiProvider", () => {
  it("is disabled without an API key", async () => {
    const xai = new XaiProvider({ apiKey: undefined });
    assert.equal(xai.isConfigured(), false);
    assert.equal(xai.getAvailability(), "disabled");
    const models = xai.listModels();
    assert.equal(models[0].id, XAI_MODEL_ID);
    assert.equal(models[0].availability, "disabled");

    await assert.rejects(
      () =>
        xai.generate({
          model: XAI_MODEL_ID,
          systemPrompt: "sys",
          userPrompt: "hello",
        }),
      (err: unknown) => {
        assert.ok(err instanceof ProviderError);
        assert.equal(err.code, "AUTH");
        return true;
      },
    );
  });

  it("calls the official chat completions endpoint when keyed", async () => {
    let sawUrl = "";
    let sawAuth = "";
    const xai = new XaiProvider({
      apiKey: "test-key-not-real",
      fetchImpl: (async (input, init) => {
        sawUrl = String(input);
        sawAuth = String((init?.headers as Record<string, string>)?.Authorization ?? "");
        return new Response(
          JSON.stringify({
            choices: [{ message: { content: '{"summary":"ok"}' }, finish_reason: "stop" }],
            model: "grok-4.5",
            usage: { prompt_tokens: 10, completion_tokens: 5, total_tokens: 15 },
          }),
          { status: 200, headers: { "Content-Type": "application/json" } },
        );
      }) as typeof fetch,
    });

    assert.equal(xai.isConfigured(), true);
    assert.equal(xai.getAvailability(), "available");

    const result = await xai.generate({
      model: XAI_MODEL_ID,
      systemPrompt: "You are a tester.",
      userPrompt: "Say ok as JSON",
    });

    assert.equal(sawUrl, "https://api.x.ai/v1/chat/completions");
    assert.equal(sawAuth, "Bearer test-key-not-real");
    assert.equal(result.provider, "xai");
    assert.equal(result.text, '{"summary":"ok"}');
    assert.equal(result.usage?.totalTokens, 15);
  });

  it("maps 429 to RATE_LIMIT and updates availability", async () => {
    const xai = new XaiProvider({
      apiKey: "test-key",
      fetchImpl: (async () =>
        new Response(JSON.stringify({ error: { message: "rate limited" } }), {
          status: 429,
        })) as typeof fetch,
    });

    await assert.rejects(
      () =>
        xai.generate({
          model: XAI_MODEL_ID,
          systemPrompt: "sys",
          userPrompt: "hi",
        }),
      (err: unknown) => {
        assert.ok(err instanceof ProviderError);
        assert.equal(err.code, "RATE_LIMIT");
        return true;
      },
    );
    assert.equal(xai.getAvailability(), "rate_limited");
  });

  it("does not treat simulateFailure as a real failure path", async () => {
    let called = false;
    const xai = new XaiProvider({
      apiKey: "test-key",
      fetchImpl: (async () => {
        called = true;
        return new Response(
          JSON.stringify({
            choices: [{ message: { content: "real" }, finish_reason: "stop" }],
            model: "grok-4.5",
          }),
          { status: 200 },
        );
      }) as typeof fetch,
    });

    const result = await xai.generate({
      model: XAI_MODEL_ID,
      systemPrompt: "sys",
      userPrompt: "hi",
      simulateFailure: true,
    });
    assert.equal(called, true);
    assert.equal(result.text, "real");
  });
});

describe("provider registry", () => {
  it("always includes mock as primary by default", async () => {
    const registry = createProviderRegistry({ autoDetectXai: false });
    assert.equal(registry.primary.id, "mock");
    const models = await registry.listModels();
    assert.ok(models.some((m) => m.provider === "mock"));
  });

  it("registers a provided extra adapter", async () => {
    const xai = new XaiProvider({ apiKey: "k" });
    const registry = createProviderRegistry({
      autoDetectXai: false,
      extra: [xai],
    });
    assert.ok(registry.get("xai"));
    const models = await registry.listModels();
    assert.ok(models.some((m) => m.id === XAI_MODEL_ID));
  });
});
