/**
 * Validated execution plan for ELL Manager.
 */

import { randomUUID } from "node:crypto";
import type { TaskRequirements } from "./task-classifier.ts";
import type { CostMode } from "./cost-modes.ts";

export type PlanStepKind =
  | "answer"
  | "inspect"
  | "research"
  | "implement"
  | "collaborate"
  | "review"
  | "qa"
  | "repair"
  | "knowledge"
  | "finalize";

export interface PlanStep {
  id: string;
  kind: PlanStepKind;
  employeeId: string;
  description: string;
  requiredCapabilities: string[];
  requiredTools: string[];
  dependsOn: string[];
  qaRequired: boolean;
  maxRetries: number;
}

export interface ManagerPlan {
  id: string;
  taskId: string;
  projectId: string;
  objective: string;
  steps: PlanStep[];
  costMode: CostMode;
  maxSteps: number;
  maxAgentExecutions: number;
  maxToolCalls: number;
  maxRetries: number;
  maxDurationMs: number;
  requirements: TaskRequirements;
  createdAt: string;
}

export interface PlanLimits {
  maxSteps: number;
  maxAgentExecutions: number;
  maxToolCalls: number;
  maxRetries: number;
  maxDurationMs: number;
}

export const DEFAULT_PLAN_LIMITS: PlanLimits = {
  maxSteps: 12,
  maxAgentExecutions: 16,
  maxToolCalls: 40,
  maxRetries: 2,
  maxDurationMs: 120_000,
};

export class PlanError extends Error {
  readonly code = "INVALID_PLAN";
  constructor(message: string) {
    super(message);
    this.name = "PlanError";
  }
}

export function validatePlan(plan: ManagerPlan, limits: PlanLimits): void {
  if (!plan.objective.trim()) throw new PlanError("Objective required");
  if (plan.steps.length === 0) throw new PlanError("Plan has no steps");
  if (plan.steps.length > limits.maxSteps) {
    throw new PlanError(`Too many steps (max ${limits.maxSteps})`);
  }
  if (plan.maxAgentExecutions > limits.maxAgentExecutions) {
    throw new PlanError("maxAgentExecutions exceeds limit");
  }
  if (plan.maxToolCalls > limits.maxToolCalls) {
    throw new PlanError("maxToolCalls exceeds limit");
  }
  const ids = new Set(plan.steps.map((s) => s.id));
  for (const step of plan.steps) {
    if (!step.employeeId) throw new PlanError(`Step ${step.id} missing employee`);
    for (const dep of step.dependsOn) {
      if (!ids.has(dep)) throw new PlanError(`Unknown dependency ${dep}`);
    }
  }
}

/**
 * Build a minimal validated plan from requirements.
 */
export function buildPlan(input: {
  taskId: string;
  projectId: string;
  objective: string;
  requirements: TaskRequirements;
  costMode: CostMode;
  limits?: Partial<PlanLimits>;
  now?: () => number;
}): ManagerPlan {
  const limits = { ...DEFAULT_PLAN_LIMITS, ...input.limits };
  const now = input.now ?? (() => Date.now());
  const req = input.requirements;
  const steps: PlanStep[] = [];
  let prev: string | null = null;

  const add = (
    kind: PlanStepKind,
    employeeId: string,
    description: string,
    extra?: Partial<PlanStep>,
  ) => {
    const id = `step_${steps.length + 1}`;
    steps.push({
      id,
      kind,
      employeeId,
      description,
      requiredCapabilities: extra?.requiredCapabilities ?? [],
      requiredTools: extra?.requiredTools ?? [],
      dependsOn: prev ? [prev] : [],
      qaRequired: extra?.qaRequired ?? false,
      maxRetries: extra?.maxRetries ?? limits.maxRetries,
    });
    prev = id;
  };

  if (req.category === "conversation" && !req.toolsRequired) {
    add("answer", "claude", "Answer the user question");
    add("finalize", "gpt", "Package final response");
  } else if (req.category === "research" && !req.codingRequired) {
    add("research", "gemini", "Research the topic", {
      requiredCapabilities: ["research"],
    });
    if (req.collaborationUseful) {
      add("review", "grok", "Challenge research findings", {
        requiredCapabilities: ["analysis"],
      });
    }
    add("finalize", "gpt", "Synthesize research answer");
  } else if (req.projectAccessRequired || req.codingRequired) {
    add("inspect", "claude", "Inspect project context", {
      requiredTools: ["project.list", "project.read", "project.search"],
      requiredCapabilities: ["code"],
    });
    if (req.researchRequired) {
      add("research", "gemini", "Research relevant approach", {
        requiredCapabilities: ["research"],
      });
    }
    add("implement", "claude", "Propose/implement changes", {
      requiredTools: ["project.changeset.apply", "project.read"],
      requiredCapabilities: ["code"],
    });
    if (req.collaborationUseful) {
      add("collaborate", "grok", "Challenge implementation", {
        requiredCapabilities: ["analysis"],
      });
    }
    if (req.qaRequired) {
      add("qa", "claude", "Run QA verification", {
        requiredTools: ["qa.run", "qa.plan"],
        qaRequired: true,
      });
      add("repair", "claude", "Repair if QA failed (bounded)", {
        requiredTools: ["project.changeset.apply", "qa.run"],
        maxRetries: limits.maxRetries,
      });
    }
    add("review", "gpt", "Final architectural review");
    add("knowledge", "gpt", "Persist durable decisions if appropriate");
    add("finalize", "gpt", "Final report");
  } else if (req.category === "review" || req.category === "qa") {
    add("inspect", "claude", "Inspect targets", {
      requiredTools: ["project.read", "qa.plan"],
    });
    if (req.category === "qa" || req.qaRequired) {
      add("qa", "claude", "Run QA", { requiredTools: ["qa.run"], qaRequired: true });
    }
    add("review", "gpt", "Review findings");
    add("finalize", "gpt", "Final report");
  } else {
    // mixed / default
    add("inspect", "claude", "Understand request", {
      requiredTools: ["project.list"],
    });
    add("research", "gemini", "Secondary analysis");
    add("review", "grok", "Challenge");
    add("finalize", "gpt", "Synthesize");
  }

  // Enforce max steps by truncating middle if needed (keep finalize)
  while (steps.length > limits.maxSteps) {
    steps.splice(Math.max(1, steps.length - 2), 1);
  }
  // Re-link dependsOn linearly after truncation
  for (let i = 0; i < steps.length; i++) {
    steps[i]!.dependsOn = i === 0 ? [] : [steps[i - 1]!.id];
  }

  const plan: ManagerPlan = {
    id: `plan_${randomUUID()}`,
    taskId: input.taskId,
    projectId: input.projectId,
    objective: input.objective.slice(0, 2000),
    steps,
    costMode: input.costMode,
    maxSteps: limits.maxSteps,
    maxAgentExecutions: limits.maxAgentExecutions,
    maxToolCalls: limits.maxToolCalls,
    maxRetries: limits.maxRetries,
    maxDurationMs: limits.maxDurationMs,
    requirements: req,
    createdAt: new Date(now()).toISOString(),
  };
  validatePlan(plan, limits);
  return plan;
}
