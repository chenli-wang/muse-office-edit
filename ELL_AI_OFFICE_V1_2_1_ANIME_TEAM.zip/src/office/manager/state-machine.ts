/**
 * Bounded Manager state machine.
 */

export type ManagerState =
  | "received"
  | "understanding"
  | "planned"
  | "routing"
  | "executing"
  | "waiting"
  | "collaborating"
  | "reviewing"
  | "qa"
  | "repairing"
  | "completed"
  | "failed"
  | "cancelled"
  | "deferred";

const TRANSITIONS: Record<ManagerState, ReadonlySet<ManagerState>> = {
  received: new Set(["understanding", "cancelled"]),
  understanding: new Set(["planned", "failed", "cancelled"]),
  planned: new Set(["routing", "failed", "cancelled"]),
  routing: new Set(["executing", "deferred", "failed", "cancelled"]),
  executing: new Set([
    "collaborating",
    "reviewing",
    "qa",
    "waiting",
    "completed",
    "failed",
    "cancelled",
  ]),
  waiting: new Set(["executing", "routing", "cancelled", "deferred", "failed"]),
  collaborating: new Set(["reviewing", "executing", "qa", "failed", "cancelled"]),
  reviewing: new Set(["qa", "completed", "failed", "cancelled"]),
  qa: new Set(["repairing", "reviewing", "completed", "failed", "cancelled"]),
  repairing: new Set(["qa", "failed", "cancelled"]),
  completed: new Set([]),
  failed: new Set([]),
  cancelled: new Set([]),
  deferred: new Set(["routing", "cancelled", "failed"]),
};

export class StateMachineError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "StateMachineError";
  }
}

export class ManagerStateMachine {
  private state: ManagerState = "received";
  private readonly history: Array<{ from: ManagerState; to: ManagerState; at: string }> = [];
  private readonly now: () => number;

  constructor(options?: { now?: () => number; initial?: ManagerState }) {
    this.now = options?.now ?? (() => Date.now());
    if (options?.initial) this.state = options.initial;
  }

  get current(): ManagerState {
    return this.state;
  }

  getHistory() {
    return this.history.map((h) => ({ ...h }));
  }

  canTransition(to: ManagerState): boolean {
    return TRANSITIONS[this.state]?.has(to) ?? false;
  }

  transition(to: ManagerState): ManagerState {
    if (!this.canTransition(to)) {
      throw new StateMachineError(
        `Invalid transition ${this.state} → ${to}`,
      );
    }
    const from = this.state;
    this.state = to;
    this.history.push({
      from,
      to,
      at: new Date(this.now()).toISOString(),
    });
    return this.state;
  }

  isTerminal(): boolean {
    return (
      this.state === "completed" ||
      this.state === "failed" ||
      this.state === "cancelled"
    );
  }
}
