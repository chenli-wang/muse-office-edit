/**
 * Provider-neutral task classification (Phase 14).
 * Deterministic keyword/heuristic classification — no free-form model dependency.
 */

export type TaskCategory =
  | "conversation"
  | "research"
  | "coding"
  | "debugging"
  | "project_change"
  | "review"
  | "qa"
  | "mixed";

export type ReasoningLevel = "low" | "medium" | "high";

export interface TaskRequirements {
  category: TaskCategory;
  reasoningLevel: ReasoningLevel;
  codingRequired: boolean;
  researchRequired: boolean;
  toolsRequired: boolean;
  projectAccessRequired: boolean;
  collaborationUseful: boolean;
  qaRequired: boolean;
  finalReviewRequired: boolean;
  confidence: "low" | "medium" | "high";
  signals: string[];
}

const PATTERNS: Array<{
  category: TaskCategory;
  re: RegExp;
  signals: string[];
}> = [
  {
    category: "qa",
    re: /\b(qa|test|verify|validation|regress(ion)?|typecheck|lint)\b/i,
    signals: ["qa"],
  },
  {
    category: "project_change",
    re: /\b(fix|implement|refactor|change|modify|edit|write code|apply|patch|changeset)\b/i,
    signals: ["project_change"],
  },
  {
    category: "debugging",
    re: /\b(debug|bug|error|fail(ing|ure)?|broken|stack trace|crash)\b/i,
    signals: ["debugging"],
  },
  {
    category: "coding",
    re: /\b(code|function|class|module|typescript|javascript|api|endpoint)\b/i,
    signals: ["coding"],
  },
  {
    category: "review",
    re: /\b(review|critique|challenge|assess|evaluate)\b/i,
    signals: ["review"],
  },
  {
    category: "research",
    re: /\b(research|investigate|find out|document|explain|what is|how does)\b/i,
    signals: ["research"],
  },
];

/**
 * Classify objective into structured requirements.
 */
export function classifyTask(objective: string): TaskRequirements {
  const text = String(objective ?? "").trim();
  const signals: string[] = [];
  const matched = new Set<TaskCategory>();

  for (const p of PATTERNS) {
    if (p.re.test(text)) {
      matched.add(p.category);
      signals.push(...p.signals);
    }
  }

  if (matched.size === 0) {
    return {
      category: "conversation",
      reasoningLevel: "low",
      codingRequired: false,
      researchRequired: false,
      toolsRequired: false,
      projectAccessRequired: false,
      collaborationUseful: false,
      qaRequired: false,
      finalReviewRequired: false,
      confidence: text.length > 20 ? "medium" : "low",
      signals: ["conversation"],
    };
  }

  let category: TaskCategory;
  if (matched.size > 1) category = "mixed";
  else category = [...matched][0]!;

  const codingRequired =
    matched.has("coding") ||
    matched.has("project_change") ||
    matched.has("debugging");
  const researchRequired = matched.has("research") || category === "mixed";
  const projectAccessRequired =
    matched.has("project_change") ||
    matched.has("debugging") ||
    matched.has("qa") ||
    matched.has("coding");
  const qaRequired =
    matched.has("qa") ||
    matched.has("project_change") ||
    /\b(fix|implement|refactor)\b/i.test(text);
  const collaborationUseful =
    category === "mixed" ||
    matched.has("review") ||
    matched.has("project_change") ||
    text.length > 120;
  const finalReviewRequired =
    collaborationUseful || matched.has("review") || qaRequired;

  const reasoningLevel: ReasoningLevel =
    category === "mixed" || matched.has("debugging")
      ? "high"
      : codingRequired || researchRequired
        ? "medium"
        : "low";

  return {
    category,
    reasoningLevel,
    codingRequired,
    researchRequired,
    toolsRequired: projectAccessRequired || codingRequired,
    projectAccessRequired,
    collaborationUseful,
    qaRequired,
    finalReviewRequired,
    confidence: matched.size >= 2 ? "high" : "medium",
    signals: [...new Set(signals)],
  };
}
