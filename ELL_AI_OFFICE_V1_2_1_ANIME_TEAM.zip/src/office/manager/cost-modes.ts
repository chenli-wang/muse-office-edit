/**
 * Cost modes and resource eligibility for ELL Manager.
 */

export type CostMode = "FREE_ONLY" | "FREE_FIRST" | "PAID";

export type CostClass = "FREE" | "PAID" | "UNKNOWN";

export interface ResourceCostMeta {
  providerId: string;
  modelId?: string;
  costClass: CostClass;
  priority?: number;
}

export interface CostPolicy {
  mode: CostMode;
  /** Explicit allowlist of paid provider ids when FREE_FIRST/PAID. */
  allowPaidProviders?: string[];
  /** Soft budget counter (calls), not currency — avoids false precision. */
  maxProviderCalls?: number;
}

export const DEFAULT_COST_POLICY: CostPolicy = {
  mode: "FREE_FIRST",
  allowPaidProviders: [],
  maxProviderCalls: 40,
};

/**
 * Whether a resource may be used under the policy.
 * UNKNOWN is never allowed in FREE_ONLY.
 */
export function isResourceAllowed(
  meta: ResourceCostMeta,
  policy: CostPolicy,
): boolean {
  if (policy.mode === "FREE_ONLY") {
    return meta.costClass === "FREE";
  }
  if (policy.mode === "FREE_FIRST") {
    if (meta.costClass === "FREE") return true;
    if (meta.costClass === "UNKNOWN") return false;
    // PAID only if explicitly allowlisted
    const allow = policy.allowPaidProviders ?? [];
    return allow.includes(meta.providerId);
  }
  // PAID mode: FREE + PAID ok; UNKNOWN still blocked
  if (meta.costClass === "UNKNOWN") return false;
  return true;
}

/** Sort candidates: free first, then priority, then id. */
export function rankResources(
  resources: ResourceCostMeta[],
  policy: CostPolicy,
): ResourceCostMeta[] {
  const allowed = resources.filter((r) => isResourceAllowed(r, policy));
  return allowed.sort((a, b) => {
    const freeA = a.costClass === "FREE" ? 0 : 1;
    const freeB = b.costClass === "FREE" ? 0 : 1;
    if (freeA !== freeB) return freeA - freeB;
    const pa = a.priority ?? 100;
    const pb = b.priority ?? 100;
    if (pa !== pb) return pa - pb;
    return a.providerId.localeCompare(b.providerId);
  });
}

/** Map known providers to default cost class (configurable override elsewhere). */
export function defaultCostClass(providerId: string): CostClass {
  if (providerId === "mock") return "FREE";
  // Live providers: treat as PAID unless explicitly configured free.
  // FREE_ONLY must not assume Gemini/xAI are free.
  if (providerId === "gemini" || providerId === "xai" || providerId === "anthropic" || providerId === "openai") {
    return "PAID";
  }
  return "UNKNOWN";
}
