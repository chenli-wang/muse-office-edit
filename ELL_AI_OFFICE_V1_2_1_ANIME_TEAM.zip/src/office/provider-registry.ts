/**
 * Provider registry — adapters + health + router.
 * Real adapters register only when configured (API key present).
 */

import { MockProvider, listProviderRecordsFrom, type ProviderAdapter } from "./providers.ts";
import { createXaiProviderFromEnv, XaiProvider } from "./xai-provider.ts";
import { createGeminiProviderFromEnv, GeminiProvider } from "./gemini-provider.ts";
import { createAnthropicProviderFromEnv, AnthropicProvider } from "./anthropic-provider.ts";
import { createOpenAIProviderFromEnv, OpenAIProvider } from "./openai-provider.ts";
import {
  ProviderHealthStore,
  seedDefaultProviderHealth,
  withHealthTracking,
  type ProviderHealth,
} from "./provider-health.ts";
import type { ProviderRecord } from "./types.ts";
import { ProviderRouter } from "./provider-router.ts";

export interface ProviderRegistry {
  primary: ProviderAdapter;
  adapters: ProviderAdapter[];
  health: ProviderHealthStore;
  router: ProviderRouter;
  listModels(): Promise<ProviderRecord[]>;
  listHealth(): ProviderHealth[];
  get(id: string): ProviderAdapter | undefined;
  getHealth(id: string): ProviderHealth | undefined;
}

export interface RegistryOptions {
  primary?: ProviderAdapter;
  extra?: ProviderAdapter[];
  autoDetectXai?: boolean;
  autoDetectGemini?: boolean;
  autoDetectAnthropic?: boolean;
  autoDetectOpenAI?: boolean;
  health?: ProviderHealthStore;
}

export function createProviderRegistry(options: RegistryOptions = {}): ProviderRegistry {
  const health = options.health ?? new ProviderHealthStore();
  const mock = new MockProvider();
  const rawAdapters: ProviderAdapter[] = [mock];

  const xaiConfigured = isXaiConfigured();
  const geminiConfigured = isGeminiConfigured();
  const anthropicConfigured = isAnthropicConfigured();
  const openaiConfigured = isOpenAIConfigured();

  if (options.autoDetectXai !== false) {
    const xai = createXaiProviderFromEnv();
    if (xai.isConfigured()) rawAdapters.push(xai);
  }
  if (options.autoDetectGemini !== false) {
    const gemini = createGeminiProviderFromEnv();
    if (gemini.isConfigured()) rawAdapters.push(gemini);
  }
  if (options.autoDetectAnthropic !== false) {
    const anthropic = createAnthropicProviderFromEnv();
    if (anthropic.isConfigured()) rawAdapters.push(anthropic);
  }
  if (options.autoDetectOpenAI !== false) {
    const openai = createOpenAIProviderFromEnv();
    if (openai.isConfigured()) rawAdapters.push(openai);
  }

  if (options.extra) {
    for (const adapter of options.extra) {
      if (!rawAdapters.some((a) => a.id === adapter.id)) rawAdapters.push(adapter);
    }
  }

  seedDefaultProviderHealth(health, {
    xaiConfigured,
    geminiConfigured,
    anthropicConfigured,
    openaiConfigured,
    mockLabel: mock.label,
  });

  for (const adapter of rawAdapters) {
    if (["mock", "xai", "gemini", "anthropic", "openai"].includes(adapter.id)) continue;
    health.register({
      providerId: adapter.id,
      label: adapter.label,
      configured: true,
      availability: "available",
    });
  }

  const adapters = rawAdapters.map((adapter) => withHealthTracking(adapter, health));

  let primary = options.primary ?? mock;
  if (options.primary) {
    primary = withHealthTracking(options.primary, health);
    if (!adapters.some((a) => a.id === primary.id)) adapters.unshift(primary);
    else {
      const idx = adapters.findIndex((a) => a.id === primary.id);
      adapters[idx] = primary;
    }
  } else {
    primary = adapters.find((a) => a.id === mock.id) ?? adapters[0]!;
  }

  const router = new ProviderRouter({ adapters, primary, health });

  return {
    primary,
    adapters,
    health,
    router,
    async listModels() {
      return listProviderRecordsFrom(adapters);
    },
    listHealth() {
      return health.list();
    },
    get(id: string) {
      return adapters.find((a) => a.id === id);
    },
    getHealth(id: string) {
      return health.get(id);
    },
  };
}

export function isXaiConfigured(): boolean {
  return Boolean(process.env.XAI_API_KEY?.trim());
}
export function isGeminiConfigured(): boolean {
  return Boolean(process.env.GEMINI_API_KEY?.trim());
}
export function isAnthropicConfigured(): boolean {
  return Boolean(process.env.ANTHROPIC_API_KEY?.trim());
}
export function isOpenAIConfigured(): boolean {
  return Boolean(process.env.OPENAI_API_KEY?.trim());
}

export { MockProvider, XaiProvider, GeminiProvider, AnthropicProvider, OpenAIProvider, ProviderHealthStore };
