import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { ProviderError } from "./errors.ts";
import {
  ProviderRouter,
  sanitizePublicErrorMessage,
  isRecoverableProviderError,
  DEFAULT_ROUTING_POLICY,
} from "./provider-router.ts";
import { ProviderHealthStore, withHealthTracking } from "./provider-health.ts";
import {
  MockProvider,
  MOCK_MODEL_ID,
  type ProviderAdapter,
  type GenerateRequest,
  type GenerateResponse,
  type ProviderCapabilities,
} from "./providers.ts";
import { createOfficeRuntime, replaceOffice } from "./runtime.ts";
import { handleListProviders } from "./http.ts";
import type { ProviderAvailability } from "./types.ts";

function makeAdapter(opts: {
  id: string;
  costClass?: "free" | "paid" | "unknown";
  failWith?: ProviderError;
  failOnceThenSucceed?: boolean;
  capabilities?: Partial<ProviderCapabilities>;
}): ProviderAdapter & { calls: number } {
  let calls = 0;
  let failedOnce = false;
  const caps: ProviderCapabilities = {
    text: true,
    code: true,
    streaming: false,
    tools: false,
    vision: false,
    jsonMode: false,
    ...opts.capabilities,
  };
  const adapter: ProviderAdapter & { calls: number } = {
    id: opts.id,
    label: opts.id,
    capabilities: caps,
    get calls() {
      return calls;
    },
    getAvailability(): ProviderAvailability {
      return "available";
    },
    listModels() {
      return [
        {
          id: `${opts.id}:model`,
          provider: opts.id,
          capabilities: ["text"],
          contextWindow: null,
          costClass: opts.costClass ?? "paid",
          availability: "available" as const,
          label: opts.id,
        },
      ];
    },
    async generate(_req: GenerateRequest): Promise<GenerateResponse> {
      calls += 1;
      if (opts.failOnceThenSucceed && !failedOnce) {
        failedOnce = true;
        throw opts.failWith ?? new ProviderError("RATE_LIMIT", "limited", true);
      }
      if (opts.failWith && !opts.failOnceThenSucceed) {
        throw opts.failWith;
      }
      return {
        text: `ok-from-${opts.id}`,
        model: `${opts.id}:model`,
        provider: opts.id,
        latencyMs: 1,
      };
    },
  };
  return adapter;
}

function harness(adapters: ProviderAdapter[], primary: ProviderAdapter) {
  const health = new ProviderHealthStore();
  for (const a of adapters) {
    health.register({
      providerId: a.id,
      label: a.label,
      configured: true,
      availability: "available",
    });
  }
  const tracked = adapters.map((a) => withHealthTracking(a, health));
  const primaryTracked =
    tracked.find((a) => a.id === primary.id) ?? withHealthTracking(primary, health);
  const router = new ProviderRouter({
    adapters: tracked,
    primary: primaryTracked,
    health,
  });
  return { router, health, tracked };
}

describe("ProviderRouter selection", () => {
  it("primary-only returns only primary", () => {
    const free = makeAdapter({ id: "free-a", costClass: "free" });
    const paid = makeAdapter({ id: "paid-b", costClass: "paid" });
    const { router } = harness([free, paid], paid);
    const { candidates, selectionReason } = router.selectCandidates({
      policy: { mode: "primary-only" },
    });
    assert.deepEqual(
      candidates.map((c) => c.id),
      ["paid-b"],
    );
    assert.match(selectionReason, /primary-only/);
  });

  it("free-first prefers free costClass deterministically", () => {
    const paid = makeAdapter({ id: "paid-z", costClass: "paid" });
    const freeB = makeAdapter({ id: "free-b", costClass: "free" });
    const freeA = makeAdapter({ id: "free-a", costClass: "free" });
    const { router } = harness([paid, freeB, freeA], paid);
    const { candidates } = router.selectCandidates({
      policy: { mode: "free-first", maxAttempts: 5 },
    });
    assert.deepEqual(
      candidates.map((c) => c.id),
      ["free-a", "free-b", "paid-z"],
    );
  });

  it("free-first excludes mock by default", () => {
    const mock = new MockProvider();
    const paid = makeAdapter({ id: "paid-1", costClass: "paid" });
    const { router } = harness([mock, paid], mock);
    const { candidates } = router.selectCandidates({
      policy: { mode: "free-first", maxAttempts: 5 },
    });
    assert.equal(
      candidates.some((c) => c.id === "mock"),
      false,
    );
    assert.deepEqual(
      candidates.map((c) => c.id),
      ["paid-1"],
    );
  });

  it("skips rate-limited and unconfigured providers", () => {
    const a = makeAdapter({ id: "a", costClass: "free" });
    const b = makeAdapter({ id: "b", costClass: "free" });
    const { router, health } = harness([a, b], a);
    health.recordFailure("a", new ProviderError("RATE_LIMIT", "limited", true));
    const { candidates } = router.selectCandidates({
      policy: { mode: "free-first", maxAttempts: 5 },
    });
    assert.deepEqual(
      candidates.map((c) => c.id),
      ["b"],
    );
  });

  it("capability matching excludes adapters lacking required capability", () => {
    const textOnly = makeAdapter({
      id: "text",
      costClass: "free",
      capabilities: { code: false },
    });
    const withCode = makeAdapter({
      id: "code",
      costClass: "paid",
      capabilities: { code: true },
    });
    const { router } = harness([textOnly, withCode], textOnly);
    const { candidates } = router.selectCandidates({
      policy: { mode: "free-first", maxAttempts: 5 },
      requiredCapabilities: ["text", "code"],
    });
    assert.deepEqual(
      candidates.map((c) => c.id),
      ["code"],
    );
  });
});

describe("ProviderRouter fallback", () => {
  it("falls back on 429 to next provider", async () => {
    const a = makeAdapter({
      id: "a",
      costClass: "free",
      failWith: new ProviderError("RATE_LIMIT", "limited", true),
    });
    const b = makeAdapter({ id: "b", costClass: "paid" });
    const { router } = harness([a, b], a);
    const { response, trace } = await router.executeWithFallback(
      { model: "m", systemPrompt: "s", userPrompt: "u" },
      { policy: { mode: "free-first", maxAttempts: 3 } },
    );
    assert.equal(response.provider, "b");
    assert.equal(trace.fallbackUsed, true);
    assert.equal(trace.success, true);
    assert.equal(trace.finalProviderId, "b");
    assert.equal(trace.attempts[0]?.outcome, "failure");
    assert.equal(trace.attempts[0]?.errorClass, "RATE_LIMIT");
  });

  it("falls back on timeout / network / 5xx", async () => {
    for (const code of ["TIMEOUT", "NETWORK", "SERVER_ERROR"] as const) {
      const a = makeAdapter({
        id: "fail",
        costClass: "free",
        failWith: new ProviderError(code, code, true),
      });
      const b = makeAdapter({ id: "ok", costClass: "paid" });
      const { router } = harness([a, b], a);
      const { response, trace } = await router.executeWithFallback(
        { model: "m", systemPrompt: "s", userPrompt: "u" },
        { policy: { mode: "free-first", maxAttempts: 3 } },
      );
      assert.equal(response.provider, "ok");
      assert.equal(trace.fallbackUsed, true);
    }
  });

  it("does not fallback on AUTH", async () => {
    const a = makeAdapter({
      id: "a",
      costClass: "free",
      failWith: new ProviderError("AUTH", "bad key", false),
    });
    const b = makeAdapter({ id: "b", costClass: "paid" });
    const { router } = harness([a, b], a);
    await assert.rejects(
      () =>
        router.executeWithFallback(
          { model: "m", systemPrompt: "s", userPrompt: "u" },
          { policy: { mode: "free-first", maxAttempts: 3 } },
        ),
      (err: unknown) => {
        assert.ok(err instanceof ProviderError);
        assert.equal(err.code, "AUTH");
        return true;
      },
    );
  });

  it("does not fallback on INVALID_REQUEST", async () => {
    const a = makeAdapter({
      id: "a",
      costClass: "free",
      failWith: new ProviderError("INVALID_REQUEST", "bad body", false),
    });
    const b = makeAdapter({ id: "b", costClass: "paid" });
    const { router } = harness([a, b], a);
    await assert.rejects(
      () =>
        router.executeWithFallback(
          { model: "m", systemPrompt: "s", userPrompt: "u" },
          { policy: { mode: "free-first", maxAttempts: 3 } },
        ),
      (err: unknown) => err instanceof ProviderError && err.code === "INVALID_REQUEST",
    );
  });

  it("respects maxAttempts and never retries same provider", async () => {
    const a = makeAdapter({
      id: "a",
      costClass: "free",
      failWith: new ProviderError("SERVER_ERROR", "x", true),
    });
    const b = makeAdapter({
      id: "b",
      costClass: "paid",
      failWith: new ProviderError("SERVER_ERROR", "y", true),
    });
    const c = makeAdapter({
      id: "c",
      costClass: "paid",
      failWith: new ProviderError("SERVER_ERROR", "z", true),
    });
    const { router } = harness([a, b, c], a);
    let traceAttempts: { providerId: string; outcome: string }[] = [];
    try {
      await router.executeWithFallback(
        { model: "m", systemPrompt: "s", userPrompt: "u" },
        { policy: { mode: "free-first", maxAttempts: 2 } },
      );
      assert.fail("expected throw");
    } catch (err) {
      assert.ok(err instanceof ProviderError);
    }
    // Re-run with captured select to verify candidate cap
    const { candidates } = router.selectCandidates({
      policy: { mode: "free-first", maxAttempts: 2 },
    });
    assert.equal(candidates.length, 2);
    assert.deepEqual(
      candidates.map((x) => x.id),
      ["a", "b"],
    );
    // Ensure c was not a candidate under maxAttempts=2
    assert.equal(candidates.some((x) => x.id === "c"), false);
  });

  it("no infinite fallback loop: candidates finite", async () => {
    const a = makeAdapter({
      id: "only",
      costClass: "free",
      failWith: new ProviderError("NETWORK", "down", true),
    });
    const { router } = harness([a], a);
    await assert.rejects(() =>
      router.executeWithFallback(
        { model: "m", systemPrompt: "s", userPrompt: "u" },
        { policy: { mode: "free-first", maxAttempts: 5 } },
      ),
    );
  });
});

describe("sanitization & security", () => {
  it("sanitizePublicErrorMessage redacts key-like strings", () => {
    const cleaned = sanitizePublicErrorMessage(
      new Error("auth failed secret-api-key-123 and Bearer tok_abc"),
    );
    assert.equal(cleaned.includes("secret-api-key-123"), false);
    assert.equal(cleaned.includes("Bearer tok_abc"), false);
    assert.match(cleaned, /REDACTED/);
  });

  it("isRecoverableProviderError classification", () => {
    assert.equal(isRecoverableProviderError(new ProviderError("RATE_LIMIT", "x", true)), true);
    assert.equal(isRecoverableProviderError(new ProviderError("AUTH", "x", false)), false);
    assert.equal(isRecoverableProviderError(new Error("nope")), false);
  });

  it("secret-api-key-123 never appears in public providers API or health", async () => {
    const store = new ProviderHealthStore();
    store.register({ providerId: "xai", label: "xAI", configured: true });
    store.recordFailure(
      "xai",
      new ProviderError("AUTH", "invalid secret-api-key-123 for account", false),
    );
    const healthJson = JSON.stringify(store.list());
    assert.equal(healthJson.includes("secret-api-key-123"), false);

    // Runtime HTTP surface
    replaceOffice(
      createOfficeRuntime({
        delays: { planningMs: 0, assignMs: 0, workMs: 0, synthMs: 0 },
      }),
    );
    // Force a failure with secret in message through mock is not secret-bearing;
    // inject via health path already covered. Also hit listProviders.
    const listed = await handleListProviders();
    const body = JSON.stringify(listed.body);
    assert.equal(body.includes("secret-api-key-123"), false);
    assert.equal(body.includes("XAI_API_KEY"), false);
    assert.equal(body.includes("GEMINI_API_KEY"), false);
  });

  it("DEFAULT_ROUTING_POLICY is primary-only for Phase 1 compatibility", () => {
    assert.equal(DEFAULT_ROUTING_POLICY.mode, "primary-only");
  });
});
