import { isOfficeError } from "./errors.ts";
import { getOffice } from "./runtime.ts";
import { buildDashboardSnapshot } from "./dashboard-api.ts";
import { loadEllConfig, publicConfigView, ELL_VERSION } from "./config/ell-config.ts";
import { validateStartup } from "./config/startup.ts";
import { buildEmployeeRegistry, buildProviderRegistryAsync } from "./config/registries.ts";

export interface HttpResult<T> {
  status: number;
  body: T;
}

export function errorBody(error: unknown): HttpResult<{ error: string; code?: string }> {
  if (isOfficeError(error)) {
    return { status: error.status, body: { error: error.message, code: error.code } };
  }
  return { status: 500, body: { error: "Internal office error", code: "INTERNAL" } };
}

export function jsonResult(result: { status: number; body: unknown }): Response {
  return Response.json(result.body, { status: result.status });
}

export async function handleHealth() {
  return { status: 200, body: { ok: true, service: "ell-ai-office", mockMode: true } };
}

export async function handleListAgents() {
  return { status: 200, body: await getOffice().listAgents() };
}

export async function handleGetAgent(id: string) {
  try {
    return { status: 200, body: await getOffice().getAgent(id) };
  } catch (error) {
    return errorBody(error);
  }
}

export async function handleListTasks() {
  return { status: 200, body: await getOffice().listTasks() };
}

export async function handleCreateTask(body: unknown) {
  try {
    const payload = (body ?? {}) as {
      objective?: unknown;
      simulateError?: unknown;
      mode?: unknown;
    };
    const mode = payload.mode === "multi" ? "multi" : "single";
    const task = await getOffice().createTask({
      objective: String(payload.objective ?? ""),
      simulateError: Boolean(payload.simulateError),
      mode,
    });
    return { status: 201, body: task };
  } catch (error) {
    return errorBody(error);
  }
}

export async function handleGetTask(id: string) {
  try {
    return { status: 200, body: await getOffice().getTask(id) };
  } catch (error) {
    return errorBody(error);
  }
}

export async function handleCancelTask(id: string) {
  try {
    return { status: 200, body: await getOffice().cancelTask(id) };
  } catch (error) {
    return errorBody(error);
  }
}

export async function handleListProviders() {
  return { status: 200, body: await getOffice().listProviders() };
}

export async function handleListEvents(since?: string) {
  return { status: 200, body: await getOffice().listEvents(since) };
}


export async function handleDashboardSnapshot() {
  return { status: 200, body: await buildDashboardSnapshot() };
}

export async function handleMemorySummary() {
  try {
    const office = getOffice();
    const snap = office.getProjectContextSnapshot(20);
    return {
      status: 200,
      body: {
        projectId: snap.projectId,
        title: snap.title,
        entryCount: snap.entryCount,
        entries: snap.entries.map((e) => ({
          id: e.id,
          type: e.type,
          content: e.content.slice(0, 400),
          sourceEmployeeId: e.sourceEmployeeId,
          tags: e.tags,
          createdAt: e.createdAt,
        })),
      },
    };
  } catch (error) {
    return errorBody(error);
  }
}

export async function handleListTools() {
  return { status: 200, body: getOffice().listTools() };
}


export async function handleStartup() {
  const cfg = loadEllConfig();
  return { status: 200, body: validateStartup(cfg) };
}

export async function handlePublicConfig() {
  const cfg = loadEllConfig();
  return { status: 200, body: publicConfigView(cfg) };
}

export async function handleEmployeeRegistry() {
  const cfg = loadEllConfig();
  return { status: 200, body: buildEmployeeRegistry(cfg) };
}

export async function handleProviderRegistry() {
  const cfg = loadEllConfig();
  try {
    const { getOffice } = await import("./runtime.ts");
    const body = await buildProviderRegistryAsync(cfg, getOffice());
    return { status: 200, body };
  } catch {
    const { buildProviderRegistry } = await import("./config/registries.ts");
    return { status: 200, body: buildProviderRegistry(cfg) };
  }
}

export async function handleVersion() {
  return {
    status: 200,
    body: {
      name: "ELL AI Office",
      version: ELL_VERSION,
      phase: 15,
    },
  };
}


/**
 * Private employee chat — single-employee generate via existing provider router.
 * Routes through the selected employee's configured provider/model binding.
 * Does not create orchestrator tasks or mutate project workspace.
 * Never fabricates replies or silently uses mock when a live provider fails.
 */
export async function handlePrivateChat(req: Request): Promise<{ status: number; body: unknown }> {
  if (req.method !== "POST") {
    return { status: 405, body: { error: "Method not allowed" } };
  }
  let body: { employeeId?: string; message?: string };
  try {
    body = (await req.json()) as { employeeId?: string; message?: string };
  } catch {
    return { status: 400, body: { error: "Invalid JSON" } };
  }
  const employeeId = String(body.employeeId ?? "").trim();
  const message = String(body.message ?? "").trim().slice(0, 2000);
  if (!employeeId || !message) {
    return { status: 400, body: { error: "employeeId and message required" } };
  }
  const allowed = new Set(["claude", "gemini", "grok", "gpt"]);
  if (!allowed.has(employeeId)) {
    return { status: 400, body: { error: "Unknown employee" } };
  }

  try {
    const { getOffice } = await import("./runtime.ts");
    const office = getOffice();
    const result = await office.privateChat({ employeeId, message });
    return { status: 200, body: result };
  } catch (e) {
    return {
      status: 200,
      body: {
        ok: false,
        unavailable: true,
        error: e instanceof Error ? e.message : "Private chat error",
        employeeId,
      },
    };
  }
}
