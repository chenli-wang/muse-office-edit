import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { ConflictError, ValidationError } from "./errors.ts";
import { MockProvider } from "./providers.ts";
import { createOfficeRuntime } from "./runtime.ts";

function harness(delays?: { planningMs?: number; assignMs?: number; workMs?: number; synthMs?: number }) {
  let t = 1_000_000;
  const runtime = createOfficeRuntime({
    now: () => t,
    delays: {
      planningMs: 10,
      assignMs: 10,
      workMs: 100,
      synthMs: 10,
      ...delays,
    },
  });
  return {
    runtime,
    advance(ms: number) {
      t += ms;
    },
  };
}

describe("task creation", () => {
  it("rejects an empty objective", async () => {
    const { runtime } = harness();
    await assert.rejects(() => runtime.createTask({ objective: "   " }), ValidationError);
  });

  it("creates a task and assigns Claude", async () => {
    const { runtime, advance } = harness();
    const created = await runtime.createTask({ objective: "Analyze fetchWithFallback" });
    assert.equal(created.status, "planning");
    assert.match(created.id, /^task_/);
    assert.equal(created.title, "Analyze fetchWithFallback");
    assert.equal(created.outputs.length, 0);

    advance(15);
    const assigned = await runtime.getTask(created.id);
    assert.equal(assigned.status, "assigned");
    assert.deepEqual(assigned.assignedEmployeeIds, ["claude"]);
    assert.equal(assigned.plan?.employeeId, "claude");
    assert.equal(assigned.subtasks.length, 1);
  });
});

describe("task completion", () => {
  it("runs Claude through the mock provider and stores a synthesis", async () => {
    const { runtime, advance } = harness();
    const created = await runtime.createTask({
      objective: "Audit the fallback timeout in fetchWithFallback",
    });

    advance(25);
    const running = await runtime.getTask(created.id);
    assert.equal(running.status, "running");
    const agents = await runtime.listAgents();
    const claude = agents.find((row) => row.id === "claude");
    assert.equal(claude?.status, "working");
    assert.equal(claude?.provider, "mock");
    assert.equal(claude?.model, "mock:phase1");

    advance(200);
    const done = await runtime.getTask(created.id);
    assert.equal(done.status, "completed");
    assert.ok(done.completedAt);
    assert.equal(done.outputs.length, 1);
    const output = done.outputs[0];
    assert.equal(output.employeeId, "claude");
    assert.match(output.summary, /Mock analysis completed/);
    assert.ok(output.findings.length >= 1);
    assert.ok(output.evidence.some((line) => /No API key/i.test(line)));
    assert.equal(output.provider, "mock");
    assert.equal(done.finalResult?.synthesizedBy, "orchestrator");
    assert.match(done.finalResult?.summary ?? "", /Mock analysis completed/);

    const idle = (await runtime.listAgents()).find((row) => row.id === "claude");
    assert.equal(idle?.status, "idle");
    assert.equal(idle?.currentTaskId, null);

    const events = await runtime.listEvents();
    const types = events.map((event) => event.type);
    assert.ok(types.includes("task.created"));
    assert.ok(types.includes("task.assigned"));
    assert.ok(types.includes("agent.started"));
    assert.ok(types.includes("agent.completed"));
    assert.ok(types.includes("task.completed"));
  });

  it("completes immediately when delays are zero", async () => {
    const { runtime } = harness({ planningMs: 0, assignMs: 0, workMs: 0, synthMs: 0 });
    const task = await runtime.createTask({ objective: "Instant path" });
    assert.equal(task.status, "completed");
    assert.equal(task.outputs.length, 1);
  });
});

describe("cancellation", () => {
  it("cancels a running task and does not store an employee result", async () => {
    const { runtime, advance } = harness({ workMs: 5_000 });
    const created = await runtime.createTask({ objective: "Long running audit" });
    advance(30);
    const running = await runtime.getTask(created.id);
    assert.equal(running.status, "running");

    const cancelled = await runtime.cancelTask(created.id);
    assert.equal(cancelled.status, "cancelled");
    assert.ok(cancelled.cancelledAt);
    assert.equal(cancelled.outputs.length, 0);

    advance(20_000);
    const still = await runtime.getTask(created.id);
    assert.equal(still.status, "cancelled");
    assert.equal(still.outputs.length, 0);

    const claude = (await runtime.listAgents()).find((row) => row.id === "claude");
    assert.equal(claude?.status, "idle");

    const events = await runtime.listEvents();
    assert.ok(events.some((event) => event.type === "task.cancelled"));
    assert.equal(
      events.some((event) => event.type === "task.completed"),
      false,
    );
  });

  it("is idempotent when cancelling an already cancelled task", async () => {
    const { runtime } = harness({ workMs: 5_000 });
    const created = await runtime.createTask({ objective: "Cancel twice" });
    const first = await runtime.cancelTask(created.id);
    const second = await runtime.cancelTask(created.id);
    assert.equal(first.status, "cancelled");
    assert.equal(second.status, "cancelled");
    assert.equal(second.id, first.id);
  });

  it("rejects cancel after completion", async () => {
    const { runtime } = harness({ planningMs: 0, assignMs: 0, workMs: 0, synthMs: 0 });
    const done = await runtime.createTask({ objective: "Already done" });
    assert.equal(done.status, "completed");
    await assert.rejects(() => runtime.cancelTask(done.id), ConflictError);
  });

  it("rejects cancel after failure", async () => {
    const { runtime } = harness({ planningMs: 0, assignMs: 0, workMs: 0, synthMs: 0 });
    const failed = await runtime.createTask({
      objective: "Break the provider",
      simulateError: true,
    });
    assert.equal(failed.status, "failed");
    await assert.rejects(() => runtime.cancelTask(failed.id), ConflictError);
  });
});

describe("error handling", () => {
  it("records an explicit provider failure without fabricating success", async () => {
    const { runtime, advance } = harness();
    const created = await runtime.createTask({
      objective: "Please fail this run",
      simulateError: true,
    });
    advance(400);
    const failed = await runtime.getTask(created.id);
    assert.equal(failed.status, "failed");
    assert.equal(failed.outputs.length, 0);
    assert.equal(failed.finalResult, null);
    assert.equal(failed.error?.class, "SERVER_ERROR");
    assert.match(failed.error?.message ?? "", /instructed to fail/);
    assert.equal(failed.error?.retryable, false);

    const claude = (await runtime.listAgents()).find((row) => row.id === "claude");
    assert.equal(claude?.status, "error");

    const events = await runtime.listEvents();
    assert.ok(events.some((event) => event.type === "agent.failed"));
    assert.ok(events.some((event) => event.type === "task.failed"));
    assert.equal(
      events.some((event) => event.type === "task.completed"),
      false,
    );
  });

  it("does not call generate when the mock is asked to fail after cancel", async () => {
    let calls = 0;
    const inner = new MockProvider();
    const provider = {
      id: inner.id,
      label: inner.label,
      capabilities: inner.capabilities,
      getAvailability: () => inner.getAvailability(),
      listModels: () => inner.listModels(),
      async generate(request: Parameters<MockProvider["generate"]>[0]) {
        calls += 1;
        return inner.generate(request);
      },
    };
    let t = 1_000_000;
    const runtime = createOfficeRuntime({
      now: () => t,
      delays: { planningMs: 0, assignMs: 0, workMs: 5_000, synthMs: 0 },
      provider,
    });
    const created = await runtime.createTask({ objective: "Cancel before generate" });
    t += 20;
    await runtime.cancelTask(created.id);
    t += 10_000;
    await runtime.tick();
    assert.equal(calls, 0);
    assert.equal((await runtime.getTask(created.id)).status, "cancelled");
  });
});

describe("roster", () => {
  it("keeps Gemini, Grok, and GPT offline in Phase 1", async () => {
    const { runtime } = harness();
    const agents = await runtime.listAgents();
    assert.deepEqual(
      agents.map((row) => row.id),
      ["claude", "gemini", "grok", "gpt"],
    );
    assert.equal(agents.find((row) => row.id === "gemini")?.status, "offline");
    assert.equal(agents.find((row) => row.id === "grok")?.status, "offline");
    assert.equal(agents.find((row) => row.id === "gpt")?.status, "offline");
  });
});
