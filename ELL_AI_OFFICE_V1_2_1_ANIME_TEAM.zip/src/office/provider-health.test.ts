import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { ProviderError } from "./errors.ts";
import {
  ProviderHealthStore,
  seedDefaultProviderHealth,
  withHealthTracking,
} from "./provider-health.ts";
import { MockProvider, MOCK_MODEL_ID } from "./providers.ts";
import { XaiProvider } from "./xai-provider.ts";
import { GeminiProvider, GEMINI_MODEL_ID } from "./gemini-provider.ts";
import { createProviderRegistry } from "./provider-registry.ts";
import { createOfficeRuntime, replaceOffice } from "./runtime.ts";
import { handleListProviders } from "./http.ts";

describe("ProviderHealthStore", () => {
  it("A. mock provider health is configured and available", () => {
    const store = new ProviderHealthStore();
    seedDefaultProviderHealth(store, { xaiConfigured: false, geminiConfigured: false });
    const mock = store.get("mock");
    assert.ok(mock);
    assert.equal(mock.configured, true);
    assert.equal(mock.availability, "available");
    assert.equal(store.isAvailableForRequest("mock"), true);
  });

  it("B. xAI without key is configuration_error / disabled", () => {
    const store = new ProviderHealthStore();
    seedDefaultProviderHealth(store, { xaiConfigured: false, geminiConfigured: false });
    const xai = store.get("xai");
    assert.ok(xai);
    assert.equal(xai.configured, false);
    assert.equal(xai.availability, "disabled");
    assert.equal(xai.reason, "configuration_error");
    assert.equal(store.isAvailableForRequest("xai"), false);
    assert.equal(xai.checkedAt, null);
  });

  it("C. Gemini without key is configuration_error / disabled", () => {
    const store = new ProviderHealthStore();
    seedDefaultProviderHealth(store, { xaiConfigured: false, geminiConfigured: false });
    const gemini = store.get("gemini");
    assert.ok(gemini);
    assert.equal(gemini.configured, false);
    assert.equal(gemini.reason, "configuration_error");
    assert.equal(store.isAvailableForRequest("gemini"), false);
  });

  it("D. configured provider state before live check is not_checked / available", () => {
    const store = new ProviderHealthStore();
    seedDefaultProviderHealth(store, { xaiConfigured: true, geminiConfigured: true });
    const xai = store.get("xai");
    assert.ok(xai);
    assert.equal(xai.configured, true);
    assert.equal(xai.availability, "available");
    assert.equal(xai.reason, "not_checked");
    assert.equal(xai.checkedAt, null);
    assert.equal(xai.lastSuccessAt, null);
  });

  it("E. successful request → available + checkedAt", async () => {
    const store = new ProviderHealthStore();
    seedDefaultProviderHealth(store, { xaiConfigured: false, geminiConfigured: false });
    const mock = withHealthTracking(new MockProvider(), store);
    await mock.generate({
      model: MOCK_MODEL_ID,
      systemPrompt: "s",
      userPrompt: "hello",
    });
    const health = store.get("mock");
    assert.ok(health);
    assert.equal(health.availability, "available");
    assert.equal(health.reason, "ok");
    assert.ok(health.checkedAt);
    assert.ok(health.lastSuccessAt);
  });

  it("F. 429 → rate_limited", async () => {
    const store = new ProviderHealthStore();
    store.register({ providerId: "gemini", label: "Google Gemini", configured: true });
    const gemini = withHealthTracking(
      new GeminiProvider({
        apiKey: "k",
        fetchImpl: (async () =>
          new Response(JSON.stringify({ error: { message: "Resource exhausted" } }), {
            status: 429,
          })) as typeof fetch,
      }),
      store,
    );
    await assert.rejects(() =>
      gemini.generate({ model: GEMINI_MODEL_ID, systemPrompt: "s", userPrompt: "u" }),
    );
    const health = store.get("gemini");
    assert.equal(health?.availability, "rate_limited");
    assert.equal(health?.reason, "rate_limited");
    assert.equal(health?.lastErrorClass, "RATE_LIMIT");
    assert.equal(health?.cooldownUntil, null); // never invented
  });

  it("G/H. 401 and 403 → authentication_error", async () => {
    for (const status of [401, 403]) {
      const store = new ProviderHealthStore();
      store.register({ providerId: "gemini", label: "Google Gemini", configured: true });
      const gemini = withHealthTracking(
        new GeminiProvider({
          apiKey: "k",
          fetchImpl: (async () =>
            new Response(JSON.stringify({ error: { message: "denied" } }), {
              status,
            })) as typeof fetch,
        }),
        store,
      );
      await assert.rejects(() =>
        gemini.generate({ model: GEMINI_MODEL_ID, systemPrompt: "s", userPrompt: "u" }),
      );
      const health = store.get("gemini");
      assert.equal(health?.availability, "auth_error");
      assert.equal(health?.reason, "authentication_error");
      assert.equal(health?.lastErrorClass, "AUTH");
      assert.equal(store.isAvailableForRequest("gemini"), false);
    }
  });

  it("I. network failure → degraded / network_error", async () => {
    const store = new ProviderHealthStore();
    store.register({ providerId: "xai", label: "xAI (Grok)", configured: true });
    const xai = withHealthTracking(
      new XaiProvider({
        apiKey: "k",
        fetchImpl: (async () => {
          throw new Error("fetch failed: ECONNREFUSED");
        }) as typeof fetch,
      }),
      store,
    );
    await assert.rejects(() =>
      xai.generate({ model: "xai:grok-4.5", systemPrompt: "s", userPrompt: "u" }),
    );
    const health = store.get("xai");
    assert.equal(health?.availability, "degraded");
    assert.equal(health?.reason, "network_error");
    assert.equal(health?.lastErrorClass, "NETWORK");
  });

  it("J. timeout → degraded / timeout", async () => {
    const store = new ProviderHealthStore();
    store.register({ providerId: "mock", label: "Mock", configured: true });
    const mock = withHealthTracking(new MockProvider(), store);
    const controller = new AbortController();
    controller.abort();
    await assert.rejects(() =>
      mock.generate({
        model: MOCK_MODEL_ID,
        systemPrompt: "s",
        userPrompt: "u",
        signal: controller.signal,
      }),
    );
    const health = store.get("mock");
    assert.equal(health?.reason, "timeout");
    assert.equal(health?.lastErrorClass, "TIMEOUT");
  });

  it("K/L. cooldown only when explicitly set; never invented on 429", () => {
    const store = new ProviderHealthStore();
    store.register({ providerId: "gemini", label: "G", configured: true });
    store.recordFailure(
      "gemini",
      new ProviderError("RATE_LIMIT", "limited", true),
    );
    assert.equal(store.get("gemini")?.cooldownUntil, null);

    const until = Date.now() + 60_000;
    store.setCooldown("gemini", until);
    assert.ok(store.get("gemini")?.cooldownUntil);
    assert.equal(store.isAvailableForRequest("gemini", Date.now()), false);
    assert.equal(store.isAvailableForRequest("gemini", until + 1), true);
  });

  it("M. secrets never appear in health output", () => {
    const store = new ProviderHealthStore();
    seedDefaultProviderHealth(store, { xaiConfigured: true, geminiConfigured: true });
    store.recordFailure(
      "xai",
      new ProviderError("AUTH", "invalid key sk-secret-should-not-leak-in-structure", false),
    );
    const json = JSON.stringify(store.list());
    assert.equal(json.includes("XAI_API_KEY"), false);
    assert.equal(json.includes("GEMINI_API_KEY"), false);
    // Message may include provider error text; keys themselves must not be in field names or config dumps
    for (const row of store.list()) {
      assert.ok(!("apiKey" in row));
      assert.ok(!("authorization" in row));
    }
  });
});

describe("registry health integration", () => {
  it("N. registry seeds health for mock/xai/gemini", () => {
    const prevX = process.env.XAI_API_KEY;
    const prevG = process.env.GEMINI_API_KEY;
    try {
      delete process.env.XAI_API_KEY;
      delete process.env.GEMINI_API_KEY;
      const registry = createProviderRegistry({
        autoDetectXai: true,
        autoDetectGemini: true,
      });
      assert.equal(registry.primary.id, "mock");
      assert.ok(registry.getHealth("mock")?.configured);
      assert.equal(registry.getHealth("xai")?.configured, false);
      assert.equal(registry.getHealth("gemini")?.configured, false);
      assert.equal(registry.getHealth("xai")?.reason, "configuration_error");
      const list = registry.listHealth();
      assert.ok(list.some((h) => h.providerId === "mock"));
      assert.ok(list.some((h) => h.providerId === "xai"));
      assert.ok(list.some((h) => h.providerId === "gemini"));
    } finally {
      if (prevX !== undefined) process.env.XAI_API_KEY = prevX;
      else delete process.env.XAI_API_KEY;
      if (prevG !== undefined) process.env.GEMINI_API_KEY = prevG;
      else delete process.env.GEMINI_API_KEY;
    }
  });

  it("O. HTTP provider list exposes health without secrets", async () => {
    replaceOffice(
      createOfficeRuntime({
        delays: { planningMs: 0, assignMs: 0, workMs: 0, synthMs: 0 },
      }),
    );
    const result = await handleListProviders();
    assert.equal(result.status, 200);
    const body = result.body as unknown as Array<Record<string, unknown>>;
    assert.ok(Array.isArray(body));
    assert.ok(body.length >= 1);
    const mock = body.find((row) => row.id === "mock");
    assert.ok(mock);
    assert.equal(mock.configured, true);
    assert.ok("availability" in mock);
    assert.ok("availableForRequest" in mock);
    assert.ok("reason" in mock);
    const serialized = JSON.stringify(body);
    assert.equal(serialized.includes("API_KEY"), false);
    assert.equal(serialized.includes("Bearer"), false);
  });
});
