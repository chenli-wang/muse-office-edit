/**
 * Official Anthropic Messages API adapter.
 * https://api.anthropic.com/v1/messages
 */

import {
  DEFAULT_CAPABILITIES,
  httpStatusToErrorClass,
  normalizeProviderError,
  withTimeoutAndSignal,
  type GenerateRequest,
  type GenerateResponse,
  type ProviderAdapter,
  type ProviderCapabilities,
} from "./providers.ts";
import { ProviderError } from "./errors.ts";
import type { ProviderAvailability, ProviderRecord } from "./types.ts";

const ANTHROPIC_BASE_URL = "https://api.anthropic.com/v1";
export const ANTHROPIC_DEFAULT_MODEL = "claude-sonnet-4-5-20250929";
export const ANTHROPIC_MODEL_ID = "anthropic:default";

export interface AnthropicProviderOptions {
  apiKey?: string;
  model?: string;
  baseUrl?: string;
  fetchImpl?: typeof fetch;
  apiVersion?: string;
}

export class AnthropicProvider implements ProviderAdapter {
  readonly id = "anthropic";
  readonly label = "Anthropic (Claude)";
  readonly capabilities: ProviderCapabilities = {
    ...DEFAULT_CAPABILITIES,
    text: true,
    code: true,
    streaming: false,
    jsonMode: false,
  };

  private readonly apiKey: string | undefined;
  private readonly apiModel: string;
  private readonly baseUrl: string;
  private readonly fetchImpl: typeof fetch;
  private readonly apiVersion: string;
  private availability: ProviderAvailability;

  constructor(options: AnthropicProviderOptions = {}) {
    this.apiKey = options.apiKey?.trim() || undefined;
    this.apiModel = options.model?.trim() || ANTHROPIC_DEFAULT_MODEL;
    this.baseUrl = (options.baseUrl ?? ANTHROPIC_BASE_URL).replace(/\/$/, "");
    this.fetchImpl = options.fetchImpl ?? fetch;
    this.apiVersion = options.apiVersion ?? "2023-06-01";
    this.availability = this.apiKey ? "available" : "disabled";
  }

  isConfigured(): boolean {
    return Boolean(this.apiKey);
  }

  getApiModel(): string {
    return this.apiModel;
  }

  setAvailability(state: ProviderAvailability): void {
    this.availability = state;
  }

  getAvailability(): ProviderAvailability {
    if (!this.apiKey) return "disabled";
    return this.availability;
  }

  listModels(): ProviderRecord[] {
    return [
      {
        id: ANTHROPIC_MODEL_ID,
        provider: this.id,
        capabilities: ["text", "code"],
        contextWindow: null,
        costClass: "paid",
        availability: this.getAvailability(),
        label: `Anthropic (${this.apiModel})`,
      },
    ];
  }

  async generate(request: GenerateRequest): Promise<GenerateResponse> {
    if (!this.apiKey) {
      throw new ProviderError(
        "AUTH",
        "Anthropic provider is not configured (missing ANTHROPIC_API_KEY). Secrets stay server-side.",
        false,
      );
    }

    const availability = this.getAvailability();
    if (availability === "disabled" || availability === "offline") {
      throw new ProviderError("AUTH", `Anthropic provider is ${availability}.`, false);
    }
    if (
      availability === "rate_limited" ||
      availability === "daily_limit_reached" ||
      availability === "monthly_limit_reached"
    ) {
      throw new ProviderError("RATE_LIMIT", `Anthropic provider is ${availability}.`, true);
    }

    let apiModel = this.apiModel;
    if (request.model && request.model !== ANTHROPIC_MODEL_ID) {
      if (request.model.startsWith("anthropic:")) {
        const stripped = request.model.slice("anthropic:".length).trim();
        if (stripped && stripped !== "default") apiModel = stripped;
      } else if (request.model.startsWith("claude-")) {
        apiModel = request.model;
      }
    }

    const started = Date.now();
    const body = {
      model: apiModel,
      max_tokens: 4096,
      system: request.systemPrompt || undefined,
      messages: [{ role: "user", content: request.userPrompt }],
    };

    const work = (async (): Promise<GenerateResponse> => {
      let response: Response;
      try {
        response = await this.fetchImpl(`${this.baseUrl}/messages`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-api-key": this.apiKey as string,
            "anthropic-version": this.apiVersion,
          },
          body: JSON.stringify(body),
          signal: request.signal,
        });
      } catch (error) {
        throw normalizeProviderError(error, "Anthropic network request failed");
      }

      if (!response.ok) {
        let detail = `Anthropic API HTTP ${response.status}`;
        try {
          const errJson = (await response.json()) as {
            error?: { message?: string };
            message?: string;
          };
          detail = errJson?.error?.message || errJson?.message || detail;
        } catch {
          /* ignore */
        }
        const { code, retryable } = httpStatusToErrorClass(response.status);
        if (code === "RATE_LIMIT") this.availability = "rate_limited";
        else if (code === "AUTH") this.availability = "auth_error";
        else if (code === "SERVER_ERROR") this.availability = "provider_error";
        throw new ProviderError(code, detail, retryable);
      }

      if (
        this.availability === "rate_limited" ||
        this.availability === "provider_error" ||
        this.availability === "auth_error"
      ) {
        this.availability = "available";
      }

      const data = (await response.json()) as {
        content?: Array<{ type?: string; text?: string }>;
        model?: string;
        stop_reason?: string;
        usage?: { input_tokens?: number; output_tokens?: number };
      };

      const text = (data.content ?? [])
        .filter((c) => c.type === "text" || c.text)
        .map((c) => c.text ?? "")
        .join("");

      if (!text) {
        throw new ProviderError("CONTENT_ERROR", "Anthropic API returned empty content.", false);
      }

      return {
        text,
        model: data.model ?? apiModel,
        provider: this.id,
        latencyMs: Math.max(1, Date.now() - started),
        usage: data.usage
          ? {
              promptTokens: data.usage.input_tokens,
              completionTokens: data.usage.output_tokens,
              totalTokens:
                (data.usage.input_tokens ?? 0) + (data.usage.output_tokens ?? 0),
            }
          : undefined,
        finishReason: data.stop_reason,
      };
    })();

    try {
      return await withTimeoutAndSignal(work, {
        timeoutMs: request.timeoutMs,
        signal: request.signal,
        label: "Anthropic provider",
      });
    } catch (error) {
      throw normalizeProviderError(error, "Anthropic generate failed");
    }
  }
}

export function createAnthropicProviderFromEnv(
  options: Omit<AnthropicProviderOptions, "apiKey" | "model"> = {},
): AnthropicProvider {
  return new AnthropicProvider({
    ...options,
    apiKey: process.env.ANTHROPIC_API_KEY?.trim() || undefined,
    model: process.env.ANTHROPIC_MODEL?.trim() || undefined,
  });
}
