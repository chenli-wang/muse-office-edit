import assert from "node:assert/strict";
import { describe, it } from "node:test";
import {
  loadEllConfig,
  publicConfigView,
  ELL_VERSION,
  bindingModeFromConfig,
} from "./ell-config.ts";
import { validateStartup } from "./startup.ts";
import {
  buildEmployeeRegistry,
  buildProviderRegistry,
} from "./registries.ts";
import {
  handleStartup,
  handlePublicConfig,
  handleEmployeeRegistry,
  handleVersion,
} from "../http.ts";

describe("ELL v1.0 config", () => {
  it("loads defaults with version 1.0.0", () => {
    const cfg = loadEllConfig({ executionMode: "mock", costMode: "FREE_FIRST" });
    assert.equal(cfg.version, "1.0.0");
    assert.equal(ELL_VERSION, "1.0.0");
    assert.equal(cfg.phase, 15);
    assert.equal(cfg.executionMode, "mock");
    assert.ok(cfg.providers.some((p) => p.providerId === "mock"));
    assert.equal(cfg.employees.length, 4);
  });

  it("public config view has no api key values", () => {
    const cfg = loadEllConfig();
    const pub = JSON.stringify(publicConfigView(cfg));
    assert.equal(pub.includes("sk-"), false);
    assert.equal(pub.includes("Bearer"), false);
    assert.ok(pub.includes("costMode"));
  });

  it("FREE_ONLY / FREE_FIRST / PAID accepted", () => {
    for (const mode of ["FREE_ONLY", "FREE_FIRST", "PAID"] as const) {
      const cfg = loadEllConfig({ costMode: mode });
      assert.equal(cfg.costMode, mode);
    }
  });

  it("binding mode follows execution mode", () => {
    assert.equal(
      bindingModeFromConfig(loadEllConfig({ executionMode: "mock" })),
      "mock",
    );
    assert.equal(
      bindingModeFromConfig(loadEllConfig({ executionMode: "live" })),
      "live",
    );
  });
});

describe("startup validation", () => {
  it("reports mock READY and optional providers MISSING_CONFIG without keys", () => {
    const report = validateStartup(
      loadEllConfig({ executionMode: "mock", costMode: "FREE_FIRST" }),
    );
    assert.equal(report.ok, true);
    assert.ok(report.providers.some((p) => p.providerId === "mock" && p.status === "READY"));
  });

  it("employee registry has four core employees", () => {
    const cfg = loadEllConfig();
    const emps = buildEmployeeRegistry(cfg);
    assert.equal(emps.length, 4);
    assert.ok(emps.every((e) => e.role.length > 0));
  });

  it("provider registry is public-safe", () => {
    const cfg = loadEllConfig();
    const regs = buildProviderRegistry(cfg);
    const blob = JSON.stringify(regs);
    assert.equal(blob.includes("API_KEY="), false);
    assert.ok(regs.some((p) => p.providerId === "mock"));
  });
});

describe("HTTP v1 endpoints", () => {
  it("startup / config / employees / version", async () => {
    const s = await handleStartup();
    assert.equal(s.status, 200);
    const c = await handlePublicConfig();
    assert.equal(c.status, 200);
    const e = await handleEmployeeRegistry();
    assert.equal(e.status, 200);
    assert.equal((e.body as unknown[]).length, 4);
    const v = await handleVersion();
    assert.equal(v.status, 200);
    assert.equal((v.body as { version: string }).version, "1.0.0");
  });
});
