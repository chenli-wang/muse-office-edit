/**
 * Startup validation for ELL v1.0 — no secrets in messages.
 */

import type { EllConfig } from "./ell-config.ts";
import { loadEllConfig } from "./ell-config.ts";

export type ProviderStartupStatus =
  | "READY"
  | "DISABLED"
  | "MISSING_CONFIG"
  | "UNAVAILABLE"
  | "ERROR";

export interface ProviderStartupReport {
  providerId: string;
  displayName: string;
  status: ProviderStartupStatus;
  costClass: string;
  message: string;
}

export interface StartupReport {
  version: string;
  ok: boolean;
  executionMode: string;
  costMode: string;
  providers: ProviderStartupReport[];
  employees: Array<{
    employeeId: string;
    enabled: boolean;
    providerId: string;
    bindingOk: boolean;
    message: string;
  }>;
  warnings: string[];
  errors: string[];
}

function hasEnv(name: string | undefined): boolean {
  if (!name) return true;
  try {
    const v = process.env[name];
    return Boolean(v && v.trim());
  } catch {
    return false;
  }
}

/**
 * Validate configuration before live work.
 * Optional providers missing keys → MISSING_CONFIG (warning), not hard fail.
 */
export function validateStartup(config?: EllConfig): StartupReport {
  const cfg = config ?? loadEllConfig();
  const warnings: string[] = [];
  const errors: string[] = [];
  const providers: ProviderStartupReport[] = [];

  for (const p of cfg.providers) {
    if (!p.enabled) {
      providers.push({
        providerId: p.providerId,
        displayName: p.displayName,
        status: "DISABLED",
        costClass: p.costClass,
        message: "Disabled in configuration",
      });
      continue;
    }
    if (p.providerId === "mock") {
      providers.push({
        providerId: p.providerId,
        displayName: p.displayName,
        status: "READY",
        costClass: p.costClass,
        message: "Mock provider ready",
      });
      continue;
    }
    if (p.apiKeyEnv && !hasEnv(p.apiKeyEnv)) {
      providers.push({
        providerId: p.providerId,
        displayName: p.displayName,
        status: "MISSING_CONFIG",
        costClass: p.costClass,
        message: `Set ${p.apiKeyEnv} to enable (value not shown)`,
      });
      if (cfg.executionMode === "live") {
        warnings.push(`${p.displayName} missing configuration`);
      }
      continue;
    }
    providers.push({
      providerId: p.providerId,
      displayName: p.displayName,
      status: "READY",
      costClass: p.costClass,
      message: "Configured",
    });
  }

  const employees = cfg.employees.map((e) => {
    const prov = providers.find((p) => p.providerId === e.providerId);
    const bindingOk =
      e.enabled &&
      (cfg.executionMode === "mock" ||
        prov?.status === "READY" ||
        e.providerId === "mock");
    return {
      employeeId: e.employeeId,
      enabled: e.enabled,
      providerId: e.providerId,
      bindingOk,
      message: bindingOk
        ? "Binding OK"
        : `Provider ${e.providerId} not ready for live mode`,
    };
  });

  if (cfg.costMode === "FREE_ONLY") {
    const freeReady = providers.some(
      (p) => p.costClass === "FREE" && (p.status === "READY" || p.providerId === "mock"),
    );
    if (!freeReady) {
      warnings.push("FREE_ONLY: no FREE provider currently READY");
    }
  }

  // Hard errors only for broken required shape
  if (!cfg.employees.some((e) => e.enabled)) {
    errors.push("No employees enabled");
  }

  return {
    version: cfg.version,
    ok: errors.length === 0,
    executionMode: cfg.executionMode,
    costMode: cfg.costMode,
    providers,
    employees,
    warnings,
    errors,
  };
}
