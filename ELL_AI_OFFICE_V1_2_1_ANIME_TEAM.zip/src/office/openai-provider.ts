/**
 * Official OpenAI Chat Completions API adapter (OpenAI-compatible endpoint).
 * https://api.openai.com/v1/chat/completions
 */

import {
  DEFAULT_CAPABILITIES,
  httpStatusToErrorClass,
  normalizeProviderError,
  withTimeoutAndSignal,
  type GenerateRequest,
  type GenerateResponse,
  type ProviderAdapter,
  type ProviderCapabilities,
} from "./providers.ts";
import { ProviderError } from "./errors.ts";
import type { ProviderAvailability, ProviderRecord } from "./types.ts";

const OPENAI_BASE_URL = "https://api.openai.com/v1";
export const OPENAI_DEFAULT_MODEL = "gpt-4.1-mini";
export const OPENAI_MODEL_ID = "openai:default";

export interface OpenAIProviderOptions {
  apiKey?: string;
  model?: string;
  baseUrl?: string;
  fetchImpl?: typeof fetch;
}

export class OpenAIProvider implements ProviderAdapter {
  readonly id = "openai";
  readonly label = "OpenAI";
  readonly capabilities: ProviderCapabilities = {
    ...DEFAULT_CAPABILITIES,
    text: true,
    code: true,
    streaming: false,
    jsonMode: true,
  };

  private readonly apiKey: string | undefined;
  private readonly apiModel: string;
  private readonly baseUrl: string;
  private readonly fetchImpl: typeof fetch;
  private availability: ProviderAvailability;

  constructor(options: OpenAIProviderOptions = {}) {
    this.apiKey = options.apiKey?.trim() || undefined;
    this.apiModel = options.model?.trim() || OPENAI_DEFAULT_MODEL;
    this.baseUrl = (options.baseUrl ?? OPENAI_BASE_URL).replace(/\/$/, "");
    this.fetchImpl = options.fetchImpl ?? fetch;
    this.availability = this.apiKey ? "available" : "disabled";
  }

  isConfigured(): boolean {
    return Boolean(this.apiKey);
  }

  getApiModel(): string {
    return this.apiModel;
  }

  setAvailability(state: ProviderAvailability): void {
    this.availability = state;
  }

  getAvailability(): ProviderAvailability {
    if (!this.apiKey) return "disabled";
    return this.availability;
  }

  listModels(): ProviderRecord[] {
    return [
      {
        id: OPENAI_MODEL_ID,
        provider: this.id,
        capabilities: ["text", "code"],
        contextWindow: null,
        costClass: "paid",
        availability: this.getAvailability(),
        label: `OpenAI (${this.apiModel})`,
      },
    ];
  }

  async generate(request: GenerateRequest): Promise<GenerateResponse> {
    if (!this.apiKey) {
      throw new ProviderError(
        "AUTH",
        "OpenAI provider is not configured (missing OPENAI_API_KEY). Secrets stay server-side.",
        false,
      );
    }

    const availability = this.getAvailability();
    if (availability === "disabled" || availability === "offline") {
      throw new ProviderError("AUTH", `OpenAI provider is ${availability}.`, false);
    }
    if (
      availability === "rate_limited" ||
      availability === "daily_limit_reached" ||
      availability === "monthly_limit_reached"
    ) {
      throw new ProviderError("RATE_LIMIT", `OpenAI provider is ${availability}.`, true);
    }

    let apiModel = this.apiModel;
    if (request.model && request.model !== OPENAI_MODEL_ID) {
      if (request.model.startsWith("openai:")) {
        const stripped = request.model.slice("openai:".length).trim();
        if (stripped && stripped !== "default") apiModel = stripped;
      } else if (!request.model.includes(":")) {
        apiModel = request.model;
      }
    }

    const started = Date.now();
    const body = {
      model: apiModel,
      messages: [
        { role: "system", content: request.systemPrompt },
        { role: "user", content: request.userPrompt },
      ],
      temperature: 0.2,
    };

    const work = (async (): Promise<GenerateResponse> => {
      let response: Response;
      try {
        response = await this.fetchImpl(`${this.baseUrl}/chat/completions`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${this.apiKey}`,
          },
          body: JSON.stringify(body),
          signal: request.signal,
        });
      } catch (error) {
        throw normalizeProviderError(error, "OpenAI network request failed");
      }

      if (!response.ok) {
        let detail = `OpenAI API HTTP ${response.status}`;
        try {
          const errJson = (await response.json()) as {
            error?: { message?: string };
            message?: string;
          };
          detail = errJson?.error?.message || errJson?.message || detail;
        } catch {
          /* ignore */
        }
        const { code, retryable } = httpStatusToErrorClass(response.status);
        if (code === "RATE_LIMIT") this.availability = "rate_limited";
        else if (code === "AUTH") this.availability = "auth_error";
        else if (code === "SERVER_ERROR") this.availability = "provider_error";
        throw new ProviderError(code, detail, retryable);
      }

      if (
        this.availability === "rate_limited" ||
        this.availability === "provider_error" ||
        this.availability === "auth_error"
      ) {
        this.availability = "available";
      }

      const data = (await response.json()) as {
        choices?: Array<{ message?: { content?: string }; finish_reason?: string }>;
        model?: string;
        usage?: {
          prompt_tokens?: number;
          completion_tokens?: number;
          total_tokens?: number;
        };
      };

      const text = data.choices?.[0]?.message?.content ?? "";
      if (!text) {
        throw new ProviderError("CONTENT_ERROR", "OpenAI API returned empty completion.", false);
      }

      return {
        text,
        model: data.model ?? apiModel,
        provider: this.id,
        latencyMs: Math.max(1, Date.now() - started),
        usage: data.usage
          ? {
              promptTokens: data.usage.prompt_tokens,
              completionTokens: data.usage.completion_tokens,
              totalTokens: data.usage.total_tokens,
            }
          : undefined,
        finishReason: data.choices?.[0]?.finish_reason,
      };
    })();

    try {
      return await withTimeoutAndSignal(work, {
        timeoutMs: request.timeoutMs,
        signal: request.signal,
        label: "OpenAI provider",
      });
    } catch (error) {
      throw normalizeProviderError(error, "OpenAI generate failed");
    }
  }
}

export function createOpenAIProviderFromEnv(
  options: Omit<OpenAIProviderOptions, "apiKey" | "model"> = {},
): OpenAIProvider {
  return new OpenAIProvider({
    ...options,
    apiKey: process.env.OPENAI_API_KEY?.trim() || undefined,
    model: process.env.OPENAI_MODEL?.trim() || undefined,
  });
}
