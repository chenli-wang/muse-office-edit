import assert from "node:assert/strict";
import { describe, it } from "node:test";
import {
  buildEmployeeCards,
  buildMemorySummary,
  buildDashboardSnapshot,
} from "./dashboard-api.ts";
import { createOfficeRuntime, replaceOffice } from "./runtime.ts";
import { handleDashboardSnapshot, handleCreateTask, handleCancelTask, handleMemorySummary, handleListTools } from "./http.ts";
import type { Employee, Task } from "./types.ts";
import type { ContextEntry } from "./memory/project-context-store.ts";

describe("dashboard state serialization", () => {
  it("builds employee cards from backend employees/tasks", () => {
    const employees: Employee[] = [
      {
        id: "claude",
        displayName: "Claude",
        role: "Lead Developer",
        status: "idle",
        provider: "mock",
        model: "mock:phase1",
        preferredModels: [],
        fallbackModels: [],
        providerPreferences: [],
        capabilities: ["code"],
        quotaStatus: "available",
        systemPrompt: "x",
        toolsAllowed: [],
        maxParallelTasks: 1,
        permissions: ["read"],
        currentTaskId: null,
        currentTaskTitle: null,
      },
      {
        id: "gpt",
        displayName: "GPT",
        role: "Architect",
        status: "idle",
        provider: "mock",
        model: "mock:phase1",
        preferredModels: [],
        fallbackModels: [],
        providerPreferences: [],
        capabilities: ["analysis"],
        quotaStatus: "available",
        systemPrompt: "x",
        toolsAllowed: [],
        maxParallelTasks: 1,
        permissions: ["read"],
        currentTaskId: null,
        currentTaskTitle: null,
      },
    ];
    const tasks: Task[] = [];
    const cards = buildEmployeeCards(employees, tasks);
    assert.equal(cards.length, 2);
    assert.equal(cards.find((c) => c.id === "gpt")?.isSynthesizer, true);
    assert.equal(cards[0].status, "idle");
  });

  it("memory summary is bounded and redacts nothing host-path-like", () => {
    const entries: ContextEntry[] = [
      {
        id: "1",
        projectId: "p",
        type: "finding",
        content: "ok finding",
        sourceEmployeeId: "claude",
        taskId: null,
        tags: ["a"],
        order: 1,
        createdAt: new Date().toISOString(),
      },
    ];
    const sum = buildMemorySummary("p", "P", entries, 1);
    assert.equal(sum.recent.length, 1);
    assert.equal(sum.projectId, "p");
  });

  it("snapshot has no secret-api-key-123", async () => {
    replaceOffice(
      createOfficeRuntime({
        delays: { planningMs: 0, assignMs: 0, workMs: 0, synthMs: 0 },
      }),
    );
    const snap = await buildDashboardSnapshot();
    const blob = JSON.stringify(snap);
    assert.equal(blob.includes("secret-api-key-123"), false);
    assert.equal(blob.includes("ANTHROPIC_API_KEY"), false);
    assert.ok(Array.isArray(snap.employees));
    assert.ok(Array.isArray(snap.providers));
    assert.ok(snap.memory);
  });
});

describe("dashboard HTTP", () => {
  it("GET dashboard snapshot", async () => {
    replaceOffice(
      createOfficeRuntime({
        delays: { planningMs: 0, assignMs: 0, workMs: 0, synthMs: 0 },
      }),
    );
    const res = await handleDashboardSnapshot();
    assert.equal(res.status, 200);
    const body = res.body as { service: string; employees: unknown[] };
    assert.equal(body.service, "ell-ai-office");
    assert.ok(body.employees.length >= 1);
  });

  it("memory and tools endpoints", async () => {
    replaceOffice(
      createOfficeRuntime({
        delays: { planningMs: 0, assignMs: 0, workMs: 0, synthMs: 0 },
      }),
    );
    const mem = await handleMemorySummary();
    assert.equal(mem.status, 200);
    const tools = await handleListTools();
    assert.equal(tools.status, 200);
    assert.ok(Array.isArray(tools.body));
  });

  it("task submit and cancel via existing handlers", async () => {
    replaceOffice(
      createOfficeRuntime({
        delays: { planningMs: 0, assignMs: 0, workMs: 0, synthMs: 0 },
      }),
    );
    const created = await handleCreateTask({
      objective: "Dashboard control test",
      mode: "single",
    });
    assert.equal(created.status, 201);
    const id = (created.body as { id: string }).id;
    // single zero-delay completes; cancel may 409
    const cancel = await handleCancelTask(id);
    assert.ok(cancel.status === 200 || cancel.status === 409);
  });
});
