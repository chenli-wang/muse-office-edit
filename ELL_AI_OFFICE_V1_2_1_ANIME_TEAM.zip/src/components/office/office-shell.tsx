/**
 * Office shell — 2D dashboard + optional 3D isometric view.
 * Both consume the same Phase 7 /api/dashboard state.
 */
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Building2, Boxes, LayoutDashboard, LoaderCircle, Square } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { OfficeDashboard } from "./dashboard.tsx";
import { OfficeScene3D } from "./3d/office-scene.tsx";
import { OfficeSceneThree } from "./3d/office-scene-three.tsx";
import { EmployeePanel } from "./3d/employee-panel.tsx";
import { mapDashboardToVisualOffice, safeLabel } from "./3d/office-state.ts";
import {
  loadPerformanceSettings,
  savePerformanceSettings,
  formatQualityVisibility,
  type PerformanceSettings,
  type FpsCap,
  type QualityLevel,
} from "./3d/performance.ts";
import type { DashboardSnapshot } from "@/office/dashboard-api.ts";
import type { TaskStatus } from "@/office/types.ts";
import { Button } from "@/components/ui/button.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { cn } from "@/lib/utils.ts";

const ACTIVE: ReadonlySet<TaskStatus> = new Set([
  "created",
  "planning",
  "assigned",
  "running",
  "synthesizing",
]);

async function readJson<T>(response: Response): Promise<T> {
  const data = (await response.json()) as T & { error?: string };
  if (!response.ok) throw new Error(data.error ?? `Request failed (${response.status})`);
  return data;
}

function prefer3DDefault(): boolean {
  if (typeof window === "undefined") return false;
  try {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return false;
    // Prefer 2D on very small phones for clarity; still allow toggle
    if (window.innerWidth < 360) return false;
    return true;
  } catch {
    return false;
  }
}

export function OfficeShell() {
  const [view, setView] = useState<"2d" | "3d">("2d");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [perf, setPerf] = useState<PerformanceSettings>(() => loadPerformanceSettings());
  const [measuredFps, setMeasuredFps] = useState(0);
  const [appliedQuality, setAppliedQuality] = useState<QualityLevel | null>(null);
  const [canvasMetrics, setCanvasMetrics] = useState<{ width: number; height: number } | null>(null);
  const [fallbackReason, setFallbackReason] = useState<string | null>(null);
  const [useLegacyCanvas, setUseLegacyCanvas] = useState(false);
  const [objective, setObjective] = useState("");
  const [mode, setMode] = useState<"single" | "multi">("multi");
  const [formError, setFormError] = useState<string | null>(null);
  const qc = useQueryClient();

  useEffect(() => {
    setView(prefer3DDefault() ? "3d" : "2d");
  }, []);

  const dash = useQuery({
    queryKey: ["office", "dashboard"],
    queryFn: () => fetch("/api/dashboard").then((r) => readJson<DashboardSnapshot>(r)),
    refetchInterval: (q) => {
      const task = q.state.data?.currentTask;
      return task && ACTIVE.has(task.status) ? 600 : 2500;
    },
  });

  // SSE reuse
  useEffect(() => {
    if (typeof EventSource === "undefined") return;
    let es: EventSource | null = null;
    try {
      es = new EventSource("/api/events/stream");
      es.addEventListener("office", () => {
        void qc.invalidateQueries({ queryKey: ["office"] });
      });
    } catch {
      /* ignore */
    }
    return () => es?.close();
  }, [qc]);

  const visual = useMemo(
    () => mapDashboardToVisualOffice(dash.data, selectedId),
    [dash.data, selectedId],
  );

  const selected = visual.employees.find((e) => e.id === selectedId) ?? null;
  const current = dash.data?.currentTask ?? null;
  const selectedEmp = visual.employees.find((e) => e.id === selectedId) ?? null;
  const canCancel = current && ACTIVE.has(current.status);

  // Keyboard: Escape clears 3D employee selection / closes profile overlay
  useEffect(() => {
    if (view !== "3d" || !selectedId) return;
    const onKey = (ev: KeyboardEvent) => {
      if (ev.key === "Escape") {
        setSelectedId(null);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [view, selectedId]);


  const createMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/tasks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ objective, mode }),
      });
      return readJson(res);
    },
    onSuccess: () => {
      setObjective("");
      setFormError(null);
      void qc.invalidateQueries({ queryKey: ["office"] });
    },
    onError: (e: Error) => setFormError(e.message),
  });

  const cancelMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await fetch(`/api/tasks/${id}/cancel`, { method: "POST" });
      return readJson(res);
    },
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["office"] }),
    onError: (e: Error) => setFormError(e.message),
  });

  if (view === "2d") {
    return (
      <div className="relative">
        <div className="fixed bottom-4 right-4 z-50">
          <Button
            type="button"
            className="bg-cyan-700 text-white shadow-lg hover:bg-cyan-600"
            onClick={() => setView("3d")}
          >
            <Boxes className="mr-1 size-4" />
            3D office
          </Button>
        </div>
        <OfficeDashboard />
      </div>
    );
  }

  return (
    <div className="min-h-dvh bg-[#0b0f14] text-zinc-100">
      <div className="mx-auto flex max-w-5xl flex-col gap-3 px-3 py-3 sm:px-5 sm:py-5">
        <header className="flex flex-wrap items-center justify-between gap-2 border-b border-zinc-800 pb-3">
          <div className="flex items-center gap-2">
            <Building2 className="size-6 text-cyan-400" />
            <div>
              <h1 className="text-base font-semibold sm:text-lg">ELL AI Office · 3D</h1>
              <p className="text-[11px] text-zinc-500">
                Presentation layer · same backend as 2D
              </p>
            </div>
          </div>
          <Button
            type="button"
            variant="outline"
            className="border-zinc-600 text-zinc-200"
            onClick={() => setView("2d")}
          >
            <LayoutDashboard className="mr-1 size-4" />
            2D dashboard
          </Button>
        </header>

        {formError ? (
          <div className="rounded-md border border-amber-900/50 bg-amber-950/40 p-2 text-sm text-amber-200">
            {formError}
          </div>
        ) : null}

        <div className="relative h-[min(48vh,380px)] w-full min-h-[240px] overflow-hidden sm:h-[min(60vh,520px)]">
          {useLegacyCanvas ? (
            <OfficeScene3D state={visual} onSelectEmployee={setSelectedId} />
          ) : (
            <OfficeSceneThree
              state={visual}
              onSelectEmployee={setSelectedId}
              performance={perf}
              onMeasuredFps={setMeasuredFps}
              onAppliedQuality={setAppliedQuality}
              onCanvasMetrics={setCanvasMetrics}
              onWebglFailed={(reason) => {
                setFallbackReason(reason);
                setUseLegacyCanvas(true);
              }}
            />
          )}
          {selectedEmp ? (
            <div className="absolute bottom-1 left-1 right-1 z-10 max-h-[min(42vh,320px)] overflow-y-auto sm:bottom-2 sm:left-auto sm:right-2 sm:max-h-[min(55vh,420px)] sm:w-80">
              <EmployeePanel
                employee={selectedEmp}
                onClose={() => setSelectedId(null)}
                className="rounded-xl"
              />
            </div>
          ) : null}
          {perf.showFps ? (
            <div
              className="pointer-events-none absolute right-1 top-1 max-w-[min(100%,280px)] rounded bg-black/70 px-2 py-1.5 font-mono text-[10px] leading-relaxed text-cyan-300 sm:right-2 sm:top-2 sm:text-[11px]"
              data-testid="office-diagnostics"
              aria-live="polite"
            >
              <div>
                FPS: {measuredFps ? measuredFps.toFixed(0) : "—"} · target{" "}
                {perf.fpsCap === 0 ? "∞" : perf.fpsCap}
              </div>
              <div>
                Mode: {useLegacyCanvas ? "2.5D-canvas" : "WebGL-3D"}
                {canvasMetrics
                  ? ` · ${canvasMetrics.width}×${canvasMetrics.height}`
                  : ""}
              </div>
              <div>
                {formatQualityVisibility(perf.quality, appliedQuality ?? perf.quality)}
              </div>
              {perf.reducedMotion ? <div>Reduced motion: on</div> : null}
              {fallbackReason ? (
                <div className="text-amber-300">Fallback: {fallbackReason.slice(0, 80)}</div>
              ) : null}
            </div>
          ) : null}
        </div>

        {/* Performance controls */}
        <div
          className="flex flex-wrap items-center gap-x-2 gap-y-2 rounded-xl border border-zinc-800 bg-zinc-900/80 p-2 text-xs"
          role="group"
          aria-label="3D performance settings"
        >
          <label className="text-zinc-500" htmlFor="ell-quality-select">
            Quality
          </label>
          <select
            id="ell-quality-select"
            value={perf.quality}
            onChange={(e) => {
              const next = { ...perf, quality: e.target.value as QualityLevel };
              setPerf(next);
              setAppliedQuality(next.quality);
              savePerformanceSettings(next);
            }}
            className="min-h-9 rounded border border-zinc-700 bg-zinc-950 px-2 py-1"
            data-testid="quality-select"
            aria-label="Render quality"
          >
            <option value="low">Low</option>
            <option value="balanced">Balanced</option>
            <option value="high">High</option>
          </select>
          <span
            className="w-full font-mono text-[11px] text-zinc-400 sm:w-auto"
            data-testid="quality-visibility"
            aria-live="polite"
          >
            {formatQualityVisibility(perf.quality, appliedQuality ?? perf.quality)}
          </span>
          <label className="text-zinc-500" htmlFor="ell-fps-select">
            FPS cap
          </label>
          <select
            id="ell-fps-select"
            value={String(perf.fpsCap)}
            onChange={(e) => {
              const v = Number(e.target.value) as FpsCap;
              const next = { ...perf, fpsCap: v };
              setPerf(next);
              savePerformanceSettings(next);
            }}
            className="min-h-9 rounded border border-zinc-700 bg-zinc-950 px-2 py-1"
            aria-label="FPS target cap"
          >
            <option value="30">30</option>
            <option value="60">60</option>
            <option value="0">Unlimited</option>
          </select>
          <label className="flex items-center gap-1 text-zinc-400">
            <input
              type="checkbox"
              checked={perf.showFps}
              onChange={(e) => {
                const next = { ...perf, showFps: e.target.checked };
                setPerf(next);
                savePerformanceSettings(next);
              }}
            />
            FPS counter
          </label>
          <label className="flex items-center gap-1 text-zinc-400">
            <input
              type="checkbox"
              checked={perf.reducedMotion}
              onChange={(e) => {
                const next = { ...perf, reducedMotion: e.target.checked };
                setPerf(next);
                savePerformanceSettings(next);
              }}
            />
            Reduced motion
          </label>
          <Button
            type="button"
            size="sm"
            variant="outline"
            className="border-zinc-600"
            onClick={() =>
              setUseLegacyCanvas((v) => {
                const next = !v;
                if (!next) setFallbackReason(null);
                return next;
              })
            }
          >
            {useLegacyCanvas ? "Try WebGL 3D" : "Canvas 2.5D fallback"}
          </Button>
        </div>

        {/* Overlay controls */}
        <div className="grid gap-3 sm:grid-cols-2">
          <div className="rounded-xl border border-zinc-800 bg-zinc-900/80 p-3">
            <p className="font-mono text-[10px] uppercase tracking-widest text-zinc-500">
              Task
            </p>
            <Textarea
              value={objective}
              onChange={(e) => setObjective(e.target.value)}
              placeholder="Objective…"
              className="mt-1 min-h-[64px] border-zinc-700 bg-zinc-950 text-sm text-zinc-100"
            />
            <div className="mt-2 flex flex-wrap gap-2">
              <select
                value={mode}
                onChange={(e) => setMode(e.target.value as "single" | "multi")}
                className="rounded border border-zinc-700 bg-zinc-950 px-2 py-1 text-xs"
              >
                <option value="multi">Multi</option>
                <option value="single">Single</option>
              </select>
              <Button
                className="bg-cyan-600 text-white hover:bg-cyan-500"
                disabled={!objective.trim() || createMutation.isPending}
                onClick={() => createMutation.mutate()}
              >
                {createMutation.isPending ? (
                  <LoaderCircle className="size-4 animate-spin" />
                ) : (
                  "Submit"
                )}
              </Button>
              {canCancel ? (
                <Button
                  variant="outline"
                  className="border-zinc-600"
                  onClick={() => current && cancelMutation.mutate(current.id)}
                >
                  <Square className="mr-1 size-3" />
                  Cancel
                </Button>
              ) : null}
            </div>
            {current ? (
              <p className="mt-2 text-xs text-zinc-400">
                {current.status}: {safeLabel(current.title, 80)}
              </p>
            ) : (
              <p className="mt-2 text-xs text-zinc-600">No active task</p>
            )}
          </div>

          <div className="rounded-xl border border-zinc-800 bg-zinc-900/80 p-3">
            <p className="font-mono text-[10px] uppercase tracking-widest text-zinc-500">
              Selected employee
            </p>
            {selected ? (
              <div className="mt-1 space-y-1 text-sm">
                <p className="font-medium text-zinc-100">
                  {selected.displayName}{" "}
                  <span className="text-xs text-zinc-500">{selected.role}</span>
                </p>
                <p className="text-xs text-zinc-400">
                  {selected.status} · {selected.provider} · {selected.model}
                </p>
                {selected.activityLabel ? (
                  <p className="text-xs text-cyan-400">{selected.activityLabel}</p>
                ) : null}
                {selected.latestSummary ? (
                  <p className="line-clamp-3 text-xs text-zinc-300">
                    {safeLabel(selected.latestSummary, 240)}
                  </p>
                ) : null}
                {selected.error ? (
                  <p className="text-xs text-red-400">{safeLabel(selected.error, 160)}</p>
                ) : null}
              </div>
            ) : (
              <p className="mt-2 text-xs text-zinc-600">Tap an avatar in the office</p>
            )}
            {selected ? (
              <button
                type="button"
                className="mt-2 text-[11px] text-cyan-500 hover:text-cyan-300"
                onClick={() => setSelectedId(null)}
                data-testid="camera-overview"
              >
                Clear selection · camera overview
              </button>
            ) : null}
            <div className="mt-3 flex gap-3 text-[11px] text-zinc-500">
              <span>
                providers {visual.providersOnline}/{visual.providersTotal}
              </span>
              <span>memory {visual.memoryEntryCount}</span>
            </div>
          </div>
        </div>

        <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-3">
          <p className="mb-1 font-mono text-[10px] uppercase tracking-widest text-zinc-500">
            Recent activity
          </p>
          <ul className="max-h-28 space-y-0.5 overflow-y-auto font-mono text-[11px] text-zinc-500">
            {visual.recentActivity.length === 0 ? (
              <li>No events</li>
            ) : (
              visual.recentActivity.map((a) => (
                <li key={a.id} className={cn(a.employeeId === selectedId && "text-cyan-600")}>
                  {a.employeeId ? `[${a.employeeId}] ` : ""}
                  {a.label}
                </li>
              ))
            )}
          </ul>
        </div>
      </div>
    </div>
  );
}
