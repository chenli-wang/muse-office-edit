/**
 * ELL AI Office — Phase 7 control-room dashboard.
 * Consumes real backend APIs only; no fake activity.
 */
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Activity,
  Brain,
  Building2,
  Database,
  LoaderCircle,
  Radio,
  Shield,
  Square,
  Wrench,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { Badge } from "@/components/ui/badge.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { cn } from "@/lib/utils.ts";
import type { DashboardSnapshot, DashboardEmployeeCard } from "@/office/dashboard-api.ts";
import type { TaskStatus } from "@/office/types.ts";

const ACTIVE: ReadonlySet<TaskStatus> = new Set([
  "created",
  "planning",
  "assigned",
  "running",
  "synthesizing",
]);

async function readJson<T>(response: Response): Promise<T> {
  const data = (await response.json()) as T & { error?: string };
  if (!response.ok) {
    throw new Error(data.error ?? `Request failed (${response.status})`);
  }
  return data;
}

function useDashboard() {
  return useQuery({
    queryKey: ["office", "dashboard"],
    queryFn: () => fetch("/api/dashboard").then((r) => readJson<DashboardSnapshot>(r)),
    refetchInterval: (q) => {
      const task = q.state.data?.currentTask;
      return task && ACTIVE.has(task.status) ? 600 : 2500;
    },
  });
}

function useEventStream(enabled: boolean) {
  const qc = useQueryClient();
  useEffect(() => {
    if (!enabled || typeof EventSource === "undefined") return;
    let es: EventSource | null = null;
    try {
      es = new EventSource("/api/events/stream");
      es.addEventListener("office", () => {
        void qc.invalidateQueries({ queryKey: ["office"] });
      });
    } catch {
      /* polling remains */
    }
    return () => {
      es?.close();
    };
  }, [enabled, qc]);
}

export function OfficeDashboard() {
  const queryClient = useQueryClient();
  const [objective, setObjective] = useState("");
  const [mode, setMode] = useState<"single" | "multi">("multi");
  const [formError, setFormError] = useState<string | null>(null);
  const dash = useDashboard();
  useEventStream(true);

  const data = dash.data;
  const current = data?.currentTask ?? null;

  const createMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/tasks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ objective, mode }),
      });
      return readJson(res);
    },
    onSuccess: () => {
      setObjective("");
      setFormError(null);
      void queryClient.invalidateQueries({ queryKey: ["office"] });
    },
    onError: (err: Error) => setFormError(err.message),
  });

  const cancelMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await fetch(`/api/tasks/${id}/cancel`, { method: "POST" });
      return readJson(res);
    },
    onSuccess: () => void queryClient.invalidateQueries({ queryKey: ["office"] }),
    onError: (err: Error) => setFormError(err.message),
  });

  const canCancel = current && ACTIVE.has(current.status);

  return (
    <div className="min-h-dvh bg-[#0b0f14] text-zinc-100">
      <div className="mx-auto flex max-w-6xl flex-col gap-4 px-3 py-4 sm:px-6 sm:py-6">
        <header className="flex flex-wrap items-center justify-between gap-3 border-b border-zinc-800 pb-4">
          <div className="flex items-center gap-3">
            <Building2 className="size-7 text-cyan-400" strokeWidth={1.5} />
            <div>
              <h1 className="text-lg font-semibold tracking-tight sm:text-xl">
                ELL AI Office
              </h1>
              <p className="text-xs text-zinc-500">
                Control room · {data?.workspaceId ?? "…"} · live backend state
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 text-xs text-zinc-500">
            <Radio className="size-3.5 text-emerald-400" />
            <span>{dash.isFetching ? "syncing" : "live"}</span>
          </div>
        </header>

        {dash.error ? (
          <div className="rounded-lg border border-red-900/60 bg-red-950/40 p-3 text-sm text-red-300">
            {(dash.error as Error).message}
          </div>
        ) : null}
        {formError ? (
          <div className="rounded-lg border border-amber-900/60 bg-amber-950/30 p-3 text-sm text-amber-200">
            {formError}
          </div>
        ) : null}

        <Card className="border-zinc-800 bg-zinc-900/80 p-4">
          <CardHeader className="p-0 pb-3">
            <CardTitle className="text-base text-zinc-100">New objective</CardTitle>
            <CardDescription className="text-zinc-500">
              Submits to the real office runtime (single Claude or multi-agent).
            </CardDescription>
          </CardHeader>
          <Textarea
            value={objective}
            onChange={(e) => setObjective(e.target.value)}
            placeholder="Describe the work for the office…"
            className="min-h-[88px] border-zinc-700 bg-zinc-950 text-zinc-100 placeholder:text-zinc-600"
          />
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <select
              value={mode}
              onChange={(e) => setMode(e.target.value as "single" | "multi")}
              className="rounded-md border border-zinc-700 bg-zinc-950 px-2 py-1.5 text-sm text-zinc-200"
              aria-label="Task mode"
            >
              <option value="multi">Multi-agent</option>
              <option value="single">Single (Claude)</option>
            </select>
            <Button
              disabled={!objective.trim() || createMutation.isPending}
              onClick={() => createMutation.mutate()}
              className="bg-cyan-600 text-white hover:bg-cyan-500"
            >
              {createMutation.isPending ? (
                <LoaderCircle className="size-4 animate-spin" />
              ) : (
                "Submit task"
              )}
            </Button>
            {canCancel ? (
              <Button
                variant="outline"
                className="border-zinc-600 text-zinc-200"
                disabled={cancelMutation.isPending}
                onClick={() => current && cancelMutation.mutate(current.id)}
              >
                <Square className="mr-1 size-3.5" />
                Cancel
              </Button>
            ) : null}
          </div>
        </Card>

        <TaskPanel task={current} />

        <section>
          <h2 className="mb-2 flex items-center gap-2 text-sm font-medium text-zinc-400">
            <Brain className="size-4" /> Employees
          </h2>
          <div className="grid gap-3 sm:grid-cols-2">
            {(data?.employees ?? []).map((emp) => (
              <EmployeeCard key={emp.id} employee={emp} />
            ))}
          </div>
        </section>

        <div className="grid gap-3 lg:grid-cols-3">
          <ProviderPanel providers={data?.providers ?? []} />
          <MemoryPanel memory={data?.memory} />
          <ToolsPanel tools={data?.tools ?? []} catalog={data?.toolCatalog ?? []} />
        </div>

        <ActivityFeed events={data?.events ?? []} />

        <footer className="border-t border-zinc-800 pt-3 text-center text-[11px] text-zinc-600">
          Observability only · no secrets · no shell · Phase 7 dashboard
        </footer>
      </div>
    </div>
  );
}

function TaskPanel({ task }: { task: DashboardSnapshot["currentTask"] }) {
  if (!task) {
    return (
      <Card className="border-zinc-800 bg-zinc-900/60 p-4 text-sm text-zinc-500">
        No active task. Submit an objective to run the office.
      </Card>
    );
  }
  return (
    <Card className="border-zinc-800 bg-zinc-900/80 p-4">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div>
          <p className="font-mono text-[10px] uppercase tracking-widest text-zinc-500">
            Current task
          </p>
          <h2 className="text-base font-medium text-zinc-100">{task.title}</h2>
          <p className="mt-1 text-sm text-zinc-400">{task.objective}</p>
        </div>
        <TaskStatusBadge status={task.status} />
      </div>
      {task.plan ? (
        <p className="mt-2 text-xs text-zinc-500">{task.plan.rationale}</p>
      ) : null}
      {task.error ? (
        <div className="mt-3 rounded-md bg-red-950/50 p-2 text-sm text-red-300">
          <p className="font-medium">{task.error.class}</p>
          <p>{task.error.message}</p>
        </div>
      ) : null}
      {task.finalResult ? (
        <div className="mt-3 space-y-2 border-t border-zinc-800 pt-3">
          <p className="font-mono text-[10px] uppercase tracking-widest text-emerald-500">
            Synthesis
          </p>
          <p className="text-sm text-zinc-200">{task.finalResult.summary}</p>
          {task.finalResult.findings?.length ? (
            <ul className="list-disc space-y-1 pl-4 text-sm text-zinc-400">
              {task.finalResult.findings.slice(0, 6).map((f) => (
                <li key={f}>{f}</li>
              ))}
            </ul>
          ) : null}
        </div>
      ) : ACTIVE.has(task.status) ? (
        <p className="mt-3 flex items-center gap-2 text-sm text-cyan-400">
          <LoaderCircle className="size-4 animate-spin" />
          In progress — status from backend
        </p>
      ) : null}
    </Card>
  );
}

function EmployeeCard({ employee }: { employee: DashboardEmployeeCard }) {
  return (
    <Card
      className={cn(
        "border-zinc-800 bg-zinc-900/70 p-3",
        employee.isSynthesizer && "border-cyan-900/50 ring-1 ring-cyan-900/30",
      )}
    >
      <div className="flex items-start justify-between gap-2">
        <div>
          <p className="font-medium text-zinc-100">{employee.displayName}</p>
          <p className="text-xs text-zinc-500">{employee.role}</p>
        </div>
        <StatusPill status={employee.status} />
      </div>
      <div className="mt-2 grid grid-cols-2 gap-1 text-[11px] text-zinc-500">
        <span>provider · {employee.provider}</span>
        <span className="truncate">model · {employee.model}</span>
      </div>
      {employee.currentObjective ? (
        <p className="mt-2 truncate text-xs text-zinc-400">{employee.currentObjective}</p>
      ) : null}
      {employee.latestSummary ? (
        <p className="mt-1 line-clamp-2 text-xs text-zinc-300">{employee.latestSummary}</p>
      ) : null}
      {employee.error ? (
        <p className="mt-1 text-xs text-red-400">{employee.error}</p>
      ) : null}
      {employee.isSynthesizer ? (
        <p className="mt-2 font-mono text-[10px] uppercase tracking-wider text-cyan-600">
          Final reviewer
        </p>
      ) : null}
    </Card>
  );
}

function StatusPill({ status }: { status: string }) {
  const color =
    status === "working" || status === "thinking"
      ? "bg-cyan-500/20 text-cyan-300"
      : status === "completed"
        ? "bg-emerald-500/20 text-emerald-300"
        : status === "failed"
          ? "bg-red-500/20 text-red-300"
          : status === "rate_limited" || status === "unavailable"
            ? "bg-amber-500/20 text-amber-300"
            : "bg-zinc-700/50 text-zinc-400";
  return (
    <span className={cn("rounded-full px-2 py-0.5 text-[10px] font-medium capitalize", color)}>
      {status.replaceAll("_", " ")}
    </span>
  );
}

function ProviderPanel({
  providers,
}: {
  providers: DashboardSnapshot["providers"];
}) {
  return (
    <Card className="border-zinc-800 bg-zinc-900/70 p-3">
      <h3 className="mb-2 flex items-center gap-2 text-sm font-medium text-zinc-400">
        <Shield className="size-4" /> Providers
      </h3>
      <ul className="space-y-2">
        {providers.length === 0 ? (
          <li className="text-xs text-zinc-600">No provider status</li>
        ) : (
          providers.map((p) => (
            <li
              key={p.id}
              className="flex items-center justify-between gap-2 text-xs text-zinc-300"
            >
              <span className="truncate">{p.label ?? p.id}</span>
              <Badge
                className={cn(
                  "text-[10px]",
                  p.availability === "available"
                    ? "bg-emerald-900/40 text-emerald-300"
                    : "bg-zinc-800 text-zinc-400",
                )}
              >
                {p.availability}
              </Badge>
            </li>
          ))
        )}
      </ul>
    </Card>
  );
}

function MemoryPanel({ memory }: { memory?: DashboardSnapshot["memory"] }) {
  return (
    <Card className="border-zinc-800 bg-zinc-900/70 p-3">
      <h3 className="mb-2 flex items-center gap-2 text-sm font-medium text-zinc-400">
        <Database className="size-4" /> Project memory
      </h3>
      {!memory ? (
        <p className="text-xs text-zinc-600">Loading…</p>
      ) : (
        <>
          <p className="text-xs text-zinc-500">
            {memory.projectId} · {memory.entryCount} entries
          </p>
          <ul className="mt-2 max-h-40 space-y-1.5 overflow-y-auto">
            {memory.recent.length === 0 ? (
              <li className="text-xs text-zinc-600">No context yet</li>
            ) : (
              memory.recent.map((e) => (
                <li key={e.id} className="text-xs text-zinc-300">
                  <span className="font-mono text-[10px] uppercase text-zinc-500">
                    {e.type}
                  </span>{" "}
                  <span className="line-clamp-2">{e.content}</span>
                </li>
              ))
            )}
          </ul>
        </>
      )}
    </Card>
  );
}

function ToolsPanel({
  tools,
  catalog,
}: {
  tools: DashboardSnapshot["tools"];
  catalog: DashboardSnapshot["toolCatalog"];
}) {
  return (
    <Card className="border-zinc-800 bg-zinc-900/70 p-3">
      <h3 className="mb-2 flex items-center gap-2 text-sm font-medium text-zinc-400">
        <Wrench className="size-4" /> Tools
      </h3>
      <p className="text-[11px] text-zinc-600">
        {catalog.map((t) => t.name).join(" · ") || "none"}
      </p>
      <ul className="mt-2 max-h-36 space-y-1 overflow-y-auto">
        {tools.length === 0 ? (
          <li className="text-xs text-zinc-600">No tool activity</li>
        ) : (
          tools
            .slice()
            .reverse()
            .slice(0, 12)
            .map((t) => (
              <li key={t.id} className="text-xs text-zinc-400">
                <span className={t.success ? "text-emerald-400" : "text-red-400"}>
                  {t.success ? "ok" : "fail"}
                </span>{" "}
                {t.toolName}
              </li>
            ))
        )}
      </ul>
    </Card>
  );
}

function ActivityFeed({ events }: { events: DashboardSnapshot["events"] }) {
  const rows = useMemo(
    () =>
      [...events]
        .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
        .slice(0, 40),
    [events],
  );
  return (
    <Card className="border-zinc-800 bg-zinc-900/70 p-3">
      <h3 className="mb-2 flex items-center gap-2 text-sm font-medium text-zinc-400">
        <Activity className="size-4" /> Activity
      </h3>
      <ul className="max-h-56 space-y-1.5 overflow-y-auto font-mono text-[11px] text-zinc-400">
        {rows.length === 0 ? (
          <li className="text-zinc-600">No events yet</li>
        ) : (
          rows.map((e) => (
            <li key={e.id} className="border-b border-zinc-800/80 pb-1">
              <span className="text-zinc-600">{e.createdAt.slice(11, 19)}</span>{" "}
              <span className="text-cyan-700">{e.type}</span>{" "}
              {e.employeeId ? (
                <span className="text-zinc-500">[{e.employeeId}]</span>
              ) : null}{" "}
              {e.message}
            </li>
          ))
        )}
      </ul>
    </Card>
  );
}

function TaskStatusBadge({ status }: { status: TaskStatus }) {
  const variant =
    status === "completed"
      ? "bg-emerald-900/50 text-emerald-300"
      : status === "failed"
        ? "bg-red-900/50 text-red-300"
        : status === "cancelled"
          ? "bg-zinc-700 text-zinc-300"
          : "bg-cyan-900/40 text-cyan-300";
  return (
    <span className={cn("rounded-full px-2.5 py-0.5 text-xs capitalize", variant)}>
      {status.replaceAll("_", " ")}
    </span>
  );
}
