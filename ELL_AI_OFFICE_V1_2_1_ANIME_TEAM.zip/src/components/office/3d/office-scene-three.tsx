/**
 * V1.1 Full 3D office — Three.js / WebGL presentation layer.
 * Backend state is authoritative; this only visualizes.
 */
"use client";

import { useEffect, useRef, useState } from "react";
import type { VisualOfficeState, VisualEmployee } from "./office-state.ts";
import {
  DESK_ORDER,
  DESK_POSITIONS,
  MEETING_TABLE_POS,
  poseForStatus,
  characterVisualFor,
  resolveEmployeeIdFromPick,
  isClickGesture,
  cameraRadiusForSelection,
  lerp,
  lerpLookTarget,
  OVERVIEW_LOOK_AT,
  OVERVIEW_RADIUS,
  pickNearestEmployeeByScreenDistance,
  statusColor,
  type CameraLookTarget,
  type ScreenProjectedDesk,
} from "./office-state.ts";
import {
  type PerformanceSettings,
  type QualityLevel,
  qualityProfile,
  frameIntervalMs,
  FpsMeter,
  AdaptiveRenderController,
} from "./performance.ts";
import {
  buildAnimeCharacter,
  resetPose,
  applyIdlePose,
  applyWalkPose,
  applySitPose,
  applyThinkPose,
  applyBlink,
  paintBeacon,
  type AnimeRig,
} from "./anime-character.ts";
import {
  createWanderAgent,
  updateWander,
  deskAabb,
  meetingTableAabb,
  ROAM_WAYPOINTS,
  type WanderAgent,
  type Aabb,
} from "./wander.ts";

type Props = {
  state: VisualOfficeState;
  onSelectEmployee: (id: string | null) => void;
  performance: PerformanceSettings;
  onMeasuredFps?: (fps: number) => void;
  /** Fires when the quality actually applied to the renderer changes. */
  onAppliedQuality?: (level: QualityLevel) => void;
  /** Canvas pixel size after layout (no secrets). */
  onCanvasMetrics?: (metrics: { width: number; height: number }) => void;
  onWebglFailed?: (reason: string) => void;
};

type ThreeModule = typeof import("three");

export function OfficeSceneThree({
  state,
  onSelectEmployee,
  performance,
  onMeasuredFps,
  onAppliedQuality,
  onCanvasMetrics,
  onWebglFailed,
}: Props) {
  const mountRef = useRef<HTMLDivElement>(null);
  const stateRef = useRef(state);
  const perfRef = useRef(performance);
  const selectRef = useRef(onSelectEmployee);
  const fpsRef = useRef(onMeasuredFps);
  const appliedRef = useRef(onAppliedQuality);
  const metricsRef = useRef(onCanvasMetrics);
  const webglFailedRef = useRef(onWebglFailed);
  const [error, setError] = useState<string | null>(null);

  stateRef.current = state;
  perfRef.current = performance;
  selectRef.current = onSelectEmployee;
  fpsRef.current = onMeasuredFps;
  appliedRef.current = onAppliedQuality;
  metricsRef.current = onCanvasMetrics;
  webglFailedRef.current = onWebglFailed;

  useEffect(() => {
    let cancelled = false;
    let cleanup: (() => void) | undefined;

    (async () => {
      try {
        const THREE = await import("three");
        if (cancelled || !mountRef.current) return;
        cleanup = bootScene(THREE, mountRef.current, {
          stateRef,
          perfRef,
          selectRef,
          onMeasuredFps: (fps: number) => fpsRef.current?.(fps),
          onAppliedQuality: (level: QualityLevel) => appliedRef.current?.(level),
          onCanvasMetrics: (m) => metricsRef.current?.(m),
        });
      } catch (e) {
        if (cancelled) return;
        const reason = e instanceof Error ? e.message : "WebGL unavailable";
        setError(reason);
        webglFailedRef.current?.(reason);
      }
    })();

    return () => {
      cancelled = true;
      cleanup?.();
    };
    // Boot once per mount — callbacks read via refs so parent re-renders do not tear down WebGL.
  }, []);

  // Rebuild quality when settings change is handled inside loop via perfRef

  if (error) {
    return (
      <div className="flex h-full items-center justify-center bg-slate-950 text-sm text-slate-400">
        3D unavailable: {error}. Use 2D view.
      </div>
    );
  }

  return (
    <div
      ref={mountRef}
      className="relative h-full w-full overflow-hidden rounded-xl bg-slate-950"
      data-testid="office-scene-three"
    />
  );
}

function bootScene(
  THREE: ThreeModule,
  mount: HTMLDivElement,
  ctx: {
    stateRef: React.MutableRefObject<VisualOfficeState>;
    perfRef: React.MutableRefObject<PerformanceSettings>;
    selectRef: React.MutableRefObject<(id: string | null) => void>;
    onMeasuredFps?: (fps: number) => void;
    onAppliedQuality?: (level: QualityLevel) => void;
    onCanvasMetrics?: (metrics: { width: number; height: number }) => void;
  },
) {
  const scene = new THREE.Scene();
  // P1: brighter office — readable on mobile screens
  scene.background = new THREE.Color(0xc8d4e4);
  scene.fog = new THREE.Fog(0xc8d4e4, 18, 36);

  const camera = new THREE.PerspectiveCamera(48, 1, 0.1, 80);
  camera.position.set(0, 9, 11);
  camera.lookAt(0, 0, 0);

  const renderer = new THREE.WebGLRenderer({
    antialias: true,
    alpha: false,
    powerPreference: "high-performance",
  });
  renderer.setClearColor(0xc8d4e4);
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.domElement.setAttribute("aria-label", "3D AI office — tap an avatar to select");
  renderer.domElement.setAttribute("role", "img");
  mount.appendChild(renderer.domElement);

  // Brighter, softer lighting (still no post-processing)
  const hemi = new THREE.HemisphereLight(0xf0f4fa, 0xb0bec8, 0.7);
  scene.add(hemi);
  const ambient = new THREE.AmbientLight(0xdde4ee, 0.45);
  scene.add(ambient);
  const dir = new THREE.DirectionalLight(0xfff8f0, 0.85);
  dir.position.set(5, 12, 4);
  dir.castShadow = true;
  dir.shadow.mapSize.set(512, 512);
  dir.shadow.camera.near = 1;
  dir.shadow.camera.far = 30;
  dir.shadow.camera.left = -10;
  dir.shadow.camera.right = 10;
  dir.shadow.camera.top = 10;
  dir.shadow.camera.bottom = -10;
  scene.add(dir);
  const fill = new THREE.DirectionalLight(0xa5b4fc, 0.3);
  fill.position.set(-7, 5, -3);
  scene.add(fill);
  const accent = new THREE.PointLight(0x38bdf8, 0.4, 12, 2);
  accent.position.set(0, 2.2, 2.2);
  scene.add(accent);

  // Floor — light office carpet
  const floor = new THREE.Mesh(
    new THREE.PlaneGeometry(16, 12),
    new THREE.MeshStandardMaterial({
      color: 0xe8eef5,
      roughness: 0.9,
      metalness: 0.02,
    }),
  );
  floor.rotation.x = -Math.PI / 2;
  floor.receiveShadow = true;
  scene.add(floor);
  const floorInset = new THREE.Mesh(
    new THREE.PlaneGeometry(5.5, 4.2),
    new THREE.MeshStandardMaterial({
      color: 0xd5dee9,
      roughness: 0.85,
      metalness: 0.04,
    }),
  );
  floorInset.rotation.x = -Math.PI / 2;
  floorInset.position.set(0, 0.01, 1.2);
  floorInset.receiveShadow = true;
  scene.add(floorInset);

  // Walls — soft light gray office
  const wallMat = new THREE.MeshStandardMaterial({
    color: 0xe2e8f0,
    roughness: 0.92,
    metalness: 0.02,
  });
  const back = new THREE.Mesh(new THREE.BoxGeometry(16, 4, 0.2), wallMat);
  back.position.set(0, 2, -6);
  back.receiveShadow = true;
  scene.add(back);
  const left = new THREE.Mesh(new THREE.BoxGeometry(0.2, 4, 12), wallMat);
  left.position.set(-8, 2, 0);
  scene.add(left);
  const right = new THREE.Mesh(new THREE.BoxGeometry(0.2, 4, 12), wallMat);
  right.position.set(8, 2, 0);
  scene.add(right);
  const baseboard = new THREE.Mesh(
    new THREE.BoxGeometry(15.6, 0.14, 0.08),
    new THREE.MeshStandardMaterial({ color: 0x94a3b8, roughness: 0.65, metalness: 0.08 }),
  );
  baseboard.position.set(0, 0.12, -5.88);
  scene.add(baseboard);
  // Window glow panels on back wall (cheap brightness cue)
  for (const wx of [-4.5, 0, 4.5]) {
    const win = new THREE.Mesh(
      new THREE.PlaneGeometry(2.2, 1.6),
      new THREE.MeshStandardMaterial({
        color: 0xf8fafc,
        emissive: 0xbdd6f0,
        emissiveIntensity: 0.35,
        roughness: 0.5,
      }),
    );
    win.position.set(wx, 2.1, -5.88);
    scene.add(win);
  }

  // Meeting table — light wood tone
  const meet = new THREE.Mesh(
    new THREE.BoxGeometry(3.2, 0.12, 1.6),
    new THREE.MeshStandardMaterial({ color: 0xc4a882, roughness: 0.55, metalness: 0.08 }),
  );
  meet.position.set(MEETING_TABLE_POS[0], 0.78, MEETING_TABLE_POS[1]);
  meet.castShadow = true;
  meet.receiveShadow = true;
  scene.add(meet);
  const meetEdge = new THREE.Mesh(
    new THREE.BoxGeometry(3.28, 0.04, 1.68),
    new THREE.MeshStandardMaterial({ color: 0xa8896a, roughness: 0.4, metalness: 0.12 }),
  );
  meetEdge.position.set(MEETING_TABLE_POS[0], 0.7, MEETING_TABLE_POS[1]);
  scene.add(meetEdge);

  // --- V1.2.1: anime cel-shaded characters + wander AI (fully procedural) ---
  type EmpNode = {
    id: string;
    deskIndex: number;
    seatX: number;
    seatZ: number;
    furniture: InstanceType<ThreeModule["Group"]>;
    rig: AnimeRig;
    agent: WanderAgent;
    walkPhase: number;
    hit: InstanceType<ThreeModule["Mesh"]>;
    monitor: InstanceType<ThreeModule["Mesh"]>;
    displayName: string;
  };
  const employees: EmpNode[] = [];

  /** Wander obstacles: desk + meeting-table footprints so characters walk around them. */
  const obstacles: Aabb[] = [
    ...DESK_POSITIONS.map(([dx, dz]) => deskAabb(dx, dz)),
    meetingTableAabb(MEETING_TABLE_POS[0], MEETING_TABLE_POS[1]),
  ];

  function mat(
    color: number,
    opts?: { roughness?: number; metalness?: number; emissive?: number; emissiveIntensity?: number },
  ) {
    return new THREE.MeshStandardMaterial({
      color,
      roughness: opts?.roughness ?? 0.65,
      metalness: opts?.metalness ?? 0.06,
      emissive: opts?.emissive ?? 0x000000,
      emissiveIntensity: opts?.emissiveIntensity ?? 0,
    });
  }

  for (let i = 0; i < 4; i++) {
    const [x, z] = DESK_POSITIONS[i]!;
    const seededId = DESK_ORDER[i] ?? `desk-${i}`;
    const vis = characterVisualFor(seededId);
    const displayName = seededId.charAt(0).toUpperCase() + seededId.slice(1);

    // --- Workstation furniture (static) ---
    const furniture = new THREE.Group();
    furniture.position.set(x, 0, z);

    const deskTop = new THREE.Mesh(
      new THREE.BoxGeometry(1.55, 0.08, 0.9),
      mat(0xc4a574, { roughness: 0.55, metalness: 0.1 }),
    );
    deskTop.position.set(0, 0.74, 0);
    deskTop.castShadow = true;
    deskTop.receiveShadow = true;
    furniture.add(deskTop);

    for (const [lx, lz] of [
      [-0.65, -0.35],
      [0.65, -0.35],
      [-0.65, 0.35],
      [0.65, 0.35],
    ] as const) {
      const leg = new THREE.Mesh(
        new THREE.BoxGeometry(0.07, 0.72, 0.07),
        mat(0x8b7355, { roughness: 0.7 }),
      );
      leg.position.set(lx, 0.36, lz);
      leg.castShadow = true;
      furniture.add(leg);
    }

    // Chair: seat + backrest + post + base (previously floating)
    const seat = new THREE.Mesh(
      new THREE.BoxGeometry(0.5, 0.08, 0.48),
      mat(0x475569, { roughness: 0.75 }),
    );
    seat.position.set(0, 0.42, 0.62);
    seat.castShadow = true;
    furniture.add(seat);
    const backrest = new THREE.Mesh(
      new THREE.BoxGeometry(0.5, 0.55, 0.07),
      mat(0x334155, { roughness: 0.75 }),
    );
    backrest.position.set(0, 0.72, 0.84);
    backrest.castShadow = true;
    furniture.add(backrest);
    const post = new THREE.Mesh(
      new THREE.CylinderGeometry(0.035, 0.035, 0.34, 8),
      mat(0x64748b, { roughness: 0.4, metalness: 0.4 }),
    );
    post.position.set(0, 0.21, 0.62);
    furniture.add(post);
    const chairBase = new THREE.Mesh(
      new THREE.CylinderGeometry(0.24, 0.26, 0.05, 12),
      mat(0x475569, { roughness: 0.6 }),
    );
    chairBase.position.set(0, 0.03, 0.62);
    furniture.add(chairBase);

    // Monitor stand + bezel + screen
    const stand = new THREE.Mesh(
      new THREE.BoxGeometry(0.12, 0.28, 0.1),
      mat(0x64748b, { roughness: 0.4, metalness: 0.3 }),
    );
    stand.position.set(0, 0.9, -0.28);
    furniture.add(stand);
    const bezel = new THREE.Mesh(
      new THREE.BoxGeometry(0.78, 0.5, 0.05),
      mat(0x1e293b, { roughness: 0.35, metalness: 0.25 }),
    );
    bezel.position.set(0, 1.22, -0.28);
    furniture.add(bezel);
    const monitor = new THREE.Mesh(
      new THREE.BoxGeometry(0.7, 0.42, 0.03),
      mat(0x0f172a, { roughness: 0.3, metalness: 0.2, emissive: 0x000000, emissiveIntensity: 1 }),
    );
    monitor.position.set(0, 1.22, -0.25);
    furniture.add(monitor);

    // Keyboard + mouse
    const keyboard = new THREE.Mesh(
      new THREE.BoxGeometry(0.55, 0.03, 0.2),
      mat(0x334155, { roughness: 0.5 }),
    );
    keyboard.position.set(0, 0.8, 0.18);
    furniture.add(keyboard);
    const mouse = new THREE.Mesh(
      new THREE.BoxGeometry(0.08, 0.03, 0.12),
      mat(0x475569, { roughness: 0.45 }),
    );
    mouse.position.set(0.42, 0.8, 0.2);
    furniture.add(mouse);

    // Nameplate / prop (brand-colored)
    const plate = new THREE.Mesh(
      new THREE.BoxGeometry(0.35, 0.04, 0.12),
      mat(vis.prop, { roughness: 0.45, metalness: 0.15 }),
    );
    plate.position.set(-0.5, 0.8, 0.28);
    furniture.add(plate);

    scene.add(furniture);

    // --- Anime character (scene-level so it can walk away from the desk) ---
    const seatX = x;
    const seatZ = z + 0.55;
    const rig = buildAnimeCharacter(THREE, vis, { displayName });
    rig.root.position.set(seatX, 0, seatZ);
    rig.root.rotation.y = Math.PI; // face the desk / monitor
    for (const m of rig.pickMeshes) {
      m.userData.isEmployee = true;
      m.userData.deskIndex = i;
      m.userData.employeeId = seededId;
    }
    scene.add(rig.root);

    const agent = createWanderAgent(seatX, seatZ, Math.PI);

    // Invisible pick volume covering the workstation
    const hit = new THREE.Mesh(
      new THREE.CylinderGeometry(0.95, 0.95, 2.3, 12),
      new THREE.MeshBasicMaterial({
        transparent: true,
        opacity: 0,
        depthWrite: false,
      }),
    );
    hit.position.set(x, 1.0, z + 0.2);
    hit.userData.isEmployee = true;
    hit.userData.deskIndex = i;
    hit.userData.employeeId = seededId;
    hit.userData.isPickVolume = true;
    scene.add(hit);

    employees.push({
      id: seededId,
      deskIndex: i,
      seatX,
      seatZ,
      furniture,
      rig,
      agent,
      walkPhase: Math.random() * 6,
      hit,
      monitor,
      displayName,
    });
  }

  // Meeting-table legs (the tabletop used to float)
  for (const [lx, lz] of [
    [-1.45, -0.65],
    [1.45, -0.65],
    [-1.45, 0.65],
    [1.45, 0.65],
  ] as const) {
    const tleg = new THREE.Mesh(
      new THREE.BoxGeometry(0.12, 0.72, 0.12),
      mat(0x8b7355, { roughness: 0.7 }),
    );
    tleg.position.set(MEETING_TABLE_POS[0] + lx, 0.36, MEETING_TABLE_POS[1] + lz);
    tleg.castShadow = true;
    scene.add(tleg);
  }

  // Corner plant — cheap warmth for the empty corner
  const pot = new THREE.Mesh(
    new THREE.CylinderGeometry(0.2, 0.26, 0.38, 10),
    mat(0xb45309, { roughness: 0.8 }),
  );
  pot.position.set(-6.9, 0.19, 4.7);
  pot.castShadow = true;
  scene.add(pot);
  const leafMat = mat(0x3f8f4f, { roughness: 0.85 });
  const leaf1 = new THREE.Mesh(new THREE.SphereGeometry(0.34, 10, 10), leafMat);
  leaf1.position.set(-6.9, 0.72, 4.7);
  leaf1.castShadow = true;
  scene.add(leaf1);
  const leaf2 = new THREE.Mesh(new THREE.SphereGeometry(0.24, 10, 10), leafMat);
  leaf2.position.set(-6.75, 1.02, 4.6);
  leaf2.castShadow = true;
  scene.add(leaf2);

  // Raycaster for selection
  const raycaster = new THREE.Raycaster();
  const pointer = new THREE.Vector2();
  const selectionRing = new THREE.Mesh(
    new THREE.RingGeometry(0.52, 0.62, 32),
    new THREE.MeshBasicMaterial({
      color: 0x22d3ee,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.9,
    }),
  );
  selectionRing.rotation.x = -Math.PI / 2;
  selectionRing.position.y = 0.04;
  selectionRing.visible = false;
  scene.add(selectionRing);

  function projectDesksToScreen(): ScreenProjectedDesk[] {
    const rect = renderer.domElement.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return [];
    const out: ScreenProjectedDesk[] = [];
    const world = new THREE.Vector3();
    for (const node of employees) {
      if (!node.id) continue;
      world.set(
        node.rig.root.position.x,
        node.rig.root.position.y + 1.2,
        node.rig.root.position.z,
      );
      world.project(camera);
      // Skip points behind the camera
      if (world.z > 1) continue;
      out.push({
        employeeId: node.id,
        screenX: (world.x * 0.5 + 0.5) * rect.width + rect.left,
        screenY: (-world.y * 0.5 + 0.5) * rect.height + rect.top,
      });
    }
    return out;
  }

  function pickEmployee(clientX: number, clientY: number): string | null {
    const rect = renderer.domElement.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return null;
    pointer.x = ((clientX - rect.left) / rect.width) * 2 - 1;
    pointer.y = -((clientY - rect.top) / rect.height) * 2 + 1;
    raycaster.setFromCamera(pointer, camera);
    const meshes: InstanceType<ThreeModule["Object3D"]>[] = employees.flatMap(
      (e) => [e.hit, ...e.rig.pickMeshes],
    );
    const hits = raycaster.intersectObjects(meshes, false);
    if (hits.length > 0) {
      const ud = hits[0]!.object.userData as {
        employeeId?: string;
        deskIndex?: number;
      };
      const fromRay = resolveEmployeeIdFromPick({
        employeeId: ud.employeeId,
        deskIndex: ud.deskIndex,
        employees: ctx.stateRef.current.employees,
      });
      if (fromRay) return fromRay;
    }
    // Fallback: nearest projected desk (reliable at overview distance)
    return pickNearestEmployeeByScreenDistance(
      clientX,
      clientY,
      projectDesksToScreen(),
    );
  }

  // Orbit + click-vs-drag; only gestures that *start* on the canvas can pick
  let canvasGesture = false;
  let dragging = false;
  let pointerMoved = false;
  let downX = 0;
  let downY = 0;
  let lastX = 0;
  let lastY = 0;
  let theta = 0.6;
  let phi = 0.85;
  let radius = OVERVIEW_RADIUS;
  let lookAtCurrent: CameraLookTarget = { ...OVERVIEW_LOOK_AT };
  let lookAtGoal: CameraLookTarget = { ...OVERVIEW_LOOK_AT };
  let radiusGoal = OVERVIEW_RADIUS;
  /** Only auto-set radiusGoal when this identity changes (not every frame). */
  let lastRadiusSelectionKey: string | null = null;
  const FOCUS_LERP = 0.08;

  const onDown = (ev: PointerEvent) => {
    if (ev.button !== 0) return;
    canvasGesture = true;
    dragging = true;
    pointerMoved = false;
    downX = lastX = ev.clientX;
    downY = lastY = ev.clientY;
    activePointerId = ev.pointerId;
    try {
      renderer.domElement.setPointerCapture(ev.pointerId);
    } catch {
      /* ignore — older browsers */
    }
  };
  const onMove = (ev: PointerEvent) => {
    if (!canvasGesture || !dragging) return;
    const dx = ev.clientX - lastX;
    const dy = ev.clientY - lastY;
    lastX = ev.clientX;
    lastY = ev.clientY;
    if (!isClickGesture(downX, downY, ev.clientX, ev.clientY)) {
      pointerMoved = true;
    }
    if (pointerMoved) {
      theta -= dx * 0.005;
      phi = Math.max(0.25, Math.min(1.35, phi + dy * 0.005));
    }
  };
  let activePointerId: number | null = null;
  const endCanvasGesture = () => {
    if (activePointerId != null) {
      try {
        if (renderer.domElement.hasPointerCapture?.(activePointerId)) {
          renderer.domElement.releasePointerCapture(activePointerId);
        }
      } catch {
        /* ignore */
      }
      activePointerId = null;
    }
    canvasGesture = false;
    dragging = false;
    pointerMoved = false;
  };
  const onUp = (ev: PointerEvent) => {
    if (ev.button !== 0) return;
    if (!canvasGesture) return;
    const wasClick = !pointerMoved && isClickGesture(downX, downY, ev.clientX, ev.clientY);
    const x = ev.clientX;
    const y = ev.clientY;
    endCanvasGesture();
    if (!wasClick) return;
    const id = pickEmployee(x, y);
    ctx.selectRef.current(id);
  };
  const onCancel = () => {
    endCanvasGesture();
  };
  const onWheel = (ev: WheelEvent) => {
    radius = Math.max(6, Math.min(22, radius + ev.deltaY * 0.01));
    radiusGoal = radius;
  };
  renderer.domElement.style.touchAction = "none";
  renderer.domElement.addEventListener("pointerdown", onDown);
  window.addEventListener("pointermove", onMove);
  window.addEventListener("pointerup", onUp);
  window.addEventListener("pointercancel", onCancel);
  renderer.domElement.addEventListener("wheel", onWheel, { passive: true });

  // Resize
  const resize = () => {
    const w = mount.clientWidth || 1;
    const h = mount.clientHeight || 1;
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    const q = qualityProfile(ctx.perfRef.current.quality);
    renderer.setPixelRatio(q.pixelRatio);
    renderer.setSize(w, h, false);
    renderer.shadowMap.enabled = q.shadows;
    dir.shadow.mapSize.set(q.shadowMapSize, q.shadowMapSize);
    ctx.onCanvasMetrics?.({ width: Math.round(w), height: Math.round(h) });
  };
  resize();
  const ro = new ResizeObserver(resize);
  ro.observe(mount);

  // Loop
  const meter = new FpsMeter();
  const adaptive = new AdaptiveRenderController(ctx.perfRef.current.quality);
  let lastUserQuality: QualityLevel = ctx.perfRef.current.quality;
  let lastAppliedQuality: QualityLevel = ctx.perfRef.current.quality;
  ctx.onAppliedQuality?.(lastAppliedQuality);
  let raf = 0;
  let lastFrame = 0;
  let accum = 0;

  function syncEmployees(st: VisualOfficeState, dt: number) {
    const reducedMotion = ctx.perfRef.current.reducedMotion;
    const t = performance.now() / 1000;
    for (let i = 0; i < employees.length; i++) {
      const visual = st.employees[i];
      const node = employees[i]!;
      if (!visual) {
        node.furniture.visible = false;
        node.rig.root.visible = false;
        node.hit.visible = false;
        continue;
      }
      node.furniture.visible = true;
      node.rig.root.visible = true;
      node.hit.visible = true;
      node.id = visual.id;
      for (const m of node.rig.pickMeshes) {
        m.userData.employeeId = visual.id;
        m.userData.deskIndex = visual.deskIndex;
      }
      node.hit.userData.employeeId = visual.id;
      node.hit.userData.deskIndex = visual.deskIndex;

      const pose = poseForStatus(visual.status);
      // Desk-bound when the backend says so; otherwise free to roam.
      // reducedMotion keeps everyone seated (accessibility).
      const wantsSeat =
        reducedMotion ||
        pose === "working" ||
        pose === "thinking" ||
        pose === "sitting";
      const upd = updateWander(node.agent, dt, {
        wantsSeat,
        waypoints: ROAM_WAYPOINTS,
        obstacles,
      });
      const rig = node.rig;
      const a = node.agent;
      rig.root.position.set(a.x, 0, a.z);

      // Monitor screen glow follows backend status (not invented activity)
      const monMat = node.monitor.material as InstanceType<
        ThreeModule["MeshStandardMaterial"]
      >;
      if (pose === "working") {
        monMat.emissive.setHex(0x0ea5e9);
        monMat.emissiveIntensity = 0.4;
      } else if (pose === "thinking") {
        monMat.emissive.setHex(0x6366f1);
        monMat.emissiveIntensity = 0.25;
      } else if (pose === "completed") {
        monMat.emissive.setHex(0x22c55e);
        monMat.emissiveIntensity = 0.18;
      } else {
        monMat.emissive.setHex(0x000000);
        monMat.emissiveIntensity = 0;
      }

      if (upd.moving && !reducedMotion) {
        node.walkPhase += dt * 7;
        rig.root.rotation.y = a.heading;
        applyWalkPose(rig, node.walkPhase);
      } else if (upd.seated) {
        rig.root.rotation.y = a.heading;
        if (pose === "working" && !reducedMotion) applySitPose(rig, t, true);
        else if (pose === "thinking" && !reducedMotion) applyThinkPose(rig, t);
        else applySitPose(rig, t, false);
      } else if (!reducedMotion) {
        rig.root.rotation.y = a.heading;
        applyIdlePose(rig, t);
      } else {
        resetPose(rig);
      }
      if (!reducedMotion) applyBlink(rig, dt);

      // Floating name/status tag — text from real dashboard state
      const label =
        visual.activityLabel ??
        visual.status.charAt(0).toUpperCase() + visual.status.slice(1);
      const key = `${label}|${statusColor(visual.status)}`;
      if (rig.beaconStatus !== key) {
        paintBeacon(THREE, rig, label, statusColor(visual.status));
      }
    }

    // Cheap separation so roaming characters don't overlap each other
    for (let i = 0; i < employees.length; i++) {
      for (let j = i + 1; j < employees.length; j++) {
        const A = employees[i]!;
        const B = employees[j]!;
        if (A.agent.mode === "seated" || B.agent.mode === "seated") continue;
        const dx = B.agent.x - A.agent.x;
        const dz = B.agent.z - A.agent.z;
        const d = Math.hypot(dx, dz);
        if (d > 0.0001 && d < 0.6) {
          const push = (0.6 - d) / 2;
          const nx = dx / d;
          const nz = dz / d;
          A.agent.x -= nx * push;
          A.agent.z -= nz * push;
          B.agent.x += nx * push;
          B.agent.z += nz * push;
        }
      }
    }

    // Selection ring follows the character (not just the desk)
    const sel = st.selectedEmployeeId
      ? employees.find((e) => e.id === st.selectedEmployeeId)
      : undefined;
    if (sel) {
      selectionRing.visible = true;
      selectionRing.position.x = sel.rig.root.position.x;
      selectionRing.position.z = sel.rig.root.position.z;
    } else {
      selectionRing.visible = false;
    }
  }
  function frame(now: number) {
    raf = requestAnimationFrame(frame);
    const perf = ctx.perfRef.current;
    const interval = frameIntervalMs(perf.fpsCap);
    const dt = lastFrame ? now - lastFrame : 16;
    lastFrame = now;
    accum += dt;
    if (interval > 0 && accum < interval) return;
    accum = 0;

    const fps = meter.tick(now);
    ctx.onMeasuredFps?.(fps);

    // User Quality control is authoritative ceiling; adaptive only lowers render cost.
    if (perf.quality !== lastUserQuality) {
      adaptive.setUserQuality(perf.quality);
      lastUserQuality = perf.quality;
    }
    const applied = adaptive.tick(fps, perf.fpsCap, now);
    if (applied !== lastAppliedQuality) {
      lastAppliedQuality = applied;
      const q = qualityProfile(applied);
      renderer.setPixelRatio(q.pixelRatio);
      renderer.shadowMap.enabled = q.shadows;
      dir.shadow.mapSize.set(q.shadowMapSize, q.shadowMapSize);
      // Re-apply size so pixel ratio takes effect without rebuilding the renderer
      const w = mount.clientWidth || 1;
      const h = mount.clientHeight || 1;
      renderer.setSize(w, h, false);
      ctx.onAppliedQuality?.(applied);
    }

    const st = ctx.stateRef.current;
    // Focus the character's live position when one is selected
    const selNode = st.selectedEmployeeId
      ? employees.find((e) => e.id === st.selectedEmployeeId)
      : undefined;
    lookAtGoal = selNode
      ? {
          x: selNode.rig.root.position.x,
          y: 0.9,
          z: selNode.rig.root.position.z,
        }
      : { ...OVERVIEW_LOOK_AT };
    // Auto radius only when selected employee identity changes — preserves wheel zoom otherwise.
    const selectionKey = st.selectedEmployeeId;
    if (selectionKey !== lastRadiusSelectionKey) {
      lastRadiusSelectionKey = selectionKey;
      radiusGoal = cameraRadiusForSelection(selectionKey);
    }
    lookAtCurrent = lerpLookTarget(lookAtCurrent, lookAtGoal, FOCUS_LERP);
    radius = lerp(radius, radiusGoal, FOCUS_LERP);

    camera.position.x = lookAtCurrent.x + Math.sin(theta) * Math.sin(phi) * radius;
    camera.position.y = lookAtCurrent.y + Math.cos(phi) * radius;
    camera.position.z = lookAtCurrent.z + Math.cos(theta) * Math.sin(phi) * radius;
    camera.lookAt(lookAtCurrent.x, lookAtCurrent.y, lookAtCurrent.z);

    const dtSec = (interval > 0 ? interval : dt) / 1000;
    syncEmployees(st, dtSec);
    renderer.render(scene, camera);
  }
  raf = requestAnimationFrame(frame);

  return () => {
    cancelAnimationFrame(raf);
    raf = 0;
    ro.disconnect();
    renderer.domElement.removeEventListener("pointerdown", onDown);
    window.removeEventListener("pointermove", onMove);
    window.removeEventListener("pointerup", onUp);
    window.removeEventListener("pointercancel", onCancel);
    renderer.domElement.removeEventListener("wheel", onWheel);
    endCanvasGesture();
    // Dispose GPU resources — geometries & materials
    scene.traverse((obj) => {
      const mesh = obj as InstanceType<ThreeModule["Mesh"]>;
      if (mesh.geometry) mesh.geometry.dispose?.();
      const mat = mesh.material as
        | InstanceType<ThreeModule["Material"]>
        | InstanceType<ThreeModule["Material"]>[]
        | undefined;
      if (Array.isArray(mat)) mat.forEach((m) => m.dispose?.());
      else mat?.dispose?.();
    });
    renderer.dispose();
    if (renderer.domElement.parentNode === mount) {
      mount.removeChild(renderer.domElement);
    }
  };
}
