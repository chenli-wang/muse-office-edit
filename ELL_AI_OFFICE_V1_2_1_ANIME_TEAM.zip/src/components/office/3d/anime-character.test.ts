import assert from "node:assert/strict";
import { describe, it } from "node:test";
import * as THREE from "three";
import {
  buildAnimeCharacter,
  resetPose,
  applyIdlePose,
  applyWalkPose,
  applySitPose,
  applyThinkPose,
  applyBlink,
  toonGradientMap,
} from "./anime-character.ts";
import { CHARACTER_VISUAL, DESK_ORDER } from "./office-state.ts";

describe("anime character builder (node-safe, no canvas)", () => {
  it("builds a distinct articulated rig for each of the four employees", () => {
    for (const id of DESK_ORDER) {
      const rig = buildAnimeCharacter(THREE, CHARACTER_VISUAL[id], {
        displayName: id,
      });
      assert.ok(rig.root instanceof THREE.Group);
      for (const part of [
        rig.hips,
        rig.torso,
        rig.headGroup,
        rig.head,
        rig.shoulderL,
        rig.shoulderR,
        rig.elbowL,
        rig.elbowR,
        rig.thighL,
        rig.thighR,
        rig.kneeL,
        rig.kneeR,
      ]) {
        assert.ok(part, `${id} missing rig part`);
      }
      // Articulated + pickable
      assert.ok(rig.pickMeshes.length > 10, `${id} pickMeshes=${rig.pickMeshes.length}`);
      // Outlines: torso/head carry an inverted-hull child
      assert.ok(rig.torso.children.length > 0, `${id} torso outline missing`);
      assert.ok(rig.head.children.length > 0, `${id} head outline missing`);
      // Node fallback (no document): geometric eyes instead of canvas face
      assert.equal(rig.face, null);
      assert.equal(rig.fallbackEyes.length, 2);
      assert.ok(rig.beacon instanceof THREE.Sprite);
    }
  });

  it("hair styles differ per character", () => {
    const counts = new Map<string, number>();
    for (const id of DESK_ORDER) {
      const rig = buildAnimeCharacter(THREE, CHARACTER_VISUAL[id]);
      const n = rig.hairGroup.children.length;
      counts.set(CHARACTER_VISUAL[id].hairStyle, n);
    }
    // Four styles, each with its own hair-piece count signature
    assert.equal(counts.size, 4);
  });

  it("toon gradient map is a shared 3-step texture", () => {
    const g1 = toonGradientMap(THREE);
    const g2 = toonGradientMap(THREE);
    assert.equal(g1, g2);
    assert.equal(g1.image.width, 3);
  });

  it("pose functions articulate joints without throwing", () => {
    const rig = buildAnimeCharacter(THREE, CHARACTER_VISUAL.claude);
    applyIdlePose(rig, 1.0);
    assert.ok(Math.abs(rig.hips.position.y - 0.74) < 0.05);

    applyWalkPose(rig, 1.2);
    assert.notEqual(rig.thighL.rotation.x, 0);
    assert.notEqual(rig.thighR.rotation.x, 0);
    // Legs oppose each other
    assert.ok(rig.thighL.rotation.x * rig.thighR.rotation.x < 0);

    applySitPose(rig, 2.0, true);
    assert.ok(rig.hips.position.y < 0.6, "sitting lowers the hips");
    assert.ok(rig.thighL.rotation.x < -1.2, "thighs point forward when seated");

    applyThinkPose(rig, 3.0);
    assert.notEqual(rig.headGroup.rotation.z, 0);

    resetPose(rig);
    assert.equal(rig.hips.position.y, 0.74);
    assert.equal(rig.thighL.rotation.x, 0);
  });

  it("blink is a no-op without a canvas face (node) and safe with dt=0", () => {
    const rig = buildAnimeCharacter(THREE, CHARACTER_VISUAL.gpt);
    assert.doesNotThrow(() => applyBlink(rig, 0.016));
    assert.doesNotThrow(() => applyBlink(rig, 0));
  });
});
