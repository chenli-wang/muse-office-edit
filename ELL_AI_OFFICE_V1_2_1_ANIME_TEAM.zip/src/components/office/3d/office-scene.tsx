/**
 * Lightweight isometric office canvas — no Three.js required.
 * Presentation-only; state from mapDashboardToVisualOffice.
 */
import { useEffect, useRef, useState, useCallback } from "react";
import {
  DESK_LAYOUT,
  statusColor,
  characterVisualFor,
  type VisualOfficeState,
  type VisualEmployee,
} from "./office-state.ts";

interface Props {
  state: VisualOfficeState;
  onSelectEmployee: (id: string | null) => void;
}

function isoProject(x: number, y: number, z: number, originX: number, originY: number, scale: number) {
  // Classic isometric
  const sx = originX + (x - z) * scale;
  const sy = originY + (x + z) * scale * 0.5 - y * scale;
  return { sx, sy };
}

export function OfficeScene3D({ state, onSelectEmployee }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [size, setSize] = useState({ w: 640, h: 420 });
  const animRef = useRef(0);
  const tickRef = useRef(0);

  useEffect(() => {
    const el = canvasRef.current?.parentElement;
    if (!el) return;
    const ro = new ResizeObserver((entries) => {
      const r = entries[0]?.contentRect;
      if (r) setSize({ w: Math.max(280, r.width), h: Math.max(240, Math.min(480, r.width * 0.65)) });
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const hitTest = useCallback(
    (clientX: number, clientY: number) => {
      const canvas = canvasRef.current;
      if (!canvas) return null;
      const rect = canvas.getBoundingClientRect();
      const mx = ((clientX - rect.left) / rect.width) * size.w;
      const my = ((clientY - rect.top) / rect.height) * size.h;
      const scale = Math.min(size.w, size.h) * 0.28;
      const originX = size.w * 0.5;
      const originY = size.h * 0.28;
      let best: { id: string; d: number } | null = null;
      for (const emp of state.employees) {
        const layout = DESK_LAYOUT[emp.deskIndex] ?? DESK_LAYOUT[0]!;
        const { sx, sy } = isoProject(layout.x * 2, 0.4, layout.z * 2, originX, originY, scale);
        const d = (mx - sx) ** 2 + (my - sy) ** 2;
        if (d < 48 * 48 && (!best || d < best.d)) best = { id: emp.id, d };
      }
      return best?.id ?? null;
    },
    [state.employees, size],
  );

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let alive = true;
    const draw = () => {
      if (!alive) return;
      tickRef.current += 1;
      const t = tickRef.current;
      const w = size.w;
      const h = size.h;
      ctx.clearRect(0, 0, w, h);

      // Background
      ctx.fillStyle = "#c8d4e4";
      ctx.fillRect(0, 0, w, h);

      const scale = Math.min(w, h) * 0.28;
      const originX = w * 0.5;
      const originY = h * 0.28;

      // Floor diamond
      const corners = [
        isoProject(0, 0, 0, originX, originY, scale),
        isoProject(2, 0, 0, originX, originY, scale),
        isoProject(2, 0, 2, originX, originY, scale),
        isoProject(0, 0, 2, originX, originY, scale),
      ];
      ctx.beginPath();
      ctx.moveTo(corners[0]!.sx, corners[0]!.sy);
      for (let i = 1; i < 4; i++) ctx.lineTo(corners[i]!.sx, corners[i]!.sy);
      ctx.closePath();
      ctx.fillStyle = "#e8eef5";
      ctx.fill();
      ctx.strokeStyle = "#334155";
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Center project table
      const center = isoProject(1, 0.05, 1, originX, originY, scale);
      ctx.fillStyle = "#243044";
      ctx.beginPath();
      ctx.ellipse(center.sx, center.sy, scale * 0.22, scale * 0.1, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#64748b";
      ctx.font = `${Math.max(9, scale * 0.08)}px sans-serif`;
      ctx.textAlign = "center";
      ctx.fillText("PROJECT", center.sx, center.sy + 3);

      // Desks + avatars
      for (const emp of state.employees) {
        drawDeskAndAvatar(ctx, emp, originX, originY, scale, t, state.selectedEmployeeId);
      }

      // Active task banner
      if (state.taskTitle) {
        ctx.fillStyle = "rgba(8,12,18,0.85)";
        ctx.fillRect(8, 8, w - 16, 28);
        ctx.fillStyle = state.hasActiveTask ? "#22d3ee" : "#94a3b8";
        ctx.font = "12px sans-serif";
        ctx.textAlign = "left";
        ctx.fillText(
          `${state.taskStatus ?? ""} · ${state.taskTitle}`.slice(0, 64),
          14,
          26,
        );
      }

      animRef.current = requestAnimationFrame(draw);
    };
    draw();
    return () => {
      alive = false;
      cancelAnimationFrame(animRef.current);
    };
  }, [state, size]);

  return (
    <div className="relative w-full overflow-hidden rounded-xl border border-zinc-800 bg-[#0b0f14]">
      <canvas
        ref={canvasRef}
        width={size.w}
        height={size.h}
        className="block w-full touch-manipulation"
        style={{ height: size.h, touchAction: "manipulation" }}
        onClick={(e) => {
          const id = hitTest(e.clientX, e.clientY);
          onSelectEmployee(id);
        }}
        onTouchEnd={(e) => {
          const touch = e.changedTouches[0];
          if (!touch) return;
          const id = hitTest(touch.clientX, touch.clientY);
          onSelectEmployee(id);
        }}
        role="img"
        aria-label="2.5D isometric AI office — tap an avatar to select"
      />
      <p className="pointer-events-none absolute bottom-2 left-2 text-[10px] text-zinc-600">
        Tap avatar to inspect · isometric view
      </p>
    </div>
  );
}

function drawDeskAndAvatar(
  ctx: CanvasRenderingContext2D,
  emp: VisualEmployee,
  originX: number,
  originY: number,
  scale: number,
  t: number,
  selectedId: string | null,
) {
  const layout = DESK_LAYOUT[emp.deskIndex] ?? DESK_LAYOUT[0]!;
  const base = isoProject(layout.x * 2, 0, layout.z * 2, originX, originY, scale);

  // Desk
  ctx.fillStyle = emp.isSynthesizer ? "#1e3a4c" : "#1e293b";
  ctx.fillRect(base.sx - scale * 0.2, base.sy - scale * 0.06, scale * 0.4, scale * 0.12);
  ctx.strokeStyle = selectedId === emp.id ? "#22d3ee" : "#475569";
  ctx.lineWidth = selectedId === emp.id ? 2 : 1;
  ctx.strokeRect(base.sx - scale * 0.2, base.sy - scale * 0.06, scale * 0.4, scale * 0.12);

  // Monitor
  const pulse =
    emp.status === "working" || emp.status === "thinking"
      ? 0.5 + 0.5 * Math.sin(t * 0.12)
      : 0.3;
  ctx.fillStyle = `rgba(34,211,238,${0.15 + pulse * 0.35})`;
  ctx.fillRect(base.sx - scale * 0.12, base.sy - scale * 0.28, scale * 0.24, scale * 0.16);

  // Avatar — identity color from CHARACTER_VISUAL (P1 parity)
  const vis = characterVisualFor(emp.id);
  const status = statusColor(emp.status);
  ctx.fillStyle = `#${vis.primary.toString(16).padStart(6, "0")}`;
  ctx.beginPath();
  ctx.arc(base.sx, base.sy - scale * 0.42, scale * 0.11, 0, Math.PI * 2);
  ctx.fill();
  // Hair
  ctx.fillStyle = `#${vis.hair.toString(16).padStart(6, "0")}`;
  ctx.beginPath();
  ctx.ellipse(base.sx, base.sy - scale * 0.5, scale * 0.1, scale * 0.06, 0, 0, Math.PI * 2);
  ctx.fill();
  // Status ring
  ctx.strokeStyle = status;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(base.sx, base.sy - scale * 0.42, scale * 0.13, 0, Math.PI * 2);
  ctx.stroke();

  // Name + activity
  ctx.textAlign = "center";
  ctx.fillStyle = "#e2e8f0";
  ctx.font = `bold ${Math.max(10, scale * 0.09)}px sans-serif`;
  ctx.fillText(emp.displayName, base.sx, base.sy + scale * 0.22);
  if (emp.activityLabel) {
    ctx.fillStyle = status;
    ctx.font = `${Math.max(9, scale * 0.07)}px sans-serif`;
    ctx.fillText(emp.activityLabel, base.sx, base.sy + scale * 0.34);
  }
}
