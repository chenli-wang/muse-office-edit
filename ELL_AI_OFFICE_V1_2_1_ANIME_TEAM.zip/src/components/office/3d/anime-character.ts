/**
 * V1.2.1 — Procedural anime-style office characters (three.js).
 *
 * Each employee gets a distinct cel-shaded character:
 * - Anime proportions (big head, compact body)
 * - MeshToonMaterial + few-step gradient map for the cel look
 * - Inverted-hull outlines for the inked anime edge
 * - Canvas-painted face: big anime eyes, blush, mouth
 * - Per-character hair style + accessory (headband / twintails / glasses / ahoge)
 * - Articulated pivots (shoulders, elbows, hips, knees, head) driven by
 *   procedural pose functions: idle breathing, walk cycle, sitting, thinking.
 *
 * Node-safe: face/beacon canvas textures are skipped when `document` is
 * unavailable (unit tests), falling back to simple geometric eyes.
 */
import type { CharacterVisual } from "./office-state.ts";

type ThreeModule = typeof import("three");
type Mesh = InstanceType<ThreeModule["Mesh"]>;
type Group = InstanceType<ThreeModule["Group"]>;
type Sprite = InstanceType<ThreeModule["Sprite"]>;

export interface AnimeRig {
  root: Group;
  hips: Group;
  torso: Mesh;
  headGroup: Group;
  head: Mesh;
  hairGroup: Group;
  /** Face patch mesh (canvas texture) — null on Node fallback. */
  face: Mesh | null;
  fallbackEyes: Mesh[];
  shoulderL: Group;
  shoulderR: Group;
  elbowL: Group;
  elbowR: Group;
  thighL: Group;
  thighR: Group;
  kneeL: Group;
  kneeR: Group;
  /** Floating name/status tag that follows the character. */
  beacon: Sprite;
  beaconCanvas: HTMLCanvasElement | null;
  beaconTexture: InstanceType<ThreeModule["CanvasTexture"]> | null;
  beaconStatus: string;
  displayName: string;
  /** All pickable meshes (outlines excluded). */
  pickMeshes: Mesh[];
  blinkTimer: number;
  blinkPhase: number;
  seed: number;
}

const OUTLINE_COLOR = 0x1b1d29;

let gradientMapCache: InstanceType<ThreeModule["DataTexture"]> | null = null;

/** 3-step gradient map shared by every toon material (cel shading). */
export function toonGradientMap(THREE: ThreeModule) {
  if (gradientMapCache) return gradientMapCache;
  const data = new Uint8Array([110, 170, 255]);
  const tex = new THREE.DataTexture(data, 3, 1, THREE.RedFormat);
  tex.minFilter = THREE.NearestFilter;
  tex.magFilter = THREE.NearestFilter;
  tex.needsUpdate = true;
  gradientMapCache = tex;
  return tex;
}

export function toon(
  THREE: ThreeModule,
  color: number,
  opts?: { emissive?: number; emissiveIntensity?: number },
): InstanceType<ThreeModule["MeshToonMaterial"]> {
  return new THREE.MeshToonMaterial({
    color,
    gradientMap: toonGradientMap(THREE),
    emissive: opts?.emissive ?? 0x000000,
    emissiveIntensity: opts?.emissiveIntensity ?? 0,
  });
}

/**
 * Inverted-hull outline: a slightly larger BackSide copy of the mesh.
 * Added as a child so it inherits the bone transform; raycast disabled.
 */
function addOutline(THREE: ThreeModule, mesh: Mesh, scale = 1.045): void {
  const outline = new THREE.Mesh(
    mesh.geometry,
    new THREE.MeshBasicMaterial({ color: OUTLINE_COLOR, side: THREE.BackSide }),
  );
  outline.scale.setScalar(scale);
  outline.castShadow = false;
  outline.receiveShadow = false;
  outline.raycast = () => {};
  mesh.add(outline);
}

type AnyGeometry =
  | InstanceType<ThreeModule["SphereGeometry"]>
  | InstanceType<ThreeModule["BoxGeometry"]>
  | InstanceType<ThreeModule["CapsuleGeometry"]>
  | InstanceType<ThreeModule["CylinderGeometry"]>
  | InstanceType<ThreeModule["ConeGeometry"]>
  | InstanceType<ThreeModule["TorusGeometry"]>;

function mesh(
  THREE: ThreeModule,
  geo: AnyGeometry,
  material: InstanceType<ThreeModule["Material"]>,
  x: number,
  y: number,
  z: number,
  outline = false,
): Mesh {
  const m = new THREE.Mesh(geo, material);
  m.position.set(x, y, z);
  m.castShadow = true;
  if (outline) addOutline(THREE, m);
  return m;
}

/** Paint a big-eyed anime face onto a 2D canvas. */
function paintFace(
  canvas: HTMLCanvasElement,
  eyeColor: string,
): void {
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  const W = canvas.width;
  const H = canvas.height;
  ctx.clearRect(0, 0, W, H);

  const eye = (cx: number, cy: number, flip: boolean) => {
    // Sclera
    ctx.fillStyle = "#ffffff";
    ctx.beginPath();
    ctx.ellipse(cx, cy, 30, 40, 0, 0, Math.PI * 2);
    ctx.fill();
    // Iris
    const grad = ctx.createRadialGradient(cx - 6, cy - 8, 4, cx, cy, 20);
    grad.addColorStop(0, "#ffffff");
    grad.addColorStop(0.25, eyeColor);
    grad.addColorStop(1, "#1e293b");
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(cx, cy, 19, 0, Math.PI * 2);
    ctx.fill();
    // Pupil
    ctx.fillStyle = "#0f172a";
    ctx.beginPath();
    ctx.arc(cx, cy, 9, 0, Math.PI * 2);
    ctx.fill();
    // Highlights
    ctx.fillStyle = "rgba(255,255,255,0.95)";
    ctx.beginPath();
    ctx.arc(cx - 7, cy - 9, 6, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "rgba(255,255,255,0.7)";
    ctx.beginPath();
    ctx.arc(cx + 6, cy + 7, 3, 0, Math.PI * 2);
    ctx.fill();
    // Upper lash — thick anime stroke
    ctx.strokeStyle = "#1e1b2e";
    ctx.lineWidth = 11;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.arc(cx, cy - 6, 30, Math.PI * 1.12, Math.PI * 1.88);
    ctx.stroke();
    // Lower lash hint
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.arc(cx, cy + 8, 30, Math.PI * 0.25, Math.PI * 0.75);
    ctx.stroke();
    // Side wing
    ctx.lineWidth = 7;
    ctx.beginPath();
    ctx.moveTo(cx + (flip ? -30 : 30), cy - 18);
    ctx.lineTo(cx + (flip ? -40 : 40), cy - 26);
    ctx.stroke();
  };

  eye(W * 0.31, H * 0.42, true);
  eye(W * 0.69, H * 0.42, false);

  // Blush
  ctx.fillStyle = "rgba(249,168,212,0.55)";
  ctx.beginPath();
  ctx.ellipse(W * 0.16, H * 0.66, 20, 10, -0.2, 0, Math.PI * 2);
  ctx.fill();
  ctx.beginPath();
  ctx.ellipse(W * 0.84, H * 0.66, 20, 10, 0.2, 0, Math.PI * 2);
  ctx.fill();

  // Mouth — small smile
  ctx.strokeStyle = "#7c2d4e";
  ctx.lineWidth = 5;
  ctx.lineCap = "round";
  ctx.beginPath();
  ctx.arc(W * 0.5, H * 0.72, 14, Math.PI * 0.2, Math.PI * 0.8);
  ctx.stroke();
}

function hexCss(n: number): string {
  return `#${n.toString(16).padStart(6, "0")}`;
}

export interface BuildAnimeOptions {
  displayName?: string;
  statusLabel?: string;
  statusColor?: string;
}

/**
 * Build a complete articulated anime character for the given visual identity.
 * Root faces +Z at heading 0.
 */
export function buildAnimeCharacter(
  THREE: ThreeModule,
  vis: CharacterVisual,
  opts: BuildAnimeOptions = {},
): AnimeRig {
  const pickMeshes: Mesh[] = [];
  const track = <T extends Mesh>(m: T): T => {
    pickMeshes.push(m);
    return m;
  };

  const skinMat = toon(THREE, vis.skin);
  const hairMat = toon(THREE, vis.hair);
  const outfitMat = toon(THREE, vis.primary);
  const accentMat = toon(THREE, vis.accent);
  const darkMat = toon(THREE, 0x23262f);
  const shoeMat = toon(THREE, 0x2b2f3a);

  const root = new THREE.Group();
  const hips = new THREE.Group();
  hips.position.y = 0.74;
  root.add(hips);

  // Hips / shorts
  const shorts = track(
    mesh(THREE, new THREE.BoxGeometry(0.34, 0.2, 0.26), darkMat, 0, -0.02, 0, true),
  );
  hips.add(shorts);

  // Torso
  const torso = track(
    mesh(THREE, new THREE.CapsuleGeometry(0.19, 0.26, 6, 12), outfitMat, 0, 0.28, 0, true),
  );
  hips.add(torso);
  const collar = mesh(THREE, new THREE.BoxGeometry(0.3, 0.09, 0.28), accentMat, 0, 0.5, 0);
  hips.add(collar);

  // Arms — shoulder pivot, elbow pivot, hand
  const buildArm = (side: -1 | 1) => {
    const shoulder = new THREE.Group();
    shoulder.position.set(0.25 * side, 0.44, 0);
    hips.add(shoulder);
    const upper = track(
      mesh(THREE, new THREE.CapsuleGeometry(0.055, 0.2, 4, 8), outfitMat, 0, -0.15, 0, true),
    );
    shoulder.add(upper);
    const elbow = new THREE.Group();
    elbow.position.set(0, -0.3, 0);
    shoulder.add(elbow);
    const fore = track(
      mesh(THREE, new THREE.CapsuleGeometry(0.05, 0.18, 4, 8), skinMat, 0, -0.13, 0),
    );
    elbow.add(fore);
    const hand = track(mesh(THREE, new THREE.SphereGeometry(0.065, 10, 10), skinMat, 0, -0.28, 0));
    elbow.add(hand);
    return { shoulder, elbow };
  };
  const armL = buildArm(-1);
  const armR = buildArm(1);

  // Legs — hip pivot, knee pivot, shoe
  const buildLeg = (side: -1 | 1) => {
    const thigh = new THREE.Group();
    thigh.position.set(0.11 * side, -0.08, 0);
    hips.add(thigh);
    const thighMesh = track(
      mesh(THREE, new THREE.CapsuleGeometry(0.075, 0.19, 4, 8), darkMat, 0, -0.17, 0, true),
    );
    thigh.add(thighMesh);
    const knee = new THREE.Group();
    knee.position.set(0, -0.34, 0);
    thigh.add(knee);
    const shin = track(
      mesh(THREE, new THREE.CapsuleGeometry(0.06, 0.18, 4, 8), skinMat, 0, -0.16, 0),
    );
    knee.add(shin);
    const shoe = track(
      mesh(THREE, new THREE.BoxGeometry(0.13, 0.09, 0.24), shoeMat, 0, -0.335, 0.045),
    );
    knee.add(shoe);
    return { thigh, knee };
  };
  const legL = buildLeg(-1);
  const legR = buildLeg(1);

  // Head — big anime head on a neck pivot
  const headGroup = new THREE.Group();
  headGroup.position.set(0, 0.36, 0);
  hips.add(headGroup);
  const head = track(
    mesh(THREE, new THREE.SphereGeometry(0.24, 20, 16), skinMat, 0, 0.2, 0, true),
  );
  headGroup.add(head);

  // Face — canvas-painted anime eyes on a curved patch hugging the head
  let face: Mesh | null = null;
  const fallbackEyes: Mesh[] = [];
  if (typeof document !== "undefined") {
    const canvas = document.createElement("canvas");
    canvas.width = 256;
    canvas.height = 256;
    paintFace(canvas, hexCss(vis.eyes));
    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = 4;
    const patch = new THREE.SphereGeometry(
      0.246,
      24,
      16,
      Math.PI / 2 - 0.62, // phiStart — centered on +Z
      1.24, // phiLength
      Math.PI / 2 - 0.4, // thetaStart
      0.8, // thetaLength
    );
    face = new THREE.Mesh(
      patch,
      new THREE.MeshBasicMaterial({ map: tex, transparent: true }),
    );
    face.position.set(0, 0.2, 0);
    face.raycast = () => {};
    headGroup.add(face);
  } else {
    // Node/test fallback — simple geometric eyes
    const eyeMat = toon(THREE, 0x1e293b);
    for (const sx of [-0.085, 0.085]) {
      const e = track(
        mesh(THREE, new THREE.SphereGeometry(0.032, 8, 8), eyeMat, sx, 0.22, 0.215),
      );
      headGroup.add(e);
      fallbackEyes.push(e);
    }
  }

  // Hair — shared back mass + per-style extras
  const hairGroup = new THREE.Group();
  hairGroup.position.set(0, 0.2, 0);
  headGroup.add(hairGroup);
  const hairMass = mesh(
    THREE,
    new THREE.SphereGeometry(0.255, 16, 12),
    hairMat,
    0,
    0.03,
    -0.045,
    true,
  );
  hairMass.scale.set(1.02, 1.06, 1.02);
  hairGroup.add(hairMass);

  const hairStyle = vis.hairStyle;
  if (hairStyle === "side") {
    // Claude — sweeping fringe + long side lock
    for (const [fx, tilt] of [[-0.12, 0.25], [0, 0], [0.12, -0.25]] as const) {
      const wedge = mesh(THREE, new THREE.ConeGeometry(0.085, 0.22, 4), hairMat, fx, 0.17, 0.2);
      wedge.rotation.x = Math.PI;
      wedge.rotation.z = tilt;
      hairGroup.add(wedge);
    }
    const lock = mesh(THREE, new THREE.BoxGeometry(0.1, 0.32, 0.13), hairMat, -0.25, -0.05, 0.05);
    lock.rotation.z = 0.12;
    hairGroup.add(lock);
    // Headband accessory
    const band = new THREE.Mesh(
      new THREE.TorusGeometry(0.245, 0.028, 8, 24, Math.PI * 1.15),
      accentMat,
    );
    band.position.set(0, 0.13, 0.01);
    band.rotation.x = Math.PI / 2 - 0.25;
    band.rotation.z = Math.PI * 0.925;
    band.castShadow = true;
    hairGroup.add(band);
  } else if (hairStyle === "twin") {
    // Gemini — twintails with ribbon ties + fringe
    for (const [fx, tilt] of [[-0.11, 0.2], [0, 0], [0.11, -0.2]] as const) {
      const wedge = mesh(THREE, new THREE.ConeGeometry(0.08, 0.2, 4), hairMat, fx, 0.17, 0.2);
      wedge.rotation.x = Math.PI;
      wedge.rotation.z = tilt;
      hairGroup.add(wedge);
    }
    for (const side of [-1, 1] as const) {
      const tail = mesh(
        THREE,
        new THREE.CylinderGeometry(0.045, 0.1, 0.44, 8),
        hairMat,
        0.31 * side,
        -0.08,
        -0.06,
        true,
      );
      tail.rotation.z = -0.55 * side;
      tail.rotation.x = 0.15;
      hairGroup.add(tail);
      const tie = new THREE.Mesh(new THREE.TorusGeometry(0.055, 0.022, 8, 14), accentMat);
      tie.position.set(0.235 * side, 0.1, -0.02);
      tie.rotation.y = Math.PI / 2;
      tie.castShadow = true;
      hairGroup.add(tie);
    }
  } else if (hairStyle === "spiky") {
    // Grok — spiky crown
    const spikes: Array<[number, number, number, number, number]> = [
      [0, 0.32, 0.02, 0, 0],
      [-0.14, 0.28, 0.05, 0, 0.5],
      [0.14, 0.28, 0.05, 0, -0.5],
      [-0.2, 0.18, -0.05, 0.3, 0.9],
      [0.2, 0.18, -0.05, -0.3, -0.9],
      [-0.08, 0.24, -0.18, -0.5, 0.2],
      [0.08, 0.24, -0.18, 0.5, -0.2],
    ];
    for (const [sx, sy, sz, rx, rz] of spikes) {
      const spike = mesh(THREE, new THREE.ConeGeometry(0.07, 0.22, 5), hairMat, sx, sy, sz);
      spike.rotation.x = rx;
      spike.rotation.z = rz;
      hairGroup.add(spike);
    }
    // Glasses accessory
    const glassMat = toon(THREE, 0x111827);
    for (const side of [-1, 1] as const) {
      const rim = new THREE.Mesh(new THREE.TorusGeometry(0.075, 0.013, 8, 20), glassMat);
      rim.position.set(0.095 * side, 0.03, 0.225);
      hairGroup.add(rim);
    }
    const bridge = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.014, 0.014), glassMat);
    bridge.position.set(0, 0.045, 0.228);
    hairGroup.add(bridge);
  } else {
    // GPT — neat cap + fringe + ahoge
    const cap = mesh(THREE, new THREE.SphereGeometry(0.25, 16, 12), hairMat, 0, 0.1, -0.01, true);
    cap.scale.set(1.03, 0.62, 1.03);
    hairGroup.add(cap);
    const fringe = mesh(THREE, new THREE.BoxGeometry(0.34, 0.07, 0.1), hairMat, 0, 0.08, 0.2);
    hairGroup.add(fringe);
    const ahoge = new THREE.Mesh(
      new THREE.TorusGeometry(0.055, 0.013, 8, 12, Math.PI * 1.25),
      hairMat,
    );
    ahoge.position.set(0.03, 0.3, 0);
    ahoge.rotation.z = Math.PI * 0.15;
    ahoge.castShadow = true;
    hairGroup.add(ahoge);
  }

  // Name / status beacon — canvas sprite floating above the head
  let beaconCanvas: HTMLCanvasElement | null = null;
  let beaconTexture: InstanceType<ThreeModule["CanvasTexture"]> | null = null;
  if (typeof document !== "undefined") {
    beaconCanvas = document.createElement("canvas");
    beaconCanvas.width = 256;
    beaconCanvas.height = 80;
    beaconTexture = new THREE.CanvasTexture(beaconCanvas);
    beaconTexture.colorSpace = THREE.SRGBColorSpace;
  }
  const beacon = new THREE.Sprite(
    new THREE.SpriteMaterial({
      map: beaconTexture ?? undefined,
      transparent: true,
      depthWrite: false,
    }),
  );
  beacon.scale.set(1.15, 0.36, 1);
  beacon.position.set(0, 0.78, 0);
  beacon.raycast = () => {};
  headGroup.add(beacon);

  const rig: AnimeRig = {
    root,
    hips,
    torso,
    headGroup,
    head,
    hairGroup,
    face,
    fallbackEyes,
    shoulderL: armL.shoulder,
    shoulderR: armR.shoulder,
    elbowL: armL.elbow,
    elbowR: armR.elbow,
    thighL: legL.thigh,
    thighR: legR.thigh,
    kneeL: legL.knee,
    kneeR: legR.knee,
    beacon,
    beaconCanvas,
    beaconTexture,
    beaconStatus: "",
    displayName: opts.displayName ?? vis.id,
    pickMeshes,
    blinkTimer: 1.5 + Math.random() * 2,
    blinkPhase: 0,
    seed: Math.random() * 10,
  };
  paintBeacon(THREE, rig, opts.statusLabel ?? "", opts.statusColor ?? "#64748b");
  resetPose(rig);
  return rig;
}

/** Redraw the floating name/status tag. */
export function paintBeacon(
  THREE: ThreeModule,
  rig: AnimeRig,
  statusLabel: string,
  statusColor: string,
): void {
  rig.beaconStatus = `${statusLabel}|${statusColor}`;
  const canvas = rig.beaconCanvas;
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  const W = canvas.width;
  const H = canvas.height;
  ctx.clearRect(0, 0, W, H);
  // Pill background
  ctx.fillStyle = "rgba(8,12,22,0.72)";
  ctx.beginPath();
  ctx.roundRect(2, 6, W - 4, H - 12, 18);
  ctx.fill();
  ctx.strokeStyle = "rgba(148,163,184,0.35)";
  ctx.lineWidth = 2;
  ctx.stroke();
  // Status dot
  ctx.fillStyle = statusColor;
  ctx.beginPath();
  ctx.arc(30, H / 2, 11, 0, Math.PI * 2);
  ctx.fill();
  // Name
  ctx.fillStyle = "#f1f5f9";
  ctx.font = "600 30px system-ui, sans-serif";
  ctx.textBaseline = "middle";
  const label = rig.displayName.slice(0, 14);
  ctx.fillText(label, 50, H / 2 + 1);
  // Status text
  if (statusLabel) {
    ctx.fillStyle = "#94a3b8";
    ctx.font = "500 22px system-ui, sans-serif";
    ctx.fillText(statusLabel.slice(0, 12), 50, H / 2 + 26 > H - 14 ? H - 16 : H / 2 + 26);
  }
  if (rig.beaconTexture) rig.beaconTexture.needsUpdate = true;
}

/** Zero every animated joint — base for all pose functions. */
export function resetPose(rig: AnimeRig): void {
  rig.hips.position.set(0, 0.74, 0);
  rig.hips.rotation.set(0, 0, 0);
  rig.headGroup.rotation.set(0, 0, 0);
  rig.headGroup.position.set(0, 0.36, 0);
  for (const j of [
    rig.shoulderL,
    rig.shoulderR,
    rig.elbowL,
    rig.elbowR,
    rig.thighL,
    rig.thighR,
    rig.kneeL,
    rig.kneeR,
  ]) {
    j.rotation.set(0, 0, 0);
  }
  // Natural slight arm angle
  rig.shoulderL.rotation.z = 0.12;
  rig.shoulderR.rotation.z = -0.12;
  rig.elbowL.rotation.x = -0.12;
  rig.elbowR.rotation.x = -0.12;
}

/** Idle: breathing bob, gentle sway. t = seconds. */
export function applyIdlePose(rig: AnimeRig, t: number): void {
  resetPose(rig);
  const s = rig.seed;
  rig.hips.position.y = 0.74 + Math.sin(t * 1.7 + s) * 0.012;
  rig.headGroup.rotation.z = Math.sin(t * 0.9 + s) * 0.045;
  rig.headGroup.rotation.y = Math.sin(t * 0.5 + s * 2) * 0.08;
  rig.shoulderL.rotation.x = Math.sin(t * 1.7 + s) * 0.03;
  rig.shoulderR.rotation.x = -Math.sin(t * 1.7 + s) * 0.03;
  rig.torso.scale.y = 1 + Math.sin(t * 1.7 + s) * 0.008;
}

/**
 * Walk cycle. p = accumulated walk phase (radians) — advance by ~7 rad/s
 * while moving for a natural stride.
 */
export function applyWalkPose(rig: AnimeRig, p: number): void {
  resetPose(rig);
  const swing = Math.sin(p);
  const swingR = Math.sin(p + Math.PI);
  rig.thighL.rotation.x = swing * 0.62;
  rig.thighR.rotation.x = swingR * 0.62;
  // Knees bend most while the leg swings forward
  rig.kneeL.rotation.x = 0.12 + Math.max(0, Math.sin(p + 2.1)) * 0.85;
  rig.kneeR.rotation.x = 0.12 + Math.max(0, Math.sin(p + Math.PI + 2.1)) * 0.85;
  // Arms counter-swing
  rig.shoulderL.rotation.x = swingR * 0.48;
  rig.shoulderR.rotation.x = swing * 0.48;
  rig.elbowL.rotation.x = -0.35 - Math.max(0, swingR) * 0.25;
  rig.elbowR.rotation.x = -0.35 - Math.max(0, swing) * 0.25;
  // Body bob + lean
  rig.hips.position.y = 0.74 + Math.abs(Math.cos(p)) * 0.028;
  rig.hips.rotation.x = 0.07;
  rig.hips.rotation.z = Math.sin(p) * 0.03;
  rig.headGroup.rotation.x = -0.04;
}

/** Sitting in the desk chair. typing=true adds the typing wiggle. */
export function applySitPose(rig: AnimeRig, t: number, typing: boolean): void {
  resetPose(rig);
  rig.hips.position.y = 0.5;
  rig.thighL.rotation.x = -1.45;
  rig.thighR.rotation.x = -1.45;
  rig.kneeL.rotation.x = 1.42;
  rig.kneeR.rotation.x = 1.42;
  rig.hips.rotation.x = 0.1;
  if (typing) {
    rig.shoulderL.rotation.x = -0.75 + Math.sin(t * 9) * 0.07;
    rig.shoulderR.rotation.x = -0.75 + Math.sin(t * 9 + Math.PI) * 0.07;
    rig.elbowL.rotation.x = -0.5;
    rig.elbowR.rotation.x = -0.5;
    rig.headGroup.rotation.x = 0.12;
  } else {
    rig.shoulderL.rotation.x = -0.35;
    rig.shoulderR.rotation.x = -0.35;
    rig.elbowL.rotation.x = -0.7;
    rig.elbowR.rotation.x = -0.7;
    rig.headGroup.rotation.x = 0.05;
  }
}

/** Thinking: seated + head tilt, one hand near chin. */
export function applyThinkPose(rig: AnimeRig, t: number): void {
  applySitPose(rig, t, false);
  rig.headGroup.rotation.z = 0.14;
  rig.headGroup.rotation.y = Math.sin(t * 0.8) * 0.1;
  rig.shoulderR.rotation.x = -0.55;
  rig.elbowR.rotation.x = -1.7;
}

/**
 * Anime blink — scale the face patch vertically for ~0.12s every few seconds.
 * Call every frame with frame dt.
 */
export function applyBlink(rig: AnimeRig, dt: number): void {
  if (!rig.face) return;
  rig.blinkTimer -= dt;
  if (rig.blinkTimer <= 0) {
    rig.blinkPhase = 0.12;
    rig.blinkTimer = 2.2 + ((rig.seed * 7) % 2.4);
  }
  if (rig.blinkPhase > 0) {
    rig.blinkPhase -= dt;
    rig.face.scale.y = 0.12;
  } else {
    rig.face.scale.y = 1;
  }
}
