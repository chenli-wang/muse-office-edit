/**
 * V1.2.1 — Procedural wander / movement AI for anime office characters.
 * Pure TypeScript: no three.js, no DOM. Safe to unit-test in Node.
 *
 * Each employee owns a WanderAgent. Employees that need to work
 * (working / thinking / queued / waiting) walk back to their desk and sit.
 * Otherwise they roam between open-floor waypoints, stand a while, then move on.
 * Obstacles (desks, meeting table) are avoided with a simple push-out so
 * characters never walk through furniture.
 */

export type Vec2 = readonly [number, number];

export interface Aabb {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
}

/** Open-floor waypoints — hand-placed in corridors clear of desks/tables. */
export const ROAM_WAYPOINTS: Vec2[] = [
  [-5.5, 1.2],
  [0, 4.6],
  [5.5, 1.2],
  [5.5, -3.6],
  [0, -4.4],
  [-5.5, -3.6],
];

/** Character collision radius used when pushing out of obstacles. */
export const AGENT_RADIUS = 0.28;
/** Walk speed in world units per second. */
export const WALK_SPEED = 1.35;
/** Max turn rate (rad/s) — characters turn smoothly instead of snapping. */
export const TURN_RATE = 5.5;
/** Arrival distance to a target. */
export const ARRIVE_DIST = 0.12;

export type WanderMode = "seated" | "toSeat" | "toWaypoint" | "atWaypoint";

export interface WanderAgent {
  mode: WanderMode;
  x: number;
  z: number;
  /** Facing direction, radians. 0 = +Z (three.js convention used by the rig). */
  heading: number;
  targetX: number;
  targetZ: number;
  /** Seconds left standing at a waypoint before picking the next one. */
  standTimer: number;
  seatX: number;
  seatZ: number;
  seatHeading: number;
  speed: number;
}

export function createWanderAgent(
  seatX: number,
  seatZ: number,
  seatHeading = Math.PI,
  speed = WALK_SPEED,
): WanderAgent {
  return {
    mode: "seated",
    x: seatX,
    z: seatZ,
    heading: seatHeading,
    targetX: seatX,
    targetZ: seatZ,
    standTimer: 0,
    seatX,
    seatZ,
    seatHeading,
    speed,
  };
}

/** AABB for one desk footprint (top view). */
export function deskAabb(deskX: number, deskZ: number): Aabb {
  return {
    minX: deskX - 0.85,
    maxX: deskX + 0.85,
    minZ: deskZ - 0.55,
    maxZ: deskZ + 0.55,
  };
}

export function meetingTableAabb(tableX: number, tableZ: number): Aabb {
  return {
    minX: tableX - 1.7,
    maxX: tableX + 1.7,
    minZ: tableZ - 0.9,
    maxZ: tableZ + 0.9,
  };
}

/** True when the point (with agent radius) is inside the box. */
export function pointInAabb(x: number, z: number, box: Aabb, pad = 0): boolean {
  return (
    x > box.minX - pad &&
    x < box.maxX + pad &&
    z > box.minZ - pad &&
    z < box.maxZ + pad
  );
}

/**
 * Push a point out of an AABB along the smallest penetration axis.
 * Returns the corrected [x, z].
 */
export function pushOutOfAabb(x: number, z: number, box: Aabb, pad: number): Vec2 {
  if (!pointInAabb(x, z, box, pad)) return [x, z];
  const dxMin = x - (box.minX - pad);
  const dxMax = box.maxX + pad - x;
  const dzMin = z - (box.minZ - pad);
  const dzMax = box.maxZ + pad - z;
  const m = Math.min(dxMin, dxMax, dzMin, dzMax);
  if (m === dxMin) return [box.minX - pad, z];
  if (m === dxMax) return [box.maxX + pad, z];
  if (m === dzMin) return [x, box.minZ - pad];
  return [x, box.maxZ + pad];
}

/** Shortest signed angular difference from `from` to `to` (radians). */
export function angleDelta(from: number, to: number): number {
  let d = (to - from) % (Math.PI * 2);
  if (d > Math.PI) d -= Math.PI * 2;
  if (d < -Math.PI) d += Math.PI * 2;
  return d;
}

export interface WanderOptions {
  /** True when the employee should be at their desk (working/thinking/waiting). */
  wantsSeat: boolean;
  waypoints: ReadonlyArray<Vec2>;
  obstacles: ReadonlyArray<Aabb>;
  /** Injected RNG so tests are deterministic. Defaults to Math.random. */
  rand?: () => number;
}

export interface WanderUpdate {
  /** True while the character is walking (drive the walk cycle). */
  moving: boolean;
  /** True when settled in the desk chair. */
  seated: boolean;
}

function pickWaypoint(
  agent: WanderAgent,
  waypoints: ReadonlyArray<Vec2>,
  rand: () => number,
): void {
  if (waypoints.length === 0) return;
  let idx = Math.floor(rand() * waypoints.length);
  // Avoid immediately re-picking the waypoint we stand on.
  if (waypoints.length > 1) {
    let guard = 0;
    while (
      guard++ < 8 &&
      Math.hypot(waypoints[idx]![0] - agent.targetX, waypoints[idx]![1] - agent.targetZ) < 0.5
    ) {
      idx = Math.floor(rand() * waypoints.length);
    }
  }
  const wp = waypoints[idx]!;
  agent.targetX = wp[0];
  agent.targetZ = wp[1];
}

/** Advance one step toward the current target, avoiding obstacles. */
function stepToward(agent: WanderAgent, dt: number, obstacles: ReadonlyArray<Aabb>): boolean {
  const dx = agent.targetX - agent.x;
  const dz = agent.targetZ - agent.z;
  const dist = Math.hypot(dx, dz);
  if (dist <= ARRIVE_DIST) return true;

  const step = Math.min(agent.speed * dt, dist);
  let nx = agent.x + (dx / dist) * step;
  let nz = agent.z + (dz / dist) * step;
  for (const box of obstacles) {
    const [cx, cz] = pushOutOfAabb(nx, nz, box, AGENT_RADIUS);
    nx = cx;
    nz = cz;
  }
  agent.x = nx;
  agent.z = nz;

  const want = Math.atan2(dx, dz);
  const d = angleDelta(agent.heading, want);
  const maxTurn = TURN_RATE * dt;
  agent.heading += Math.max(-maxTurn, Math.min(maxTurn, d));
  return false;
}

export function updateWander(
  agent: WanderAgent,
  dt: number,
  opts: WanderOptions,
): WanderUpdate {
  const rand = opts.rand ?? Math.random;
  const step = Math.max(0, Math.min(dt, 0.25)); // clamp huge frame gaps

  if (opts.wantsSeat) {
    if (agent.mode !== "seated" && agent.mode !== "toSeat") {
      agent.mode = "toSeat";
      agent.targetX = agent.seatX;
      agent.targetZ = agent.seatZ;
    }
    if (agent.mode === "toSeat") {
      // Walk home; the seat itself sits inside the desk/chair footprint,
      // so ease the last stretch without obstacle push-out to avoid jitter.
      const home = Math.hypot(agent.targetX - agent.x, agent.targetZ - agent.z);
      const arrived =
        home < 0.45
          ? stepToward(agent, step, [])
          : stepToward(agent, step, opts.obstacles);
      if (arrived) {
        agent.mode = "seated";
        agent.x = agent.seatX;
        agent.z = agent.seatZ;
        agent.heading = agent.seatHeading;
      }
      return { moving: true, seated: false };
    }
    return { moving: false, seated: true };
  }

  // Free-roam behaviour.
  if (agent.mode === "seated" || agent.mode === "toSeat") {
    agent.mode = "toWaypoint";
    pickWaypoint(agent, opts.waypoints, rand);
  }
  if (agent.mode === "toWaypoint") {
    const arrived = stepToward(agent, step, opts.obstacles);
    if (arrived) {
      agent.mode = "atWaypoint";
      agent.standTimer = 3 + rand() * 6;
    }
    return { moving: true, seated: false };
  }
  // atWaypoint — stand, look around, then wander on.
  agent.standTimer -= step;
  agent.heading += Math.sin(agent.standTimer * 1.7) * 0.15 * step;
  if (agent.standTimer <= 0) {
    agent.mode = "toWaypoint";
    pickWaypoint(agent, opts.waypoints, rand);
    return { moving: true, seated: false };
  }
  return { moving: false, seated: false };
}
