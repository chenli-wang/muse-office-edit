import assert from "node:assert/strict";
import { describe, it } from "node:test";
import {
  DEFAULT_PERFORMANCE,
  frameIntervalMs,
  qualityProfile,
  suggestQuality,
  FpsMeter,
  AdaptiveRenderController,
  stepDownQuality,
  qualityRank,
  formatQualityVisibility,
  qualityLabel,
  type QualityLevel,
} from "./performance.ts";

describe("performance settings", () => {
  it("default FPS target is 60", () => {
    assert.equal(DEFAULT_PERFORMANCE.fpsCap, 60);
  });

  it("frame interval for 30/60/unlimited", () => {
    assert.equal(frameIntervalMs(30), 1000 / 30);
    assert.equal(frameIntervalMs(60), 1000 / 60);
    assert.equal(frameIntervalMs(0), 0);
  });

  it("quality profiles differ", () => {
    const low = qualityProfile("low");
    const high = qualityProfile("high");
    assert.equal(low.shadows, false);
    assert.equal(high.shadows, true);
    assert.ok(high.shadowMapSize >= low.shadowMapSize);
  });

  it("suggestQuality drops when FPS is low", () => {
    assert.equal(suggestQuality("high", 20, 60), "balanced");
    assert.equal(suggestQuality("balanced", 20, 60), "low");
    assert.equal(suggestQuality("low", 5, 60), "low");
    assert.equal(suggestQuality("high", 55, 60), "high");
  });

  it("FpsMeter averages samples", () => {
    const m = new FpsMeter();
    assert.equal(m.tick(0), 0);
    m.tick(16);
    const fps = m.tick(32);
    assert.ok(fps > 50);
  });
});

describe("adaptive render controller", () => {
  it("stepDownQuality and rank", () => {
    assert.equal(stepDownQuality("high"), "balanced");
    assert.equal(stepDownQuality("balanced"), "low");
    assert.equal(stepDownQuality("low"), "low");
    assert.ok(qualityRank("high") > qualityRank("low"));
  });

  it("does not drop on a single low sample", () => {
    const c = new AdaptiveRenderController("high", {
      needBelow: 5,
      cooldownMs: 1000,
      thresholdRatio: 0.7,
    });
    assert.equal(c.tick(10, 60, 100), "high");
    assert.equal(c.tick(10, 60, 116), "high");
  });

  it("drops after sustained low FPS with cooldown", () => {
    const c = new AdaptiveRenderController("high", {
      needBelow: 3,
      cooldownMs: 1000,
      thresholdRatio: 0.7,
    });
    let q: QualityLevel = "high";
    for (let i = 0; i < 3; i++) {
      q = c.tick(10, 60, 100 + i * 16);
    }
    assert.equal(q, "balanced");
    // Immediate further drop blocked by cooldown
    for (let i = 0; i < 5; i++) {
      q = c.tick(10, 60, 200 + i * 16);
    }
    assert.equal(q, "balanced");
    // After cooldown, can drop again
    q = c.tick(10, 60, 2000);
    q = c.tick(10, 60, 2016);
    q = c.tick(10, 60, 2032);
    assert.equal(q, "low");
  });

  it("setUserQuality resets applied up to user choice", () => {
    const c = new AdaptiveRenderController("high", { needBelow: 2, cooldownMs: 0 });
    c.tick(5, 60, 0);
    c.tick(5, 60, 16);
    assert.equal(c.appliedQuality, "balanced");
    c.setUserQuality("high");
    assert.equal(c.appliedQuality, "high");
    assert.equal(c.userQuality, "high");
  });

  it("never applies above user quality", () => {
    const c = new AdaptiveRenderController("low", { needBelow: 2, cooldownMs: 0 });
    c.tick(5, 60, 0);
    c.tick(5, 60, 16);
    assert.equal(c.appliedQuality, "low");
  });
  it("formatQualityVisibility marks adaptive only when applied is below selected", () => {
    assert.equal(
      formatQualityVisibility("high", "high"),
      "Selected: High · Active: High",
    );
    assert.equal(
      formatQualityVisibility("high", "balanced"),
      "Selected: High · Active: Balanced (adaptive)",
    );
    assert.equal(
      formatQualityVisibility("high", "low"),
      "Selected: High · Active: Low (adaptive)",
    );
    assert.equal(
      formatQualityVisibility("balanced", "balanced"),
      "Selected: Balanced · Active: Balanced",
    );
    assert.equal(qualityLabel("low"), "Low");
  });

});
