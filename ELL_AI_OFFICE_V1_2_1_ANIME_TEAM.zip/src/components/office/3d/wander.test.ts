import assert from "node:assert/strict";
import { describe, it } from "node:test";
import {
  createWanderAgent,
  updateWander,
  deskAabb,
  meetingTableAabb,
  pointInAabb,
  pushOutOfAabb,
  angleDelta,
  ROAM_WAYPOINTS,
  WALK_SPEED,
  AGENT_RADIUS,
  type Aabb,
} from "./wander.ts";

const DESKS: Array<readonly [number, number]> = [
  [-3.2, -1.5],
  [-1, -1.5],
  [1.2, -1.5],
  [3.4, -1.5],
];
const OBSTACLES: Aabb[] = [
  ...DESKS.map(([x, z]) => deskAabb(x, z)),
  meetingTableAabb(0, 2.2),
];

const randZero = () => 0;

function stepSim(
  agent: ReturnType<typeof createWanderAgent>,
  seconds: number,
  wantsSeat: boolean,
  dt = 0.05,
): { maxStep: number; everInside: boolean; everMoving: boolean } {
  let maxStep = 0;
  let everInside = false;
  let everMoving = false;
  const n = Math.ceil(seconds / dt);
  for (let k = 0; k < n; k++) {
    const px = agent.x;
    const pz = agent.z;
    const upd = updateWander(
      agent,
      dt,
      { wantsSeat, waypoints: ROAM_WAYPOINTS, obstacles: OBSTACLES, rand: randZero },
    );
    if (upd.moving) everMoving = true;
    maxStep = Math.max(maxStep, Math.hypot(agent.x - px, agent.z - pz));
    if (agent.mode !== "seated") {
      for (const box of OBSTACLES) {
        if (pointInAabb(agent.x, agent.z, box, AGENT_RADIUS * 0.5)) {
          everInside = true;
        }
      }
    }
  }
  return { maxStep, everInside, everMoving };
}

describe("wander movement AI", () => {
  it("starts seated at the desk", () => {
    const a = createWanderAgent(-3.2, -0.95, Math.PI);
    assert.equal(a.mode, "seated");
    assert.equal(a.x, -3.2);
    assert.equal(a.z, -0.95);
    assert.equal(a.heading, Math.PI);
  });

  it("idle agents leave the desk and roam without entering furniture", () => {
    const a = createWanderAgent(-3.2, -0.95, Math.PI);
    const { maxStep, everInside, everMoving } = stepSim(a, 40, false);
    assert.equal(everMoving, true);
    assert.equal(everInside, false);
    // Roamed away from the seat
    assert.ok(Math.hypot(a.x - -3.2, a.z - -0.95) > 1.5);
    // Speed cap respected (plus small tolerance for obstacle ejection)
    assert.ok(maxStep <= WALK_SPEED * 0.05 + 0.35, `maxStep=${maxStep}`);
  });

  it("agents return to their seat and face the desk when asked", () => {
    const a = createWanderAgent(-3.2, -0.95, Math.PI);
    stepSim(a, 20, false); // roam first
    assert.notEqual(a.mode, "seated");
    stepSim(a, 60, true); // then work calls them back
    assert.equal(a.mode, "seated");
    assert.ok(Math.abs(a.x - -3.2) < 1e-9);
    assert.ok(Math.abs(a.z - -0.95) < 1e-9);
    assert.ok(Math.abs(a.heading - Math.PI) < 1e-9);
  });

  it("seated agents stay put while wantsSeat", () => {
    const a = createWanderAgent(1.2, -0.95, Math.PI);
    const upd = updateWander(
      a,
      1,
      { wantsSeat: true, waypoints: ROAM_WAYPOINTS, obstacles: OBSTACLES, rand: randZero },
    );
    assert.equal(upd.seated, true);
    assert.equal(upd.moving, false);
    assert.equal(a.x, 1.2);
  });

  it("heading turns smoothly toward travel direction", () => {
    const a = createWanderAgent(0, -0.95, Math.PI);
    // Force a waypoint straight ahead (+Z)
    const upd = updateWander(
      a,
      0.1,
      { wantsSeat: false, waypoints: [[0, 4.6]], obstacles: [], rand: randZero },
    );
    assert.equal(upd.moving, true);
    // Heading rotated from PI toward 0 but clamped by TURN_RATE * dt
    assert.ok(a.heading < Math.PI && a.heading > Math.PI - 0.6);
  });

  it("angleDelta takes the shortest path", () => {
    assert.ok(Math.abs(angleDelta(0, Math.PI * 1.5) - -Math.PI / 2) < 1e-9);
    assert.ok(Math.abs(angleDelta(Math.PI, -Math.PI + 0.1) - 0.1) < 1e-9);
  });

  it("pushOutOfAabb ejects along the smallest penetration axis", () => {
    const box = deskAabb(-3.2, -1.5);
    const [cx, cz] = pushOutOfAabb(-3.2, -0.95, box, AGENT_RADIUS);
    assert.ok(!pointInAabb(cx, cz, box, AGENT_RADIUS));
    // Untouched points pass through unchanged
    const [ux, uz] = pushOutOfAabb(5, 5, box, AGENT_RADIUS);
    assert.equal(ux, 5);
    assert.equal(uz, 5);
  });

  it("waypoints are clear of desk and table footprints", () => {
    for (const [wx, wz] of ROAM_WAYPOINTS) {
      for (const box of OBSTACLES) {
        assert.ok(
          !pointInAabb(wx, wz, box, AGENT_RADIUS),
          `waypoint (${wx},${wz}) inside obstacle`,
        );
      }
    }
  });
});
