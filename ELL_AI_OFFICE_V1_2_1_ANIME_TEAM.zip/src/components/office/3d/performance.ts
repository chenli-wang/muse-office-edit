/**
 * V1.1 performance / FPS target system (presentation only).
 * Cap is a TARGET, not a guarantee.
 */

export type FpsCap = 30 | 60 | 0; // 0 = unlimited
export type QualityLevel = "low" | "balanced" | "high";

export interface PerformanceSettings {
  fpsCap: FpsCap;
  quality: QualityLevel;
  showFps: boolean;
  reducedMotion: boolean;
}

export const DEFAULT_PERFORMANCE: PerformanceSettings = {
  fpsCap: 60,
  quality: "balanced",
  showFps: false,
  reducedMotion: false,
};

export function preferDefaultQuality(): QualityLevel {
  if (typeof window === "undefined") return "balanced";
  try {
    const cores = navigator.hardwareConcurrency ?? 4;
    const mem = (navigator as { deviceMemory?: number }).deviceMemory;
    if (cores <= 2 || (mem != null && mem <= 2)) return "low";
    if (window.innerWidth < 480) return "low";
    return "balanced";
  } catch {
    return "balanced";
  }
}

export function loadPerformanceSettings(): PerformanceSettings {
  const base = { ...DEFAULT_PERFORMANCE, quality: preferDefaultQuality() };
  if (typeof window === "undefined") return base;
  try {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      base.reducedMotion = true;
      base.fpsCap = 30;
      base.quality = "low";
    }
    const raw = localStorage.getItem("ell.office.perf");
    if (!raw) return base;
    const parsed = JSON.parse(raw) as Partial<PerformanceSettings>;
    return {
      fpsCap: parsed.fpsCap === 30 || parsed.fpsCap === 60 || parsed.fpsCap === 0
        ? parsed.fpsCap
        : base.fpsCap,
      quality:
        parsed.quality === "low" || parsed.quality === "balanced" || parsed.quality === "high"
          ? parsed.quality
          : base.quality,
      showFps: Boolean(parsed.showFps),
      reducedMotion: Boolean(parsed.reducedMotion ?? base.reducedMotion),
    };
  } catch {
    return base;
  }
}

export function savePerformanceSettings(s: PerformanceSettings): void {
  try {
    localStorage.setItem("ell.office.perf", JSON.stringify(s));
  } catch {
    /* ignore */
  }
}

/** Minimum ms between frames for a given cap (0 = no throttle). */
export function frameIntervalMs(cap: FpsCap): number {
  if (cap === 0) return 0;
  return 1000 / cap;
}

export interface QualityProfile {
  pixelRatio: number;
  shadows: boolean;
  shadowMapSize: number;
  antialias: boolean;
  deskDetail: "minimal" | "normal";
}

export function qualityProfile(level: QualityLevel): QualityProfile {
  switch (level) {
    case "low":
      return {
        pixelRatio: 1,
        shadows: false,
        shadowMapSize: 256,
        antialias: false,
        deskDetail: "minimal",
      };
    case "high":
      return {
        pixelRatio: typeof window !== "undefined" ? Math.min(window.devicePixelRatio || 1, 2) : 1.5,
        shadows: true,
        shadowMapSize: 1024,
        antialias: true,
        deskDetail: "normal",
      };
    default:
      return {
        pixelRatio: typeof window !== "undefined" ? Math.min(window.devicePixelRatio || 1, 1.5) : 1,
        shadows: true,
        shadowMapSize: 512,
        antialias: true,
        deskDetail: "normal",
      };
  }
}

/**
 * One-shot suggestion (legacy / tests): if FPS is below target * threshold, step down one level.
 * Prefer AdaptiveRenderController for runtime (hysteresis + cooldown).
 */
export function suggestQuality(
  current: QualityLevel,
  measuredFps: number,
  targetCap: FpsCap,
  thresholdRatio = 0.7,
): QualityLevel {
  const target = targetCap === 0 ? 60 : targetCap;
  if (measuredFps > 0 && measuredFps < target * thresholdRatio) {
    if (current === "high") return "balanced";
    if (current === "balanced") return "low";
  }
  return current;
}

export function qualityRank(level: QualityLevel): number {
  if (level === "low") return 0;
  if (level === "balanced") return 1;
  return 2;
}


/** Human-readable quality name for UI. */
export function qualityLabel(level: QualityLevel): string {
  if (level === "low") return "Low";
  if (level === "balanced") return "Balanced";
  return "High";
}

/**
 * Visible Selected vs Active quality line.
 * Only marks "(adaptive)" when applied is strictly below the user selection.
 */
export function formatQualityVisibility(
  selected: QualityLevel,
  applied: QualityLevel,
): string {
  const sel = qualityLabel(selected);
  const act = qualityLabel(applied);
  if (selected === applied) {
    return `Selected: ${sel} · Active: ${act}`;
  }
  if (qualityRank(applied) < qualityRank(selected)) {
    return `Selected: ${sel} · Active: ${act} (adaptive)`;
  }
  // Applied should never exceed selected; still show facts without claiming adaptive.
  return `Selected: ${sel} · Active: ${act}`;
}

export function stepDownQuality(level: QualityLevel): QualityLevel {
  if (level === "high") return "balanced";
  if (level === "balanced") return "low";
  return "low";
}

/**
 * Runtime adaptive render quality: only lowers applied quality under sustained low FPS,
 * with cooldown to avoid oscillation. Never raises above the user's selected quality.
 * Does not mutate user settings — caller applies profiles to the renderer only.
 */
export class AdaptiveRenderController {
  /** Quality the user chose (ceiling). */
  userQuality: QualityLevel;
  /** Quality currently applied to the renderer. */
  appliedQuality: QualityLevel;
  private belowStreak = 0;
  private cooldownUntilMs = 0;
  private readonly needBelow: number;
  private readonly cooldownMs: number;
  private readonly thresholdRatio: number;

  constructor(
    userQuality: QualityLevel,
    options?: { needBelow?: number; cooldownMs?: number; thresholdRatio?: number },
  ) {
    this.userQuality = userQuality;
    this.appliedQuality = userQuality;
    this.needBelow = options?.needBelow ?? 45; // ~0.75s at 60fps samples
    this.cooldownMs = options?.cooldownMs ?? 4000;
    this.thresholdRatio = options?.thresholdRatio ?? 0.65;
  }

  /** Call when the user changes the Quality control. */
  setUserQuality(level: QualityLevel): void {
    this.userQuality = level;
    // Manual setting is authoritative — reset applied up to user choice.
    this.appliedQuality = level;
    this.belowStreak = 0;
    this.cooldownUntilMs = 0;
  }

  /**
   * Feed measured FPS. Returns the quality that should be applied after this sample.
   */
  tick(measuredFps: number, targetCap: FpsCap, nowMs: number): QualityLevel {
    // If user raised quality, applied already matches via setUserQuality.
    if (qualityRank(this.appliedQuality) > qualityRank(this.userQuality)) {
      this.appliedQuality = this.userQuality;
    }

    const target = targetCap === 0 ? 60 : targetCap;
    if (measuredFps <= 0) return this.appliedQuality;

    const floor = target * this.thresholdRatio;
    if (measuredFps < floor) {
      this.belowStreak += 1;
    } else {
      this.belowStreak = 0;
    }

    if (
      this.belowStreak >= this.needBelow &&
      nowMs >= this.cooldownUntilMs &&
      this.appliedQuality !== "low"
    ) {
      this.appliedQuality = stepDownQuality(this.appliedQuality);
      this.belowStreak = 0;
      this.cooldownUntilMs = nowMs + this.cooldownMs;
    }

    return this.appliedQuality;
  }
}

/** Simple FPS meter using delta samples. */
export class FpsMeter {
  private samples: number[] = [];
  private last = 0;

  tick(nowMs: number): number {
    if (this.last > 0) {
      const dt = nowMs - this.last;
      if (dt > 0 && dt < 1000) {
        this.samples.push(1000 / dt);
        if (this.samples.length > 30) this.samples.shift();
      }
    }
    this.last = nowMs;
    if (this.samples.length === 0) return 0;
    return this.samples.reduce((a, b) => a + b, 0) / this.samples.length;
  }

  reset(): void {
    this.samples = [];
    this.last = 0;
  }
}
