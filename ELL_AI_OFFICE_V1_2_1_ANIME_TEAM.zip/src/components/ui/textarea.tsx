import * as React from "react";
import { cn } from "@/lib/utils.ts";

const Textarea = React.forwardRef<HTMLTextAreaElement, React.TextareaHTMLAttributes<HTMLTextAreaElement>>(
  ({ className, ...props }, ref) => (
    <textarea
      ref={ref}
      className={cn(
        "flex min-h-28 w-full rounded-[var(--radius-md)] border border-border bg-bg px-3.5 py-3 text-sm text-fg shadow-[var(--shadow-border)] placeholder:text-subtle outline-none transition-[border-color,box-shadow] duration-[var(--motion-quick)] ease-[var(--ease-out)] focus-visible:border-accent/50 focus-visible:ring-2 focus-visible:ring-ring/40 disabled:cursor-not-allowed disabled:opacity-50",
        className,
      )}
      {...props}
    />
  ),
);
Textarea.displayName = "Textarea";

export { Textarea };
