import { createFileRoute } from "@tanstack/react-router";
import { handleProviderRegistry, jsonResult } from "@/office/http.ts";

export const Route = createFileRoute("/api/providers-registry")({
  server: {
    handlers: {
      GET: async () => jsonResult(await handleProviderRegistry()),
    },
  },
});
