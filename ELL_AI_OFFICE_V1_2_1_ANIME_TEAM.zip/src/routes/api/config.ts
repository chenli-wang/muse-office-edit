import { createFileRoute } from "@tanstack/react-router";
import { handlePublicConfig, jsonResult } from "@/office/http.ts";

export const Route = createFileRoute("/api/config")({
  server: {
    handlers: {
      GET: async () => jsonResult(await handlePublicConfig()),
    },
  },
});
