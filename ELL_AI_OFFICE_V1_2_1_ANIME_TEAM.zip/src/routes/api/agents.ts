import { createFileRoute } from "@tanstack/react-router";
import { handleListAgents, jsonResult } from "@/office/http.ts";

export const Route = createFileRoute("/api/agents")({
  server: {
    handlers: {
      GET: async () => jsonResult(await handleListAgents()),
    },
  },
});
