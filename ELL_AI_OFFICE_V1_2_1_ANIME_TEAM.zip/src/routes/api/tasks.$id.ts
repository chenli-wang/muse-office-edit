import { createFileRoute } from "@tanstack/react-router";
import { handleGetTask, jsonResult } from "@/office/http.ts";

export const Route = createFileRoute("/api/tasks/$id")({
  server: {
    handlers: {
      GET: async ({ params }) => jsonResult(await handleGetTask(params.id)),
    },
  },
});
