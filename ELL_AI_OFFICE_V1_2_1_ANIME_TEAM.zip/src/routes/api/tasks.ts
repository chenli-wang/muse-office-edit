import { createFileRoute } from "@tanstack/react-router";
import { handleCreateTask, handleListTasks, jsonResult } from "@/office/http.ts";

export const Route = createFileRoute("/api/tasks")({
  server: {
    handlers: {
      GET: async () => jsonResult(await handleListTasks()),
      POST: async ({ request }) => {
        let body: unknown = {};
        try {
          body = await request.json();
        } catch {
          body = {};
        }
        return jsonResult(await handleCreateTask(body));
      },
    },
  },
});
