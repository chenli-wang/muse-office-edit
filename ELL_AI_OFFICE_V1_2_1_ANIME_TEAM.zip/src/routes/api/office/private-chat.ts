import { createFileRoute } from "@tanstack/react-router";
import { handlePrivateChat, jsonResult } from "@/office/http.ts";

export const Route = createFileRoute("/api/office/private-chat")({
  server: {
    handlers: {
      POST: async ({ request }) => jsonResult(await handlePrivateChat(request)),
    },
  },
});
