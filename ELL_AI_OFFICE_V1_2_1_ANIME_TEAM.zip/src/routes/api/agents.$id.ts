import { createFileRoute } from "@tanstack/react-router";
import { handleGetAgent, jsonResult } from "@/office/http.ts";

export const Route = createFileRoute("/api/agents/$id")({
  server: {
    handlers: {
      GET: async ({ params }) => jsonResult(await handleGetAgent(params.id)),
    },
  },
});
