import { createFileRoute } from "@tanstack/react-router";
import { handleDashboardSnapshot, jsonResult } from "@/office/http.ts";

export const Route = createFileRoute("/api/dashboard")({
  server: {
    handlers: {
      GET: async () => jsonResult(await handleDashboardSnapshot()),
    },
  },
});
