import { createFileRoute } from "@tanstack/react-router";
import { handleHealth, jsonResult } from "@/office/http.ts";

export const Route = createFileRoute("/api/health")({
  server: {
    handlers: {
      GET: async () => jsonResult(await handleHealth()),
    },
  },
});
