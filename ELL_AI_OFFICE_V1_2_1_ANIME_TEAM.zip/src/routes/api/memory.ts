import { createFileRoute } from "@tanstack/react-router";
import { handleMemorySummary, jsonResult } from "@/office/http.ts";

export const Route = createFileRoute("/api/memory")({
  server: {
    handlers: {
      GET: async () => jsonResult(await handleMemorySummary()),
    },
  },
});
