import { createFileRoute } from "@tanstack/react-router";
import { handleCancelTask, jsonResult } from "@/office/http.ts";

export const Route = createFileRoute("/api/tasks/$id/cancel")({
  server: {
    handlers: {
      POST: async ({ params }) => jsonResult(await handleCancelTask(params.id)),
    },
  },
});
