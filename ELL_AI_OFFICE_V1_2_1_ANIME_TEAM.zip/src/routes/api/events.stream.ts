import { createFileRoute } from "@tanstack/react-router";
import { getOffice } from "@/office/runtime.ts";

/**
 * Lightweight SSE stream of office events.
 * Polls listEvents and emits new rows; no secrets.
 */
export const Route = createFileRoute("/api/events/stream")({
  server: {
    handlers: {
      GET: async () => {
        const encoder = new TextEncoder();
        let lastSeen = "";
        let closed = false;

        const stream = new ReadableStream({
          async start(controller) {
            const send = (event: string, data: unknown) => {
              controller.enqueue(
                encoder.encode(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`),
              );
            };
            send("connected", { ok: true });
            while (!closed) {
              try {
                const events = await getOffice().listEvents(lastSeen || undefined);
                for (const ev of events) {
                  if (ev.createdAt <= lastSeen) continue;
                  send("office", {
                    id: ev.id,
                    type: ev.type,
                    taskId: ev.taskId,
                    employeeId: ev.employeeId,
                    message: String(ev.message).slice(0, 300),
                    createdAt: ev.createdAt,
                  });
                  if (ev.createdAt > lastSeen) lastSeen = ev.createdAt;
                }
              } catch {
                send("error", { message: "stream tick failed" });
              }
              await new Promise((r) => setTimeout(r, 800));
            }
          },
          cancel() {
            closed = true;
          },
        });

        return new Response(stream, {
          headers: {
            "Content-Type": "text/event-stream",
            "Cache-Control": "no-cache, no-transform",
            Connection: "keep-alive",
          },
        });
      },
    },
  },
});
