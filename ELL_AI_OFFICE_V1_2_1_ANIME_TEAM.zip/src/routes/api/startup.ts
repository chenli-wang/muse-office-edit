import { createFileRoute } from "@tanstack/react-router";
import { handleStartup, jsonResult } from "@/office/http.ts";

export const Route = createFileRoute("/api/startup")({
  server: {
    handlers: {
      GET: async () => jsonResult(await handleStartup()),
    },
  },
});
