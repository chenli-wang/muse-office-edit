import { createFileRoute } from "@tanstack/react-router";
import { handleEmployeeRegistry, jsonResult } from "@/office/http.ts";

export const Route = createFileRoute("/api/employees")({
  server: {
    handlers: {
      GET: async () => jsonResult(await handleEmployeeRegistry()),
    },
  },
});
