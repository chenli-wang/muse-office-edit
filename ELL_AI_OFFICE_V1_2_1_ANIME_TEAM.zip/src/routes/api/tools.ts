import { createFileRoute } from "@tanstack/react-router";
import { handleListTools, jsonResult } from "@/office/http.ts";

export const Route = createFileRoute("/api/tools")({
  server: {
    handlers: {
      GET: async () => jsonResult(await handleListTools()),
    },
  },
});
