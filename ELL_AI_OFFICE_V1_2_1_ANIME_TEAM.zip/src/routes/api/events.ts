import { createFileRoute } from "@tanstack/react-router";
import { handleListEvents, jsonResult } from "@/office/http.ts";

export const Route = createFileRoute("/api/events")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const url = new URL(request.url);
        const since = url.searchParams.get("since") ?? undefined;
        return jsonResult(await handleListEvents(since));
      },
    },
  },
});
