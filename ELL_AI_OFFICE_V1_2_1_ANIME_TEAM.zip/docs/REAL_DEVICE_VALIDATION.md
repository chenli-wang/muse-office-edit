# Real-device validation checklist — ELL AI Office V1.1.x

Use this checklist on **physical** Android Chrome and desktop browsers.
Automated Playwright/SwiftShader results are **not** a substitute for the rows marked *device*.

## Preconditions

- [ ] Production or preview build served over HTTP(S) on the LAN or USB debugging
- [ ] No production API keys required for mock-mode smoke (private chat may use mock)
- [ ] FPS counter enabled in the 3D performance panel
- [ ] Record: device model, OS version, browser version, GPU (if Settings shows it)

## A. Desktop Chrome / Edge / Firefox

| # | Step | Expected | Result |
|---|------|----------|--------|
| D1 | Open office, switch to **3D** if needed | WebGL canvas visible; diagnostics Mode: `WebGL-3D` | |
| D2 | Note canvas size in diagnostics | Non-zero width×height | |
| D3 | Click each avatar: Claude, Gemini, Grok, GPT | Correct name/role in profile; selection ring | |
| D4 | Drag on empty floor | Orbit only; selection unchanged if already selected | |
| D5 | Wheel zoom then select another employee | Zoom held until selection identity changes; focus moves | |
| D6 | **Clear selection · camera overview** or Escape | Profile closes; overview framing | |
| D7 | Set Quality High, enable FPS counter, idle 30s | Selected=Active; FPS displayed (no guarantee of 60) | |
| D8 | Switch to 2.5D fallback then **Try WebGL 3D** | Single canvas; no duplicate scenes; Mode updates | |
| D9 | Reduced motion on | Pose bob reduced/off; UI still usable | |

## B. Android Chrome (physical device)

| # | Step | Expected | Result |
|---|------|----------|--------|
| A1 | Open URL in Chrome; rotate portrait/landscape | No horizontal page overflow; controls reachable | |
| A2 | Tap each of four avatars | Correct profile; panel does not block Quality/FPS forever | |
| A3 | Drag finger to orbit | Orbit without accidental select (click threshold) | |
| A4 | Pinch/scroll near scene | Page does not fight canvas drag excessively | |
| A5 | Close profile (Close / overview / back if applicable) | Returns to overview; can select again | |
| A6 | Toggle 2.5D ↔ WebGL | Stable; diagnostics Mode correct | |
| A7 | 60s idle with FPS counter | App remains responsive; note FPS range | |
| A8 | Background app 30s, return | Scene still works or recovers without crash | |

## C. Accessibility (spot check)

| # | Step | Expected | Result |
|---|------|----------|--------|
| K1 | Tab to Quality and FPS selects | Visible focus; labels announced if SR on | |
| K2 | Escape with profile open | Profile closes | |
| K3 | Reduced motion OS preference | Prefer low quality / reduced motion defaults | |

## D. What automation cannot prove

- True GPU frame times and thermal throttling
- Real multi-touch quality on all OEMs
- Screen-reader verbosity on TalkBack/VoiceOver
- Production provider latency and auth

## Sign-off

| Role | Name | Date | Go / No-go |
|------|------|------|------------|
| Tester | | | |
| Reviewer | | | |

**Do not mark RELEASE READY until A and B are completed on at least one desktop and one physical Android device with notes attached.**
