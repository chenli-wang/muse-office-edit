# Deployment

## Topology

- **Frontend:** static / TanStack Start UI (GitHub Pages, Vercel, etc.)
- **Backend:** Node server with OfficeRuntime (not static-only hosts)
- **Workspace:** server-side filesystem or future object store
- **Knowledge:** `.ell-knowledge/` JSON files (future Supabase behind same interface)

GitHub Pages **cannot** run the Office backend.

## Mock vs live

```bash
ELL_EXECUTION_MODE=mock npm run dev          # no keys
ELL_EXECUTION_MODE=live ELL_COST_MODE=FREE_FIRST \
  GEMINI_API_KEY=... npm run dev
```

## Security

Keys stay on the server. Dashboard APIs return public registries without secrets.
