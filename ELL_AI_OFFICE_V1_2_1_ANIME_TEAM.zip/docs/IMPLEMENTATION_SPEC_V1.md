# ELL AI OFFICE — IMPLEMENTATION SPEC V1

## Mission

Implement the approved ELL AI Office architecture as a real, testable application.

## Non-negotiable

- Do not redesign the architecture without an ADR.
- Do not add fake AI capabilities.
- Do not expose provider secrets to the frontend.
- Do not bypass provider limits.
- Do not build 3D before the backend works.
- Do not add unnecessary agents.
- The mock provider must work before real providers are connected.

## Phase 1 acceptance

The application must support:

1. User enters an objective.
2. Backend creates a task.
3. Orchestrator assigns it to an employee.
4. Employee invokes a provider abstraction.
5. Provider returns a structured result.
6. Result is stored.
7. UI displays live status.
8. User can cancel the task.
9. Errors are represented explicitly.

## Phase 2

Add real provider adapters one at a time:

- OpenAI
- Anthropic
- Gemini
- xAI

Use environment variables on the server only.

## Phase 3

Add multi-agent dependency graphs, handoffs, challenger review, and final synthesis.

## Phase 4

Add provider health, free-first routing, cooldowns, and fallback.

## Phase 5+

Tools, memory, dashboard expansion, 2D office, then 3D.

## Required engineering behavior

Before changing architecture, explain:
- why the change is needed;
- which requirement it affects;
- migration impact;
- alternatives considered.

Every meaningful change must be testable.

## Definition of done for Phase 1

A fresh clone can install dependencies, start server and web app, submit a task, observe a working employee, receive a result, and cancel a task without any API key.
