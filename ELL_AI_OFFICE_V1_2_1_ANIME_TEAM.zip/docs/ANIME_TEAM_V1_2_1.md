# ELL AI Office V1.2.1 — Anime Team

Tanggal: 12 Oktober 2026

## Ringkasan
- Roster **tidak berubah**: tetap tim bernama model (Claude, Gemini, Grok, GPT) sesuai baseline.
- Tidak ada rebrand, tidak ada perubahan orkestrasi/logika backend.
- Perubahan hanya di **lapisan presentasi 3D** + perbaikan visual yang jelas rusak.

## Karakter anime 3D (baru)
- `src/components/office/3d/anime-character.ts` — builder karakter anime prosedural:
  - Proporsi anime (kepala besar, badan mungil).
  - Cel-shading via `MeshToonMaterial` + gradient map 3-step.
  - Outline gaya anime (inverted hull, BackSide) di kepala, torso, rambut, lengan, kaki.
  - Wajah: canvas-painted — mata besar bergaya anime (iris warna per karakter),
    blush, senyum; berkedip otomatis tiap beberapa detik.
  - Tiap karyawan beda: Claude (fringe menyamping + headband), Gemini (twintails
    + pita), Grok (rambut spiky + kacamata), GPT (neat cap + ahoge).
  - Rig artikulasi: pivot bahu, siku, pinggul, lutut, kepala.
  - Pose prosedural: idle (napas), walk cycle (ayunan kaki/lengan, body bob),
    duduk (typing saat working, tangan-di-dagu saat thinking).
  - Name tag melayang (sprite canvas): nama + dot status dari state backend asli.
- `src/components/office/3d/wander.ts` — movement AI murni (tanpa three.js):
  - Karyawan yang idle/standby **berjalan mondar-mandir** antar waypoint koridor,
    berhenti sejenak, lalu pindah lagi; menghadap arah jalan (smooth turn).
  - Saat status backend `working` / `thinking` / `queued` / `waiting`, karakter
    **berjalan kembali ke mejanya dan duduk**.
  - Collision sederhana: AABB meja + meja meeting → karakter tidak menembus furnitur.
  - Separasi antar karakter supaya tidak bertumpuk.
  - `reducedMotion` (aksesibilitas): semua karakter tetap duduk, animasi mati.

## Perbaikan visual ("yang jelek-jeleknya")
- Meja meeting sebelumnya **mengambang** (tanpa kaki) → ditambah 4 kaki.
- Kursi sebelumnya mengambang → ditambah tiang + alas kaki kursi.
- Mata karakter lama **tenggelam di dalam kepala** (sphere mata di dalam sphere
  kepala) → wajah baru di permukaan depan kepala.
- Status dot melayang aneh di atas kepala → diganti name tag informatif.
- GLB pilot loader (eksperimen P2, file GLB tidak ada di repo) **dihapus** —
  karakter anime prosedural adalah jalur utama; tidak ada lagi desk kosong saat
  load gagal.
- Tambahan: tanaman di sudut ruangan supaya tidak kosong.

## File yang berubah
- Baru: `src/components/office/3d/anime-character.ts`,
  `src/components/office/3d/wander.ts`,
  `src/components/office/3d/wander.test.ts`,
  `src/components/office/3d/anime-character.test.ts`, `docs/ANIME_TEAM_V1_2_1.md`
- Ubah: `src/components/office/3d/office-scene-three.tsx` (integrasi rig + wander),
  `src/components/office/3d/office-state.ts` (tambah field `eyes` di
  `CharacterVisual`, komentar diperbarui), `package.json` (versi 1.2.1 + test script).

## Catatan desain
- Animasi jalan murni prosedural (bukan motion capture / GLB) agar ringan dan
  tidak butuh aset eksternal.
- Waypoint dipilih di koridor yang sudah diverifikasi bebas dari furnitur;
  push-out AABB sebagai jaring pengaman.
- Performa: ~30 draw call per karakter, outline hanya di bagian besar,
  gradient map dishare — target tetap 60fps di profil kualitas yang ada.
