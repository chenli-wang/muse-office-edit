# Providers

| Id | Display | Default costClass |
|----|---------|-------------------|
| mock | Mock Provider | FREE |
| gemini | Google Gemini | PAID |
| xai | xAI Grok | PAID |
| anthropic | Anthropic | PAID |
| openai | OpenAI | PAID |

Override with `ELL_COST_CLASS_<id>=FREE` only when you have a legitimate free/zero-cost API path.

Future adapters (OpenRouter free models, Cloudflare AI, Ollama) plug into the same registry + cost metadata — no Manager rewrite.
