# Release readiness — V1.1.6

**Package intent:** Real-device validation prep + lightweight diagnostics.  
**Status: NOT RELEASE READY**

## Automated evidence (this train)

| Check | Result |
|-------|--------|
| `npm run typecheck` | Required on package |
| `npm test` | Required on package |
| `npm run build` | Required on package |
| Playwright desktop 4 desks | Established in V1.1.4–V1.1.5 |
| Playwright mobile 390×844 | Established in V1.1.5 (no overflow-x; touch pick) |
| Physical Android Chrome | **NOT VERIFIED** |
| Physical desktop GPU 60 FPS | **NOT VERIFIED** |

## Features considered complete for candidate *after* device sign-off

- Private-chat / provider routing (no silent mock substitution when live configured)
- 3D pick → profile → focus → zoom persistence → overview
- Adaptive quality with Selected/Active visibility (no auto-upgrade)
- Mobile layout hardening, Escape close, lifecycle dispose
- Diagnostics overlay (FPS counter on): mode, canvas size, quality line, fallback reason

## Diagnostics (no secrets)

When **FPS counter** is enabled, overlay shows:

- Measured FPS and FPS target
- Mode: `WebGL-3D` or `2.5D-canvas`
- Canvas CSS pixel size
- Selected · Active quality (and `(adaptive)` only when applied is below selected)
- Reduced motion flag when on
- Fallback reason string (truncated) if WebGL failed

Never displays API keys, tokens, or provider credentials.

## Go / No-go

| Criterion | Met? |
|-----------|------|
| Typecheck / tests / build green on candidate ZIP | **Yes** (typecheck 0, 347/347, build 0) |
| Automated interaction regressions | **Yes** — 4 desks + diagnostics overlay (SwiftShader) |
| Physical Android checklist signed | **No** |
| Physical desktop GPU notes | **No** |
| Live provider production config | Out of scope / deferred |

**Decision: NO-GO for production release** until real-device checklist (docs/REAL_DEVICE_VALIDATION.md) is completed and attached.

## Known limitations

- SwiftShader/Playwright FPS ≠ device FPS
- Adaptive quality drop under load needs device confirmation for UI string `(adaptive)`
- Screen-reader coverage is spot-check only
