# Configuration

Load order: defaults → environment (`ELL_*`, provider keys) → optional overrides.

| Variable | Values | Default |
|----------|--------|---------|
| `ELL_EXECUTION_MODE` | `mock` \| `live` | `mock` |
| `ELL_COST_MODE` | `FREE_ONLY` \| `FREE_FIRST` \| `PAID` | `FREE_FIRST` |
| `ELL_PAID_FALLBACK` | `true` \| `false` | `false` |
| `ELL_PROJECT_ID` | string | `default` |
| `ELL_COST_CLASS_<providerId>` | `FREE` \| `PAID` \| `UNKNOWN` | catalog default |

API keys: `XAI_API_KEY`, `GEMINI_API_KEY`, `ANTHROPIC_API_KEY`, `OPENAI_API_KEY` (server only).

**Important:** Consumer ChatGPT/Claude/Grok *web* free tiers are **not** free API access.
