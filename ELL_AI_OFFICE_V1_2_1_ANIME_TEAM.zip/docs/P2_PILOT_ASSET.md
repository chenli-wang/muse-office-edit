# P2 Pilot asset — Claude GLB

| Field | Value |
|-------|--------|
| File | `public/office/characters/claude-pilot.glb` |
| Size | ~96.6 KB (98916 bytes) |
| Build | `node scripts/build-pilot-glb.mjs` |
| License | Original project work for ELL AI Office; see `LICENSE.txt` beside the GLB |
| Scope | **Pilot only** — Claude desk. Gemini/Grok/GPT remain P1 procedural. |

Not a commercial brand mascot. Animation clip export is partial (position tracks more reliable than rotation in this exporter path); pose mapping still prefers clip names `idle|thinking|working|completed|error` when present, and never plays `working` unless backend pose is working.
