# Cost Modes

| Mode | Behavior |
|------|----------|
| **FREE_ONLY** | Only `costClass: FREE`. PAID/UNKNOWN blocked. No silent paid fallback. |
| **FREE_FIRST** | Prefer FREE. Paid only if `ELL_PAID_FALLBACK=true` or allowlisted. UNKNOWN blocked. |
| **PAID** | FREE + configured PAID. UNKNOWN blocked by default. |

Cost class is **explicit configuration**, never inferred from marketing free tiers.
