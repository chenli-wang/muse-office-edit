# ELL AI Office — Architecture (v1.0)

```
USER → ELL Manager → Plan + Cost Policy
         → ProviderRouter → Employees (Claude / Gemini / Grok / GPT)
         → ToolRegistry → Project Execution / QA / Knowledge
         → Collaboration → Final Result → Dashboard (2D/3D)
```

**One** task system, **one** Manager, **one** ProviderRouter, **one** ToolRegistry.

Phases 1–14 implemented the core. Phase 15 packages configuration, registries, and docs.

See `docs/decisions/` for ADRs.
