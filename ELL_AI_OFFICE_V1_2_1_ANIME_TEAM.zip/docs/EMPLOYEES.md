# Employees

| Id | Role | Default provider |
|----|------|------------------|
| claude | Lead Developer / Implementation | anthropic |
| gemini | Research / Analysis / QA | gemini |
| grok | Challenger / Independent Review | xai |
| gpt | Chief Architect / Final Synthesis | openai |

Four employees only. Binding is configuration (Phase 4). Manager assigns roles; ProviderRouter executes within cost policy.
