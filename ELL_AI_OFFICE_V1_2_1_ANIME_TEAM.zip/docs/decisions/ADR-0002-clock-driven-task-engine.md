# ADR-0002 — Clock-driven task advancement

**Status:** Accepted  
**Phase:** 1  
**Date:** 2026-10-06

## Context

The ZIP completed work with `setTimeout` after `POST /api/tasks` returned. That is racy (cancel vs complete), untestable without sleeping, and does not survive a serverless freeze after the response is sent.

## Decision

The task engine is a deterministic state machine. Each API read/write calls `tick(now)`. Lifecycle timestamps are scheduled up front. The mock provider is invoked during the RUNNING → SYNTHESIZING transition, not from a background timer.

## Why

Cancellation, completion, and provider errors must be testable without flaky waits, and must work in a long-lived preview process.

## Requirement affected

Task lifecycle and cancellation. States still follow the architecture: created → planning → assigned → running → synthesizing → completed, plus failed / cancelled.

## Alternatives considered

- `setTimeout` as in the ZIP: rejected (race, serverless).
- Persistent worker / Redis: deferred; Phase 1 does not need it.

## Migration

None.
