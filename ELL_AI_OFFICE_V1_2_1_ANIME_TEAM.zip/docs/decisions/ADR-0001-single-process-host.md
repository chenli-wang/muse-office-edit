# ADR-0001 — Single-process TanStack Start host

**Status:** Accepted  
**Phase:** 1  
**Date:** 2026-10-06

## Context

The V0.1 ZIP scaffolds a two-process monorepo: Express on port 8787 and a separate Vite app. This workspace (and the live preview / deploy target) requires one app bound on `0.0.0.0:8080`.

## Decision

Implement Phase 1 as a single TanStack Start application:

- Domain lives in `src/office/` (provider, employees, orchestrator, task engine).
- HTTP contract lives in `src/routes/api/*` (same REST shapes as the architecture).
- Dashboard is the Start UI, polling those APIs.

Employee/role/provider/task semantics are unchanged.

## Why

The preview and production host cannot run a second Express process or a hardcoded `localhost:8787` client.

## Requirement affected

Hosting only. Phase 1 acceptance flow is unchanged: user → task → orchestrator → employee → provider → stored result → UI, plus cancel and explicit errors.

## Alternatives considered

- Keep Express and proxy it: not available in this host.
- Two ports: the live preview would be empty.

## Migration

None. This is the first runnable implementation.
