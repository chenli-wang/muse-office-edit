# ADR-0016 — QA & Verification Engine (Phase 12)

**Status:** Accepted  
**Phase:** 12  
**Date:** 2026-10-07

## Decision

1. `QAEngine` plans and runs validation levels: static, project, change, regression.
2. Metadata discovery reads package.json / known configs — **never executes scripts**.
3. Without a controlled command runner, project-level checks return **INCONCLUSIVE** (not PASS).
4. Static PASS alone does not imply overall PASS when project validation was requested and unavailable.
5. Regression compares failure sets to an optional baseline.
6. Tools: `qa.plan`, `qa.run`, `qa.report` (read permission for all employees).
7. No unrestricted shell/terminal.

## Security

Allowlist-only optional runner interface; default has no runner. Output/path/secret sanitization. Workspace isolation preserved.
