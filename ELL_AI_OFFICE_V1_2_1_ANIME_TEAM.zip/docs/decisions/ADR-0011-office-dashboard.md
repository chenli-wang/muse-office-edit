# ADR-0011 — Real-time Office Dashboard (Phase 7)

**Status:** Accepted  
**Phase:** 7  
**Date:** 2026-10-07

## Decision

1. Aggregated read-only snapshot via `GET /api/dashboard` (safe public DTO).
2. SSE `GET /api/events/stream` for lightweight live updates; UI also polls.
3. Memory/tools panels via `/api/memory` and `/api/tools`.
4. Task submit/cancel reuse existing `/api/tasks` lifecycle.
5. Employee cards derive status from task + employee backend data — no invented activity.
6. Dark mobile-first control-room UI; no 3D.

## Security

Sanitize messages; never expose API keys, env vars, host absolute paths, or auth headers.
