# ADR-0005 — Provider health & availability (Phase 2C)

**Status:** Accepted  
**Phase:** 2C  
**Date:** 2026-10-07

## Context

Phase 2A/2B added Mock, xAI, and Gemini adapters plus a Provider Registry.
Before free-first routing (Phase 2D+), the system needs a single answer to:

> Is this provider currently usable, and why?

## Decision

1. Introduce `ProviderHealthStore` — narrow store of per-provider health snapshots.
2. Seed state from **configuration only** (key present / absent). Never claim “API healthy” without an observed `generate()` outcome.
3. Distinguish:
   - **configured** — credentials present (mock always true)
   - **checked** — at least one live generate outcome (`checkedAt`)
   - **availableForRequest** — configured and not blocked by auth/disabled/active rate-limit cooldown
4. Wrap adapters with `withHealthTracking` so success/failure updates the store.
5. On 429: mark `rate_limited`. Set `cooldownUntil` **only** when explicitly provided — never invent durations.
6. On 401/403: `auth_error` / `authentication_error` (not network).
7. On network/timeout: `degraded` with reason `network_error` / `timeout`.
8. Expose health via existing `GET /api/providers` as `ProviderStatus[]` (secret-free).
9. **No routing, fallback, load balancing, or retries across providers.**

## State transitions (observed)

```
not configured → disabled + configuration_error

configured + not_checked → available (for request attempts)

configured → generate success → available + ok (checkedAt set)

configured → 429 → rate_limited
configured → 401/403 → auth_error
configured → network → degraded (network_error)
configured → timeout/cancel → degraded (timeout)
configured → 5xx → provider_error
```

## Why routing is excluded

Health is an input to Phase 2D routing. Implementing selection here would couple infrastructure to policy and skip the deliberate free-first design phase.

## Security

Health JSON never includes API keys, Authorization headers, or credential fields.

## Migration

Existing adapters and registry remain. Phase 1–2B tests stay green. New `provider-health.test.ts` covers A–O.
