# ADR-0010 — Project Memory + Shared Context (Phase 6)

**Status:** Accepted  
**Phase:** 6  
**Date:** 2026-10-07

## Decision

1. `ProjectContextStore` holds structured entries (decision, finding, issue, note, task_summary).
2. In-memory implementation first; interface allows future persistence.
3. Isolation by `projectId` — no cross-project reads.
4. Explicit writes only — no automatic dump of full model responses.
5. Bounded: max entries, content length, retrieval count.
6. Sanitization strips API keys / Bearer tokens before persistence.
7. `ContextManager` provides snapshots for task start; multi-agent records findings + task_summary after completion; GPT synthesis receives `contextPromptBlock`.

## Non-goals

Vector DB, embeddings, RAG, external DB, UI, personal/user memory.
