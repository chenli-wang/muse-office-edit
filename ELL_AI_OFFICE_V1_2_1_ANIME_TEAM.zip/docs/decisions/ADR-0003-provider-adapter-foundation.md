# ADR-0003 — Provider adapter foundation (Phase 2A)

**Status:** Accepted  
**Phase:** 2A  
**Date:** 2026-10-07

## Context

Phase 1 used a minimal `ProviderAdapter` with `id`, `label`, and `generate()`.
That was enough for MockProvider but lacked:

- capability metadata
- availability reporting
- normalized error mapping for HTTP providers
- timeout and cancellation (AbortSignal)
- a registry so real adapters can be added without rewriting the orchestrator

## Decision

1. Expand `ProviderAdapter` with `capabilities`, `getAvailability()`, `listModels()`.
2. Extend `GenerateRequest` with optional `timeoutMs` and `signal`.
3. Provide shared helpers: `withTimeoutAndSignal`, `normalizeProviderError`, `httpStatusToErrorClass`.
4. Keep `MockProvider` fully compatible (including `simulateFailure` for tests).
5. Add one official adapter — `XaiProvider` — using the documented OpenAI-compatible API at `https://api.x.ai/v1`. It activates only when `XAI_API_KEY` is present server-side.
6. Introduce `createProviderRegistry` so the runtime can list models from multiple adapters while the primary path remains mock by default.
7. Propagate task cancellation via `AbortController` into the in-flight `generate()` call.

## Why

Phase 2 requires real providers one at a time without breaking Phase 1 tests or leaking secrets. A single clean contract + registry avoids per-provider branches in the orchestrator.

## Requirement affected

Architecture §§13–17 (provider abstraction, model registry, free-first routing foundation, quota states). MVP still works offline with MockProvider.

## Alternatives considered

- Inline fetch in the runtime: rejected (couples orchestrator to HTTP).
- Auto-switch primary to xAI when key present: rejected for Phase 2A; primary stays mock so behaviour is deterministic without keys. Routing comes in Phase 4.
- Implement all four providers at once: rejected (architecture says one at a time).

## Non-goals (unchanged)

- No Gemini / OpenAI / Anthropic adapters until official SDKs/endpoints are wired the same way.
- No quota bypass, no web-chat scraping, no leaked keys.
- No activation of offline employees (Gemini, Grok, GPT roles stay offline).

## Migration

- Existing Phase 1 tests continue to pass with MockProvider.
- `.env.example` documents `XAI_API_KEY` as optional and server-only.
