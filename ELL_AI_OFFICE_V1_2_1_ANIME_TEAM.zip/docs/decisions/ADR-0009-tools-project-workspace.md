# ADR-0009 — Tools + Project Workspace (Phase 5)

**Status:** Accepted  
**Phase:** 5  
**Date:** 2026-10-07

## Decision

1. `WorkspaceScope` confines all file operations to one explicit root with traversal protection.
2. `ToolRegistry` holds typed tools with permission metadata and audit events.
3. Project tools: `project.list`, `project.read`, `project.search`, `project.write`, `project.metadata`.
4. Writes are atomic (temp file + rename) and size-limited.
5. Integration via `OfficeRuntime.listTools` / `invokeTool` — not hard-coded into providers.
6. Public metadata uses `workspaceId` (basename), not host absolute paths.

## Non-goals

Shell/terminal, GitHub, unrestricted FS, memory, frontend, new providers.
