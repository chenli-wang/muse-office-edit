# ADR-0012 — 3D AI Office visualization (Phase 8)

**Status:** Accepted  
**Phase:** 8  
**Date:** 2026-10-07

## Decision

1. **Presentation only** — 3D/isometric layer consumes Phase 7 `/api/dashboard` + SSE; no second task system.
2. **Canvas isometric renderer** — no mandatory Three.js dependency (mobile-friendly, low object count).
3. **2D fallback** — `OfficeShell` toggles between full Phase 7 dashboard and 3D view.
4. **Pure mapping module** (`office-state.ts`) unit-tested without WebGL.
5. Four employees only; states mapped from backend cards.
6. Task submit/cancel reuse existing APIs.

## Non-goals

Physics, multiplayer, photorealism, new providers/employees, RAG, shell.
