# ADR-0015 — Advanced agent collaboration (Phase 11)

**Status:** Accepted  
**Phase:** 11  
**Date:** 2026-10-07

## Decision

1. Structured collaboration messages (finding, proposal, artifact, review_*, challenge, handoff, decision, final).
2. `CollaborationManager` owns bounded sessions, fingerprints, review/handoff limits.
3. Multi-agent synthesizer receives collaboration context before GPT runs.
4. Memory stores explicit decisions/outcomes only — not every message.
5. Events for dashboard: collaboration.started/message/handoff/review_*/challenge/decision/completed/limit_reached.
6. No second orchestrator; permissions remain at tool/employee layer.

## Non-goals

Unlimited debates, forced consensus, shell, autonomous internet.
