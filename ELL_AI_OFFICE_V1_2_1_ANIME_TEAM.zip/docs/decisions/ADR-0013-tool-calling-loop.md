# ADR-0013 — Bounded agent tool-calling loop (Phase 9)

**Status:** Accepted  
**Phase:** 9  
**Date:** 2026-10-07

## Decision

1. Provider-neutral text protocol: `TOOL_CALL {json}` / `FINAL {json}` for models without native tools.
2. `runToolLoop` validates name, checks per-employee permissions, invokes `ToolRegistry`, bounds/sanitizes results.
3. Limits: max iterations, max tool calls, per-tool timeout, max result chars, repeated-call detection.
4. Optional integration via `AgentExecutor` (`enableToolLoop` + `tools`) — default path unchanged.
5. No shell/terminal tools; workspace tools only.

## Security

Permission matrix per employee; unknown tools denied; results sanitized; audit trail without secrets.
