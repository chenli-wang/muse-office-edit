# ADR-0008 — Real provider binding + async task runtime (Phase 4)

**Status:** Accepted  
**Phase:** 4  
**Date:** 2026-10-07

## Decision

### A. Employee / provider binding
- Employees are roles; bindings map `employeeId → { providerId, modelId }`.
- Default live targets: Claude→Anthropic, Gemini→Gemini, Grok→xAI, GPT→OpenAI.
- Mock bindings used for deterministic tests.
- Adapters: existing Gemini/xAI + new Anthropic Messages API + OpenAI Chat Completions.
- Keys only from env; never in API/events/health.

### B. Async lifecycle
- Multi-agent `create()` returns after plan registration; orchestration runs in-process in background.
- `POST /api/tasks` with `mode:"multi"` returns promptly (non-terminal status).
- `GET /api/tasks/:id` reflects live state; `waitFor` for tests.
- Parent `AbortController` cancels children; no synthesis after cancel; idempotent cancel.
- Single mode remains synchronous for Phase 1 compatibility.
- No Redis/BullMQ yet — clean in-process abstraction for future queue migration.

## Non-goals
Tools, memory, DB, 3D, UI redesign, dynamic LLM planning, quota bypass.

## Correction — preferred provider routing

`ProviderRouter.executeWithFallback` accepts `preferredProviderId` from employee bindings.

- Preferred provider is attempted first when configured and available.
- Recoverable failures may fall back among real providers (never silent Mock substitution).
- Mock binding uses only MockProvider.
- `AgentResult` records `employeeId`, `preferredProviderId`, `providerId` (actual), and secret-free `routeTrace`.
