# ADR-0017 — Long-term project knowledge (Phase 13)

**Status:** Accepted  
**Phase:** 13  
**Date:** 2026-10-07

## Why

Phase 6 in-memory context is short-lived and task-oriented. Durable project decisions,
conventions, known issues, and lessons must survive process restarts without becoming
unbounded transcript dumps.

## Relationship to Phase 6

| Phase 6 memory | Phase 13 knowledge |
|----------------|--------------------|
| In-process | Persistent (JSON files under workspace `.ell-knowledge/`) |
| Task/session oriented | Project lifetime |
| High churn | Explicit writes only |

Both can inject bounded prompt blocks; they coexist.

## Persistence model

`FileKnowledgeStore`: one JSON file per `projectId`, atomic write via temp+rename.
Corrupt files are quarantined; store recovers empty rather than crashing.

## Lifecycle

`active` → `superseded` (history retained via supersedesId) or `invalidated`.

## Provenance

user | gpt | claude | gemini | grok | qa | project_execution | collaboration | system

## Security

Sanitize secrets/paths; project isolation; size limits; write limited to Claude/GPT tools;
no automatic transcript persistence; no vector DB required.

## Retrieval

Deterministic ranking (title/content/tag match), capped result count and prompt block size.

## Future

Optional DB backend behind same `KnowledgeStore` interface; optional embeddings later.
