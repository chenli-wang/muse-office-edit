# ADR-0007 — Multi-Agent Core (Phase 3)

**Status:** Accepted  
**Phase:** 3  
**Date:** 2026-10-07

## Context

Phases 1–2F delivered single-employee orchestration, provider adapters, health, and routing.
Phase 3 adds real multi-agent collaboration without tools, memory, or LLM-driven planning.

## Decision

1. **Static planner** (`planMultiAgent`): Claude + Gemini + Grok in parallel, GPT synthesis depends on all three.
2. **AgentExecutor** runs one agent task via existing `ProviderRouter` (`primary-only` in MVP).
3. **MultiAgentOrchestrator** schedules waves: independent tasks via `Promise.all`, dependents after deps complete.
4. **Result passing** through structured `upstreamResults` on agent tasks — no global mutable agent bus.
5. **Partial failure**: non-required parallel failures do not block synthesis; GPT still runs with available results; final result notes missing agents.
6. **Cancellation**: parent AbortController propagates to in-flight generate calls; no new work after cancel.
7. **API**: `POST /api/tasks` with `{ mode: "multi" }` enables multi-agent; default remains `single` for Phase 1–2F BC.
8. **Determinism**: fixed employee order, static plan, mock provider in tests — no random assignment.

## Architecture

```
User Task → MultiAgentOrchestrator → Planner → AgentTasks
                ↓
         AgentExecutor → ProviderRouter → Adapter
                ↓
         Result collection → GPT synthesis → FinalResult
```

## Non-goals

Tools, shell, GitHub, web, memory, dynamic LLM planning, 3D, UI redesign.

## Failure policy

- Parallel agent failure → continue
- Required synthesis blocked only if policy marks required deps failed and step cannot run
- GPT unavailable/failed → graceful partial synthesis (no fake GPT identity)
