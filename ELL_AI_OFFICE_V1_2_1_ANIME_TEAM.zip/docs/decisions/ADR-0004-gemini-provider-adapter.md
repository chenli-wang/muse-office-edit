# ADR-0004 — Gemini provider adapter (Phase 2B)

**Status:** Accepted  
**Phase:** 2B  
**Date:** 2026-10-07

## Context

Phase 2A established the ProviderAdapter contract, MockProvider, XaiProvider, and Provider Registry.
Phase 2B adds the second official real provider: Google Gemini.

## Decision

1. Implement `GeminiProvider` against the official REST endpoint:
   `POST https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent`
   with authentication via the `x-goog-api-key` header.
2. Environment variables (server-only):
   - `GEMINI_API_KEY` — required to register/activate the adapter
   - `GEMINI_MODEL` — optional model id (default: `gemini-2.5-flash`, documented and overridable)
3. Register Gemini in the existing `createProviderRegistry` when `GEMINI_API_KEY` is set.
   Mock remains the default primary. Do not auto-switch primary to Gemini.
4. Map `GenerateRequest` → Gemini `contents` + optional `systemInstruction`.
   Map response candidates/usageMetadata → `GenerateResponse` (no invented usage).
5. Reuse `withTimeoutAndSignal`, `normalizeProviderError`, `httpStatusToErrorClass`.
   No automatic retries. Rate limits surface as `RATE_LIMIT` only.
6. Capabilities reflect what this adapter implements: text + code; streaming/tools/vision = false.

## Why

Second real provider without redesigning the registry or orchestrator. Official API only.

## Non-goals

- Router / free-first / fallback
- Streaming, tools, vision wiring
- OpenAI / Anthropic adapters
- Multi-agent activation of the Gemini *employee* role
- Quota rotation or key bypass

## Migration

Phase 1 + 2A tests unchanged. New `gemini-provider.test.ts` uses mocked fetch only.
