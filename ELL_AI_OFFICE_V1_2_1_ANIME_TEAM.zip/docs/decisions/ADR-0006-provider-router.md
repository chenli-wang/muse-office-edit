# ADR-0006 — Provider router, free-first, and fallback (Phase 2D–2F)

**Status:** Accepted  
**Phase:** 2D–2F  
**Date:** 2026-10-07

## Context

Phases 2A–2C delivered adapters, registry, and health. The next layer is
**Provider Intelligence**: deterministic selection, free-first preference, and
controlled fallback — without coupling routing into adapters or the orchestrator’s
core state machine.

## Decision

1. **`ProviderRouter`** owns selection + fallback. Adapters only implement `generate`.
2. **Modes**
   - `primary-only` (default): Phase 1 path — single primary (mock).
   - `free-first`: order by `costClass` (free → unknown → paid), then stable `id`.
3. **Mock is not real AI**: free-first excludes `mock` by default (`excludeMockInFreeFirst`).
4. **Fallback** only on recoverable classes: `RATE_LIMIT`, `TIMEOUT`, `NETWORK`, `SERVER_ERROR`.
   Stop on `AUTH`, `INVALID_REQUEST`, `CONTENT_ERROR`, configuration failures.
5. **Constraints**: maxAttempts, never retry the same provider in one chain, no infinite loops,
   respect health cooldowns, never invent cooldown durations.
6. **Health**: reuse `ProviderHealthStore`; outcomes update it via tracking wrappers + router.
7. **Security**: `sanitizePublicErrorMessage` strips key-like tokens; health messages are
   catalog text only (no raw provider bodies). Regression test forbids `secret-api-key-123`
   in public API/health JSON.
8. **Transparency**: `RouteTrace` records selection reason, candidates, attempts, fallback flag,
   final provider — all secret-free.

## Non-goals

Multi-agent, OpenAI/Anthropic adapters, tools, memory, 3D, frontend redesign.

## Runtime

Task execution uses `primary-only` so Phase 1–2C behaviour stays intact. Free-first is
available for future policies / explicit callers.
