# ADR-0018 — ELL Manager / Autonomous Orchestrator (Phase 14)

**Status:** Accepted  
**Phase:** 14  
**Date:** 2026-10-08

## Responsibilities

ELL Manager is the decision/orchestration layer **above** OfficeRuntime. It:
- classifies tasks (deterministic heuristics)
- builds bounded execution plans
- selects resources under cost policy
- delegates execution to existing MultiAgentOrchestrator via `createTask`
- optionally runs QA and records durable knowledge
- exposes a state machine and sanitized events

It is **not** a second task database, provider, or agent framework.

## State machine

received → understanding → planned → routing → executing → …
Terminal: completed | failed | cancelled; deferred when FREE_ONLY has no free providers.

## Cost modes

| Mode | Behavior |
|------|----------|
| FREE_ONLY | Only `costClass: FREE`; never paid/unknown |
| FREE_FIRST | Prefer free; paid only if allowlisted |
| PAID | Free + paid; UNKNOWN still blocked |

No quota bypassing, no scraped sessions, no leaked keys.

## Integration

Reuses: ProviderRouter (via runtime), MultiAgent, Tool Loop, Project Execution,
Collaboration, QA, ContextManager, KnowledgeManager.

## MCP / Supabase

Extension points only — not required in Phase 14.

## Security

Existing workspace/tool/permission boundaries unchanged. Fail closed on policy violations.

## Hardening (Phase 14 correction)

### Routing is a constraint layer

Manager resolves `allowedProviderIds` from cost policy and passes them into
`createTask({ routing })` → MultiAgentOrchestrator / AgentExecutor →
`ProviderRouter.executeWithFallback({ policy.allowedProviderIds })`.

ProviderRouter remains the sole selection authority **within** that allowlist.

### preferred vs actual

`ManagerRouteTrace` records:
- preferredProviderId (policy intent)
- actualProviderId (from task outputs after execution)
- fallbackReason when they differ

### FREE_ONLY guarantee

Allowlist excludes PAID and UNKNOWN. Router cannot select outside allowlist.
Post-execution check fails the manager task if actual provider is not FREE.

### executionMode

- `mock`: preferred mock, silent mock OK
- `live`: no silent mock substitution (existing router rules)

### QA repair

Bounded loop: QA → FAIL → repair attempt ≤ maxRepairAttempts → QA again.
Never fabricates PASS; INCONCLUSIVE stays INCONCLUSIVE.

## Final hardening — real ChangeSet repair

Repair uses `attemptBoundedRepair` which only calls ToolRegistry:
`project.read` → `tryStaticFix` → `project.changeset.apply` → `project.validate`.

Only `claude` may apply writes. Gemini/Grok cannot escalate.

QA semantics unchanged: PASS / FAIL / INCONCLUSIVE (never fabricated).

Actual provider execution is proven by spy-adapter tests through ProviderRouter.
