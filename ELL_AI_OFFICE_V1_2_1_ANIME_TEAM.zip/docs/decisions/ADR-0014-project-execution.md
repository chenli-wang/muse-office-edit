# ADR-0014 — Controlled project execution (Phase 10)

**Status:** Accepted  
**Phase:** 10  
**Date:** 2026-10-07

## Decision

1. Structured **change sets** (create/update/delete) with path/size validation.
2. **CheckpointStore** snapshots before apply; rollback restores prior content (not Git).
3. Atomic per-file writes under WorkspaceScope (symlink/path protections preserved).
4. **StaticProjectValidator** — bracket/JSON heuristics only; **no shell**.
5. Tools: `project.changeset.apply`, `project.checkpoint.rollback`, `project.changeset.get`, `project.validate`.
6. Claude may apply/rollback; Gemini/Grok/GPT review/validate only (permission matrix).
7. Integrates with Phase 9 tool loop; memory records explicit outcomes only.

## Non-goals

Unrestricted shell, real Git, CI runners, second task system.
