# ADR-0020 — V1.1 Full 3D Office Presentation

**Status:** Accepted  
**Version:** 1.1.0  

## Decision

Upgrade the office presentation layer to a real Three.js / WebGL scene while keeping
the V1.0 backend locked and authoritative.

## Scope

- 3D office geometry (floor, walls, desks, chairs, monitors, meeting table)
- Four low-poly employee placeholders mapped to Claude / Gemini / Grok / GPT
- Backend status → pose (idle, working, thinking, …) via `office-state.ts`
- Click selection + profile panel + private chat API (existing runtime path)
- FPS cap 30/60/unlimited, quality low/balanced/high, adaptive drop
- Canvas isometric remains as fallback when WebGL fails

## Non-goals

No second orchestration system, no fake activity, no voice (V1.3), no heavy assets.
