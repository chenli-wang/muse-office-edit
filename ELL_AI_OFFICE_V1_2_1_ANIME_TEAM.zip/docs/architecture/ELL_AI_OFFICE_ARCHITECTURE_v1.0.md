# ELL AI OFFICE — MASTER ARCHITECTURE
## Version 1.0 — Architecture & Implementation Specification

**Status:** DRAFT FOR APPROVAL  
**Owner:** ELL  
**Purpose:** Build a unified multi-provider AI office where GPT, Claude, Gemini, and Grok operate as coordinated employees under one orchestrator.

---

## 1. Vision

ELL AI Office is a personal AI operating environment.

The user gives one high-level objective. ELL Orchestrator decomposes the objective, assigns work to specialized AI employees, collects their outputs, coordinates review, and produces one final result.

Core flow:

USER → ELL ORCHESTRATOR → SPECIALIZED EMPLOYEES → COLLABORATION/REVIEW → FINAL SYNTHESIS → USER

Initial employees:

- **Claude** — Lead Developer
- **Gemini** — Researcher / Analyst
- **Grok** — Challenger / Independent Reviewer
- **GPT** — Chief Architect / Auditor

The architecture must allow additional models/providers later without rewriting the core system.

---

## 2. Non-Goals

V1 is NOT intended to:

- train a frontier LLM;
- bypass provider rate limits;
- use leaked, stolen, shared, or reverse-engineered credentials;
- pretend paid models are free;
- reproduce proprietary chat products;
- start with dozens of agents;
- start with a complex 3D world;
- require expensive infrastructure;
- lock the system to one model provider.

Free access means only legitimate provider free tiers, open models, local models, or other legally available access.

If a provider quota is exhausted, the system must cooldown, route elsewhere, or wait for reset.

---

## 3. Design Principles

1. Provider independence
2. Employee/role independence from model
3. Fail gracefully
4. Free-first operation
5. Explicit permissions
6. Observable execution
7. Persistent project context
8. Human approval for risky actions
9. Modular architecture
10. Build backend before visual polish
11. Never expose API secrets to the browser
12. Never silently fabricate tool results

---

## 4. High-Level Architecture

```text
                    USER / ELL
                        │
                        ▼
               ELL ORCHESTRATOR
              planning / routing
                        │
          ┌─────────────┼─────────────┐
          ▼             ▼             ▼
       CLAUDE        GEMINI          GROK
      Developer     Researcher     Challenger
          │             │             │
          └─────────────┼─────────────┘
                        ▼
                       GPT
                 Architect/Auditor
                        │
                        ▼
                   FINAL RESULT
```

Supporting services:

- Provider Router
- Model Registry
- Task Engine
- Agent Runtime
- Tool Manager
- Memory Manager
- Event Bus
- Quota Manager
- Security / Permissions
- Observability
- Web UI

---

## 5. Employee Model

An employee is NOT the same thing as a model.

Conceptually:

```text
Employee → Role → Model Selection → Provider → Access Method
```

Each employee configuration should contain:

- id
- display_name
- role
- system_prompt
- capabilities
- preferred_models
- fallback_models
- tools_allowed
- max_parallel_tasks
- status
- provider_preferences
- permissions

This lets a role survive even when its preferred provider is unavailable.

---

## 6. Initial Employees

### Claude — Lead Developer

Responsibilities:

- inspect source code;
- implement changes;
- debug;
- refactor;
- write tests;
- explain implementation decisions;
- work with project files.

Constraints:

- do not change architecture without approval;
- do not delete important project data without approval;
- do not claim code was executed if it was not;
- avoid unrelated file changes.

### Gemini — Researcher / Analyst

Responsibilities:

- documentation research;
- technical comparisons;
- current information gathering;
- source verification;
- requirements analysis;
- independent analysis.

Must distinguish verified facts from assumptions and preserve source references when available.

### Grok — Challenger

Responsibilities:

- challenge assumptions;
- search for weaknesses;
- adversarial review;
- edge cases;
- alternative approaches;
- independent evaluation.

Grok should not simply agree with previous outputs.

### GPT — Chief Architect / Auditor

Responsibilities:

- architecture review;
- cross-agent synthesis;
- consistency checking;
- requirement verification;
- final technical audit;
- final recommendation.

GPT treats other outputs as evidence, not unquestionable truth.

---

## 7. Orchestrator

Responsibilities:

1. receive user objective;
2. determine task type;
3. inspect project context;
4. create a task plan;
5. select employees;
6. assign subtasks;
7. execute independent work in parallel where safe;
8. collect outputs;
9. trigger reviews;
10. resolve conflicts;
11. request human approval when needed;
12. produce final synthesis.

The orchestrator must NOT blindly send every task to every employee.

Example:

```text
User: "Audit my PWA."

Claude → code inspection
Gemini → documentation/research
Grok → independent challenge
GPT → final audit
```

For simple tasks, only the necessary employees should be used.

---

## 8. Task Lifecycle

```text
CREATED
  ↓
PLANNING
  ↓
ASSIGNED
  ↓
RUNNING
  ↓
WAITING
  ↓
REVIEWING
  ↓
SYNTHESIZING
  ↓
COMPLETED
```

Failure/block states:

- FAILED
- CANCELLED
- BLOCKED
- WAITING_FOR_USER
- WAITING_FOR_QUOTA

Every important transition creates an event.

---

## 9. Task Object

Conceptual schema:

```json
{
  "id": "task_001",
  "title": "Audit project",
  "objective": "...",
  "status": "planning",
  "priority": "normal",
  "createdAt": "...",
  "parentTaskId": null,
  "subtasks": [],
  "assignedEmployees": [],
  "contextRefs": [],
  "outputs": [],
  "approvalRequired": false
}
```

Implementation may use a different database representation, but the semantic fields should remain.

---

## 10. Subtasks

Each subtask should contain:

- task id
- employee id
- objective
- context
- constraints
- expected output format
- dependencies
- timeout
- retry policy
- approval requirements

Example:

```text
Parent: "Audit fetchWithFallback"

Claude: inspect implementation and identify bugs.
Gemini: research correct API behavior and edge cases.
Grok: try to disprove Claude's conclusions.
GPT: review all reports and produce final audit.
```

---

## 11. Agent Communication

Agents communicate through structured task messages.

Conceptual schema:

```json
{
  "id": "...",
  "from": "claude",
  "to": "gpt",
  "type": "result",
  "taskId": "...",
  "content": "...",
  "artifacts": [],
  "confidence": 0.0,
  "createdAt": "..."
}
```

Message types:

- task
- result
- critique
- question
- clarification
- approval_request
- status
- error
- handoff

Agents should not directly mutate another agent's internal state.

---

## 12. Agent Handoff

Example:

```text
Claude:
"I found a potential timeout bug."

Orchestrator:
creates review task

Grok:
"Counterpoint: this occurs only when source A stalls."

Orchestrator:
sends evidence to GPT

GPT:
evaluates both claims
```

The trace should remain:

**claim → evidence → challenge → resolution**

---

## 13. Provider Abstraction

The system exposes one internal interface regardless of provider.

Conceptually:

```text
generate(request) → response
```

Provider adapters:

- OpenAIAdapter
- AnthropicAdapter
- GeminiAdapter
- XAIAdapter
- OpenRouterAdapter
- OllamaAdapter
- future adapters

Each adapter handles provider-specific authentication, request format, streaming, errors, rate limits, model names, and token accounting.

The rest of the system must not depend directly on provider-specific SDK behavior.

---

## 14. Model Registry

Maintain a registry of available models.

Example:

```json
{
  "id": "provider:model",
  "provider": "example",
  "capabilities": ["text", "code"],
  "contextWindow": null,
  "costClass": "free",
  "availability": "unknown"
}
```

Do not permanently assume a model is free. Pricing/free status is dynamic metadata.

---

## 15. Free-First Routing

Routing priority:

1. legitimate free model/provider;
2. configured paid provider if allowed;
3. local model;
4. another configured fallback;
5. wait for quota reset;
6. ask user.

The router must never:

- bypass rate limits;
- rotate stolen keys;
- scrape private sessions;
- impersonate users;
- reverse-engineer paid access;
- claim unavailable providers are available.

---

## 16. Quota Management

Provider states:

- AVAILABLE
- DEGRADED
- RATE_LIMITED
- DAILY_LIMIT_REACHED
- MONTHLY_LIMIT_REACHED
- AUTH_ERROR
- PROVIDER_ERROR
- DISABLED
- UNKNOWN

When rate limited:

1. record error;
2. calculate cooldown if known;
3. stop unnecessary retries;
4. select another valid route;
5. notify UI;
6. retry only according to policy.

No infinite retry loops.

---

## 17. Routing Strategy

Routing can consider:

- employee role compatibility;
- model capability;
- provider availability;
- quota;
- latency;
- cost;
- context capacity;
- tool compatibility;
- reliability.

Conceptually:

```text
score =
  capability
  + availability
  + reliability
  + role_fit
  - cost
  - latency
```

Exact scoring should be configurable.

---

## 18. Parallel Execution

Independent tasks should run concurrently when possible.

```text
Claude ─────┐
Gemini ─────┼──→ GPT
Grok ───────┘
```

Dependent tasks must wait.

```text
Research
   ↓
Implementation
   ↓
Review
```

The orchestrator must understand dependencies.

---

## 19. Review System

Recommended pattern:

```text
PRIMARY WORK
     ↓
  CHALLENGE
     ↓
   AUDIT
     ↓
 SYNTHESIS
```

Important tasks should have at least one independent reviewer.

Reviewers receive the original objective, relevant context, primary result, evidence, and constraints.

Avoid unnecessary context flooding.

---

## 20. Conflict Resolution

Agents can disagree.

Never resolve disagreement using majority vote alone.

Process:

1. identify exact disagreement;
2. extract claims;
3. compare evidence;
4. request targeted verification;
5. escalate to architect;
6. ask user if unresolved and consequential.

Preserve disagreement in task history.

---

## 21. Confidence

Confidence is metadata, not truth.

Possible values:

- low
- medium
- high

or numeric 0–1.

Important claims should explain uncertainty.

---

## 22. Memory Architecture

Three levels:

### Global Memory

System-wide preferences and rules.

### Project Memory

Architecture, conventions, decisions, known issues, files, requirements.

### Task Memory

Inputs, outputs, decisions, reviews, artifacts.

Memory should support:

- retrieval;
- update;
- provenance;
- timestamps;
- source references;
- deletion;
- conflict detection.

Old memory must not automatically be treated as correct.

---

## 23. Project Context

A project context pack should contain:

- project summary;
- stack;
- folder structure;
- important files;
- current objective;
- coding rules;
- known constraints;
- previous decisions;
- recent task history.

Only relevant context should be passed to each employee.

---

## 24. Tools

Tool layer:

- GitHub
- Files
- Web
- Terminal
- Code Runner
- Documentation
- Memory
- Project Search

Every tool needs:

- name;
- description;
- input schema;
- permission level;
- timeout;
- audit logging;
- failure behavior.

---

## 25. Tool Permissions

### READ

Examples:

- read files;
- search repository;
- read documentation.

### WRITE

Examples:

- edit file;
- create file;
- create branch.

### DANGEROUS / EXTERNAL

Examples:

- delete data;
- production deployment;
- financial action;
- sending external messages;
- changing credentials;
- destructive commands.

Default:

```text
READ = allowed
WRITE = controlled
DANGEROUS = approval required
```

---

## 26. Human Approval

The user remains final authority.

Approval UI should show:

- what will happen;
- affected resources;
- proposed changes;
- risk;
- employee requesting action.

Actions:

```text
APPROVE
REJECT
MODIFY
```

No agent should silently perform a consequential external action.

---

## 27. Security

Critical rules:

- API keys only on trusted backend;
- secrets never sent to frontend;
- redact secrets from logs;
- validate tool inputs;
- sandbox code execution;
- restrict filesystem access;
- restrict shell commands;
- enforce timeouts;
- maintain audit logs;
- isolate tenants if multi-user support is added.

Never log raw credentials.

---

## 28. Event Bus

Important events:

```text
task.created
task.assigned
agent.started
agent.thinking
agent.tool_call
agent.completed
agent.failed
provider.rate_limited
provider.recovered
review.started
approval.requested
approval.granted
task.completed
```

The office UI consumes these events.

This is the bridge between backend and visualization.

---

## 29. Employee Status

Recommended states:

- IDLE
- PLANNING
- WORKING
- THINKING
- USING_TOOL
- WAITING
- REVIEWING
- COMPLETED
- ERROR
- OFFLINE

UI must derive status from real backend events.

---

## 30. Frontend

V0.1 is a normal web dashboard.

Required panels:

### Command Center
- objective input;
- task status;
- start/cancel controls.

### Employees
- employee;
- current status;
- current task;
- provider;
- model;
- quota status.

### Activity
Live event timeline.

### Results
Agent outputs and final synthesis.

### Approval
Pending actions requiring user permission.

---

## 31. Office Visualization

Do NOT start with 3D.

Phase 1: dashboard  
Phase 2: 2D office  
Phase 3: 3D office

The visual layer reads backend state.

Example:

```text
backend: claude = WORKING
visual:  Claude avatar = working animation
```

The visual layer is never the source of truth.

---

## 32. Future 3D Office

Possible areas:

- Boss / ELL area
- Claude developer desk
- Gemini research desk
- Grok review desk
- GPT architecture room
- shared meeting table
- project board
- task notifications
- speech bubbles
- collaboration lines

Movement is cosmetic. Actual collaboration occurs through backend messages/events.

---

## 33. Recommended Stack

Initial stack:

**Frontend**
- React
- TypeScript
- Vite

**Backend**
- Node.js
- TypeScript

**Communication**
- REST for commands
- WebSocket or Server-Sent Events for live events

**Storage**
- SQLite initially
- PostgreSQL when scaling

**Queue**
- simple in-process queue initially
- Redis/BullMQ later if actually needed

**3D**
- Three.js / React Three Fiber later

Do not introduce infrastructure before it is necessary.

---

## 34. Folder Structure

Recommended:

```text
ell-ai-office/
├── apps/
│   ├── web/
│   └── server/
│
├── packages/
│   ├── core/
│   ├── agents/
│   ├── providers/
│   ├── router/
│   ├── memory/
│   ├── tools/
│   ├── events/
│   └── shared/
│
├── docs/
│   ├── architecture/
│   ├── protocols/
│   └── decisions/
│
├── tests/
├── .env.example
├── README.md
└── package.json
```

For the first prototype, a simpler structure is acceptable. Avoid premature over-engineering.

---

## 35. API Contract

Possible endpoints:

```text
POST /api/tasks
GET  /api/tasks/:id
POST /api/tasks/:id/cancel

GET  /api/agents
GET  /api/agents/:id

GET  /api/providers
GET  /api/providers/:id/status

GET  /api/events
GET  /api/projects

POST /api/approvals/:id/approve
POST /api/approvals/:id/reject
```

Exact framework is implementation-dependent.

---

## 36. Streaming

Agent output should stream when the provider supports it.

UI may display:

```text
Claude is working...
Claude found 3 files...
Claude completed analysis.
```

Do not expose hidden chain-of-thought. Show concise status events and final reasoning summaries instead.

---

## 37. Observability

Track:

- task duration;
- provider;
- model;
- success/failure;
- rate-limit events;
- token usage where available;
- estimated cost where available;
- tool calls;
- retries;
- final outcome.

Later dashboard:

- tasks today;
- successful tasks;
- provider availability;
- free quota usage;
- average latency;
- errors.

---

## 38. Error Handling

Classify provider errors:

- AUTH
- RATE_LIMIT
- INVALID_REQUEST
- TIMEOUT
- SERVER_ERROR
- NETWORK
- CONTENT_ERROR
- UNKNOWN

Retry policy must be category-specific.

Examples:

RATE_LIMIT → cooldown / fallback  
TIMEOUT → limited retry / fallback  
AUTH → do not repeatedly retry  
INVALID_REQUEST → fix request before retry

---

## 39. Idempotency

Avoid accidental duplicate writes.

Every external write operation should have an operation ID.

On retry, determine whether the operation already succeeded.

---

## 40. Cancellation

User must be able to cancel a task.

Cancellation should propagate:

```text
User cancel
    ↓
Orchestrator
    ↓
running subtasks
    ↓
provider requests where supported
```

Completed safe work may remain in history.

---

## 41. Cost Control

Default:

```text
FREE-FIRST = ON
```

Optional limits:

- max tokens/task;
- max provider calls/task;
- max parallel agents;
- max total cost/day.

Paid calls can require approval.

---

## 42. Context Control

Do not send every previous message to every employee.

Use:

- relevant context;
- task-specific context;
- project context;
- necessary outputs only.

This reduces cost, latency, confusion, and context overflow.

---

## 43. Agent Prompt Design

Each employee gets stable role instructions plus task-specific instructions.

Structure:

```text
ROLE
RESPONSIBILITIES
CONSTRAINTS
TOOLS
PROJECT CONTEXT
TASK
EXPECTED OUTPUT
```

Avoid unnecessary duplication.

---

## 44. Standard Output Format

Preferred agent output:

```text
Summary
Findings
Evidence
Risks
Recommendations
Questions / Blockers
```

Developer outputs can additionally include:

```text
Files inspected
Files changed
Tests run
Tests not run
```

This simplifies cross-agent synthesis.

---

## 45. Audit Trail

Preserve:

- original request;
- plan;
- assignments;
- agent outputs;
- tool-call metadata;
- provider errors;
- approvals;
- final decision.

This allows debugging of the AI system itself.

---

## 46. Repository Reference Policy

ELL AI Office can take architectural inspiration from:

- multi-agent orchestration frameworks;
- multi-provider routers;
- coding-agent collaboration systems;
- AI office dashboards;
- engineering workflow systems.

Previously identified examples include:

- Consilium — orchestration / multi-agent review
- rAInbow-Code — coding-agent collaboration
- free LLM gateway/router projects — provider routing
- ClawProwl / AI office dashboards — visualization
- ECC — engineering workflow / skills

Existing repositories are references, not code to blindly copy.

Before importing code, verify:

1. current repository state;
2. license;
3. dependencies;
4. security posture;
5. maintenance;
6. compatibility.

---

## 47. License / Dependency Policy

Before importing code:

1. identify license;
2. verify compatibility;
3. inspect dependencies;
4. inspect security;
5. inspect maintenance;
6. preserve attribution where required.

---

## 48. Development Phases

### Phase 0 — Architecture

Deliver:

- architecture document;
- decisions;
- provider abstraction;
- employee definitions;
- security model.

**Current phase.**

### Phase 1 — Minimal Orchestrator

Build:

- backend;
- task creation;
- one employee;
- provider abstraction;
- result storage;
- basic UI.

Success:

**User → task → agent → result**

### Phase 2 — Four Employees

Add Claude, Gemini, Grok, GPT.

Success:

**one task → multiple agents → collected results**

### Phase 3 — Collaboration

Add:

- dependencies;
- handoffs;
- reviews;
- challenger;
- final synthesis.

### Phase 4 — Free Router

Add:

- provider registry;
- availability;
- rate-limit detection;
- cooldown;
- fallback;
- free-first routing.

### Phase 5 — Tools

Add:

- files;
- GitHub;
- web;
- terminal;
- code runner.

### Phase 6 — Memory

Add:

- project memory;
- task history;
- retrieval;
- provenance.

### Phase 7 — Dashboard

Add:

- live statuses;
- activity timeline;
- quota display;
- task graph;
- approvals.

### Phase 8 — 2D Office

Visualize employees and work state.

### Phase 9 — 3D Office

Add:

- Three.js / React Three Fiber;
- office;
- desks;
- avatars;
- animations;
- collaboration visualization.

### Phase 10 — Personal AI Integration

Potentially integrate ELL's own model/system as an employee or orchestrator model without redesigning the core.

---

## 49. MVP Definition

MVP is complete when:

1. User enters one objective.
2. Orchestrator creates a plan.
3. At least two employees can receive different subtasks.
4. Employees return structured results.
5. Results are stored.
6. Orchestrator synthesizes them.
7. User sees live task status.
8. Provider failures are handled.
9. Secrets remain server-side.
10. User can cancel a task.

**3D is NOT required for MVP.**

---

## 50. V1 Definition

V1 additionally provides:

- four employee roles;
- provider abstraction;
- free-first routing;
- quota awareness;
- multi-agent review;
- project memory;
- GitHub/files/web tools;
- approvals;
- event-driven dashboard;
- task history;
- audit trail;
- optional 2D/3D visualization.

---

## 51. Implementation Rules

**Rule 1:** Do not rewrite architecture during implementation without recording an Architecture Decision Record (ADR).

**Rule 2:** Do not add an agent simply to increase agent count.

**Rule 3:** Do not add infrastructure without demonstrated need.

**Rule 4:** Never expose secrets in frontend code.

**Rule 5:** Never bypass provider restrictions.

**Rule 6:** Never claim an operation succeeded without evidence.

**Rule 7:** Visual state is never the source of truth.

**Rule 8:** Prefer deterministic orchestration over uncontrolled autonomous loops.

**Rule 9:** Every external side effect requires permissions.

**Rule 10:** Human remains final authority.

---

## 52. First Implementation Task

The first coding task is NOT the 3D office.

Implement Phase 1:

```text
Backend
   ↓
Task API
   ↓
Provider Interface
   ↓
Mock Provider
   ↓
One Employee
   ↓
Result Storage
   ↓
Minimal Web Dashboard
```

Before connecting four real providers, prove the internal architecture with a mock provider.

Then connect real providers one by one.

---

## 53. Acceptance Test

The first prototype should pass:

```text
USER
  ↓
"Analyze this task."
  ↓
SYSTEM creates task
  ↓
ORCHESTRATOR creates subtask
  ↓
EMPLOYEE processes subtask
  ↓
PROVIDER returns result
  ↓
SYSTEM stores result
  ↓
UI displays employee status
  ↓
ORCHESTRATOR synthesizes
  ↓
USER receives final answer
```

If this works reliably, the foundation is valid.

---

## 54. Final Architectural Principle

ELL AI Office is not fundamentally a 3D game.

It is:

```text
orchestration system
+ provider abstraction
+ specialized AI roles
+ tools
+ memory
+ event system
+ permission layer
+ visualization
```

**The office is the interface.**  
**The orchestrator is the brain.**  
**The employees are specialized workers.**  
**The providers are replaceable engines.**  
**The user remains the boss.**

---

# NEXT STEP AFTER APPROVAL

1. Create Git repository.
2. Initialize project.
3. Create monorepo structure.
4. Create shared types.
5. Implement provider interface.
6. Implement mock provider.
7. Implement employee registry.
8. Implement task engine.
9. Implement orchestrator.
10. Implement minimal dashboard.
11. Write tests.
12. Connect real providers one by one.

**END OF ELL AI OFFICE ARCHITECTURE V1.0**
