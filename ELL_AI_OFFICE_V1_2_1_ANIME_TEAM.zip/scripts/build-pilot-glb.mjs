/**
 * Original pilot character GLB for ELL AI Office P2.
 * License: original project work for ELL AI Office (not third-party proprietary).
 */
import * as THREE from "three";
import { GLTFExporter } from "three/examples/jsm/exporters/GLTFExporter.js";
import fs from "fs";
import path from "path";

if (typeof globalThis.FileReader === "undefined") {
  globalThis.FileReader = class FileReader {
    result = null;
    onloadend = null;
    onerror = null;
    readAsArrayBuffer(blob) {
      Promise.resolve(blob.arrayBuffer())
        .then((buf) => {
          this.result = buf;
          this.onloadend?.({ target: this });
        })
        .catch((e) => this.onerror?.(e));
    }
  };
}

const outDir = path.resolve("public/office/characters");
fs.mkdirSync(outDir, { recursive: true });

function mat(color, opts = {}) {
  return new THREE.MeshStandardMaterial({
    color,
    roughness: opts.roughness ?? 0.55,
    metalness: opts.metalness ?? 0.05,
  });
}

const root = new THREE.Group();
root.name = "ClaudePilot";

const primary = 0xd97757;
const accent = 0xf5e6d3;
const hair = 0x3d2914;
const skin = 0xf0c4a0;

const hips = new THREE.Group();
hips.name = "Hips";
hips.position.y = 0.55;
root.add(hips);

const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.28, 0.45, 8, 12), mat(primary));
torso.name = "Torso";
torso.position.y = 0.45;
torso.castShadow = true;
hips.add(torso);

const collar = new THREE.Mesh(new THREE.BoxGeometry(0.48, 0.1, 0.32), mat(accent, { roughness: 0.5 }));
collar.name = "Collar";
collar.position.y = 0.72;
hips.add(collar);

const head = new THREE.Mesh(new THREE.SphereGeometry(0.26, 16, 16), mat(skin, { roughness: 0.7 }));
head.name = "Head";
head.position.y = 1.05;
head.castShadow = true;
hips.add(head);

const eyeGeo = new THREE.SphereGeometry(0.045, 10, 10);
const eyeMat = mat(0x1e293b, { roughness: 0.35 });
const eyeL = new THREE.Mesh(eyeGeo, eyeMat);
eyeL.position.set(-0.09, 1.08, 0.2);
hips.add(eyeL);
const eyeR = new THREE.Mesh(eyeGeo, eyeMat);
eyeR.position.set(0.09, 1.08, 0.2);
hips.add(eyeR);

const hairMat = mat(hair, { roughness: 0.8 });
const hairTop = new THREE.Mesh(new THREE.SphereGeometry(0.24, 12, 12), hairMat);
hairTop.scale.set(1.1, 0.75, 1.15);
hairTop.position.set(0, 1.22, -0.02);
hips.add(hairTop);
const hairSide = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.35, 0.2), hairMat);
hairSide.position.set(-0.24, 1.0, 0);
hips.add(hairSide);
const fringe = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.08, 0.12), hairMat);
fringe.position.set(0, 1.12, 0.18);
hips.add(fringe);

const leftArmG = new THREE.Group();
leftArmG.name = "LeftArm";
leftArmG.position.set(-0.38, 0.55, 0.05);
hips.add(leftArmG);
const leftArmMesh = new THREE.Mesh(new THREE.CapsuleGeometry(0.07, 0.32, 6, 8), mat(primary));
leftArmMesh.position.set(0, -0.2, 0);
leftArmG.add(leftArmMesh);

const rightArmG = new THREE.Group();
rightArmG.name = "RightArm";
rightArmG.position.set(0.38, 0.55, 0.05);
hips.add(rightArmG);
const rightArmMesh = new THREE.Mesh(new THREE.CapsuleGeometry(0.07, 0.32, 6, 8), mat(primary));
rightArmMesh.position.set(0, -0.2, 0);
rightArmG.add(rightArmMesh);

const legMat = mat(0x44403c, { roughness: 0.7 });
const leftLeg = new THREE.Mesh(new THREE.CapsuleGeometry(0.09, 0.28, 6, 8), legMat);
leftLeg.name = "LeftLeg";
leftLeg.position.set(-0.14, 0.2, 0.05);
hips.add(leftLeg);
const rightLeg = new THREE.Mesh(new THREE.CapsuleGeometry(0.09, 0.28, 6, 8), legMat);
rightLeg.name = "RightLeg";
rightLeg.position.set(0.14, 0.2, 0.05);
hips.add(rightLeg);

root.scale.setScalar(0.95);
root.updateMatrixWorld(true);

const idle = new THREE.AnimationClip("idle", 2, [
  new THREE.VectorKeyframeTrack("Hips.position", [0, 1, 2], [0, 0.55, 0, 0, 0.57, 0, 0, 0.55, 0]),
]);
const thinking = new THREE.AnimationClip("thinking", 2, [
  new THREE.VectorKeyframeTrack("Head.rotation", [0, 1, 2], [0, 0, 0, 0, 0, 0.12, 0, 0, 0]),
]);
const working = new THREE.AnimationClip("working", 1, [
  new THREE.VectorKeyframeTrack("LeftArm.rotation", [0, 0.5, 1], [0.2, 0, 0, -0.35, 0, 0, 0.2, 0, 0]),
  new THREE.VectorKeyframeTrack("RightArm.rotation", [0, 0.5, 1], [-0.15, 0, 0, 0.3, 0, 0, -0.15, 0, 0]),
]);
const completed = new THREE.AnimationClip("completed", 2, [
  new THREE.VectorKeyframeTrack("Hips.position", [0, 1, 2], [0, 0.55, 0, 0, 0.62, 0, 0, 0.55, 0]),
]);
const errorClip = new THREE.AnimationClip("error", 1, [
  new THREE.VectorKeyframeTrack("Hips.rotation", [0, 0.5, 1], [0, 0, 0, 0, 0, 0.06, 0, 0, 0]),
]);

const animations = [idle, thinking, working, completed, errorClip];

const exporter = new GLTFExporter();
const glb = await new Promise((resolve, reject) => {
  exporter.parse(
    root,
    (result) => resolve(result),
    (err) => reject(err),
    { binary: true, animations },
  );
});

const outPath = path.join(outDir, "claude-pilot.glb");
fs.writeFileSync(outPath, Buffer.from(glb));
console.log(JSON.stringify({ outPath, bytes: fs.statSync(outPath).size, kb: +(fs.statSync(outPath).size / 1024).toFixed(1) }));
