# ELL AI Office v1.0.0

Multi-agent AI office: **EllManager** coordinates Claude, Gemini, Grok, and GPT through ProviderRouter, tools, collaboration, QA, memory, and long-term knowledge — with a 2D/3D dashboard.

- **Mock mode** (default): no API keys required  
- **Live mode**: configure provider keys server-side only  
- **Cost modes**: `FREE_ONLY` | `FREE_FIRST` | `PAID` (explicit cost class; web free tiers ≠ free API)

```bash
npm install
npm run dev
npm test
```

Docs: `docs/ARCHITECTURE.md`, `docs/CONFIGURATION.md`, `docs/COST-MODES.md`, `docs/PROVIDERS.md`, `docs/EMPLOYEES.md`, `docs/DEPLOYMENT.md`.

---

# ELL AI Office — Phase 1 + Provider Foundation (2A)

Personal AI office: one objective, an orchestrator, specialized employees, providers, stored results.

Phase 1 proves the internal loop **without real model API keys**.  
Phase 2A–2C: provider adapter contract, xAI + Gemini adapters, registry, and provider health/availability (no router yet).

## What works

- Task API (`POST /api/tasks`, `GET /api/tasks/:id`, `POST /api/tasks/:id/cancel`)
- Orchestrator plan → assign Claude → provider → synthesis
- **MockProvider** (default) — no keys required
- **XaiProvider** — official `https://api.x.ai/v1` Chat Completions; activates only when `XAI_API_KEY` is set server-side
- **GeminiProvider** — official `generativelanguage.googleapis.com` generateContent; activates only when `GEMINI_API_KEY` is set server-side
- **Provider registry** — mock always primary; xAI/Gemini registered when keyed
- **Provider health** — configured vs checked vs availableForRequest; rate-limit/auth/network states; `GET /api/providers`
- **Provider router** — deterministic free-first selection + recoverable fallback (default path remains primary-only/mock)
- Structured employee output (summary, findings, evidence, risks, recommendations)
- In-memory result + event storage
- Dashboard: command center, employees, activity, results, empty approvals
- Cancel before completion (AbortSignal propagated to provider); explicit provider-error path
- Secrets stay off the client

## Run

```bash
npm install
npm run dev
```

Optional: set `XAI_API_KEY` in the server environment to register the xAI adapter (primary path remains mock until free-first routing lands later).

## Tests

```bash
npm test
# or office-only:
node --experimental-strip-types --test src/office/*.test.ts
```

## Intentionally not yet

- OpenAI / Anthropic adapters
- Switching primary away from mock without explicit config
- Multi-agent review (Gemini, Grok, GPT roles remain offline)
- Tools, GitHub, shell, persistent database
- 2D / 3D office

See `docs/IMPLEMENTATION_SPEC_V1.md`, `docs/architecture/ELL_AI_OFFICE_ARCHITECTURE_v1.0.md`, and `docs/decisions/ADR-0003-provider-adapter-foundation.md`.


### Phase 5 tools
-  confined to workspace root
-  / 
