# Employees

ELL AI Office runs a six-person AI employee team. Every employee is mock-bound in mock mode; in live mode the bindings below select each employee's preferred provider (the engine), while the employee id is the office role.

| Id | Title | Responsibilities | Live provider |
|----|-------|------------------|---------------|
| ceo | CEO (Chief Executive) | Final review and synthesis of multi-agent work; the synthesizer. | openai |
| pm | Project Manager | Planning, scoping, and coordinating work across the team. | anthropic |
| developer | Developer Agent | Implementation: inspect, code, debug, refactor, write tests. Single-task mode assigns here. | anthropic |
| researcher | Researcher Agent | Research and analysis; knowledge gathering. | gemini |
| automation | Automation Agent | Parallel execution slot: workflows, repetitive operations, bulk work. | xai |
| jira | Jira Agent | Task tracking and status bookkeeping. | openai |

## Task assignment

- **Single-task mode** → `developer` (the single-task worker).
- **Multi-agent mode** (`planMultiAgent`) → parallel steps `step_developer`, `step_researcher`, `step_automation`, then synthesis step `step_ceo` which depends on all three.
- **Mapping by work type:** implementation → `developer`, research → `researcher`, review / final synthesis → `ceo`, tracking → `jira`, automation → `automation`, planning → `pm`.
- **Write permission:** knowledge writes are restricted to `developer` + `ceo`; repair work is restricted to `developer`.

## Notes

- Provider ids (`mock`, `anthropic`, `gemini`, `xai`, `openai`) are engines, not employees; binding is configuration. Manager assigns roles; ProviderRouter executes within cost policy.
- Private chat is allowed for all six employee ids.
- 3D office: `DESK_ORDER = ["ceo", "pm", "developer", "researcher", "automation", "jira"]` (six desks, indices 0–5).
