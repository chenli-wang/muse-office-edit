import type { ToolDefinition, ToolRegistry } from "../tools/tool-registry.ts";
import type { KnowledgeManager } from "./knowledge-manager.ts";
import {
  isKnowledgeType,
  isProvenance,
  type KnowledgeType,
  type KnowledgeProvenance,
} from "./knowledge-types.ts";
import { KnowledgeError } from "./knowledge-types.ts";

/** Employees allowed to write knowledge (explicit writes only). */
const WRITE_EMPLOYEES = new Set(["developer", "ceo"]);

export function createKnowledgeTools(
  manager: KnowledgeManager,
  defaultProjectId: string,
): ToolDefinition[] {
  const projectIdOf = (input: unknown, ctx: { taskId?: string | null }) => {
    const body = (input ?? {}) as { projectId?: string };
    return (body.projectId ?? defaultProjectId).trim() || defaultProjectId;
  };

  return [
    {
      name: "knowledge.list",
      description: "List active long-term knowledge for the project.",
      permission: "read",
      inputSchema: { type: "object", properties: { projectId: { type: "string" } } },
      async execute(input) {
        return manager.list(projectIdOf(input, {}));
      },
    },
    {
      name: "knowledge.search",
      description: "Search project knowledge by text/type/tag.",
      permission: "read",
      inputSchema: {
        type: "object",
        properties: {
          projectId: { type: "string" },
          search: { type: "string" },
          type: { type: "string" },
          tags: { type: "array", items: { type: "string" } },
          limit: { type: "number" },
        },
      },
      async execute(input) {
        const body = (input ?? {}) as {
          projectId?: string;
          search?: string;
          type?: string;
          tags?: string[];
          limit?: number;
        };
        const type =
          body.type && isKnowledgeType(body.type) ? (body.type as KnowledgeType) : undefined;
        return manager.query({
          projectId: projectIdOf(input, {}),
          search: body.search,
          type,
          tags: body.tags,
          limit: body.limit,
        });
      },
    },
    {
      name: "knowledge.get",
      description: "Get a knowledge item by id.",
      permission: "read",
      inputSchema: {
        type: "object",
        properties: { projectId: { type: "string" }, id: { type: "string" } },
        required: ["id"],
      },
      async execute(input) {
        const body = (input ?? {}) as { id?: string };
        const item = manager.get(projectIdOf(input, {}), String(body.id ?? ""));
        if (!item) throw new KnowledgeError("NOT_FOUND", "Knowledge not found");
        return item;
      },
    },
    {
      name: "knowledge.add",
      description:
        "Explicitly add long-term knowledge. Write restricted to Developer Agent/CEO. Do not dump transcripts.",
      permission: "write",
      inputSchema: {
        type: "object",
        properties: {
          projectId: { type: "string" },
          type: { type: "string" },
          title: { type: "string" },
          content: { type: "string" },
          provenance: { type: "string" },
          tags: { type: "array", items: { type: "string" } },
          confidence: { type: "string" },
        },
        required: ["type", "title", "content"],
      },
      async execute(input, ctx) {
        if (!WRITE_EMPLOYEES.has(ctx.employeeId ?? "")) {
          throw new KnowledgeError("PERMISSION", "Knowledge write not allowed for this employee");
        }
        const body = (input ?? {}) as {
          type?: string;
          title?: string;
          content?: string;
          provenance?: string;
          tags?: string[];
          confidence?: "low" | "medium" | "high";
        };
        if (!body.type || !isKnowledgeType(body.type)) {
          throw new KnowledgeError("INVALID", "Invalid type");
        }
        const provenance: KnowledgeProvenance =
          body.provenance && isProvenance(body.provenance)
            ? body.provenance
            : mapEmployeeProvenance(ctx.employeeId);
        return manager.add({
          projectId: projectIdOf(input, ctx),
          type: body.type,
          title: String(body.title ?? ""),
          content: String(body.content ?? ""),
          provenance,
          sourceEmployeeId: ctx.employeeId ?? null,
          tags: body.tags,
          confidence: body.confidence,
        });
      },
    },
    {
      name: "knowledge.update",
      description: "Update an active knowledge item (Developer Agent/CEO only).",
      permission: "write",
      inputSchema: {
        type: "object",
        properties: {
          projectId: { type: "string" },
          id: { type: "string" },
          title: { type: "string" },
          content: { type: "string" },
          tags: { type: "array", items: { type: "string" } },
        },
        required: ["id"],
      },
      async execute(input, ctx) {
        if (!WRITE_EMPLOYEES.has(ctx.employeeId ?? "")) {
          throw new KnowledgeError("PERMISSION", "Knowledge write not allowed for this employee");
        }
        const body = (input ?? {}) as {
          id?: string;
          title?: string;
          content?: string;
          tags?: string[];
        };
        return manager.update(projectIdOf(input, ctx), String(body.id ?? ""), {
          title: body.title,
          content: body.content,
          tags: body.tags,
        });
      },
    },
    {
      name: "knowledge.supersede",
      description: "Replace active knowledge with a newer version (keeps history).",
      permission: "write",
      inputSchema: {
        type: "object",
        properties: {
          projectId: { type: "string" },
          oldId: { type: "string" },
          type: { type: "string" },
          title: { type: "string" },
          content: { type: "string" },
          provenance: { type: "string" },
          tags: { type: "array", items: { type: "string" } },
        },
        required: ["oldId", "type", "title", "content"],
      },
      async execute(input, ctx) {
        if (!WRITE_EMPLOYEES.has(ctx.employeeId ?? "")) {
          throw new KnowledgeError("PERMISSION", "Knowledge write not allowed for this employee");
        }
        const body = (input ?? {}) as {
          oldId?: string;
          type?: string;
          title?: string;
          content?: string;
          provenance?: string;
          tags?: string[];
        };
        if (!body.type || !isKnowledgeType(body.type)) {
          throw new KnowledgeError("INVALID", "Invalid type");
        }
        const provenance: KnowledgeProvenance =
          body.provenance && isProvenance(body.provenance)
            ? body.provenance
            : mapEmployeeProvenance(ctx.employeeId);
        return manager.supersede(projectIdOf(input, ctx), String(body.oldId ?? ""), {
          type: body.type,
          title: String(body.title ?? ""),
          content: String(body.content ?? ""),
          provenance,
          sourceEmployeeId: ctx.employeeId ?? null,
          tags: body.tags,
        });
      },
    },
    {
      name: "knowledge.invalidate",
      description: "Mark knowledge as invalidated (Developer Agent/CEO only).",
      permission: "write",
      inputSchema: {
        type: "object",
        properties: { projectId: { type: "string" }, id: { type: "string" } },
        required: ["id"],
      },
      async execute(input, ctx) {
        if (!WRITE_EMPLOYEES.has(ctx.employeeId ?? "")) {
          throw new KnowledgeError("PERMISSION", "Knowledge write not allowed for this employee");
        }
        const body = (input ?? {}) as { id?: string };
        return manager.invalidate(projectIdOf(input, ctx), String(body.id ?? ""));
      },
    },
  ];
}

function mapEmployeeProvenance(employeeId: string | null | undefined): KnowledgeProvenance {
  if (employeeId === "ceo") return "ceo";
  if (employeeId === "pm") return "pm";
  if (employeeId === "developer") return "developer";
  if (employeeId === "researcher") return "researcher";
  if (employeeId === "automation") return "automation";
  if (employeeId === "jira") return "jira";
  if (employeeId === "claude") return "claude";
  if (employeeId === "gemini") return "gemini";
  if (employeeId === "grok") return "grok";
  if (employeeId === "gpt") return "gpt";
  return "system";
}

export function registerKnowledgeTools(
  registry: ToolRegistry,
  manager: KnowledgeManager,
  defaultProjectId: string,
): void {
  for (const tool of createKnowledgeTools(manager, defaultProjectId)) {
    registry.register(tool);
  }
}
