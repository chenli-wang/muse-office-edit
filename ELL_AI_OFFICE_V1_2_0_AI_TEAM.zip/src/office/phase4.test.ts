import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { ProviderError } from "./errors.ts";
import { AnthropicProvider, ANTHROPIC_MODEL_ID } from "./anthropic-provider.ts";
import { OpenAIProvider, OPENAI_MODEL_ID } from "./openai-provider.ts";
import { resolveEmployeeBindings, bindingFor } from "./employee-bindings.ts";
import { createProviderRegistry } from "./provider-registry.ts";
import { createOfficeRuntime, replaceOffice } from "./runtime.ts";
import { handleCreateTask, handleGetTask, handleCancelTask } from "./http.ts";
import { MultiAgentOrchestrator } from "./multi-agent-orchestrator.ts";
import { createMultiAgentRoster } from "./employees.ts";
import { MockProvider } from "./providers.ts";

function jsonResponse(status: number, body: unknown): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

describe("AnthropicProvider", () => {
  it("is disabled without key", async () => {
    const p = new AnthropicProvider({});
    assert.equal(p.isConfigured(), false);
    await assert.rejects(
      () => p.generate({ model: ANTHROPIC_MODEL_ID, systemPrompt: "s", userPrompt: "u" }),
      (e: unknown) => e instanceof ProviderError && e.code === "AUTH",
    );
  });

  it("maps Messages API success", async () => {
    let url = "";
    let key = "";
    const p = new AnthropicProvider({
      apiKey: "test-key",
      fetchImpl: (async (input, init) => {
        url = String(input);
        key = String((init?.headers as Record<string, string>)?.["x-api-key"] ?? "");
        return jsonResponse(200, {
          content: [{ type: "text", text: "hello anthropic" }],
          model: "claude-test",
          stop_reason: "end_turn",
          usage: { input_tokens: 3, output_tokens: 2 },
        });
      }) as typeof fetch,
    });
    const r = await p.generate({
      model: ANTHROPIC_MODEL_ID,
      systemPrompt: "sys",
      userPrompt: "hi",
    });
    assert.match(url, /api\.anthropic\.com\/v1\/messages/);
    assert.equal(key, "test-key");
    assert.equal(r.text, "hello anthropic");
    assert.equal(r.provider, "anthropic");
    assert.equal(r.usage?.totalTokens, 5);
  });

  it("maps 429 and respects abort", async () => {
    const p = new AnthropicProvider({
      apiKey: "k",
      fetchImpl: (async () =>
        jsonResponse(429, { error: { message: "rate limited" } })) as typeof fetch,
    });
    await assert.rejects(
      () => p.generate({ model: ANTHROPIC_MODEL_ID, systemPrompt: "s", userPrompt: "u" }),
      (e: unknown) => e instanceof ProviderError && e.code === "RATE_LIMIT",
    );
    const c = new AbortController();
    c.abort();
    const p2 = new AnthropicProvider({
      apiKey: "k",
      fetchImpl: (async () => jsonResponse(200, { content: [{ type: "text", text: "x" }] })) as typeof fetch,
    });
    await assert.rejects(
      () =>
        p2.generate({
          model: ANTHROPIC_MODEL_ID,
          systemPrompt: "s",
          userPrompt: "u",
          signal: c.signal,
        }),
      (e: unknown) => e instanceof ProviderError && e.code === "TIMEOUT",
    );
  });
});

describe("OpenAIProvider", () => {
  it("is disabled without key", async () => {
    const p = new OpenAIProvider({});
    assert.equal(p.isConfigured(), false);
    await assert.rejects(
      () => p.generate({ model: OPENAI_MODEL_ID, systemPrompt: "s", userPrompt: "u" }),
      (e: unknown) => e instanceof ProviderError && e.code === "AUTH",
    );
  });

  it("maps chat completions success", async () => {
    let url = "";
    const p = new OpenAIProvider({
      apiKey: "sk-test",
      fetchImpl: (async (input) => {
        url = String(input);
        return jsonResponse(200, {
          choices: [{ message: { content: "hello openai" }, finish_reason: "stop" }],
          model: "gpt-test",
          usage: { prompt_tokens: 1, completion_tokens: 2, total_tokens: 3 },
        });
      }) as typeof fetch,
    });
    const r = await p.generate({
      model: OPENAI_MODEL_ID,
      systemPrompt: "s",
      userPrompt: "u",
    });
    assert.match(url, /api\.openai\.com\/v1\/chat\/completions/);
    assert.equal(r.text, "hello openai");
    assert.equal(r.provider, "openai");
    assert.equal(r.usage?.totalTokens, 3);
  });
});

describe("employee bindings", () => {
  it("mock bindings map all employees to mock", () => {
    const b = resolveEmployeeBindings("mock");
    assert.equal(bindingFor("developer", b).providerId, "mock");
    assert.equal(bindingFor("ceo", b).providerId, "mock");
  });

  it("live bindings target anthropic/gemini/xai/openai", () => {
    const b = resolveEmployeeBindings("live");
    assert.equal(bindingFor("developer", b).providerId, "anthropic");
    assert.equal(bindingFor("researcher", b).providerId, "gemini");
    assert.equal(bindingFor("automation", b).providerId, "xai");
    assert.equal(bindingFor("ceo", b).providerId, "openai");
  });
});

describe("async multi-agent lifecycle", () => {
  it("create returns before completion; waitFor finishes", async () => {
    const registry = createProviderRegistry({
      primary: new MockProvider(),
      autoDetectXai: false,
      autoDetectGemini: false,
      autoDetectAnthropic: false,
      autoDetectOpenAI: false,
    });
    const o = new MultiAgentOrchestrator({
      employees: createMultiAgentRoster(),
      router: registry.router,
      bindings: resolveEmployeeBindings("mock"),
    });
    const created = o.create("Async audit");
    assert.ok(["planned", "running", "pending"].includes(created.status));
    assert.equal(created.finalResult, null);
    const done = await o.waitFor(created.id);
    assert.equal(done.status, "completed");
    assert.ok(done.finalResult);
  });

  it("POST multi returns non-terminal; GET eventually completes", async () => {
    replaceOffice(
      createOfficeRuntime({
        delays: { planningMs: 0, assignMs: 0, workMs: 0, synthMs: 0 },
      }),
    );
    const created = await handleCreateTask({ objective: "HTTP async multi", mode: "multi" });
    assert.equal(created.status, 201);
    const task = created.body as { id: string; status: string };
    assert.notEqual(task.status, "completed");
    // Poll until done
    let status = task.status;
    for (let i = 0; i < 50; i++) {
      const got = await handleGetTask(task.id);
      status = (got.body as { status: string }).status;
      if (status === "completed" || status === "failed" || status === "cancelled") break;
      await new Promise((r) => setTimeout(r, 10));
    }
    assert.equal(status, "completed");
  });

  it("in-flight cancel sets cancelled and is idempotent", async () => {
    // Slow mock: delay generate
    const slow = new MockProvider();
    const original = slow.generate.bind(slow);
    slow.generate = async (req) => {
      await new Promise((r) => setTimeout(r, 80));
      return original(req);
    };
    const registry = createProviderRegistry({
      primary: slow,
      autoDetectXai: false,
      autoDetectGemini: false,
      autoDetectAnthropic: false,
      autoDetectOpenAI: false,
    });
    const o = new MultiAgentOrchestrator({
      employees: createMultiAgentRoster(),
      router: registry.router,
    });
    const created = o.create("Cancel me");
    assert.ok(created.status !== "completed");
    const cancelled = await o.cancel(created.id);
    assert.equal(cancelled.status, "cancelled");
    const again = await o.cancel(created.id);
    assert.equal(again.status, "cancelled");
    const after = await o.waitFor(created.id);
    assert.equal(after.status, "cancelled");
    assert.equal(after.finalResult, null);
  });

  it("cancel completed multi returns conflict via HTTP", async () => {
    replaceOffice(
      createOfficeRuntime({
        delays: { planningMs: 0, assignMs: 0, workMs: 0, synthMs: 0 },
      }),
    );
    const created = await handleCreateTask({ objective: "finish first", mode: "multi" });
    const id = (created.body as { id: string }).id;
    for (let i = 0; i < 50; i++) {
      const got = await handleGetTask(id);
      if ((got.body as { status: string }).status === "completed") break;
      await new Promise((r) => setTimeout(r, 10));
    }
    const cancel = await handleCancelTask(id);
    assert.equal(cancel.status, 409);
  });

  it("secret-api-key-123 never in task snapshot", async () => {
    const registry = createProviderRegistry({
      primary: new MockProvider(),
      autoDetectXai: false,
      autoDetectGemini: false,
      autoDetectAnthropic: false,
      autoDetectOpenAI: false,
    });
    registry.health.recordFailure(
      "anthropic",
      new ProviderError("AUTH", "bad secret-api-key-123", false),
    );
    const blob = JSON.stringify(registry.listHealth());
    assert.equal(blob.includes("secret-api-key-123"), false);
  });
});

describe("single mode still synchronous for BC", () => {
  it("zero-delay single completes on createTask", async () => {
    const runtime = createOfficeRuntime({
      delays: { planningMs: 0, assignMs: 0, workMs: 0, synthMs: 0 },
    });
    const task = await runtime.createTask({ objective: "sync single" });
    assert.equal(task.status, "completed");
  });
});
