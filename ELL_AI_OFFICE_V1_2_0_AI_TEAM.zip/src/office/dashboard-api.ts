/**
 * Safe public dashboard state — no secrets, no host paths, no credentials.
 */

import type { Employee, OfficeEvent, Task, ProviderStatus } from "./types.ts";
import { getOffice } from "./runtime.ts";
import type { ContextEntry } from "./memory/project-context-store.ts";
import type { ToolAuditEvent } from "./tools/tool-registry.ts";

export type DashboardEmployeeState =
  | "idle"
  | "queued"
  | "thinking"
  | "working"
  | "waiting"
  | "completed"
  | "failed"
  | "cancelled"
  | "rate_limited"
  | "unavailable";

export interface DashboardEmployeeCard {
  id: string;
  displayName: string;
  role: string;
  status: DashboardEmployeeState;
  provider: string;
  model: string;
  currentTaskId: string | null;
  currentObjective: string | null;
  latestSummary: string | null;
  error: string | null;
  isSynthesizer: boolean;
}

export interface DashboardMemorySummary {
  projectId: string;
  title: string;
  entryCount: number;
  byType: Record<string, number>;
  recent: Array<{
    id: string;
    type: string;
    content: string;
    sourceEmployeeId: string | null;
    tags: string[];
    createdAt: string;
  }>;
}

export interface DashboardToolActivity {
  id: string;
  toolName: string;
  success: boolean;
  taskId: string | null;
  employeeId: string | null;
  meta: Record<string, unknown>;
  error?: string;
  createdAt: string;
}

export interface DashboardSnapshot {
  service: string;
  generatedAt: string;
  workspaceId: string;
  currentTask: Task | null;
  tasks: Task[];
  employees: DashboardEmployeeCard[];
  providers: ProviderStatus[];
  events: OfficeEvent[];
  memory: DashboardMemorySummary;
  tools: DashboardToolActivity[];
  toolCatalog: Array<{ name: string; description: string; permission: string }>;
}

const MAX_EVENTS = 80;
const MAX_MEMORY = 12;
const MAX_TOOL_AUDITS = 30;

function mapEmployeeStatus(
  emp: Employee,
  activeTask: Task | null,
): DashboardEmployeeState {
  if (emp.status === "offline") return "unavailable";
  if (emp.quotaStatus === "rate_limited") return "rate_limited";
  if (!activeTask) {
    if (emp.status === "idle") return "idle";
    return emp.status === "working" ? "idle" : "idle";
  }
  const assigned = activeTask.assignedEmployeeIds.includes(emp.id);
  if (!assigned) return "idle";
  if (activeTask.status === "completed") return "completed";
  if (activeTask.status === "failed") return "failed";
  if (activeTask.status === "cancelled") return "cancelled";
  if (activeTask.status === "planning") return "queued";
  if (activeTask.status === "assigned") return "queued";
  if (activeTask.status === "running") {
    // Subtask status if present
    const sub = activeTask.subtasks.find((s) => s.employeeId === emp.id);
    if (sub?.status === "completed") return "completed";
    if (sub?.status === "failed") return "failed";
    if (sub?.status === "cancelled") return "cancelled";
    if (sub?.status === "running") return emp.id === "ceo" ? "thinking" : "working";
    if (sub?.status === "assigned") return "waiting";
    return emp.id === "ceo" ? "waiting" : "working";
  }
  if (activeTask.status === "synthesizing") {
    return emp.id === "ceo" ? "thinking" : "completed";
  }
  return "idle";
}

function sanitizeText(s: string, max = 400): string {
  return s
    .replace(/Bearer\s+[A-Za-z0-9._\-]+/gi, "[REDACTED]")
    .replace(/secret-api-key-[A-Za-z0-9\-]+/gi, "[REDACTED]")
    .replace(/\b(sk|xai|AIza)[-_A-Za-z0-9]{8,}/g, "[REDACTED]")
    .slice(0, max);
}

function activeTaskFrom(tasks: Task[]): Task | null {
  const active = tasks.find((t) =>
    ["created", "planning", "assigned", "running", "synthesizing"].includes(t.status),
  );
  return active ?? tasks[0] ?? null;
}

export function buildEmployeeCards(
  employees: Employee[],
  tasks: Task[],
): DashboardEmployeeCard[] {
  const current = activeTaskFrom(tasks);
  return employees.map((emp) => {
    const output = current?.outputs.find((o) => o.employeeId === emp.id);
    const err =
      current?.error && current.assignedEmployeeIds.includes(emp.id)
        ? sanitizeText(current.error.message, 200)
        : null;
    return {
      id: emp.id,
      displayName: emp.displayName,
      role: emp.role,
      status: mapEmployeeStatus(emp, current),
      provider: emp.provider ?? "unknown",
      model: emp.model ?? "unknown",
      currentTaskId: current && current.assignedEmployeeIds.includes(emp.id) ? current.id : null,
      currentObjective:
        current && current.assignedEmployeeIds.includes(emp.id)
          ? sanitizeText(current.objective, 120)
          : null,
      latestSummary: output ? sanitizeText(output.summary, 240) : null,
      error: err,
      isSynthesizer: emp.id === "ceo",
    };
  });
}

export function buildMemorySummary(
  projectId: string,
  title: string,
  entries: ContextEntry[],
  entryCount: number,
): DashboardMemorySummary {
  const byType: Record<string, number> = {};
  for (const e of entries) {
    byType[e.type] = (byType[e.type] ?? 0) + 1;
  }
  // Recount from full would need store — approximate with snapshot
  return {
    projectId,
    title,
    entryCount,
    byType,
    recent: entries.slice(0, MAX_MEMORY).map((e) => ({
      id: e.id,
      type: e.type,
      content: sanitizeText(e.content, 280),
      sourceEmployeeId: e.sourceEmployeeId,
      tags: e.tags.slice(0, 8),
      createdAt: e.createdAt,
    })),
  };
}

export async function buildDashboardSnapshot(): Promise<DashboardSnapshot> {
  const office = getOffice();
  const [tasks, employees, events, providers] = await Promise.all([
    office.listTasks(),
    office.listAgents(),
    office.listEvents(),
    office.listProviders(),
  ]);

  const snapshot = office.getProjectContextSnapshot(MAX_MEMORY);
  const toolList = office.listTools();

  // Tool audits are internal to registry — approximate from events mentioning tools
  const toolEvents: DashboardToolActivity[] = events
    .filter((e) => e.message.startsWith("tool "))
    .slice(-MAX_TOOL_AUDITS)
    .map((e) => ({
      id: e.id,
      toolName: e.message.replace(/^tool\s+/, "").replace(/\s+ok$/, "").replace(/\s+failed:.*$/, ""),
      success: !e.message.includes("failed"),
      taskId: e.taskId,
      employeeId: e.employeeId,
      meta: {},
      error: e.message.includes("failed") ? sanitizeText(e.message, 160) : undefined,
      createdAt: e.createdAt,
    }));

  const sortedEvents = [...events]
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
    .slice(0, MAX_EVENTS)
    .map((e) => ({
      ...e,
      message: sanitizeText(e.message, 300),
    }));

  return {
    service: "ell-ai-office",
    generatedAt: new Date().toISOString(),
    workspaceId: office.getWorkspaceId(),
    currentTask: activeTaskFrom(tasks),
    tasks: tasks.slice(0, 20),
    employees: buildEmployeeCards(employees, tasks),
    providers,
    events: sortedEvents,
    memory: buildMemorySummary(
      snapshot.projectId,
      snapshot.title,
      snapshot.entries,
      snapshot.entryCount,
    ),
    tools: toolEvents,
    toolCatalog: toolList.map((t) => ({
      name: t.name,
      description: t.description,
      permission: t.permission,
    })),
  };
}
