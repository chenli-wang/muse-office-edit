/**
 * ELL AI Office v1.0 centralized configuration.
 * Secrets come from environment only — never hardcode keys.
 */

import type { CostMode, CostClass } from "../manager/cost-modes.ts";
import type { BindingMode } from "../employee-bindings.ts";

export const ELL_VERSION = "1.0.0";
export const ELL_PHASE = 15;

export type ExecutionMode = "mock" | "live";

export interface ProviderConfigEntry {
  providerId: string;
  displayName: string;
  /** Explicit cost classification — never assumed. */
  costClass: CostClass;
  enabled: boolean;
  /** Env var name that holds the API key (not the value). */
  apiKeyEnv?: string;
  defaultModel?: string;
  priority?: number;
}

export interface EmployeeConfigEntry {
  employeeId: string;
  displayName: string;
  role: string;
  providerId: string;
  modelId: string;
  enabled: boolean;
}

export interface EllLimitsConfig {
  maxPlanSteps: number;
  maxAgentExecutions: number;
  maxToolCalls: number;
  maxRetries: number;
  maxDurationMs: number;
  maxRepairAttempts: number;
  maxProviderCalls: number;
}

export interface EllConfig {
  version: string;
  phase: number;
  executionMode: ExecutionMode;
  costMode: CostMode;
  /** When FREE_FIRST, allow paid providers as fallback if true. */
  paidFallback: boolean;
  projectId: string;
  workspaceRoot?: string;
  providers: ProviderConfigEntry[];
  employees: EmployeeConfigEntry[];
  limits: EllLimitsConfig;
  /** Explicit cost class overrides (providerId → class). */
  costClassByProvider: Record<string, CostClass>;
}

export const DEFAULT_LIMITS: EllLimitsConfig = {
  maxPlanSteps: 12,
  maxAgentExecutions: 16,
  maxToolCalls: 40,
  maxRetries: 2,
  maxDurationMs: 120_000,
  maxRepairAttempts: 1,
  maxProviderCalls: 40,
};

/** Canonical v1 provider catalog — costClass is configuration, not a promise of free quota. */
export const DEFAULT_PROVIDER_CATALOG: ProviderConfigEntry[] = [
  {
    providerId: "mock",
    displayName: "Mock Provider",
    costClass: "FREE",
    enabled: true,
    defaultModel: "mock:phase1",
    priority: 0,
  },
  {
    providerId: "gemini",
    displayName: "Google Gemini",
    costClass: "PAID",
    enabled: true,
    apiKeyEnv: "GEMINI_API_KEY",
    defaultModel: "gemini-2.0-flash",
    priority: 20,
  },
  {
    providerId: "xai",
    displayName: "xAI Grok",
    costClass: "PAID",
    enabled: true,
    apiKeyEnv: "XAI_API_KEY",
    defaultModel: "grok-2-latest",
    priority: 30,
  },
  {
    providerId: "anthropic",
    displayName: "Anthropic Claude",
    costClass: "PAID",
    enabled: true,
    apiKeyEnv: "ANTHROPIC_API_KEY",
    defaultModel: "claude-sonnet-4-20250514",
    priority: 10,
  },
  {
    providerId: "openai",
    displayName: "OpenAI",
    costClass: "PAID",
    enabled: true,
    apiKeyEnv: "OPENAI_API_KEY",
    defaultModel: "gpt-4o-mini",
    priority: 40,
  },
];

export const DEFAULT_EMPLOYEE_CATALOG: EmployeeConfigEntry[] = [
  {
    employeeId: "ceo",
    displayName: "CEO",
    role: "Chief Executive",
    providerId: "openai",
    modelId: "gpt-4o-mini",
    enabled: true,
  },
  {
    employeeId: "pm",
    displayName: "Project Manager",
    role: "Project Manager",
    providerId: "anthropic",
    modelId: "claude-sonnet-4-20250514",
    enabled: true,
  },
  {
    employeeId: "developer",
    displayName: "Developer Agent",
    role: "Developer",
    providerId: "anthropic",
    modelId: "claude-sonnet-4-20250514",
    enabled: true,
  },
  {
    employeeId: "researcher",
    displayName: "Researcher Agent",
    role: "Researcher",
    providerId: "gemini",
    modelId: "gemini-2.0-flash",
    enabled: true,
  },
  {
    employeeId: "automation",
    displayName: "Automation Agent",
    role: "Automation",
    providerId: "xai",
    modelId: "grok-2-latest",
    enabled: true,
  },
  {
    employeeId: "jira",
    displayName: "Jira Agent",
    role: "Task Tracker",
    providerId: "openai",
    modelId: "gpt-4o-mini",
    enabled: true,
  },
];

function env(name: string): string | undefined {
  try {
    const v = process.env[name];
    return v && v.trim() ? v.trim() : undefined;
  } catch {
    return undefined;
  }
}

function parseCostMode(raw: string | undefined): CostMode {
  if (raw === "FREE_ONLY" || raw === "FREE_FIRST" || raw === "PAID") return raw;
  return "FREE_FIRST";
}

function parseExecutionMode(raw: string | undefined): ExecutionMode {
  if (raw === "live") return "live";
  return "mock";
}

/**
 * Load ELL config from environment + defaults.
 * Does not embed secret values — only env var *names* for keys.
 */
export function loadEllConfig(overrides?: Partial<EllConfig>): EllConfig {
  const executionMode = parseExecutionMode(
    overrides?.executionMode ?? env("ELL_EXECUTION_MODE"),
  );
  const costMode = parseCostMode(overrides?.costMode ?? env("ELL_COST_MODE"));
  const paidFallback =
    overrides?.paidFallback ?? env("ELL_PAID_FALLBACK") === "true";

  const providers = (overrides?.providers ?? DEFAULT_PROVIDER_CATALOG).map((p) => ({
    ...p,
  }));
  const employees = (overrides?.employees ?? DEFAULT_EMPLOYEE_CATALOG).map((e) => ({
    ...e,
  }));

  // In mock mode, employee bindings still list live provider ids as targets,
  // but execution uses mock unless live keys + live mode.
  const costClassByProvider: Record<string, CostClass> = {
    ...Object.fromEntries(providers.map((p) => [p.providerId, p.costClass])),
    ...(overrides?.costClassByProvider ?? {}),
  };

  // Allow explicit FREE overrides via env e.g. ELL_COST_CLASS_gemini=FREE
  for (const p of providers) {
    const override = env(`ELL_COST_CLASS_${p.providerId}`);
    if (override === "FREE" || override === "PAID" || override === "UNKNOWN") {
      costClassByProvider[p.providerId] = override;
      p.costClass = override;
    }
  }

  return {
    version: ELL_VERSION,
    phase: ELL_PHASE,
    executionMode,
    costMode,
    paidFallback,
    projectId: overrides?.projectId ?? env("ELL_PROJECT_ID") ?? "default",
    workspaceRoot: overrides?.workspaceRoot ?? env("ELL_WORKSPACE_ROOT"),
    providers,
    employees,
    limits: { ...DEFAULT_LIMITS, ...overrides?.limits },
    costClassByProvider,
  };
}

/** Binding mode derived from execution mode. */
export function bindingModeFromConfig(cfg: EllConfig): BindingMode {
  return cfg.executionMode === "live" ? "live" : "mock";
}

/** Public-safe snapshot (no secrets). */
export function publicConfigView(cfg: EllConfig): Record<string, unknown> {
  return {
    version: cfg.version,
    phase: cfg.phase,
    executionMode: cfg.executionMode,
    costMode: cfg.costMode,
    paidFallback: cfg.paidFallback,
    projectId: cfg.projectId,
    limits: cfg.limits,
    providers: cfg.providers.map((p) => ({
      providerId: p.providerId,
      displayName: p.displayName,
      costClass: p.costClass,
      enabled: p.enabled,
      defaultModel: p.defaultModel,
      configured: p.apiKeyEnv ? Boolean(env(p.apiKeyEnv)) : p.providerId === "mock",
      // never include apiKeyEnv values
    })),
    employees: cfg.employees.map((e) => ({
      employeeId: e.employeeId,
      displayName: e.displayName,
      role: e.role,
      providerId: e.providerId,
      modelId: e.modelId,
      enabled: e.enabled,
    })),
  };
}
