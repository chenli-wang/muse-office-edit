/**
 * Public provider + employee registries for dashboard (no secrets).
 */

import type { EllConfig } from "./ell-config.ts";
import { loadEllConfig } from "./ell-config.ts";
import type { OfficeRuntime } from "../runtime.ts";
import { validateStartup, type ProviderStartupStatus } from "./startup.ts";

export interface PublicProviderRecord {
  providerId: string;
  displayName: string;
  costClass: string;
  enabled: boolean;
  availability: string;
  capabilities: string[];
  supportedModels: string[];
  health: string;
  configurationStatus: ProviderStartupStatus;
}

export interface PublicEmployeeRecord {
  employeeId: string;
  displayName: string;
  role: string;
  providerId: string;
  modelId: string;
  capabilities: string[];
  enabled: boolean;
  status: string;
}

export function buildProviderRegistry(
  cfg: EllConfig,
  runtime?: OfficeRuntime,
): PublicProviderRecord[] {
  const startup = validateStartup(cfg);
  const healthRows = new Map<string, { availability: string }>();
  // runtime.listProviders is async — caller may pass prefetched; sync path uses startup only
  void runtime;
  return cfg.providers.map((p) => {
    const st = startup.providers.find((x) => x.providerId === p.providerId);
    return {
      providerId: p.providerId,
      displayName: p.displayName,
      costClass: p.costClass,
      enabled: p.enabled,
      availability: st?.status === "READY" ? "available" : "unavailable",
      capabilities: ["text"],
      supportedModels: p.defaultModel ? [p.defaultModel] : [],
      health: st?.status ?? "UNKNOWN",
      configurationStatus: st?.status ?? "ERROR",
    };
  });
}

export async function buildProviderRegistryAsync(
  cfg: EllConfig,
  runtime: OfficeRuntime,
): Promise<PublicProviderRecord[]> {
  const base = buildProviderRegistry(cfg);
  try {
    const live = await runtime.listProviders();
    return base.map((p) => {
      const row = live.find((l) => l.id === p.providerId);
      if (!row) return p;
      return {
        ...p,
        availability: row.availability,
        supportedModels: row.models?.map((m) => m.id) ?? p.supportedModels,
        health: row.availability,
      };
    });
  } catch {
    return base;
  }
}

export function buildEmployeeRegistry(
  cfg: EllConfig,
  runtime?: OfficeRuntime,
): PublicEmployeeRecord[] {
  void runtime;
  return cfg.employees.map((e) => ({
    employeeId: e.employeeId,
    displayName: e.displayName,
    role: e.role,
    providerId: e.providerId,
    modelId: e.modelId,
    capabilities:
      e.employeeId === "ceo"
        ? ["synthesis", "decision", "review"]
        : e.employeeId === "pm"
          ? ["planning", "coordination", "tracking"]
          : e.employeeId === "developer"
            ? ["code", "implementation"]
            : e.employeeId === "researcher"
              ? ["research", "analysis"]
              : e.employeeId === "automation"
                ? ["automation", "integration"]
                : e.employeeId === "jira"
                  ? ["tracking", "monitoring"]
                  : ["general"],
    enabled: e.enabled,
    status: "idle",
  }));
}

export function getDefaultRegistries() {
  const cfg = loadEllConfig();
  return {
    config: cfg,
    providers: buildProviderRegistry(cfg),
    employees: buildEmployeeRegistry(cfg),
    startup: validateStartup(cfg),
  };
}
