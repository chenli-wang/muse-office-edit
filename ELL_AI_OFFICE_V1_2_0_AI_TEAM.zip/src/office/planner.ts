/**
 * Deterministic static task planner (Phase 3 MVP).
 * Does NOT call an LLM to decompose tasks.
 */

import type { Employee } from "./types.ts";

export type PlanStepKind = "parallel" | "synthesis";

export interface PlanStep {
  id: string;
  employeeId: string;
  kind: PlanStepKind;
  /** Assignment for this employee. */
  objective: string;
  /** Step ids that must complete before this step may run. */
  dependsOn: string[];
  /** If true, failure of this step blocks dependents. */
  required: boolean;
}

export interface ExecutionPlan {
  strategy: "single-employee" | "multi-agent-static";
  rationale: string;
  steps: PlanStep[];
}

const PARALLEL_OBJECTIVES: Record<string, string> = {
  developer:
    "Inspect the implementation and identify engineering issues, bugs, and maintainability risks related to the user objective.",
  researcher:
    "Research relevant technical requirements, constraints, and alternative approaches related to the user objective. Distinguish verified facts from assumptions.",
  automation:
    "Identify automation opportunities: repetitive workflows, integrations, and scheduled jobs related to the user objective.",
  ceo:
    "Review all upstream agent findings. Synthesize a final decision and recommendation, note disagreements, and cite which agent contributed major claims.",
};

/**
 * Build a deterministic multi-agent plan for the given roster.
 * Parallel: Developer, Researcher, Automation. Synthesis: CEO depends on all three.
 */
export function planMultiAgent(objective: string, employees: Employee[]): ExecutionPlan {
  const byId = new Map(employees.map((e) => [e.id, e]));
  const parallelIds = ["developer", "researcher", "automation"].filter((id) => byId.has(id));
  const steps: PlanStep[] = parallelIds.map((employeeId) => ({
    id: `step_${employeeId}`,
    employeeId,
    kind: "parallel",
    objective: `${PARALLEL_OBJECTIVES[employeeId] ?? "Analyze the objective."}\n\nUser objective:\n${objective}`,
    dependsOn: [],
    required: false,
  }));

  if (byId.has("ceo")) {
    steps.push({
      id: "step_ceo",
      employeeId: "ceo",
      kind: "synthesis",
      objective: `${PARALLEL_OBJECTIVES.ceo}\n\nUser objective:\n${objective}`,
      dependsOn: parallelIds.map((id) => `step_${id}`),
      required: true,
    });
  }

  return {
    strategy: "multi-agent-static",
    rationale:
      "Static Phase 3 plan: Developer + Researcher + Automation in parallel, then CEO synthesis over collected results.",
    steps,
  };
}

export function planSingleEmployee(
  objective: string,
  employeeId: string,
): ExecutionPlan {
  return {
    strategy: "single-employee",
    rationale: `Phase 1 single-employee path via ${employeeId}.`,
    steps: [
      {
        id: `step_${employeeId}`,
        employeeId,
        kind: "parallel",
        objective,
        dependsOn: [],
        required: true,
      },
    ],
  };
}
