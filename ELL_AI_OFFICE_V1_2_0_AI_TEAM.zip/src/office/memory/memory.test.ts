import assert from "node:assert/strict";
import { describe, it } from "node:test";
import {
  InMemoryProjectContextStore,
  sanitizeContextContent,
} from "./project-context-store.ts";
import { ContextManager } from "./context-manager.ts";
import { createOfficeRuntime } from "../runtime.ts";

describe("ProjectContextStore", () => {
  it("create project context", () => {
    const store = new InMemoryProjectContextStore();
    const p = store.createProject("proj-a", "Alpha");
    assert.equal(p.projectId, "proj-a");
    assert.equal(store.getProject("proj-a")?.title, "Alpha");
  });

  it("entry creation and update", () => {
    const store = new InMemoryProjectContextStore();
    store.createProject("p1");
    const e = store.addEntry({
      projectId: "p1",
      type: "finding",
      content: "Latency spikes under load",
      sourceEmployeeId: "developer",
      tags: ["perf"],
    });
    assert.equal(e.type, "finding");
    assert.ok(e.id);
    assert.equal(store.getProject("p1")?.entryCount, 1);
  });

  it("retrieval ordering recent-first", () => {
    const store = new InMemoryProjectContextStore();
    store.createProject("p1");
    store.addEntry({ projectId: "p1", type: "note", content: "first" });
    store.addEntry({ projectId: "p1", type: "note", content: "second" });
    const entries = store.getEntries({ projectId: "p1", limit: 10 });
    assert.equal(entries[0].content, "second");
    assert.equal(entries[1].content, "first");
  });

  it("type filtering", () => {
    const store = new InMemoryProjectContextStore();
    store.createProject("p1");
    store.addEntry({ projectId: "p1", type: "decision", content: "use postgres" });
    store.addEntry({ projectId: "p1", type: "issue", content: "flaky test" });
    const decisions = store.getEntries({ projectId: "p1", type: "decision" });
    assert.equal(decisions.length, 1);
    assert.equal(decisions[0].type, "decision");
  });

  it("tag filtering", () => {
    const store = new InMemoryProjectContextStore();
    store.createProject("p1");
    store.addEntry({
      projectId: "p1",
      type: "finding",
      content: "a",
      tags: ["security"],
    });
    store.addEntry({
      projectId: "p1",
      type: "finding",
      content: "b",
      tags: ["perf"],
    });
    const sec = store.getEntries({ projectId: "p1", tags: ["security"] });
    assert.equal(sec.length, 1);
    assert.equal(sec[0].content, "a");
  });

  it("bounded retrieval", () => {
    const store = new InMemoryProjectContextStore({
      limits: { maxRetrieval: 3, maxEntriesPerProject: 50 },
    });
    store.createProject("p1");
    for (let i = 0; i < 10; i++) {
      store.addEntry({ projectId: "p1", type: "note", content: `n${i}` });
    }
    const entries = store.getEntries({ projectId: "p1", limit: 100 });
    assert.equal(entries.length, 3);
  });

  it("project isolation", () => {
    const store = new InMemoryProjectContextStore();
    store.createProject("a");
    store.createProject("b");
    store.addEntry({ projectId: "a", type: "note", content: "only-a" });
    store.addEntry({ projectId: "b", type: "note", content: "only-b" });
    assert.equal(store.getEntries({ projectId: "a" })[0].content, "only-a");
    assert.equal(store.getEntries({ projectId: "b" })[0].content, "only-b");
    assert.equal(store.getEntries({ projectId: "a" }).length, 1);
  });

  it("sanitization strips secrets", () => {
    const cleaned = sanitizeContextContent(
      "token Bearer sk-abc123secret and secret-api-key-123",
      4000,
    );
    assert.equal(cleaned.includes("secret-api-key-123"), false);
    assert.equal(cleaned.includes("sk-abc"), false);
  });

  it("size limits on content and entry count", () => {
    const store = new InMemoryProjectContextStore({
      limits: { maxContentLength: 20, maxEntriesPerProject: 2 },
    });
    store.createProject("p1");
    const e = store.addEntry({
      projectId: "p1",
      type: "note",
      content: "x".repeat(100),
    });
    assert.ok(e.content.length <= 20);
    store.addEntry({ projectId: "p1", type: "note", content: "one" });
    store.addEntry({ projectId: "p1", type: "note", content: "two" });
    store.addEntry({ projectId: "p1", type: "note", content: "three" });
    assert.equal(store.getProject("p1")?.entryCount, 2);
  });
});

describe("ContextManager", () => {
  it("snapshot and events", () => {
    const cm = new ContextManager({ defaultProjectId: "demo" });
    cm.addEntry({
      projectId: "demo",
      type: "decision",
      content: "Ship Phase 6",
      sourceEmployeeId: "ceo",
    });
    const snap = cm.snapshotForTask("demo", { limit: 5 });
    assert.equal(snap.projectId, "demo");
    assert.ok(snap.promptBlock.includes("Ship Phase 6"));
    const types = cm.listEvents().map((e) => e.type);
    assert.ok(types.includes("context.updated") || types.includes("context.created"));
    assert.ok(types.includes("context.retrieved"));
  });

  it("recordAgentContribution", () => {
    const cm = new ContextManager({ defaultProjectId: "p" });
    const e = cm.recordAgentContribution({
      projectId: "p",
      taskId: "task_1",
      employeeId: "developer",
      type: "finding",
      content: "Missing error boundary",
      tags: ["ui"],
    });
    assert.equal(e.sourceEmployeeId, "developer");
    assert.equal(e.taskId, "task_1");
  });
});

describe("runtime memory integration", () => {
  it("task context snapshot and explicit add", () => {
    const runtime = createOfficeRuntime({
      projectId: "office-demo",
      delays: { planningMs: 0, assignMs: 0, workMs: 0, synthMs: 0 },
    });
    runtime.addProjectContext({
      type: "issue",
      content: "Flaky cancel race",
      employeeId: "automation",
      tags: ["runtime"],
    });
    const snap = runtime.getProjectContextSnapshot(10);
    assert.equal(snap.projectId, "office-demo");
    assert.ok(snap.entries.some((e) => e.type === "issue"));
  });

  it("multi-agent records findings into shared context", async () => {
    const runtime = createOfficeRuntime({
      projectId: "multi-mem",
      delays: { planningMs: 0, assignMs: 0, workMs: 0, synthMs: 0 },
    });
    const task = await runtime.createTask({
      objective: "Audit memory layer",
      mode: "multi",
    });
    for (let i = 0; i < 50; i++) {
      const t = await runtime.getTask(task.id);
      if (t.status === "completed" || t.status === "failed") break;
      await new Promise((r) => setTimeout(r, 15));
    }
    const snap = runtime.getProjectContextSnapshot(40);
    assert.ok(snap.entryCount >= 1);
    assert.ok(
      snap.entries.some((e) => e.type === "task_summary" || e.type === "finding"),
    );
  });
});
