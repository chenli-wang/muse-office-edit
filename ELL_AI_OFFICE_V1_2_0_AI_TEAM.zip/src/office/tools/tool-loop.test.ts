import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { mkdtempSync, writeFileSync, rmSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";
import {
  parseAssistantTurn,
  sanitizeToolResultPayload,
  runToolLoop,
  DEFAULT_EMPLOYEE_PERMISSIONS,
} from "./tool-loop.ts";
import { ToolRegistry } from "./tool-registry.ts";
import { WorkspaceScope } from "./workspace-scope.ts";
import { registerProjectTools } from "./project-tools.ts";
import { ProviderRouter } from "../provider-router.ts";
import { ProviderHealthStore, withHealthTracking } from "../provider-health.ts";
import type { ProviderAdapter, GenerateRequest, GenerateResponse } from "../providers.ts";
import { ProviderError } from "../errors.ts";
import type { ProviderAvailability } from "../types.ts";

function scriptedProvider(responses: string[]): ProviderAdapter & { calls: number } {
  let calls = 0;
  return {
    id: "mock",
    label: "scripted",
    capabilities: {
      text: true,
      code: true,
      streaming: false,
      tools: false,
      vision: false,
      jsonMode: false,
    },
    get calls() {
      return calls;
    },
    getAvailability(): ProviderAvailability {
      return "available";
    },
    listModels() {
      return [
        {
          id: "mock:phase1",
          provider: "mock",
          capabilities: ["text"],
          contextWindow: null,
          costClass: "free",
          availability: "available",
          label: "mock",
        },
      ];
    },
    async generate(_req: GenerateRequest): Promise<GenerateResponse> {
      const text = responses[Math.min(calls, responses.length - 1)] ?? "FINAL {}";
      calls += 1;
      return { text, model: "mock:phase1", provider: "mock", latencyMs: 1 };
    },
  };
}

function makeRouter(adapter: ProviderAdapter) {
  const health = new ProviderHealthStore();
  health.register({
    providerId: adapter.id,
    label: adapter.label,
    configured: true,
    availability: "available",
  });
  const tracked = withHealthTracking(adapter, health);
  return new ProviderRouter({
    adapters: [tracked],
    primary: tracked,
    health,
  });
}

function makeTools(root: string) {
  const reg = new ToolRegistry();
  registerProjectTools(reg, new WorkspaceScope({ root }));
  return reg;
}

describe("parseAssistantTurn", () => {
  it("parses TOOL_CALL", () => {
    const p = parseAssistantTurn('TOOL_CALL {"name":"project.read","arguments":{"path":"a.ts"}}');
    assert.equal(p.kind, "tool_call");
    if (p.kind === "tool_call") {
      assert.equal(p.call.name, "project.read");
      assert.equal(p.call.arguments.path, "a.ts");
    }
  });

  it("parses FINAL", () => {
    const p = parseAssistantTurn('FINAL {"summary":"done"}');
    assert.equal(p.kind, "final");
  });

  it("plain text treated as final", () => {
    const p = parseAssistantTurn("Just an answer");
    assert.equal(p.kind, "final");
  });

  it("malformed TOOL_CALL JSON", () => {
    const p = parseAssistantTurn("TOOL_CALL {not json");
    assert.equal(p.kind, "malformed");
  });
});

describe("sanitizeToolResultPayload", () => {
  it("redacts secrets and truncates", () => {
    const s = sanitizeToolResultPayload(
      { msg: "Bearer tok_abc secret-api-key-123" },
      40,
    );
    assert.equal(s.includes("secret-api-key-123"), false);
    assert.ok(s.length <= 40 || s.endsWith("…[truncated]"));
  });
});

describe("runToolLoop", () => {
  let root: string;

  function setup(responses: string[]) {
    root = mkdtempSync(join(tmpdir(), "ell-loop-"));
    writeFileSync(join(root, "readme.txt"), "hello tools\n", "utf8");
    const tools = makeTools(root);
    const adapter = scriptedProvider(responses);
    const router = makeRouter(adapter);
    return { tools, router, adapter };
  }

  it("successful single tool call then FINAL", async () => {
    const { tools, router } = setup([
      'TOOL_CALL {"name":"project.read","arguments":{"path":"readme.txt"}}',
      'FINAL {"summary":"read file","findings":["hello"],"confidence":"low"}',
    ]);
    const result = await runToolLoop({
      router,
      tools,
      modelId: "mock:phase1",
      systemPrompt: "sys",
      userObjective: "read readme",
      employeeId: "developer",
      providerId: "mock",
    });
    assert.equal(result.stoppedReason, "final");
    assert.equal(result.toolCalls, 1);
    assert.match(result.finalText, /read file|hello/);
    assert.ok(result.audits.some((a) => a.kind === "tool" && a.success));
  });

  it("multiple tool calls", async () => {
    const { tools, router } = setup([
      'TOOL_CALL {"name":"project.list","arguments":{"path":"."}}',
      'TOOL_CALL {"name":"project.metadata","arguments":{}}',
      'FINAL {"summary":"listed"}',
    ]);
    const result = await runToolLoop({
      router,
      tools,
      modelId: "mock:phase1",
      systemPrompt: "sys",
      userObjective: "explore",
      employeeId: "developer",
      providerId: "mock",
    });
    assert.equal(result.stoppedReason, "final");
    assert.equal(result.toolCalls, 2);
  });

  it("max iterations", async () => {
    const { tools, router } = setup([
      'TOOL_CALL {"name":"project.metadata","arguments":{}}',
    ]);
    const result = await runToolLoop({
      router,
      tools,
      modelId: "mock:phase1",
      systemPrompt: "sys",
      userObjective: "loop",
      employeeId: "developer",
      providerId: "mock",
      limits: { maxIterations: 2, maxRepeatedIdenticalCalls: 10 },
    });
    assert.equal(result.stoppedReason, "max_iterations");
  });

  it("repeated identical calls stop", async () => {
    const { tools, router } = setup([
      'TOOL_CALL {"name":"project.metadata","arguments":{}}',
      'TOOL_CALL {"name":"project.metadata","arguments":{}}',
      'TOOL_CALL {"name":"project.metadata","arguments":{}}',
    ]);
    const result = await runToolLoop({
      router,
      tools,
      modelId: "mock:phase1",
      systemPrompt: "sys",
      userObjective: "repeat",
      employeeId: "developer",
      providerId: "mock",
      limits: { maxIterations: 6, maxRepeatedIdenticalCalls: 2 },
    });
    assert.equal(result.stoppedReason, "repeated_calls");
  });

  it("cancellation", async () => {
    const { tools, router } = setup(['FINAL {"summary":"x"}']);
    const c = new AbortController();
    c.abort();
    const result = await runToolLoop({
      router,
      tools,
      modelId: "mock:phase1",
      systemPrompt: "sys",
      userObjective: "x",
      employeeId: "developer",
      providerId: "mock",
      signal: c.signal,
    });
    assert.equal(result.stoppedReason, "cancelled");
  });

  it("permission denial for write as researcher", async () => {
    const { tools, router } = setup([
      'TOOL_CALL {"name":"project.write","arguments":{"path":"x.txt","content":"no"}}',
      'FINAL {"summary":"denied path"}',
    ]);
    const result = await runToolLoop({
      router,
      tools,
      modelId: "mock:phase1",
      systemPrompt: "sys",
      userObjective: "write",
      employeeId: "researcher",
      permissions: DEFAULT_EMPLOYEE_PERMISSIONS.researcher,
      providerId: "mock",
    });
    assert.equal(result.stoppedReason, "final");
    assert.equal(result.toolCalls, 0);
    assert.ok(result.audits.some((a) => a.kind === "denied"));
  });

  it("unknown tool denied", async () => {
    const { tools, router } = setup([
      'TOOL_CALL {"name":"shell.exec","arguments":{}}',
      'FINAL {"summary":"no shell"}',
    ]);
    const result = await runToolLoop({
      router,
      tools,
      modelId: "mock:phase1",
      systemPrompt: "sys",
      userObjective: "shell",
      employeeId: "developer",
      providerId: "mock",
    });
    assert.ok(result.audits.some((a) => a.kind === "denied" && a.detail.includes("unknown")));
  });

  it("malformed then recovery to FINAL", async () => {
    const { tools, router } = setup([
      "TOOL_CALL {bad",
      'FINAL {"summary":"recovered"}',
    ]);
    const result = await runToolLoop({
      router,
      tools,
      modelId: "mock:phase1",
      systemPrompt: "sys",
      userObjective: "x",
      employeeId: "developer",
      providerId: "mock",
    });
    assert.equal(result.stoppedReason, "final");
    assert.ok(result.audits.some((a) => a.detail.includes("malformed")));
  });

  it("provider error", async () => {
    const health = new ProviderHealthStore();
    const failing: ProviderAdapter = {
      id: "mock",
      label: "fail",
      capabilities: {
        text: true,
        code: false,
        streaming: false,
        tools: false,
        vision: false,
        jsonMode: false,
      },
      getAvailability: () => "available",
      listModels: () => [],
      generate: async () => {
        throw new ProviderError("SERVER_ERROR", "boom", true);
      },
    };
    health.register({
      providerId: "mock",
      label: "fail",
      configured: true,
      availability: "available",
    });
    const tracked = withHealthTracking(failing, health);
    const router = new ProviderRouter({
      adapters: [tracked],
      primary: tracked,
      health,
    });
    root = mkdtempSync(join(tmpdir(), "ell-loop-"));
    const tools = makeTools(root);
    const result = await runToolLoop({
      router,
      tools,
      modelId: "m",
      systemPrompt: "s",
      userObjective: "u",
      employeeId: "developer",
      providerId: "mock",
    });
    assert.equal(result.stoppedReason, "provider_error");
  });

  it("bounded context block accepted", async () => {
    const { tools, router } = setup(['FINAL {"summary":"with context"}']);
    const result = await runToolLoop({
      router,
      tools,
      modelId: "mock:phase1",
      systemPrompt: "sys",
      userObjective: "obj",
      contextBlock: "PROJECT CONTEXT:\n- prior finding",
      employeeId: "developer",
      providerId: "mock",
    });
    assert.equal(result.stoppedReason, "final");
  });

  it("oversized tool result truncated in transcript path", () => {
    const big = { data: "x".repeat(20_000) };
    const s = sanitizeToolResultPayload(big, 100);
    assert.ok(s.includes("[truncated]") || s.length <= 110);
  });
});
