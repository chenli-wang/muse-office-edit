import assert from "node:assert/strict";
import { describe, it, beforeEach, afterEach } from "node:test";
import {
  mkdtempSync,
  rmSync,
  writeFileSync,
  readFileSync,
  existsSync,
  symlinkSync,
  mkdirSync,
} from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { WorkspaceScope } from "./workspace-scope.ts";
import { ToolRegistry } from "./tool-registry.ts";
import { registerProjectTools } from "./project-tools.ts";
import {
  createProjectExecutionServices,
  registerExecutionTools,
} from "./project-execution.ts";
import { validateChangeSetShape, ChangeSetError } from "./change-set.ts";
import { StaticProjectValidator } from "./validation.ts";
import { createOfficeRuntime } from "../runtime.ts";
import { runToolLoop } from "./tool-loop.ts";
import { ProviderRouter } from "../provider-router.ts";
import { ProviderHealthStore, withHealthTracking } from "../provider-health.ts";
import type { ProviderAdapter, GenerateRequest, GenerateResponse } from "../providers.ts";
import type { ProviderAvailability } from "../types.ts";

describe("change set validation", () => {
  it("accepts valid change set", () => {
    const changes = validateChangeSetShape({
      changes: [{ path: "src/a.ts", operation: "create", content: "export const a = 1;\n" }],
    });
    assert.equal(changes.length, 1);
  });

  it("rejects empty / invalid / traversal / oversized", () => {
    assert.throws(() => validateChangeSetShape({ changes: [] }), ChangeSetError);
    assert.throws(
      () =>
        validateChangeSetShape({
          changes: [{ path: "../x", operation: "create", content: "x" }],
        }),
      ChangeSetError,
    );
    assert.throws(
      () =>
        validateChangeSetShape({
          changes: [{ path: "a.ts", operation: "create", content: "x".repeat(300_000) }],
        }),
      ChangeSetError,
    );
  });
});

describe("project execution", () => {
  let root: string;
  let registry: ToolRegistry;
  let services: ReturnType<typeof createProjectExecutionServices>;

  beforeEach(() => {
    root = mkdtempSync(join(tmpdir(), "ell-exec-"));
    writeFileSync(join(root, "existing.ts"), "export const n = 1;\n", "utf8");
    mkdirSync(join(root, "src"));
    const scope = new WorkspaceScope({ root });
    services = createProjectExecutionServices(scope);
    registry = new ToolRegistry();
    registerProjectTools(registry, scope);
    registerExecutionTools(registry, services);
  });

  afterEach(() => {
    rmSync(root, { recursive: true, force: true });
  });

  it("project inspection still works", async () => {
    const list = await registry.invoke("project.list", { path: "." });
    assert.equal(list.ok, true);
    const meta = await registry.invoke("project.metadata", {});
    assert.equal(meta.ok, true);
  });

  it("atomic modification + diff tracking", async () => {
    const r = await registry.invoke(
      "project.changeset.apply",
      {
        changes: [
          {
            path: "src/new.ts",
            operation: "create",
            content: "export const x = 2;\n",
          },
          {
            path: "existing.ts",
            operation: "update",
            content: "export const n = 2;\n",
          },
        ],
      },
      { taskId: "t1", employeeId: "developer" },
    );
    assert.equal(r.ok, true);
    const body = r.result as {
      changeSetId: string;
      checkpointId: string;
      diffs: unknown[];
    };
    assert.ok(body.changeSetId);
    assert.ok(body.checkpointId);
    assert.equal(body.diffs.length, 2);
    assert.equal(readFileSync(join(root, "src/new.ts"), "utf8"), "export const x = 2;\n");
    assert.equal(readFileSync(join(root, "existing.ts"), "utf8"), "export const n = 2;\n");
  });

  it("checkpoint rollback restores files", async () => {
    const applied = await registry.invoke("project.changeset.apply", {
      changes: [
        {
          path: "existing.ts",
          operation: "update",
          content: "export const n = 99;\n",
        },
      ],
    });
    assert.equal(applied.ok, true);
    const cpId = (applied.result as { checkpointId: string }).checkpointId;
    assert.equal(readFileSync(join(root, "existing.ts"), "utf8"), "export const n = 99;\n");
    const rb = await registry.invoke("project.checkpoint.rollback", {
      checkpointId: cpId,
    });
    assert.equal(rb.ok, true);
    assert.equal(readFileSync(join(root, "existing.ts"), "utf8"), "export const n = 1;\n");
  });

  it("conflicting create fails", async () => {
    const r = await registry.invoke("project.changeset.apply", {
      changes: [
        {
          path: "existing.ts",
          operation: "create",
          content: "nope",
        },
      ],
    });
    assert.equal(r.ok, false);
  });

  it("path traversal rejected", async () => {
    const r = await registry.invoke("project.changeset.apply", {
      changes: [{ path: "../escape.ts", operation: "create", content: "x" }],
    });
    assert.equal(r.ok, false);
  });

  it("symlink escape rejected on apply", async () => {
    const outside = join(tmpdir(), `ell-out-${Date.now()}`);
    writeFileSync(outside, "secret\n", "utf8");
    try {
      symlinkSync(outside, join(root, "link.txt"));
    } catch {
      // platform may not support symlinks; skip soft
      return;
    }
    // resolveSafe may or may not follow — workspace hardening should reject outside
    const r = await registry.invoke("project.changeset.apply", {
      changes: [{ path: "link.txt", operation: "update", content: "hacked" }],
    });
    // Either fail or not write outside
    if (r.ok) {
      assert.equal(readFileSync(outside, "utf8"), "secret\n");
    } else {
      assert.equal(r.ok, false);
    }
    try {
      rmSync(outside, { force: true });
    } catch {
      /* ignore */
    }
  });

  it("validation success and failure", async () => {
    const ok = await registry.invoke("project.validate", {
      paths: ["existing.ts"],
    });
    assert.equal(ok.ok, true);
    assert.equal((ok.result as { status: string }).status, "pass");

    writeFileSync(join(root, "bad.ts"), "export const x = {\n", "utf8");
    const bad = await registry.invoke("project.validate", { paths: ["bad.ts"] });
    assert.equal(bad.ok, true);
    assert.equal((bad.result as { status: string }).status, "fail");
  });

  it("validation timeout", async () => {
    const v = new StaticProjectValidator();
    const scope = new WorkspaceScope({ root });
    // Force timeout by 0ms
    const result = await v.validate(scope, { timeoutMs: 0 });
    assert.ok(result.status === "error" || result.status === "pass");
  });

  it("tool loop can apply + validate", async () => {
    let calls = 0;
    const adapter: ProviderAdapter = {
      id: "mock",
      label: "mock",
      capabilities: {
        text: true,
        code: true,
        streaming: false,
        tools: false,
        vision: false,
        jsonMode: false,
      },
      getAvailability: (): ProviderAvailability => "available",
      listModels: () => [],
      async generate(_req: GenerateRequest): Promise<GenerateResponse> {
        const seq = [
          'TOOL_CALL {"name":"project.changeset.apply","arguments":{"changes":[{"path":"from-loop.ts","operation":"create","content":"export const ok = 1;"}]}}',
          'TOOL_CALL {"name":"project.validate","arguments":{"paths":["from-loop.ts"]}}',
          'FINAL {"summary":"applied and validated","confidence":"low"}',
        ];
        const text = seq[Math.min(calls, seq.length - 1)]!;
        calls += 1;
        return { text, model: "m", provider: "mock", latencyMs: 1 };
      },
    };
    const health = new ProviderHealthStore();
    health.register({
      providerId: "mock",
      label: "mock",
      configured: true,
      availability: "available",
    });
    const tracked = withHealthTracking(adapter, health);
    const router = new ProviderRouter({
      adapters: [tracked],
      primary: tracked,
      health,
    });
    const result = await runToolLoop({
      router,
      tools: registry,
      modelId: "m",
      systemPrompt: "sys",
      userObjective: "add file",
      employeeId: "developer",
      providerId: "mock",
    });
    assert.equal(result.stoppedReason, "final");
    assert.ok(result.toolCalls >= 1);
    assert.ok(existsSync(join(root, "from-loop.ts")));
  });

  it("runtime registers execution tools", () => {
    const rt = createOfficeRuntime({ workspaceRoot: root });
    const names = rt.listTools().map((t) => t.name);
    assert.ok(names.includes("project.changeset.apply"));
    assert.ok(names.includes("project.validate"));
    assert.ok(names.includes("project.checkpoint.rollback"));
  });

  it("memory can record execution outcome", () => {
    const rt = createOfficeRuntime({
      workspaceRoot: root,
      projectId: "exec-demo",
    });
    const entry = rt.addProjectContext({
      type: "finding",
      content: "Change set applied successfully",
      employeeId: "developer",
      tags: ["execution"],
    });
    assert.equal(entry.type, "finding");
    const snap = rt.getProjectContextSnapshot();
    assert.ok(snap.entries.some((e) => e.tags.includes("execution")));
  });
});
