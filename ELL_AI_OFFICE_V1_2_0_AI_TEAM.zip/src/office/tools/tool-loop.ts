/**
 * Bounded agent tool-calling loop (Phase 9).
 *
 * Provider-neutral protocol for models without native function-calling:
 *   Assistant may emit: TOOL_CALL {"name":"...","arguments":{...}}
 *   or FINAL {"summary":"...","findings":[],...}
 *
 * Pipeline: parse → validate → permission → ToolRegistry.invoke →
 * sanitize/bound result → feed back → until FINAL or limits.
 */

import type { ProviderRouter } from "../provider-router.ts";
import { sanitizePublicErrorMessage } from "../provider-router.ts";
import { ProviderError } from "../errors.ts";
import type { ToolRegistry, ToolContext, ToolPermissionLevel } from "./tool-registry.ts";
import type { GenerateRequest, GenerateResponse } from "../providers.ts";

export interface ToolLoopLimits {
  maxIterations: number;
  maxToolCallsPerRun: number;
  perToolTimeoutMs: number;
  maxResultChars: number;
  maxRepeatedIdenticalCalls: number;
}

export const DEFAULT_TOOL_LOOP_LIMITS: ToolLoopLimits = {
  maxIterations: 6,
  maxToolCallsPerRun: 8,
  perToolTimeoutMs: 8_000,
  maxResultChars: 6_000,
  maxRepeatedIdenticalCalls: 2,
};

/** Per-employee tool permission: tool name → max permission allowed. */
export type EmployeeToolPermissions = Record<string, ToolPermissionLevel | "deny">;

export const DEFAULT_EMPLOYEE_PERMISSIONS: Record<string, EmployeeToolPermissions> = {
  developer: {
    "knowledge.list": "read",
    "knowledge.search": "read",
    "knowledge.get": "read",
    "knowledge.add": "write",
    "knowledge.update": "write",
    "knowledge.supersede": "write",
    "knowledge.invalidate": "write",
    "qa.plan": "read",
    "qa.run": "read",
    "qa.report": "read",
    "project.list": "read",
    "project.read": "read",
    "project.search": "read",
    "project.write": "write",
    "project.metadata": "read",
    "project.changeset.apply": "write",
    "project.checkpoint.rollback": "write",
    "project.changeset.get": "read",
    "project.validate": "read",
  },
  researcher: {
    "knowledge.list": "read",
    "knowledge.search": "read",
    "knowledge.get": "read",
    "knowledge.add": "deny",
    "knowledge.update": "deny",
    "knowledge.supersede": "deny",
    "knowledge.invalidate": "deny",
    "qa.plan": "read",
    "qa.run": "read",
    "qa.report": "read",
    "project.list": "read",
    "project.read": "read",
    "project.search": "read",
    "project.write": "deny",
    "project.metadata": "read",
    "project.changeset.apply": "deny",
    "project.checkpoint.rollback": "deny",
    "project.changeset.get": "read",
    "project.validate": "read",
  },
  automation: {
    "knowledge.list": "read",
    "knowledge.search": "read",
    "knowledge.get": "read",
    "knowledge.add": "deny",
    "knowledge.update": "deny",
    "knowledge.supersede": "deny",
    "knowledge.invalidate": "deny",
    "qa.plan": "read",
    "qa.run": "read",
    "qa.report": "read",
    "project.list": "read",
    "project.read": "read",
    "project.search": "read",
    "project.write": "deny",
    "project.metadata": "read",
    "project.changeset.apply": "deny",
    "project.checkpoint.rollback": "deny",
    "project.changeset.get": "read",
    "project.validate": "read",
  },
  ceo: {
    "knowledge.list": "read",
    "knowledge.search": "read",
    "knowledge.get": "read",
    "knowledge.add": "write",
    "knowledge.update": "write",
    "knowledge.supersede": "write",
    "knowledge.invalidate": "write",
    "qa.plan": "read",
    "qa.run": "read",
    "qa.report": "read",
    "project.list": "read",
    "project.read": "read",
    "project.search": "read",
    "project.write": "deny",
    "project.metadata": "read",
    "project.changeset.apply": "deny",
    "project.checkpoint.rollback": "deny",
    "project.changeset.get": "read",
    "project.validate": "read",
  },
  pm: {
    "knowledge.list": "read",
    "knowledge.search": "read",
    "knowledge.get": "read",
    "knowledge.add": "deny",
    "knowledge.update": "deny",
    "knowledge.supersede": "deny",
    "knowledge.invalidate": "deny",
    "qa.plan": "read",
    "qa.run": "read",
    "qa.report": "read",
    "project.list": "read",
    "project.read": "read",
    "project.search": "read",
    "project.write": "deny",
    "project.metadata": "read",
    "project.changeset.apply": "deny",
    "project.checkpoint.rollback": "deny",
    "project.changeset.get": "read",
    "project.validate": "read",
  },
  jira: {
    "knowledge.list": "read",
    "knowledge.search": "read",
    "knowledge.get": "read",
    "knowledge.add": "deny",
    "knowledge.update": "deny",
    "knowledge.supersede": "deny",
    "knowledge.invalidate": "deny",
    "qa.plan": "read",
    "qa.run": "read",
    "qa.report": "read",
    "project.list": "read",
    "project.read": "read",
    "project.search": "read",
    "project.write": "deny",
    "project.metadata": "read",
    "project.changeset.apply": "deny",
    "project.checkpoint.rollback": "deny",
    "project.changeset.get": "read",
    "project.validate": "read",
  },
};

export interface ToolCallRequest {
  name: string;
  arguments: Record<string, unknown>;
}

export type ParsedAssistantTurn =
  | { kind: "tool_call"; call: ToolCallRequest }
  | { kind: "final"; text: string }
  | { kind: "malformed"; raw: string; reason: string };

export interface ToolLoopStepAudit {
  iteration: number;
  kind: "llm" | "tool" | "denied" | "error" | "final";
  toolName?: string;
  success: boolean;
  detail: string;
  createdAt: string;
}

export interface ToolLoopResult {
  finalText: string;
  iterations: number;
  toolCalls: number;
  stoppedReason:
    | "final"
    | "max_iterations"
    | "max_tool_calls"
    | "cancelled"
    | "timeout"
    | "provider_error"
    | "repeated_calls"
    | "empty";
  audits: ToolLoopStepAudit[];
  usage?: GenerateResponse["usage"];
}

export interface ToolLoopOptions {
  router: ProviderRouter;
  tools: ToolRegistry;
  modelId: string;
  systemPrompt: string;
  userObjective: string;
  /** Optional bounded project context block. */
  contextBlock?: string;
  employeeId: string;
  taskId?: string | null;
  permissions?: EmployeeToolPermissions;
  limits?: Partial<ToolLoopLimits>;
  signal?: AbortSignal;
  timeoutMs?: number;
  providerId?: string;
  now?: () => number;
}

const TOOL_CALL_RE = /TOOL_CALL\s*(\{[\s\S]*?\})\s*(?:$|\n)/i;
const FINAL_RE = /FINAL\s*(\{[\s\S]*\}|[\s\S]+)/i;

export function parseAssistantTurn(text: string): ParsedAssistantTurn {
  const trimmed = text.trim();
  if (!trimmed) return { kind: "malformed", raw: "", reason: "empty response" };

  const toolMatch = trimmed.match(TOOL_CALL_RE);
  if (toolMatch) {
    try {
      const parsed = JSON.parse(toolMatch[1]!) as { name?: unknown; arguments?: unknown };
      const name = typeof parsed.name === "string" ? parsed.name.trim() : "";
      if (!name) return { kind: "malformed", raw: trimmed.slice(0, 200), reason: "missing tool name" };
      const args =
        parsed.arguments && typeof parsed.arguments === "object" && !Array.isArray(parsed.arguments)
          ? (parsed.arguments as Record<string, unknown>)
          : {};
      return { kind: "tool_call", call: { name, arguments: args } };
    } catch {
      return { kind: "malformed", raw: trimmed.slice(0, 200), reason: "invalid TOOL_CALL JSON" };
    }
  }

  const finalMatch = trimmed.match(FINAL_RE);
  if (finalMatch) {
    return { kind: "final", text: finalMatch[1]!.trim() };
  }

  // If response looks like plain final answer without marker, treat as final.
  if (!/TOOL_CALL/i.test(trimmed)) {
    return { kind: "final", text: trimmed };
  }

  return { kind: "malformed", raw: trimmed.slice(0, 200), reason: "unparsed TOOL_CALL" };
}

export function sanitizeToolResultPayload(value: unknown, maxChars: number): string {
  let text: string;
  try {
    text = typeof value === "string" ? value : JSON.stringify(value);
  } catch {
    text = String(value);
  }
  text = text
    .replace(/Bearer\s+[A-Za-z0-9._\-]+/gi, "Bearer [REDACTED]")
    .replace(/\b(sk|xai|AIza)[-_A-Za-z0-9]{8,}/g, "[REDACTED_KEY]")
    .replace(/secret-api-key-[A-Za-z0-9\-]+/gi, "[REDACTED_KEY]")
    .replace(/api[_-]?key["\s:=]+[A-Za-z0-9._\-]+/gi, "api_key=[REDACTED]");
  if (text.length > maxChars) {
    return `${text.slice(0, maxChars - 1)}…[truncated]`;
  }
  return text;
}

function permissionAllows(
  permissions: EmployeeToolPermissions,
  toolName: string,
  required: ToolPermissionLevel,
): boolean {
  const allowed = permissions[toolName];
  if (!allowed || allowed === "deny") return false;
  if (required === "read") return allowed === "read" || allowed === "write";
  return allowed === "write";
}

function callFingerprint(call: ToolCallRequest): string {
  return `${call.name}:${JSON.stringify(call.arguments)}`;
}

function buildToolAwareSystemPrompt(
  base: string,
  toolCatalog: Array<{ name: string; description: string; permission: string }>,
  allowedNames: string[],
): string {
  const catalog = toolCatalog
    .filter((t) => allowedNames.includes(t.name))
    .map((t) => `- ${t.name} (${t.permission}): ${t.description}`)
    .join("\n");
  return `${base}

TOOLS (optional):
You may call at most one tool per turn using exactly this format:
TOOL_CALL {"name":"<tool>","arguments":{...}}

Available tools:
${catalog || "(none)"}

When finished, respond with:
FINAL {"summary":"...","findings":[],"evidence":[],"risks":[],"recommendations":[],"questions":[],"confidence":"low"}

Do not invent tool names. Do not request shell or network tools.`;
}

export async function runToolLoop(options: ToolLoopOptions): Promise<ToolLoopResult> {
  const limits: ToolLoopLimits = { ...DEFAULT_TOOL_LOOP_LIMITS, ...options.limits };
  const permissions =
    options.permissions ??
    DEFAULT_EMPLOYEE_PERMISSIONS[options.employeeId] ??
    DEFAULT_EMPLOYEE_PERMISSIONS.developer!;
  const now = options.now ?? (() => Date.now());
  const audits: ToolLoopStepAudit[] = [];
  const push = (step: Omit<ToolLoopStepAudit, "createdAt">) => {
    audits.push({ ...step, createdAt: new Date(now()).toISOString() });
  };

  const catalog = options.tools.list();
  const allowedNames = catalog
    .filter((t) => permissionAllows(permissions, t.name, t.permission))
    .map((t) => t.name);

  const systemPrompt = buildToolAwareSystemPrompt(
    options.systemPrompt,
    catalog,
    allowedNames,
  );

  let conversation = options.userObjective;
  if (options.contextBlock) {
    conversation = `${options.contextBlock}\n\nUSER OBJECTIVE:\n${options.userObjective}`;
  }

  let toolCalls = 0;
  let lastUsage: GenerateResponse["usage"];
  const fingerprints = new Map<string, number>();
  const transcript: string[] = [];

  for (let iteration = 1; iteration <= limits.maxIterations; iteration++) {
    if (options.signal?.aborted) {
      push({ iteration, kind: "error", success: false, detail: "cancelled" });
      return {
        finalText: "",
        iterations: iteration,
        toolCalls,
        stoppedReason: "cancelled",
        audits,
        usage: lastUsage,
      };
    }

    const userPrompt =
      transcript.length === 0
        ? conversation
        : `${conversation}\n\n---\nTool/assistant transcript:\n${transcript.join("\n")}\n\nContinue. Emit TOOL_CALL or FINAL.`;

    let response: GenerateResponse;
    try {
      const { response: resp } = await options.router.executeWithFallback(
        {
          model: options.modelId,
          systemPrompt,
          userPrompt,
          timeoutMs: options.timeoutMs,
          signal: options.signal,
        } satisfies GenerateRequest,
        {
          preferredProviderId: options.providerId ?? "mock",
          policy: {
            mode: options.providerId && options.providerId !== "mock" ? "free-first" : "primary-only",
            maxAttempts: options.providerId && options.providerId !== "mock" ? 3 : 1,
            excludeMockInFreeFirst: options.providerId !== "mock",
          },
        },
      );
      response = resp;
      if (resp.usage) lastUsage = resp.usage;
    } catch (error) {
      if (options.signal?.aborted) {
        push({ iteration, kind: "error", success: false, detail: "cancelled" });
        return {
          finalText: "",
          iterations: iteration,
          toolCalls,
          stoppedReason: "cancelled",
          audits,
          usage: lastUsage,
        };
      }
      const msg = sanitizePublicErrorMessage(error);
      push({ iteration, kind: "error", success: false, detail: msg });
      return {
        finalText: "",
        iterations: iteration,
        toolCalls,
        stoppedReason: "provider_error",
        audits,
        usage: lastUsage,
      };
    }

    push({
      iteration,
      kind: "llm",
      success: true,
      detail: `assistant tokens≈${response.text.length}`,
    });

    const parsed = parseAssistantTurn(response.text);

    if (parsed.kind === "final") {
      push({ iteration, kind: "final", success: true, detail: "FINAL received" });
      return {
        finalText: parsed.text,
        iterations: iteration,
        toolCalls,
        stoppedReason: "final",
        audits,
        usage: lastUsage,
      };
    }

    if (parsed.kind === "malformed") {
      transcript.push(
        `ASSISTANT (malformed): ${parsed.reason}. Please emit TOOL_CALL {json} or FINAL {json}.`,
      );
      push({
        iteration,
        kind: "error",
        success: false,
        detail: `malformed: ${parsed.reason}`,
      });
      continue;
    }

    // tool_call
    if (toolCalls >= limits.maxToolCallsPerRun) {
      push({
        iteration,
        kind: "error",
        success: false,
        detail: "max tool calls reached",
      });
      return {
        finalText: response.text,
        iterations: iteration,
        toolCalls,
        stoppedReason: "max_tool_calls",
        audits,
        usage: lastUsage,
      };
    }

    const call = parsed.call;
    const fp = callFingerprint(call);
    const seen = (fingerprints.get(fp) ?? 0) + 1;
    fingerprints.set(fp, seen);
    if (seen > limits.maxRepeatedIdenticalCalls) {
      push({
        iteration,
        kind: "error",
        toolName: call.name,
        success: false,
        detail: "repeated identical tool call",
      });
      return {
        finalText: "",
        iterations: iteration,
        toolCalls,
        stoppedReason: "repeated_calls",
        audits,
        usage: lastUsage,
      };
    }

    const toolDef = options.tools.get(call.name);
    if (!toolDef) {
      transcript.push(`TOOL_RESULT ${call.name}: ERROR unknown tool`);
      push({
        iteration,
        kind: "denied",
        toolName: call.name,
        success: false,
        detail: "unknown tool",
      });
      continue;
    }

    if (!permissionAllows(permissions, call.name, toolDef.permission)) {
      transcript.push(`TOOL_RESULT ${call.name}: ERROR permission denied`);
      push({
        iteration,
        kind: "denied",
        toolName: call.name,
        success: false,
        detail: "permission denied",
      });
      continue;
    }

    toolCalls += 1;
    const toolCtx: ToolContext = {
      taskId: options.taskId ?? null,
      employeeId: options.employeeId,
      now,
    };

    // Per-tool timeout via AbortSignal.timeout composition
    const toolAbort = new AbortController();
    const onParentAbort = () => toolAbort.abort();
    options.signal?.addEventListener("abort", onParentAbort, { once: true });
    const timer = setTimeout(() => toolAbort.abort(), limits.perToolTimeoutMs);

    let invokeResult;
    try {
      if (toolAbort.signal.aborted) {
        throw new ProviderError("TIMEOUT", "Tool call timed out or cancelled", true);
      }
      invokeResult = await options.tools.invoke(call.name, call.arguments, toolCtx);
    } catch (error) {
      const msg = sanitizePublicErrorMessage(error);
      transcript.push(`TOOL_RESULT ${call.name}: ERROR ${msg}`);
      push({
        iteration,
        kind: "tool",
        toolName: call.name,
        success: false,
        detail: msg,
      });
      continue;
    } finally {
      clearTimeout(timer);
      options.signal?.removeEventListener("abort", onParentAbort);
    }

    if (!invokeResult.ok) {
      const errMsg = invokeResult.error?.message ?? "tool failed";
      transcript.push(
        `TOOL_RESULT ${call.name}: ERROR ${sanitizeToolResultPayload(errMsg, 400)}`,
      );
      push({
        iteration,
        kind: "tool",
        toolName: call.name,
        success: false,
        detail: errMsg.slice(0, 160),
      });
      continue;
    }

    const bounded = sanitizeToolResultPayload(invokeResult.result, limits.maxResultChars);
    transcript.push(`TOOL_RESULT ${call.name}: ${bounded}`);
    push({
      iteration,
      kind: "tool",
      toolName: call.name,
      success: true,
      detail: `ok bytes≈${bounded.length}`,
    });
  }

  push({
    iteration: limits.maxIterations,
    kind: "error",
    success: false,
    detail: "max iterations",
  });
  return {
    finalText: transcript.at(-1) ?? "",
    iterations: limits.maxIterations,
    toolCalls,
    stoppedReason: "max_iterations",
    audits,
    usage: lastUsage,
  };
}
