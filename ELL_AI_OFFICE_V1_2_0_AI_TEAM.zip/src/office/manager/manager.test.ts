import assert from "node:assert/strict";
import { describe, it, beforeEach, afterEach } from "node:test";
import { mkdtempSync, rmSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { classifyTask } from "./task-classifier.ts";
import { buildPlan, validatePlan, PlanError, DEFAULT_PLAN_LIMITS } from "./plan.ts";
import {
  isResourceAllowed,
  rankResources,
  defaultCostClass,
  type ResourceCostMeta,
} from "./cost-modes.ts";
import { ManagerStateMachine, StateMachineError } from "./state-machine.ts";
import { EllManager } from "./ell-manager.ts";
import { createOfficeRuntime, replaceOffice } from "../runtime.ts";

describe("task classification", () => {
  it("classifies conversation", () => {
    const r = classifyTask("Hello there");
    assert.equal(r.category, "conversation");
    assert.equal(r.qaRequired, false);
  });

  it("classifies coding / project_change", () => {
    const r = classifyTask("Please fix the auth bug and implement a patch");
    assert.ok(
      r.category === "mixed" ||
        r.category === "project_change" ||
        r.category === "debugging" ||
        r.category === "coding",
    );
    assert.equal(r.codingRequired, true);
  });

  it("classifies QA", () => {
    const r = classifyTask("Run QA and verify validation");
    assert.ok(r.category === "qa" || r.qaRequired);
  });

  it("classifies research", () => {
    const r = classifyTask("Research how does OAuth work");
    assert.equal(r.category, "research");
    assert.equal(r.researchRequired, true);
  });
});

describe("plan generation", () => {
  it("builds and validates a plan", () => {
    const req = classifyTask("Implement a small refactor");
    const plan = buildPlan({
      taskId: "t1",
      projectId: "p1",
      objective: "Implement a small refactor",
      requirements: req,
      costMode: "FREE_FIRST",
    });
    assert.ok(plan.steps.length >= 2);
    assert.ok(plan.steps.some((s) => s.kind === "finalize"));
    validatePlan(plan, DEFAULT_PLAN_LIMITS);
  });

  it("conversation plan is minimal", () => {
    const req = classifyTask("Hi");
    const plan = buildPlan({
      taskId: "t",
      projectId: "p",
      objective: "Hi",
      requirements: req,
      costMode: "FREE_ONLY",
    });
    assert.ok(plan.steps.length <= 4);
  });

  it("rejects empty objective via validate", () => {
    const req = classifyTask("code something");
    assert.throws(() => {
      const plan = buildPlan({
        taskId: "t",
        projectId: "p",
        objective: "code something",
        requirements: req,
        costMode: "PAID",
      });
      plan.objective = "";
      validatePlan(plan, DEFAULT_PLAN_LIMITS);
    }, PlanError);
  });
});

describe("cost modes", () => {
  const resources: ResourceCostMeta[] = [
    { providerId: "mock", costClass: "FREE", priority: 0 },
    { providerId: "openai", costClass: "PAID", priority: 10 },
    { providerId: "weird", costClass: "UNKNOWN", priority: 5 },
  ];

  it("FREE_ONLY blocks paid and unknown", () => {
    assert.equal(
      isResourceAllowed(resources[0]!, { mode: "FREE_ONLY" }),
      true,
    );
    assert.equal(
      isResourceAllowed(resources[1]!, { mode: "FREE_ONLY" }),
      false,
    );
    assert.equal(
      isResourceAllowed(resources[2]!, { mode: "FREE_ONLY" }),
      false,
    );
  });

  it("FREE_FIRST allows paid only when allowlisted", () => {
    assert.equal(
      isResourceAllowed(resources[1]!, {
        mode: "FREE_FIRST",
        allowPaidProviders: [],
      }),
      false,
    );
    assert.equal(
      isResourceAllowed(resources[1]!, {
        mode: "FREE_FIRST",
        allowPaidProviders: ["openai"],
      }),
      true,
    );
  });

  it("PAID still blocks UNKNOWN", () => {
    assert.equal(
      isResourceAllowed(resources[2]!, { mode: "PAID" }),
      false,
    );
  });

  it("rank prefers free", () => {
    const ranked = rankResources(resources, {
      mode: "FREE_FIRST",
      allowPaidProviders: ["openai"],
    });
    assert.equal(ranked[0]?.providerId, "mock");
  });

  it("defaultCostClass maps mock to FREE", () => {
    assert.equal(defaultCostClass("mock"), "FREE");
    assert.equal(defaultCostClass("openai"), "PAID");
  });
});

describe("state machine", () => {
  it("allows valid transitions", () => {
    const sm = new ManagerStateMachine();
    assert.equal(sm.current, "received");
    sm.transition("understanding");
    sm.transition("planned");
    sm.transition("routing");
    sm.transition("executing");
    sm.transition("completed");
    assert.equal(sm.current, "completed");
    assert.equal(sm.isTerminal(), true);
  });

  it("rejects invalid transitions", () => {
    const sm = new ManagerStateMachine();
    assert.throws(() => sm.transition("completed"), StateMachineError);
  });
});

describe("EllManager integration", () => {
  let root: string;

  beforeEach(() => {
    root = mkdtempSync(join(tmpdir(), "ell-mgr-"));
    replaceOffice(
      createOfficeRuntime({
        workspaceRoot: root,
        projectId: "mgr-demo",
        delays: { planningMs: 0, assignMs: 0, workMs: 0, synthMs: 0 },
      }),
    );
  });
  afterEach(() => rmSync(root, { recursive: true, force: true }));

  it("runs simple conversation to completion", async () => {
    const runtime = createOfficeRuntime({
      workspaceRoot: root,
      projectId: "mgr-demo",
      delays: { planningMs: 0, assignMs: 0, workMs: 0, synthMs: 0 },
    });
    const mgr = new EllManager({
      runtime,
      costPolicy: { mode: "FREE_ONLY" },
      costClassByProvider: { mock: "FREE" },
      planLimits: { maxDurationMs: 10_000 },
      projectId: "mgr-demo",
    });
    const result = await mgr.run("Hello, what can you do?");
    assert.ok(
      result.state === "completed" || result.state === "failed",
      result.state,
    );
    assert.equal(result.costMode, "FREE_ONLY");
    assert.ok(result.plan);
    assert.ok(result.requirements);
  });

  it("FREE_ONLY never selects paid providers", async () => {
    const runtime = createOfficeRuntime({
      workspaceRoot: root,
      delays: { planningMs: 0, assignMs: 0, workMs: 0, synthMs: 0 },
    });
    const mgr = new EllManager({
      runtime,
      costPolicy: { mode: "FREE_ONLY" },
      costClassByProvider: { mock: "FREE", openai: "PAID" },
    });
    const trace = await mgr.selectResources("openai");
    assert.notEqual(trace.finalProviderId, "openai");
    assert.ok(
      trace.rejected.some(
        (r) => r.providerId === "openai" || r.reason.includes("FREE_ONLY"),
      ) || trace.finalProviderId === "mock",
    );
  });

  it("cancellation", async () => {
    const runtime = createOfficeRuntime({
      workspaceRoot: root,
      delays: { planningMs: 0, assignMs: 0, workMs: 0, synthMs: 0 },
    });
    const mgr = new EllManager({
      runtime,
      costPolicy: { mode: "FREE_FIRST" },
      costClassByProvider: { mock: "FREE" },
    });
    const c = new AbortController();
    c.abort();
    const result = await mgr.run("Do something", { signal: c.signal });
    assert.equal(result.state, "cancelled");
  });

  it("coding task produces multi-step plan and office task", async () => {
    const runtime = createOfficeRuntime({
      workspaceRoot: root,
      projectId: "mgr-code",
      delays: { planningMs: 0, assignMs: 0, workMs: 0, synthMs: 0 },
    });
    const mgr = new EllManager({
      runtime,
      costPolicy: { mode: "FREE_FIRST" },
      costClassByProvider: { mock: "FREE" },
      planLimits: { maxDurationMs: 15_000 },
      projectId: "mgr-code",
    });
    const result = await mgr.run(
      "Inspect the project and implement a small fix with QA",
    );
    assert.ok(result.plan && result.plan.steps.length >= 3);
    assert.ok(result.requirements.codingRequired || result.requirements.qaRequired);
    assert.ok(result.officeTaskId || result.state === "failed");
  });

  it("route trace has no secrets", async () => {
    const runtime = createOfficeRuntime({
      workspaceRoot: root,
      delays: { planningMs: 0, assignMs: 0, workMs: 0, synthMs: 0 },
    });
    const mgr = new EllManager({
      runtime,
      costPolicy: { mode: "FREE_ONLY" },
      costClassByProvider: { mock: "FREE" },
    });
    const result = await mgr.run("Hello");
    const blob = JSON.stringify(result);
    assert.equal(blob.includes("secret-api-key"), false);
    assert.equal(blob.includes("Bearer "), false);
  });
});

describe("Phase 14 hardening — routing integrity", () => {
  let root: string;

  beforeEach(() => {
    root = mkdtempSync(join(tmpdir(), "ell-h14-"));
  });
  afterEach(() => rmSync(root, { recursive: true, force: true }));

  it("FREE_ONLY blocks paid and unknown in resolveAllowedProviderIds", () => {
    const runtime = createOfficeRuntime({
      workspaceRoot: root,
      delays: { planningMs: 0, assignMs: 0, workMs: 0, synthMs: 0 },
    });
    const mgr = new EllManager({
      runtime,
      costPolicy: { mode: "FREE_ONLY" },
      costClassByProvider: {
        mock: "FREE",
        openai: "PAID",
        weird: "UNKNOWN",
      },
      executionMode: "mock",
    });
    const allowed = mgr.resolveAllowedProviderIds(["mock", "openai", "weird"]);
    assert.deepEqual(allowed, ["mock"]);
  });

  it("FREE_FIRST without paidFallback blocks paid", () => {
    const runtime = createOfficeRuntime({
      workspaceRoot: root,
      delays: { planningMs: 0, assignMs: 0, workMs: 0, synthMs: 0 },
    });
    const mgr = new EllManager({
      runtime,
      costPolicy: { mode: "FREE_FIRST", paidFallback: false },
      costClassByProvider: { mock: "FREE", openai: "PAID" },
      executionMode: "mock",
    });
    const allowed = mgr.resolveAllowedProviderIds(["mock", "openai"]);
    assert.ok(allowed.includes("mock"));
    assert.ok(!allowed.includes("openai"));
  });

  it("FREE_FIRST with paidFallback allows paid", () => {
    const runtime = createOfficeRuntime({
      workspaceRoot: root,
      delays: { planningMs: 0, assignMs: 0, workMs: 0, synthMs: 0 },
    });
    const mgr = new EllManager({
      runtime,
      costPolicy: { mode: "FREE_FIRST", paidFallback: true },
      costClassByProvider: { mock: "FREE", openai: "PAID" },
      executionMode: "mock",
    });
    const allowed = mgr.resolveAllowedProviderIds(["mock", "openai"]);
    assert.ok(allowed.includes("openai"));
  });

  it("mock executionMode prefers mock and completes", async () => {
    const runtime = createOfficeRuntime({
      workspaceRoot: root,
      delays: { planningMs: 0, assignMs: 0, workMs: 0, synthMs: 0 },
    });
    const mgr = new EllManager({
      runtime,
      costPolicy: { mode: "FREE_ONLY" },
      costClassByProvider: { mock: "FREE" },
      executionMode: "mock",
      planLimits: { maxDurationMs: 10_000 },
    });
    const result = await mgr.run("Hello");
    assert.ok(result.routeTrace);
    assert.equal(result.routeTrace!.preferredProviderId, "mock");
    // actual may be mock from office outputs
    if (result.routeTrace!.actualProviderId) {
      assert.equal(result.routeTrace!.actualProviderId, "mock");
    }
  });

  it("router allowlist blocks preferred paid under FREE_ONLY", async () => {
    const { ProviderRouter } = await import("../provider-router.ts");
    const { ProviderHealthStore, withHealthTracking } = await import("../provider-health.ts");
    const { MockProvider } = await import("../providers.ts");
    const health = new ProviderHealthStore();
    const mock = new MockProvider();
    health.register({
      providerId: "mock",
      label: "Mock",
      configured: true,
      availability: "available",
    });
    const tracked = withHealthTracking(mock, health);
    const router = new ProviderRouter({
      adapters: [tracked],
      primary: tracked,
      health,
    });
    const { candidates, selectionReason } = router.selectCandidates({
      preferredProviderId: "openai",
      policy: {
        mode: "primary-only",
        maxAttempts: 1,
        allowedProviderIds: ["mock"],
      },
    });
    assert.equal(candidates.length, 0);
    assert.match(selectionReason, /blocked by allowedProviderIds|not configured/);
  });

  it("router allowlist only returns free providers", async () => {
    const { ProviderRouter } = await import("../provider-router.ts");
    const { ProviderHealthStore, withHealthTracking } = await import("../provider-health.ts");
    const { MockProvider } = await import("../providers.ts");
    const health = new ProviderHealthStore();
    const mock = new MockProvider();
    health.register({
      providerId: "mock",
      label: "Mock",
      configured: true,
      availability: "available",
    });
    const tracked = withHealthTracking(mock, health);
    const router = new ProviderRouter({
      adapters: [tracked],
      primary: tracked,
      health,
    });
    const { candidates } = router.selectCandidates({
      preferredProviderId: "mock",
      policy: {
        mode: "primary-only",
        maxAttempts: 1,
        allowedProviderIds: ["mock"],
      },
    });
    assert.equal(candidates.length, 1);
    assert.equal(candidates[0]!.id, "mock");
  });
});

describe("Phase 14 final — actual provider execution proof", () => {
  it("Manager preferred provider is actually invoked (spy adapter)", async () => {
    const { ProviderRouter } = await import("../provider-router.ts");
    const { ProviderHealthStore, withHealthTracking } = await import(
      "../provider-health.ts"
    );
    const { ProviderError } = await import("../errors.ts");
    const health = new ProviderHealthStore();
    let geminiCalls = 0;
    let anthropicCalls = 0;
    let mockCalls = 0;

    const makeAdapter = (
      id: string,
      onCall: () => void,
    ): import("../providers.ts").ProviderAdapter => ({
      id,
      label: id,
      capabilities: {
        text: true,
        code: true,
        streaming: false,
        tools: false,
        vision: false,
        jsonMode: false,
      },
      getAvailability: () => "available" as const,
      listModels: () => [
        {
          id: `${id}:m`,
          provider: id,
          capabilities: ["text"],
          contextWindow: null,
          costClass: id === "mock" ? "free" : "paid",
          availability: "available",
          label: id,
        },
      ],
      async generate() {
        onCall();
        return {
          text: JSON.stringify({
            summary: `from ${id}`,
            findings: [],
            evidence: [],
            risks: [],
            recommendations: [],
            questions: [],
            confidence: "low",
          }),
          model: `${id}:m`,
          provider: id,
          latencyMs: 1,
        };
      },
    });

    const gemini = makeAdapter("gemini", () => {
      geminiCalls += 1;
    });
    const anthropic = makeAdapter("anthropic", () => {
      anthropicCalls += 1;
    });
    const mock = makeAdapter("mock", () => {
      mockCalls += 1;
    });

    for (const a of [gemini, anthropic, mock]) {
      health.register({
        providerId: a.id,
        label: a.label,
        configured: true,
        availability: "available",
      });
    }
    const adapters = [gemini, anthropic, mock].map((a) =>
      withHealthTracking(a, health),
    );
    const router = new ProviderRouter({
      adapters,
      primary: adapters[2]!,
      health,
    });

    const { response, trace } = await router.executeWithFallback(
      {
        model: "gemini:m",
        systemPrompt: "sys",
        userPrompt: "hello",
        timeoutMs: 5000,
      },
      {
        preferredProviderId: "gemini",
        policy: {
          mode: "primary-only",
          maxAttempts: 1,
          allowedProviderIds: ["gemini", "mock"],
        },
      },
    );

    assert.equal(geminiCalls, 1);
    assert.equal(anthropicCalls, 0);
    assert.equal(response.provider, "gemini");
    assert.equal(trace.finalProviderId, "gemini");
    assert.equal(trace.preferredProviderId, "gemini");
    void mockCalls;
  });

  it("fallback invokes alternate when preferred rate-limits", async () => {
    const { ProviderRouter } = await import("../provider-router.ts");
    const { ProviderHealthStore, withHealthTracking } = await import(
      "../provider-health.ts"
    );
    const { ProviderError } = await import("../errors.ts");
    const health = new ProviderHealthStore();
    let geminiCalls = 0;
    let openrouterCalls = 0;

    const gemini: import("../providers.ts").ProviderAdapter = {
      id: "gemini",
      label: "gemini",
      capabilities: {
        text: true,
        code: false,
        streaming: false,
        tools: false,
        vision: false,
        jsonMode: false,
      },
      getAvailability: () => "available",
      listModels: () => [
        {
          id: "gemini:m",
          provider: "gemini",
          capabilities: ["text"],
          contextWindow: null,
          costClass: "free",
          availability: "available",
          label: "g",
        },
      ],
      async generate() {
        geminiCalls += 1;
        throw new ProviderError("RATE_LIMIT", "rate limited", true);
      },
    };
    const openrouter: import("../providers.ts").ProviderAdapter = {
      id: "openrouter",
      label: "openrouter",
      capabilities: {
        text: true,
        code: false,
        streaming: false,
        tools: false,
        vision: false,
        jsonMode: false,
      },
      getAvailability: () => "available",
      listModels: () => [
        {
          id: "or:m",
          provider: "openrouter",
          capabilities: ["text"],
          contextWindow: null,
          costClass: "free",
          availability: "available",
          label: "or",
        },
      ],
      async generate() {
        openrouterCalls += 1;
        return {
          text: "ok",
          model: "or:m",
          provider: "openrouter",
          latencyMs: 1,
        };
      },
    };

    for (const a of [gemini, openrouter]) {
      health.register({
        providerId: a.id,
        label: a.label,
        configured: true,
        availability: "available",
      });
    }
    const adapters = [gemini, openrouter].map((a) => withHealthTracking(a, health));
    const router = new ProviderRouter({
      adapters,
      primary: adapters[0]!,
      health,
    });

    const { response, trace } = await router.executeWithFallback(
      {
        model: "gemini:m",
        systemPrompt: "s",
        userPrompt: "u",
        timeoutMs: 3000,
      },
      {
        preferredProviderId: "gemini",
        policy: {
          mode: "free-first",
          maxAttempts: 2,
          excludeMockInFreeFirst: true,
          allowedProviderIds: ["gemini", "openrouter"],
        },
      },
    );

    assert.equal(geminiCalls, 1);
    assert.equal(openrouterCalls, 1);
    assert.equal(response.provider, "openrouter");
    assert.equal(trace.finalProviderId, "openrouter");
    assert.equal(trace.fallbackUsed, true);
  });

  it("FREE_ONLY never invokes paid provider", async () => {
    const { ProviderRouter } = await import("../provider-router.ts");
    const { ProviderHealthStore, withHealthTracking } = await import(
      "../provider-health.ts"
    );
    const health = new ProviderHealthStore();
    let paidCalls = 0;
    let freeCalls = 0;

    const paid: import("../providers.ts").ProviderAdapter = {
      id: "openai",
      label: "openai",
      capabilities: {
        text: true,
        code: false,
        streaming: false,
        tools: false,
        vision: false,
        jsonMode: false,
      },
      getAvailability: () => "available",
      listModels: () => [
        {
          id: "o",
          provider: "openai",
          capabilities: ["text"],
          contextWindow: null,
          costClass: "paid",
          availability: "available",
          label: "o",
        },
      ],
      async generate() {
        paidCalls += 1;
        return { text: "paid", model: "o", provider: "openai", latencyMs: 1 };
      },
    };
    const free: import("../providers.ts").ProviderAdapter = {
      id: "gemini",
      label: "gemini",
      capabilities: {
        text: true,
        code: false,
        streaming: false,
        tools: false,
        vision: false,
        jsonMode: false,
      },
      getAvailability: () => "available",
      listModels: () => [
        {
          id: "g",
          provider: "gemini",
          capabilities: ["text"],
          contextWindow: null,
          costClass: "free",
          availability: "available",
          label: "g",
        },
      ],
      async generate() {
        freeCalls += 1;
        return { text: "free", model: "g", provider: "gemini", latencyMs: 1 };
      },
    };

    for (const a of [paid, free]) {
      health.register({
        providerId: a.id,
        label: a.label,
        configured: true,
        availability: "available",
      });
    }
    const adapters = [paid, free].map((a) => withHealthTracking(a, health));
    const router = new ProviderRouter({
      adapters,
      primary: adapters[0]!,
      health,
    });

    // Prefer paid but allowlist is FREE only
    const { response, trace } = await router.executeWithFallback(
      {
        model: "g",
        systemPrompt: "s",
        userPrompt: "u",
        timeoutMs: 3000,
      },
      {
        preferredProviderId: "openai",
        policy: {
          mode: "free-first",
          maxAttempts: 2,
          allowedProviderIds: ["gemini"],
        },
      },
    );

    assert.equal(paidCalls, 0);
    assert.equal(freeCalls, 1);
    assert.equal(response.provider, "gemini");
    assert.equal(trace.finalProviderId, "gemini");
  });
});

describe("Phase 14 final — real ChangeSet QA repair", () => {
  let root: string;

  beforeEach(() => {
    root = mkdtempSync(join(tmpdir(), "ell-repair-"));
  });
  afterEach(() => rmSync(root, { recursive: true, force: true }));

  it("tryStaticFix closes unbalanced brace", async () => {
    const { tryStaticFix } = await import("./repair.ts");
    const fixed = tryStaticFix("export const x = {\n");
    assert.ok(fixed);
    assert.ok(fixed!.includes("}"));
  });

  it("tryStaticFix ignores bracket characters inside strings and comments", async () => {
    const { tryStaticFix } = await import("./repair.ts");
    assert.equal(tryStaticFix('const message = "{";'), null);
    assert.equal(tryStaticFix("// { is only a comment\nconst value = 1;"), null);
    assert.equal(tryStaticFix('const message = "comma,}";'), null);
  });

  it("tryStaticFix removes a real trailing comma without editing string content", async () => {
    const { tryStaticFix } = await import("./repair.ts");
    assert.equal(tryStaticFix('const value = { name: "comma,}", };'), 'const value = { name: "comma,}" };\n');
    assert.equal(tryStaticFix('{ "name": "ok", }'), '{ "name": "ok" }\n');
  });

  it("QA FAIL → ChangeSet repair → QA PASS", async () => {
    writeFileSync(join(root, "broken.ts"), "export const x = {\n", "utf8");
    const runtime = createOfficeRuntime({
      workspaceRoot: root,
      projectId: "repair-demo",
      delays: { planningMs: 0, assignMs: 0, workMs: 0, synthMs: 0 },
    });

    // Prove initial QA fails
    const failRun = await runtime.invokeTool(
      "qa.run",
      { levels: ["static"], paths: ["broken.ts"] },
      { employeeId: "developer", taskId: "t0" },
    );
    assert.equal(failRun.ok, true);
    assert.equal((failRun.result as { status: string }).status, "FAIL");

    const { attemptBoundedRepair } = await import("./repair.ts");
    const failures = (failRun.result as { failures: string[] }).failures;
    const repair = await attemptBoundedRepair(runtime, {
      taskId: "t0",
      failures,
      employeeId: "developer",
    });
    assert.equal(repair.applied, true, repair.reason);
    assert.ok(repair.changeSetId);

    const passRun = await runtime.invokeTool(
      "qa.run",
      { levels: ["static"], paths: ["broken.ts"] },
      { employeeId: "developer", taskId: "t0" },
    );
    assert.equal((passRun.result as { status: string }).status, "PASS");

    // File was actually modified
    const { readFileSync } = await import("node:fs");
    const content = readFileSync(join(root, "broken.ts"), "utf8");
    assert.ok(content.includes("}"));
  });

  it("repair refuses non-write employee", async () => {
    writeFileSync(join(root, "broken.ts"), "export const x = {\n", "utf8");
    const runtime = createOfficeRuntime({
      workspaceRoot: root,
      delays: { planningMs: 0, assignMs: 0, workMs: 0, synthMs: 0 },
    });
    const { attemptBoundedRepair } = await import("./repair.ts");
    const result = await attemptBoundedRepair(runtime, {
      taskId: "t1",
      failures: ["broken.ts: Unbalanced '{'"],
      employeeId: "researcher",
    });
    assert.equal(result.applied, false);
    assert.match(result.reason, /permission/i);
    const { readFileSync } = await import("node:fs");
    assert.equal(readFileSync(join(root, "broken.ts"), "utf8"), "export const x = {\n");
  });

  it("maxRepairAttempts 0 means no repair applied via manager path still respects QA FAIL", async () => {
    writeFileSync(join(root, "ok.ts"), "export const a = 1;\n", "utf8");
    const runtime = createOfficeRuntime({
      workspaceRoot: root,
      delays: { planningMs: 0, assignMs: 0, workMs: 0, synthMs: 0 },
    });
    const mgr = new EllManager({
      runtime,
      costPolicy: { mode: "FREE_ONLY" },
      costClassByProvider: { mock: "FREE" },
      executionMode: "mock",
      maxRepairAttempts: 0,
      planLimits: { maxDurationMs: 8_000 },
    });
    // conversation without qa
    const result = await mgr.run("Hello");
    assert.ok(result.state === "completed" || result.state === "failed");
  });
});
