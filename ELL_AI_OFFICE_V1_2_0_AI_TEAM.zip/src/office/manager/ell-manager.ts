/**
 * ELL Manager — bounded decision/orchestration layer above OfficeRuntime.
 * Coordinates existing systems; does not replace them.
 */

import { randomUUID } from "node:crypto";
import type { OfficeRuntime } from "../runtime.ts";
import { classifyTask, type TaskRequirements } from "./task-classifier.ts";
import {
  buildPlan,
  type ManagerPlan,
  type PlanLimits,
  DEFAULT_PLAN_LIMITS,
} from "./plan.ts";
import {
  type CostMode,
  type CostPolicy,
  DEFAULT_COST_POLICY,
  defaultCostClass,
  isResourceAllowed,
  rankResources,
  type ResourceCostMeta,
} from "./cost-modes.ts";
import { ManagerStateMachine, type ManagerState } from "./state-machine.ts";
import { attemptBoundedRepair } from "./repair.ts";

export interface ManagerEvent {
  id: string;
  type: string;
  managerTaskId: string;
  message: string;
  state: ManagerState;
  createdAt: string;
}

export interface ManagerRouteTrace {
  preferredProviderId: string | null;
  /** Provider that actually produced the result (from execution). */
  actualProviderId: string | null;
  finalProviderId: string | null;
  costMode: CostMode;
  candidates: string[];
  rejected: Array<{ providerId: string; reason: string }>;
  fallbackUsed: boolean;
  selectionReason: string;
  fallbackReason: string | null;
  employeeId: string | null;
  modelId: string | null;
  finalStatus: "SUCCESS" | "FAILED" | "DEFERRED" | "CANCELLED" | null;
}

export interface ManagerTaskResult {
  managerTaskId: string;
  officeTaskId: string | null;
  state: ManagerState;
  requirements: TaskRequirements;
  plan: ManagerPlan | null;
  routeTrace: ManagerRouteTrace | null;
  costMode: CostMode;
  summary: string;
  officeTaskStatus: string | null;
  qaStatus: string | null;
  events: ManagerEvent[];
  error: string | null;
}

export interface EllManagerOptions {
  runtime: OfficeRuntime;
  costPolicy?: Partial<CostPolicy> & { paidFallback?: boolean };
  planLimits?: Partial<PlanLimits>;
  projectId?: string;
  /** Optional cost class overrides by provider id. */
  costClassByProvider?: Record<string, "FREE" | "PAID" | "UNKNOWN">;
  /** mock = tests/offline; live = no silent mock substitution. */
  executionMode?: "mock" | "live";
  maxRepairAttempts?: number;
  now?: () => number;
}

function sanitize(msg: string, max = 400): string {
  return String(msg ?? "")
    .replace(/Bearer\s+\S+/gi, "Bearer [REDACTED]")
    .replace(/secret-api-key-\S+/gi, "[REDACTED]")
    .replace(/\b(sk|xai|AIza)[-_A-Za-z0-9]{8,}/g, "[REDACTED]")
    .replace(/\/home\/[^\s"']+/g, "[PATH]")
    .slice(0, max);
}

export class EllManager {
  private readonly runtime: OfficeRuntime;
  private readonly costPolicy: CostPolicy;
  private readonly planLimits: PlanLimits;
  private readonly projectId: string;
  private readonly costClassByProvider: Record<string, "FREE" | "PAID" | "UNKNOWN">;
  private readonly executionMode: "mock" | "live";
  private readonly maxRepairAttempts: number;
  private readonly paidFallback: boolean;
  private readonly now: () => number;
  private readonly events: ManagerEvent[] = [];
  private providerCallCount = 0;

  constructor(options: EllManagerOptions) {
    this.runtime = options.runtime;
    this.costPolicy = { ...DEFAULT_COST_POLICY, ...options.costPolicy };
    this.planLimits = { ...DEFAULT_PLAN_LIMITS, ...options.planLimits };
    this.projectId = options.projectId ?? "default";
    this.costClassByProvider = options.costClassByProvider ?? {};
    this.executionMode = options.executionMode ?? "mock";
    this.maxRepairAttempts = options.maxRepairAttempts ?? 1;
    this.paidFallback = Boolean(
      (options.costPolicy as { paidFallback?: boolean } | undefined)?.paidFallback,
    );
    this.now = options.now ?? (() => Date.now());
  }

  /** Providers allowed under current cost policy (execution constraint). */
  resolveAllowedProviderIds(allProviderIds: string[]): string[] {
    const metas = allProviderIds.map((id) => ({
      providerId: id,
      costClass: this.costClassByProvider[id] ?? defaultCostClass(id),
    }));
    let policy = this.costPolicy;
    if (this.costPolicy.mode === "FREE_FIRST" && this.paidFallback) {
      policy = {
        ...this.costPolicy,
        allowPaidProviders: [
          ...(this.costPolicy.allowPaidProviders ?? []),
          ...metas.filter((m) => m.costClass === "PAID").map((m) => m.providerId),
        ],
      };
    }
    return metas.filter((m) => isResourceAllowed(m, policy)).map((m) => m.providerId);
  }

  getCostPolicy(): CostPolicy {
    return { ...this.costPolicy };
  }

  listEvents(): ManagerEvent[] {
    return this.events.map((e) => ({ ...e }));
  }

  /**
   * Select provider ids allowed under cost policy + health listing.
   */
  async selectResources(preferredProviderId?: string): Promise<ManagerRouteTrace> {
    const providers = await this.runtime.listProviders();
    const metas: ResourceCostMeta[] = providers.map((p) => ({
      providerId: p.id,
      costClass:
        this.costClassByProvider[p.id] ?? defaultCostClass(p.id),
      priority: p.id === "mock" ? 0 : 50,
    }));

    const rejected: ManagerRouteTrace["rejected"] = [];
    for (const m of metas) {
      if (!isResourceAllowed(m, this.costPolicy)) {
        rejected.push({
          providerId: m.providerId,
          reason:
            this.costPolicy.mode === "FREE_ONLY" && m.costClass !== "FREE"
              ? "blocked by FREE_ONLY"
              : m.costClass === "UNKNOWN"
                ? "UNKNOWN cost class blocked"
                : "not allowlisted for paid use",
        });
      }
    }

    const ranked = rankResources(metas, this.costPolicy);
    // Prefer healthy/available
    const healthy = ranked.filter((m) => {
      const p = providers.find((x) => x.id === m.providerId);
      return p?.availability === "available" || p?.availableForRequest;
    });
    const pool = healthy.length ? healthy : ranked;

    let preferred: string | null =
      preferredProviderId &&
      pool.some((m) => m.providerId === preferredProviderId)
        ? preferredProviderId
        : pool[0]?.providerId ?? null;

    // FREE_ONLY: never select paid
    if (
      preferred &&
      this.costPolicy.mode === "FREE_ONLY" &&
      (this.costClassByProvider[preferred] ?? defaultCostClass(preferred)) !==
        "FREE"
    ) {
      preferred = pool.find((m) => m.costClass === "FREE")?.providerId ?? null;
    }

    return {
      preferredProviderId: preferred,
      actualProviderId: null,
      finalProviderId: preferred,
      costMode: this.costPolicy.mode,
      candidates: pool.map((m) => m.providerId),
      rejected,
      fallbackUsed: false,
      selectionReason: preferred
        ? `selected ${preferred} under ${this.costPolicy.mode}`
        : `no eligible providers under ${this.costPolicy.mode}`,
      fallbackReason: null,
      employeeId: null,
      modelId: null,
      finalStatus: preferred ? null : "DEFERRED",
    };
  }

  /**
   * Run the full bounded manager lifecycle for one high-level objective.
   */
  async run(objective: string, options?: { signal?: AbortSignal }): Promise<ManagerTaskResult> {
    const managerTaskId = `mgr_${randomUUID()}`;
    const sm = new ManagerStateMachine({ now: this.now });
    let plan: ManagerPlan | null = null;
    let routeTrace: ManagerRouteTrace | null = null;
    let officeTaskId: string | null = null;
    let officeTaskStatus: string | null = null;
    let qaStatus: string | null = null;
    let error: string | null = null;
    let summary = "";
    const started = this.now();

    const emit = (type: string, message: string) => {
      this.events.push({
        id: `mevt_${randomUUID()}`,
        type,
        managerTaskId,
        message: sanitize(message),
        state: sm.current,
        createdAt: new Date(this.now()).toISOString(),
      });
    };

    const transition = (to: ManagerState) => {
      sm.transition(to);
      emit(`manager.${to}`, `state → ${to}`);
    };

    try {
      emit("manager.received", "Task received");
      if (options?.signal?.aborted) {
        transition("cancelled");
        return this.finish(
          managerTaskId,
          null,
          sm.current,
          classifyTask(objective),
          null,
          null,
          "cancelled",
          null,
          "Cancelled before start",
          null,
        );
      }

      transition("understanding");
      const requirements = classifyTask(objective);
      emit("manager.classified", `category=${requirements.category}`);

      transition("planned");
      plan = buildPlan({
        taskId: managerTaskId,
        projectId: this.projectId,
        objective,
        requirements,
        costMode: this.costPolicy.mode,
        limits: this.planLimits,
        now: this.now,
      });
      emit("manager.planned", `${plan.steps.length} steps`);

      transition("routing");
      routeTrace = await this.selectResources(
        requirements.codingRequired ? "mock" : undefined,
      );
      if (!routeTrace.finalProviderId) {
        if (this.costPolicy.mode === "FREE_ONLY") {
          transition("deferred");
          summary = "No free providers available; deferred";
          return this.finish(
            managerTaskId,
            null,
            sm.current,
            requirements,
            plan,
            routeTrace,
            null,
            null,
            summary,
            null,
          );
        }
        transition("failed");
        error = "No eligible providers";
        return this.finish(
          managerTaskId,
          null,
          sm.current,
          requirements,
          plan,
          routeTrace,
          null,
          null,
          summary,
          error,
        );
      }

      if (
        this.costPolicy.maxProviderCalls != null &&
        this.providerCallCount >= this.costPolicy.maxProviderCalls
      ) {
        transition("failed");
        error = "Provider call budget exhausted";
        return this.finish(
          managerTaskId,
          null,
          sm.current,
          requirements,
          plan,
          routeTrace,
          null,
          null,
          summary,
          error,
        );
      }

      transition("executing");
      this.providerCallCount += 1;

      // Map to existing office createTask — multi when collaboration useful
      const mode =
        requirements.collaborationUseful || requirements.finalReviewRequired
          ? "multi"
          : "single";

      const providers = await this.runtime.listProviders();
      const allowed = this.resolveAllowedProviderIds(providers.map((p) => p.id));
      // Mock execution mode always allows mock
      if (this.executionMode === "mock" && !allowed.includes("mock")) {
        allowed.push("mock");
      }
      routeTrace = {
        ...routeTrace,
        candidates: allowed,
      };
      if (this.costPolicy.mode === "FREE_ONLY" && allowed.length === 0) {
        transition("deferred");
        summary = "No free providers available under FREE_ONLY";
        return this.finish(
          managerTaskId,
          null,
          sm.current,
          requirements,
          plan,
          { ...routeTrace!, finalStatus: "DEFERRED" },
          null,
          null,
          summary,
          null,
        );
      }
      const preferredForExec =
        this.executionMode === "mock"
          ? "mock"
          : routeTrace.preferredProviderId && allowed.includes(routeTrace.preferredProviderId)
            ? routeTrace.preferredProviderId
            : allowed[0] ?? "mock";
      routeTrace = {
        ...routeTrace,
        preferredProviderId: preferredForExec,
        finalProviderId: preferredForExec,
      };

      const task = await this.runtime.createTask({
        objective: objective.slice(0, 4000),
        mode,
        routing: {
          preferredProviderId: preferredForExec,
          executionMode: this.executionMode,
          costMode: this.costPolicy.mode,
          allowedProviderIds: allowed,
          maxAttempts: this.executionMode === "mock" ? 1 : 3,
        },
      });
      officeTaskId = task.id;
      emit("manager.office_task", `office task ${task.id} mode=${mode}`);

      // Poll until terminal or limits
      const deadline = started + this.planLimits.maxDurationMs;
      while (this.now() < deadline) {
        if (options?.signal?.aborted) {
          await this.runtime.cancelTask(task.id).catch(() => undefined);
          transition("cancelled");
          officeTaskStatus = "cancelled";
          summary = "Cancelled during execution";
          return this.finish(
            managerTaskId,
            officeTaskId,
            sm.current,
            requirements,
            plan,
            routeTrace,
            officeTaskStatus,
            qaStatus,
            summary,
            null,
          );
        }
        const current = await this.runtime.getTask(task.id);
        officeTaskStatus = current.status;
        if (
          current.status === "completed" ||
          current.status === "failed" ||
          current.status === "cancelled"
        ) {
          break;
        }
        await new Promise((r) => setTimeout(r, 15));
      }

      const finalTask = await this.runtime.getTask(task.id);
      officeTaskStatus = finalTask.status;

      if (finalTask.status === "cancelled") {
        transition("cancelled");
        summary = "Office task cancelled";
      } else if (finalTask.status === "failed") {
        transition("failed");
        error = sanitize(finalTask.error?.message ?? "Task failed");
        summary = error;
      } else if (finalTask.status !== "completed") {
        transition("failed");
        error = "Execution deadline exceeded";
        summary = error;
        await this.runtime.cancelTask(task.id).catch(() => undefined);
      } else {
        // Capture actual provider from office outputs
        const actualProv = finalTask.outputs[0]?.provider ?? null;
        if (routeTrace) {
          routeTrace = {
            ...routeTrace,
            actualProviderId: actualProv,
            finalProviderId: actualProv ?? routeTrace.finalProviderId,
            modelId: finalTask.outputs[0]?.model ?? null,
            employeeId: finalTask.outputs[0]?.employeeId ?? "developer",
            fallbackUsed: Boolean(
              actualProv &&
                routeTrace.preferredProviderId &&
                actualProv !== routeTrace.preferredProviderId,
            ),
            fallbackReason:
              actualProv &&
              routeTrace.preferredProviderId &&
              actualProv !== routeTrace.preferredProviderId
                ? "provider_changed_during_execution"
                : null,
            finalStatus: "SUCCESS",
          };
          // FREE_ONLY integrity: actual must be free
          if (this.costPolicy.mode === "FREE_ONLY" && actualProv) {
            const cls =
              this.costClassByProvider[actualProv] ?? defaultCostClass(actualProv);
            if (cls !== "FREE") {
              transition("failed");
              error = `FREE_ONLY violation: actual provider ${actualProv} is ${cls}`;
              summary = error;
              routeTrace = { ...routeTrace, finalStatus: "FAILED" };
              return this.finish(
                managerTaskId,
                officeTaskId,
                sm.current,
                requirements,
                plan,
                routeTrace,
                officeTaskStatus,
                qaStatus,
                summary,
                error,
              );
            }
          }
        }

        // Optional QA stage with bounded repair loop
        if (requirements.qaRequired) {
          let repairAttempt = 0;
          while (repairAttempt <= this.maxRepairAttempts) {
            if (options?.signal?.aborted) {
              transition("cancelled");
              return this.finish(
                managerTaskId,
                officeTaskId,
                sm.current,
                requirements,
                plan,
                routeTrace,
                officeTaskStatus,
                qaStatus,
                "Cancelled during QA",
                null,
              );
            }
            if (sm.current !== "qa") {
              try {
                transition("qa");
              } catch {
                /* already in qa */
              }
            }
            try {
              const qaResult = await this.runtime.invokeTool(
                "qa.run",
                { levels: ["static", "project"] },
                { taskId: task.id, employeeId: "developer" },
              );
              if (qaResult.ok) {
                const body = qaResult.result as { status?: string };
                qaStatus = body.status ?? "INCONCLUSIVE";
                emit("manager.qa", `QA ${qaStatus} attempt=${repairAttempt}`);
                if (qaStatus === "PASS") break;
                if (qaStatus === "INCONCLUSIVE") {
                  emit("manager.qa", "INCONCLUSIVE remains INCONCLUSIVE (no fake PASS)");
                  break;
                }
                if (qaStatus === "FAIL") {
                  if (repairAttempt >= this.maxRepairAttempts) {
                    transition("failed");
                    error = "QA FAIL after repair limit";
                    summary = sanitize(
                      finalTask.finalResult?.summary ??
                        finalTask.outputs[0]?.summary ??
                        "QA FAIL",
                    );
                    return this.finish(
                      managerTaskId,
                      officeTaskId,
                      sm.current,
                      requirements,
                      plan,
                      routeTrace
                        ? { ...routeTrace, finalStatus: "FAILED" }
                        : null,
                      officeTaskStatus,
                      qaStatus,
                      summary,
                      error,
                    );
                  }
                  transition("repairing");
                  emit("manager.repair", `Repair attempt ${repairAttempt + 1}`);
                  const failures =
                    (qaResult.result as { failures?: string[] })?.failures ?? [];
                  const repair = await attemptBoundedRepair(this.runtime, {
                    taskId: task.id,
                    failures,
                    employeeId: "developer",
                    signal: options?.signal,
                  });
                  emit(
                    "manager.repair",
                    repair.applied
                      ? `ChangeSet applied: ${repair.changeSetId ?? "ok"}`
                      : `Repair skipped: ${repair.reason}`,
                  );
                  if (!repair.applied && repair.reason.includes("permission")) {
                    transition("failed");
                    error = "Repair permission denied";
                    return this.finish(
                      managerTaskId,
                      officeTaskId,
                      sm.current,
                      requirements,
                      plan,
                      routeTrace
                        ? { ...routeTrace, finalStatus: "FAILED" }
                        : null,
                      officeTaskStatus,
                      qaStatus,
                      error,
                      error,
                    );
                  }
                  repairAttempt += 1;
                  continue;
                }
              } else {
                qaStatus = "INCONCLUSIVE";
                emit("manager.qa", "QA tool error → INCONCLUSIVE");
                break;
              }
            } catch {
              qaStatus = "INCONCLUSIVE";
              emit("manager.qa", "QA unavailable → INCONCLUSIVE");
              break;
            }
            break;
          }
        }

        if (requirements.finalReviewRequired || mode === "multi") {
          if (sm.current !== "failed") {
            try {
              if (sm.canTransition("reviewing")) transition("reviewing");
            } catch {
              /* already past */
            }
          }
        }

        // Knowledge: explicit durable decision only for substantial completed work
        if (
          finalTask.status === "completed" &&
          (requirements.category === "project_change" ||
            requirements.category === "mixed")
        ) {
          try {
            this.runtime.addKnowledge({
              type: "decision",
              title: `Manager: ${requirements.category}`,
              content: (
                finalTask.finalResult?.summary ??
                finalTask.outputs[0]?.summary ??
                objective
              ).slice(0, 1500),
              provenance: "system",
              tags: ["manager", requirements.category],
            });
            emit("manager.knowledge", "Durable decision recorded");
          } catch {
            /* ACL / validation — non-fatal */
          }
        }

        if (!sm.isTerminal()) {
          transition("completed");
        }
        summary = sanitize(
          finalTask.finalResult?.summary ??
            finalTask.outputs[0]?.summary ??
            "Task completed",
        );
      }
    } catch (err) {
      error = sanitize(err instanceof Error ? err.message : "Manager error");
      try {
        if (!sm.isTerminal()) {
          if (sm.canTransition("failed")) transition("failed");
        }
      } catch {
        /* ignore */
      }
      summary = error;
    }

    return this.finish(
      managerTaskId,
      officeTaskId,
      sm.current,
      plan?.requirements ?? classifyTask(objective),
      plan,
      routeTrace,
      officeTaskStatus,
      qaStatus,
      summary,
      error,
    );
  }

  private finish(
    managerTaskId: string,
    officeTaskId: string | null,
    state: ManagerState,
    requirements: TaskRequirements,
    plan: ManagerPlan | null,
    routeTrace: ManagerRouteTrace | null,
    officeTaskStatus: string | null,
    qaStatus: string | null,
    summary: string,
    error: string | null,
  ): ManagerTaskResult {
    return {
      managerTaskId,
      officeTaskId,
      state,
      requirements,
      plan,
      routeTrace,
      costMode: this.costPolicy.mode,
      summary: sanitize(summary),
      officeTaskStatus,
      qaStatus,
      events: this.listEvents().filter((e) => e.managerTaskId === managerTaskId),
      error: error ? sanitize(error) : null,
    };
  }
}
