/**
 * Bounded QA repair via existing Project Execution ChangeSet tools.
 * Manager must not call fs directly — only ToolRegistry.
 */

import type { OfficeRuntime } from "../runtime.ts";

export interface RepairLimits {
  maxRepairToolCalls: number;
  maxRepairDurationMs: number;
}

export const DEFAULT_REPAIR_LIMITS: RepairLimits = {
  maxRepairToolCalls: 8,
  maxRepairDurationMs: 15_000,
};

export interface RepairAttemptResult {
  applied: boolean;
  changeSetId: string | null;
  checkpointId: string | null;
  reason: string;
  toolCalls: number;
}

function sanitize(s: string, max = 240): string {
  return String(s ?? "")
    .replace(/Bearer\s+\S+/gi, "[REDACTED]")
    .replace(/secret-api-key-\S+/gi, "[REDACTED]")
    .replace(/\/home\/[^\s"']+/g, "[PATH]")
    .slice(0, max);
}

/**
 * Parse relative path from a QA failure line like `src/bad.ts: Unbalanced '{'`.
 */
export function parseFailurePath(failure: string): string | null {
  const m = failure.match(/^([^:]+):\s/);
  if (!m) return null;
  const p = m[1]!.trim();
  if (!p || p === "?" || p.includes("..") || p.startsWith("/")) return null;
  return p;
}

/**
 * Attempt a minimal static fix for common bracket/JSON issues using ChangeSet.
 * Only runs tools; never touches fs directly.
 */
export async function attemptBoundedRepair(
  runtime: OfficeRuntime,
  input: {
    taskId: string;
    failures: string[];
    employeeId?: string;
    signal?: AbortSignal;
    limits?: Partial<RepairLimits>;
  },
): Promise<RepairAttemptResult> {
  const limits = { ...DEFAULT_REPAIR_LIMITS, ...input.limits };
  const employeeId = input.employeeId ?? "developer";
  let toolCalls = 0;
  const started = Date.now();

  if (input.signal?.aborted) {
    return {
      applied: false,
      changeSetId: null,
      checkpointId: null,
      reason: "cancelled",
      toolCalls,
    };
  }

  // Prefer Developer Agent (write-capable). If caller passed a non-write employee, refuse write.
  if (employeeId !== "developer") {
    return {
      applied: false,
      changeSetId: null,
      checkpointId: null,
      reason: "repair employee lacks write permission",
      toolCalls,
    };
  }

  const paths = [
    ...new Set(
      input.failures
        .map(parseFailurePath)
        .filter((p): p is string => Boolean(p)),
    ),
  ].slice(0, 5);

  if (paths.length === 0) {
    return {
      applied: false,
      changeSetId: null,
      checkpointId: null,
      reason: "no repairable file path in QA failures",
      toolCalls,
    };
  }

  for (const relPath of paths) {
    if (input.signal?.aborted) {
      return {
        applied: false,
        changeSetId: null,
        checkpointId: null,
        reason: "cancelled",
        toolCalls,
      };
    }
    if (Date.now() - started > limits.maxRepairDurationMs) {
      return {
        applied: false,
        changeSetId: null,
        checkpointId: null,
        reason: "repair duration limit",
        toolCalls,
      };
    }
    if (toolCalls >= limits.maxRepairToolCalls) {
      return {
        applied: false,
        changeSetId: null,
        checkpointId: null,
        reason: "repair tool-call limit",
        toolCalls,
      };
    }

    toolCalls += 1;
    const read = await runtime.invokeTool(
      "project.read",
      { path: relPath },
      { taskId: input.taskId, employeeId },
    );
    if (!read.ok) continue;

    const content =
      typeof read.result === "string"
        ? read.result
        : typeof (read.result as { content?: string })?.content === "string"
          ? (read.result as { content: string }).content
          : null;
    if (content == null) continue;

    const fixed = tryStaticFix(content);
    if (fixed == null || fixed === content) continue;

    // Reserve three calls before applying: ChangeSet, validation, and a possible rollback.
    // This keeps the entire repair path within the configured tool-call limit.
    if (toolCalls + 3 > limits.maxRepairToolCalls) break;
    toolCalls += 1;
    const apply = await runtime.invokeTool(
      "project.changeset.apply",
      {
        label: "qa-repair",
        changes: [
          {
            path: relPath,
            operation: "update",
            content: fixed,
          },
        ],
      },
      { taskId: input.taskId, employeeId },
    );

    if (!apply.ok) {
      return {
        applied: false,
        changeSetId: null,
        checkpointId: null,
        reason: sanitize(apply.error?.message ?? "changeset apply failed"),
        toolCalls,
      };
    }

    const body = apply.result as {
      changeSetId?: string;
      checkpointId?: string;
    };

    // Validation is mandatory. If it fails, roll back the ChangeSet instead of
    // claiming success for a repair that did not pass the project's validator.
    toolCalls += 1;
    const validation = await runtime.invokeTool(
      "project.validate",
      { paths: [relPath] },
      { taskId: input.taskId, employeeId },
    );
    const validationResult = validation.ok
      ? validation.result as { status?: string; issues?: Array<{ message?: string }> }
      : null;

    if (!validation.ok || validationResult?.status !== "pass") {
      if (body.checkpointId) {
        toolCalls += 1;
        const rollback = await runtime.invokeTool(
          "project.checkpoint.rollback",
          { checkpointId: body.checkpointId },
          { taskId: input.taskId, employeeId },
        );
        if (!rollback.ok) {
          return {
            applied: true,
            changeSetId: body.changeSetId ?? null,
            checkpointId: body.checkpointId ?? null,
            reason: sanitize(`validation failed and rollback failed: ${rollback.error?.message ?? "unknown error"}`),
            toolCalls,
          };
        }
      }
      const details = validationResult?.issues?.map((issue) => issue.message).filter(Boolean).join("; ");
      return {
        applied: false,
        changeSetId: body.changeSetId ?? null,
        checkpointId: body.checkpointId ?? null,
        reason: sanitize(`validation failed; change rolled back${details ? `: ${details}` : ""}`),
        toolCalls,
      };
    }

    return {
      applied: true,
      changeSetId: body.changeSetId ?? null,
      checkpointId: body.checkpointId ?? null,
      reason: sanitize(`validated fix applied to ${relPath}`),
      toolCalls,
    };
  }

  return {
    applied: false,
    changeSetId: null,
    checkpointId: null,
    reason: "no automatic static fix available",
    toolCalls,
  };
}

/**
 * Minimal deterministic fixes for static validator failures (brackets/JSON).
 * Returns null if no safe fix.
 */
export function tryStaticFix(content: string): string | null {
  const trimmed = content.replace(/\s+$/, "");
  if (!trimmed) return null;

  // Tokenize enough of JS/TS/JSON to ignore bracket-like characters inside
  // quoted strings and comments. We intentionally avoid broad auto-rewrites:
  // only close a single unmatched opener when it is the final code token, or
  // remove a trailing comma that is immediately before a real closing token.
  type State = "code" | "single" | "double" | "template" | "line-comment" | "block-comment";
  let state: State = "code";
  const stack: Array<{ char: "{" | "["; index: number }> = [];
  const closing: Array<{ index: number; char: "}" | "]" }> = [];
  const commas: number[] = [];
  let escaped = false;

  for (let i = 0; i < trimmed.length; i++) {
    const ch = trimmed[i]!;
    const next = trimmed[i + 1] ?? "";

    if (state === "line-comment") {
      if (ch === "\n" || ch === "\r") state = "code";
      continue;
    }
    if (state === "block-comment") {
      if (ch === "*" && next === "/") { state = "code"; i++; }
      continue;
    }
    if (state === "single" || state === "double" || state === "template") {
      if (escaped) { escaped = false; continue; }
      if (ch === "\\") { escaped = true; continue; }
      if ((state === "single" && ch === "'") ||
          (state === "double" && ch === '"') ||
          (state === "template" && ch === "`")) state = "code";
      continue;
    }

    if (ch === "/" && next === "/") { state = "line-comment"; i++; continue; }
    if (ch === "/" && next === "*") { state = "block-comment"; i++; continue; }
    if (ch === "'") { state = "single"; continue; }
    if (ch === '"') { state = "double"; continue; }
    if (ch === "`") { state = "template"; continue; }

    if (ch === "{" || ch === "[") {
      stack.push({ char: ch, index: i });
    } else if (ch === "}" || ch === "]") {
      closing.push({ index: i, char: ch });
      const expected = ch === "}" ? "{" : "[";
      const top = stack[stack.length - 1];
      if (top?.char === expected) stack.pop();
    } else if (ch === ",") {
      commas.push(i);
    }
  }

  // Only repair one unmatched opener when the opener itself is the last
  // non-whitespace code token. This is deliberately conservative.
  const last = trimmed.length - 1;
  const top = stack[stack.length - 1];
  if (top && top.index === last && stack.length === 1) {
    return `${trimmed}\n${top.char === "{" ? "}" : "]"}\n`;
  }

  // Remove only a comma whose next non-whitespace character is a closing
  // bracket and which is not inside a string/comment (positions were tokenized).
  const comma = commas.at(-1);
  if (comma != null) {
    let j = comma + 1;
    while (j < trimmed.length && /\s/.test(trimmed[j]!)) j++;
    if (trimmed[j] === "}" || trimmed[j] === "]") {
      return `${trimmed.slice(0, comma)}${trimmed.slice(comma + 1)}\n`;
    }
  }

  return null;
}
