import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { ProviderError } from "./errors.ts";
import { ProviderRouter } from "./provider-router.ts";
import { ProviderHealthStore, withHealthTracking } from "./provider-health.ts";
import {
  type ProviderAdapter,
  type GenerateRequest,
  type GenerateResponse,
  type ProviderCapabilities,
} from "./providers.ts";
import type { ProviderAvailability } from "./types.ts";
import { AgentExecutor, type AgentTask } from "./agent-executor.ts";
import { resolveEmployeeBindings, bindingFor } from "./employee-bindings.ts";

function fakeAdapter(opts: {
  id: string;
  costClass?: "free" | "paid";
  failWith?: ProviderError;
  capture?: { model?: string; calls: number };
}): ProviderAdapter {
  const caps: ProviderCapabilities = {
    text: true,
    code: true,
    streaming: false,
    tools: false,
    vision: false,
    jsonMode: false,
  };
  const capture = opts.capture ?? { calls: 0 };
  return {
    id: opts.id,
    label: opts.id,
    capabilities: caps,
    getAvailability(): ProviderAvailability {
      return "available";
    },
    listModels() {
      return [
        {
          id: `${opts.id}:model`,
          provider: opts.id,
          capabilities: ["text"],
          contextWindow: null,
          costClass: opts.costClass ?? "paid",
          availability: "available",
          label: opts.id,
        },
      ];
    },
    async generate(req: GenerateRequest): Promise<GenerateResponse> {
      capture.calls += 1;
      capture.model = req.model;
      if (opts.failWith) throw opts.failWith;
      return {
        text: JSON.stringify({
          summary: `from-${opts.id}`,
          findings: [`provider:${opts.id}`],
          evidence: [],
          risks: [],
          recommendations: [],
          questions: [],
          confidence: "low",
        }),
        model: req.model,
        provider: opts.id,
        latencyMs: 1,
      };
    },
  };
}

function makeRouter(adapters: ProviderAdapter[], primaryId = "mock") {
  const health = new ProviderHealthStore();
  for (const a of adapters) {
    health.register({
      providerId: a.id,
      label: a.label,
      configured: true,
      availability: "available",
    });
  }
  const tracked = adapters.map((a) => withHealthTracking(a, health));
  const primary = tracked.find((a) => a.id === primaryId) ?? tracked[0]!;
  return {
    router: new ProviderRouter({ adapters: tracked, primary, health }),
    health,
    tracked,
  };
}

function agentTask(employeeId: string): AgentTask {
  return {
    id: `step_${employeeId}`,
    parentTaskId: "task_1",
    employeeId,
    role: employeeId,
    objective: "do work",
    status: "pending",
    dependsOn: [],
    required: false,
    kind: "parallel",
    timeoutMs: 5000,
    upstreamResults: [],
    result: null,
    error: null,
    createdAt: new Date().toISOString(),
    startedAt: null,
    completedAt: null,
  };
}

describe("preferred provider routing", () => {
  it("1–6. live bindings select anthropic/gemini/xai/openai", async () => {
    const captures = {
      anthropic: { calls: 0 },
      gemini: { calls: 0 },
      xai: { calls: 0 },
      openai: { calls: 0 },
      mock: { calls: 0 },
    };
    const adapters = [
      fakeAdapter({ id: "mock", capture: captures.mock }),
      fakeAdapter({ id: "anthropic", capture: captures.anthropic }),
      fakeAdapter({ id: "gemini", capture: captures.gemini }),
      fakeAdapter({ id: "xai", capture: captures.xai }),
      fakeAdapter({ id: "openai", capture: captures.openai }),
    ];
    const { router } = makeRouter(adapters);
    const exec = new AgentExecutor();
    const bindings = resolveEmployeeBindings("live");

    for (const emp of ["developer", "researcher", "automation", "ceo", "pm", "jira"] as const) {
      const b = bindingFor(emp, bindings);
      const result = await exec.execute(agentTask(emp), "obj", {
        router,
        modelId: b.modelId,
        systemPrompt: "sys",
        providerId: b.providerId,
      });
      assert.equal(result.status, "completed");
      assert.equal(result.employeeId, emp);
      assert.equal(result.preferredProviderId, b.providerId);
      assert.equal(result.providerId, b.providerId);
      assert.equal(result.routeTrace?.preferredProviderId, b.providerId);
      assert.equal(result.routeTrace?.finalProviderId, b.providerId);
    }
    assert.equal(captures.anthropic.calls, 2); // developer, pm
    assert.equal(captures.gemini.calls, 1); // researcher
    assert.equal(captures.xai.calls, 1); // automation
    assert.equal(captures.openai.calls, 2); // ceo, jira
    assert.equal(captures.mock.calls, 0); // all six have live bindings
  });

  it("5. modelId from binding reaches the provider", async () => {
    const capture = { calls: 0, model: "" };
    const adapters = [
      fakeAdapter({ id: "mock" }),
      fakeAdapter({ id: "anthropic", capture }),
    ];
    const { router } = makeRouter(adapters);
    const exec = new AgentExecutor();
    await exec.execute(agentTask("developer"), "obj", {
      router,
      modelId: "anthropic:claude-custom-model",
      systemPrompt: "sys",
      providerId: "anthropic",
    });
    assert.equal(capture.model, "anthropic:claude-custom-model");
  });

  it("6–7. preferred first; recoverable failure falls back", async () => {
    const captureA = { calls: 0 };
    const captureB = { calls: 0 };
    const adapters = [
      fakeAdapter({ id: "mock" }),
      fakeAdapter({
        id: "anthropic",
        capture: captureA,
        failWith: new ProviderError("RATE_LIMIT", "limited", true),
      }),
      fakeAdapter({ id: "openai", capture: captureB, costClass: "paid" }),
    ];
    const { router } = makeRouter(adapters);
    const { response, trace } = await router.executeWithFallback(
      { model: "m", systemPrompt: "s", userPrompt: "u" },
      {
        preferredProviderId: "anthropic",
        policy: { mode: "free-first", maxAttempts: 3, excludeMockInFreeFirst: true },
      },
    );
    assert.equal(response.provider, "openai");
    assert.equal(trace.preferredProviderId, "anthropic");
    assert.equal(trace.fallbackUsed, true);
    assert.equal(trace.finalProviderId, "openai");
    assert.equal(captureA.calls, 1);
    assert.equal(captureB.calls, 1);
    assert.equal(trace.candidates[0], "anthropic");
  });

  it("8. AUTH does not fallback", async () => {
    const adapters = [
      fakeAdapter({ id: "mock" }),
      fakeAdapter({
        id: "anthropic",
        failWith: new ProviderError("AUTH", "bad key", false),
      }),
      fakeAdapter({ id: "openai" }),
    ];
    const { router } = makeRouter(adapters);
    await assert.rejects(
      () =>
        router.executeWithFallback(
          { model: "m", systemPrompt: "s", userPrompt: "u" },
          {
            preferredProviderId: "anthropic",
            policy: { mode: "free-first", maxAttempts: 3, excludeMockInFreeFirst: true },
          },
        ),
      (e: unknown) => e instanceof ProviderError && e.code === "AUTH",
    );
  });

  it("9. INVALID_REQUEST does not fallback", async () => {
    const adapters = [
      fakeAdapter({ id: "mock" }),
      fakeAdapter({
        id: "gemini",
        failWith: new ProviderError("INVALID_REQUEST", "bad", false),
      }),
      fakeAdapter({ id: "openai" }),
    ];
    const { router } = makeRouter(adapters);
    await assert.rejects(
      () =>
        router.executeWithFallback(
          { model: "m", systemPrompt: "s", userPrompt: "u" },
          {
            preferredProviderId: "gemini",
            policy: { mode: "free-first", maxAttempts: 3, excludeMockInFreeFirst: true },
          },
        ),
      (e: unknown) => e instanceof ProviderError && e.code === "INVALID_REQUEST",
    );
  });

  it("10–11. fallback preserves employeeId; actual provider separate", async () => {
    const adapters = [
      fakeAdapter({ id: "mock" }),
      fakeAdapter({
        id: "openai",
        failWith: new ProviderError("SERVER_ERROR", "5xx", true),
      }),
      fakeAdapter({ id: "anthropic" }),
    ];
    const { router } = makeRouter(adapters);
    const exec = new AgentExecutor();
    const result = await exec.execute(agentTask("ceo"), "obj", {
      router,
      modelId: "openai:default",
      systemPrompt: "sys",
      providerId: "openai",
    });
    assert.equal(result.employeeId, "ceo");
    assert.equal(result.preferredProviderId, "openai");
    assert.equal(result.providerId, "anthropic");
    assert.equal(result.routeTrace?.fallbackUsed, true);
  });

  it("12. mock mode maps all employees to MockProvider", async () => {
    const capture = { calls: 0 };
    const adapters = [
      fakeAdapter({ id: "mock", capture }),
      fakeAdapter({ id: "anthropic" }),
    ];
    const { router } = makeRouter(adapters);
    const exec = new AgentExecutor();
    const bindings = resolveEmployeeBindings("mock");
    for (const emp of ["developer", "researcher", "automation", "ceo", "pm", "jira"]) {
      const b = bindingFor(emp, bindings);
      const result = await exec.execute(agentTask(emp), "obj", {
        router,
        modelId: b.modelId,
        systemPrompt: "sys",
        providerId: b.providerId,
      });
      assert.equal(result.providerId, "mock");
      assert.equal(result.preferredProviderId, "mock");
    }
    assert.equal(capture.calls, 6);
  });

  it("13. live mode never silently substitutes MockProvider when preferred missing", async () => {
    const captureMock = { calls: 0 };
    const adapters = [
      fakeAdapter({ id: "mock", capture: captureMock }),
      // anthropic NOT registered
      fakeAdapter({ id: "openai" }),
    ];
    const { router } = makeRouter(adapters);
    // preferred anthropic with maxAttempts 1 → empty candidates → error, not mock
    await assert.rejects(
      () =>
        router.executeWithFallback(
          { model: "m", systemPrompt: "s", userPrompt: "u" },
          {
            preferredProviderId: "anthropic",
            policy: { mode: "primary-only", maxAttempts: 1 },
          },
        ),
      (e: unknown) => e instanceof ProviderError,
    );
    assert.equal(captureMock.calls, 0);
  });

  it("16. route traces never contain secrets", async () => {
    const adapters = [
      fakeAdapter({ id: "mock" }),
      fakeAdapter({
        id: "anthropic",
        failWith: new ProviderError("AUTH", "secret-api-key-123 failed", false),
      }),
    ];
    const { router } = makeRouter(adapters);
    try {
      await router.executeWithFallback(
        { model: "m", systemPrompt: "s", userPrompt: "u" },
        { preferredProviderId: "anthropic", policy: { mode: "free-first", maxAttempts: 1 } },
      );
    } catch (e) {
      const msg = e instanceof Error ? e.message : "";
      // ProviderError may still carry original message internally; public sanitize is separate
      void msg;
    }
    const { trace } = await router
      .executeWithFallback(
        { model: "m", systemPrompt: "s", userPrompt: "u" },
        { preferredProviderId: "mock", policy: { mode: "primary-only", maxAttempts: 1 } },
      )
      .then((r) => r);
    const blob = JSON.stringify(trace);
    assert.equal(blob.includes("API_KEY"), false);
    assert.equal(blob.includes("Authorization"), false);
  });
});
