/**
 * Employee → provider/model bindings (Phase 4).
 * Employees are roles; providers are engines. Binding is configuration, not identity.
 */

import { MOCK_MODEL_ID } from "./providers.ts";
import { ANTHROPIC_MODEL_ID } from "./anthropic-provider.ts";
import { GEMINI_MODEL_ID } from "./gemini-provider.ts";
import { XAI_MODEL_ID } from "./xai-provider.ts";
import { OPENAI_MODEL_ID } from "./openai-provider.ts";

export interface EmployeeBinding {
  employeeId: string;
  providerId: string;
  modelId: string;
}

/** Live target bindings (require corresponding API keys to activate). */
export const LIVE_EMPLOYEE_BINDINGS: readonly EmployeeBinding[] = [
  { employeeId: "ceo", providerId: "openai", modelId: OPENAI_MODEL_ID },
  { employeeId: "pm", providerId: "anthropic", modelId: ANTHROPIC_MODEL_ID },
  { employeeId: "developer", providerId: "anthropic", modelId: ANTHROPIC_MODEL_ID },
  { employeeId: "researcher", providerId: "gemini", modelId: GEMINI_MODEL_ID },
  { employeeId: "automation", providerId: "xai", modelId: XAI_MODEL_ID },
  { employeeId: "jira", providerId: "openai", modelId: OPENAI_MODEL_ID },
] as const;

/** Deterministic mock bindings for tests and offline operation. */
export const MOCK_EMPLOYEE_BINDINGS: readonly EmployeeBinding[] = [
  { employeeId: "ceo", providerId: "mock", modelId: MOCK_MODEL_ID },
  { employeeId: "pm", providerId: "mock", modelId: MOCK_MODEL_ID },
  { employeeId: "developer", providerId: "mock", modelId: MOCK_MODEL_ID },
  { employeeId: "researcher", providerId: "mock", modelId: MOCK_MODEL_ID },
  { employeeId: "automation", providerId: "mock", modelId: MOCK_MODEL_ID },
  { employeeId: "jira", providerId: "mock", modelId: MOCK_MODEL_ID },
] as const;

export type BindingMode = "mock" | "live";

export function resolveEmployeeBindings(mode: BindingMode = "mock"): EmployeeBinding[] {
  return mode === "live"
    ? LIVE_EMPLOYEE_BINDINGS.map((b) => ({ ...b }))
    : MOCK_EMPLOYEE_BINDINGS.map((b) => ({ ...b }));
}

export function bindingFor(
  employeeId: string,
  bindings: readonly EmployeeBinding[],
): EmployeeBinding {
  const found = bindings.find((b) => b.employeeId === employeeId);
  return (
    found ?? {
      employeeId,
      providerId: "mock",
      modelId: MOCK_MODEL_ID,
    }
  );
}
