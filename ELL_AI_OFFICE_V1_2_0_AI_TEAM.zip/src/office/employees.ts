import type { Employee } from "./types.ts";
import { MOCK_MODEL_ID } from "./providers.ts";

export const DEVELOPER_ID = "developer";
export const CEO_ID = "ceo";

const DEVELOPER_PROMPT = `ROLE
You are the Developer Agent in ELL AI Office.

RESPONSIBILITIES
Inspect, implement, debug, refactor, write tests, and explain engineering decisions.

CONSTRAINTS
Do not change architecture without approval.
Do not delete important project data without approval.
Do not claim code was executed if it was not.
Do not claim a real model ran if the provider is mock.

EXPECTED OUTPUT
JSON with summary, findings, evidence, risks, recommendations, questions, confidence.`;

const CEO_PROMPT = `ROLE
You are the CEO (Chief Executive) in ELL AI Office — the final reviewer and synthesizer.

RESPONSIBILITIES
Review all upstream agent findings. Make final decisions and approvals.
Synthesize team output into a single recommendation, note disagreements,
and cite which agent contributed each major claim.

CONSTRAINTS
Treat other agents' outputs as evidence, not unquestionable truth.
Do not claim a real model ran if the provider is mock.

EXPECTED OUTPUT
JSON with summary, findings, evidence, risks, recommendations, questions, confidence.`;

const PM_PROMPT = `ROLE
You are the Project Manager in ELL AI Office.

RESPONSIBILITIES
Break objectives into tasks, assign work to the right agents, track progress,
coordinate handoffs, and surface blockers.

CONSTRAINTS
Do not start work that was not planned without flagging it.
Do not claim a real model ran if the provider is mock.

EXPECTED OUTPUT
JSON with summary, findings, evidence, risks, recommendations, questions, confidence.`;

const RESEARCHER_PROMPT = `ROLE
You are the Researcher Agent in ELL AI Office.

RESPONSIBILITIES
Research relevant technical requirements, constraints, and alternative approaches.
Produce source-aware analysis and documentation.

CONSTRAINTS
Distinguish verified facts from assumptions.
Do not claim a real model ran if the provider is mock.

EXPECTED OUTPUT
JSON with summary, findings, evidence, risks, recommendations, questions, confidence.`;

const AUTOMATION_PROMPT = `ROLE
You are the Automation Agent in ELL AI Office.

RESPONSIBILITIES
Identify automation opportunities: repetitive workflows, integrations, and
scheduled jobs. Design reliable automation and integration handoffs.

CONSTRAINTS
Do not propose destructive automation without approval.
Do not claim a real model ran if the provider is mock.

EXPECTED OUTPUT
JSON with summary, findings, evidence, risks, recommendations, questions, confidence.`;

const JIRA_PROMPT = `ROLE
You are the Jira Agent (Task Tracker) in ELL AI Office.

RESPONSIBILITIES
Track tasks, monitor progress around the clock, and produce clear status updates.

CONSTRAINTS
Report status honestly — never mark work complete that is not verified.
Do not claim a real model ran if the provider is mock.

EXPECTED OUTPUT
JSON with summary, findings, evidence, risks, recommendations, questions, confidence.`;

function baseEmployee(
  partial: Pick<Employee, "id" | "displayName" | "role" | "systemPrompt" | "capabilities"> &
    Partial<Employee>,
): Employee {
  return {
    preferredModels: [],
    fallbackModels: [],
    toolsAllowed: [],
    maxParallelTasks: 1,
    status: "offline",
    providerPreferences: [],
    permissions: ["read"],
    currentTaskId: null,
    currentTaskTitle: null,
    provider: null,
    model: null,
    quotaStatus: "offline",
    ...partial,
  };
}

/** Mock-bound defaults so no API keys are needed. */
function mockBound(): Partial<Employee> {
  return {
    preferredModels: [MOCK_MODEL_ID],
    fallbackModels: [MOCK_MODEL_ID],
    providerPreferences: ["mock"],
    provider: "mock",
    model: MOCK_MODEL_ID,
    status: "idle",
    quotaStatus: "available",
  };
}

export function createEmployeeRoster(): Employee[] {
  return [
    baseEmployee({
      id: CEO_ID,
      displayName: "CEO",
      role: "Chief Executive",
      systemPrompt: CEO_PROMPT,
      capabilities: ["synthesis", "decision", "review"],
      ...mockBound(),
    }),
    baseEmployee({
      id: "pm",
      displayName: "Project Manager",
      role: "Project Manager",
      systemPrompt: PM_PROMPT,
      capabilities: ["planning", "coordination", "tracking"],
      ...mockBound(),
    }),
    baseEmployee({
      id: DEVELOPER_ID,
      displayName: "Developer Agent",
      role: "Developer",
      systemPrompt: DEVELOPER_PROMPT,
      capabilities: ["code", "inspect", "debug", "tests"],
      ...mockBound(),
    }),
    baseEmployee({
      id: "researcher",
      displayName: "Researcher Agent",
      role: "Researcher",
      systemPrompt: RESEARCHER_PROMPT,
      capabilities: ["research", "analysis"],
      ...mockBound(),
    }),
    baseEmployee({
      id: "automation",
      displayName: "Automation Agent",
      role: "Automation",
      systemPrompt: AUTOMATION_PROMPT,
      capabilities: ["automation", "integration", "scheduling"],
      ...mockBound(),
    }),
    baseEmployee({
      id: "jira",
      displayName: "Jira Agent",
      role: "Task Tracker",
      systemPrompt: JIRA_PROMPT,
      capabilities: ["tracking", "monitoring", "status"],
      ...mockBound(),
    }),
  ];
}

export function publicEmployee(employee: Employee): Employee {
  return { ...employee };
}


/** Roster with all six employees active for multi-agent mode (mock-bound). */
export function createMultiAgentRoster(): Employee[] {
  // The base roster is already mock-bound and idle; normalize defensively so
  // future edits to createEmployeeRoster cannot silently deactivate anyone.
  return createEmployeeRoster().map((e) => ({
    ...e,
    status: "idle" as const,
    preferredModels: [MOCK_MODEL_ID],
    fallbackModels: [MOCK_MODEL_ID],
    providerPreferences: ["mock"],
    provider: "mock",
    model: MOCK_MODEL_ID,
    quotaStatus: "available" as const,
  }));
}
