import assert from "node:assert/strict";
import { describe, it } from "node:test";
import {
  activityLabelFor,
  mapDashboardToVisualOffice,
  mapEmployeeToVisual,
  safeLabel,
  statusColor,
} from "./office-state.ts";
import type { DashboardSnapshot, DashboardEmployeeCard } from "@/office/dashboard-api.ts";

const baseCard = (id: string, status: DashboardEmployeeCard["status"]): DashboardEmployeeCard => ({
  id,
  displayName: id[0]!.toUpperCase() + id.slice(1),
  role: "role",
  status,
  provider: "mock",
  model: "mock:phase1",
  currentTaskId: null,
  currentObjective: null,
  latestSummary: null,
  error: null,
  isSynthesizer: id === "ceo",
});

describe("3D office state mapping", () => {
  it("maps employee states to activity labels", () => {
    assert.equal(activityLabelFor("idle"), null);
    assert.equal(activityLabelFor("working"), "Working");
    assert.equal(activityLabelFor("thinking"), "Thinking");
    assert.equal(activityLabelFor("rate_limited"), "Rate limited");
  });

  it("status colors are defined for all known states", () => {
    for (const s of [
      "idle",
      "queued",
      "thinking",
      "working",
      "waiting",
      "completed",
      "failed",
      "cancelled",
      "rate_limited",
      "unavailable",
    ] as const) {
      assert.ok(statusColor(s).startsWith("#"));
    }
  });

  it("mapEmployeeToVisual preserves identity and synthesizer flag", () => {
    const v = mapEmployeeToVisual(baseCard("ceo", "thinking"), 0);
    assert.equal(v.id, "ceo");
    assert.equal(v.isSynthesizer, true);
    assert.equal(v.activityLabel, "Thinking");
    assert.equal(v.deskIndex, 0);
  });

  it("mapDashboardToVisualOffice uses real cards only", () => {
    const snap = {
      service: "ell-ai-office",
      generatedAt: new Date().toISOString(),
      workspaceId: "ws",
      currentTask: null,
      tasks: [],
      employees: [
        baseCard("ceo", "working"),
        baseCard("pm", "idle"),
        baseCard("developer", "idle"),
        baseCard("researcher", "idle"),
        baseCard("automation", "idle"),
        baseCard("jira", "waiting"),
      ],
      providers: [{ id: "mock", label: "Mock", availability: "available" } as never],
      events: [
        {
          id: "e1",
          type: "task.created",
          taskId: null,
          employeeId: "developer",
          message: "hello <script>",
          createdAt: new Date().toISOString(),
        },
      ],
      memory: {
        projectId: "default",
        title: "Default",
        entryCount: 2,
        byType: {},
        recent: [],
      },
      tools: [],
      toolCatalog: [],
    } as DashboardSnapshot;

    const visual = mapDashboardToVisualOffice(snap, "developer");
    assert.equal(visual.employees.length, 6);
    assert.equal(visual.employees[0]?.status, "working");
    assert.equal(visual.selectedEmployeeId, "developer");
    assert.equal(visual.memoryEntryCount, 2);
    assert.ok(!visual.recentActivity[0]?.label.includes("<script>"));
  });

  it("safeLabel strips angle brackets and secrets", () => {
    assert.equal(safeLabel("a <b> c").includes("<"), false);
    assert.equal(safeLabel("secret-api-key-123 leaked").includes("secret-api-key"), false);
  });

  it("null snapshot yields empty visual state", () => {
    const v = mapDashboardToVisualOffice(null);
    assert.equal(v.employees.length, 0);
    assert.equal(v.hasActiveTask, false);
  });
});

describe("V1.1 pose and interaction", () => {
  it("poseForStatus covers all dashboard states", async () => {
    const { poseForStatus } = await import("./office-state.ts");
    for (const s of [
      "idle",
      "queued",
      "thinking",
      "working",
      "waiting",
      "completed",
      "failed",
      "cancelled",
      "rate_limited",
      "unavailable",
    ] as const) {
      assert.ok(poseForStatus(s));
    }
  });

  it("voice placeholder is not available", async () => {
    const { voicePlaceholder } = await import("./office-state.ts");
    const v = voicePlaceholder();
    assert.equal(v.available, false);
    assert.match(v.message, /V1\.3/);
  });

  it("desk positions are six", async () => {
    const { DESK_POSITIONS } = await import("./office-state.ts");
    assert.equal(DESK_POSITIONS.length, 6);
  });

  it("resolveEmployeeIdFromDeskIndex maps desk slots", async () => {
    const { resolveEmployeeIdFromDeskIndex } = await import("./office-state.ts");
    const employees = [
      { id: "ceo", deskIndex: 0 },
      { id: "pm", deskIndex: 1 },
      { id: "developer", deskIndex: 2 },
      { id: "researcher", deskIndex: 3 },
      { id: "automation", deskIndex: 4 },
      { id: "jira", deskIndex: 5 },
    ];
    assert.equal(resolveEmployeeIdFromDeskIndex(employees, 0), "ceo");
    assert.equal(resolveEmployeeIdFromDeskIndex(employees, 5), "jira");
    assert.equal(resolveEmployeeIdFromDeskIndex(employees, 9), null);
  });

  it("resolveEmployeeIdFromPick prefers employeeId over deskIndex", async () => {
    const { resolveEmployeeIdFromPick } = await import("./office-state.ts");
    const employees = [
      { id: "developer", deskIndex: 0 },
      { id: "researcher", deskIndex: 1 },
    ];
    assert.equal(
      resolveEmployeeIdFromPick({ employeeId: "researcher", deskIndex: 0, employees }),
      "researcher",
    );
    assert.equal(
      resolveEmployeeIdFromPick({ employeeId: "nobody", deskIndex: 0, employees }),
      "developer",
    );
    assert.equal(
      resolveEmployeeIdFromPick({ employeeId: null, deskIndex: 1, employees }),
      "researcher",
    );
  });

  it("isClickGesture discriminates drag from click", async () => {
    const { isClickGesture, PICK_CLICK_THRESHOLD_PX } = await import("./office-state.ts");
    assert.equal(isClickGesture(10, 10, 12, 11), true);
    assert.equal(isClickGesture(0, 0, PICK_CLICK_THRESHOLD_PX + 5, 0), false);
  });

  it("cameraLookTargetForSelection focuses desk or overview", async () => {
    const {
      cameraLookTargetForSelection,
      cameraRadiusForSelection,
      OVERVIEW_LOOK_AT,
      FOCUS_RADIUS,
      OVERVIEW_RADIUS,
      DESK_POSITIONS,
      lerpLookTarget,
    } = await import("./office-state.ts");
    const employees = [
      { id: "ceo", deskIndex: 0 },
      { id: "jira", deskIndex: 5 },
    ];
    const overview = cameraLookTargetForSelection(null, employees);
    assert.equal(overview.x, OVERVIEW_LOOK_AT.x);
    assert.equal(cameraRadiusForSelection(null), OVERVIEW_RADIUS);
    const focus = cameraLookTargetForSelection("ceo", employees);
    assert.equal(focus.x, DESK_POSITIONS[0]![0]);
    assert.equal(focus.z, DESK_POSITIONS[0]![1]);
    assert.equal(cameraRadiusForSelection("ceo"), FOCUS_RADIUS);
    const mid = lerpLookTarget(overview, focus, 0.5);
    assert.ok(Math.abs(mid.x - (overview.x + focus.x) / 2) < 1e-9);
  });


  it("pickNearestEmployeeByScreenDistance picks nearest desk within radius", async () => {
    const {
      pickNearestEmployeeByScreenDistance,
      PICK_SCREEN_RADIUS_PX,
    } = await import("./office-state.ts");
    const projected = [
      { employeeId: "developer", screenX: 100, screenY: 200 },
      { employeeId: "ceo", screenX: 400, screenY: 200 },
    ];
    assert.equal(
      pickNearestEmployeeByScreenDistance(105, 198, projected),
      "developer",
    );
    assert.equal(
      pickNearestEmployeeByScreenDistance(390, 210, projected),
      "ceo",
    );
    assert.equal(
      pickNearestEmployeeByScreenDistance(250, 200, projected, 30),
      null,
    );
    assert.ok(PICK_SCREEN_RADIUS_PX >= 40);
  });


  it("characterVisualFor distinguishes six employees", async () => {
    const { characterVisualFor, DESK_ORDER } = await import("./office-state.ts");
    const set = new Set(DESK_ORDER.map((id) => characterVisualFor(id).primary));
    assert.equal(set.size, 6);
    assert.equal(characterVisualFor("ceo").hairStyle, "neat");
    assert.equal(characterVisualFor("pm").hairStyle, "side");
    assert.equal(characterVisualFor("developer").hairStyle, "spiky");
    assert.equal(characterVisualFor("researcher").hairStyle, "twin");
    assert.equal(characterVisualFor("automation").hairStyle, "neat");
    assert.equal(characterVisualFor("jira").hairStyle, "side");
  });

});
