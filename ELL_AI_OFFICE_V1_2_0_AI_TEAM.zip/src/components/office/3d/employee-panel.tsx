/**
 * Employee inspection panel — truthful backend data only.
 */
"use client";

import { useEffect, useRef, useState } from "react";
import type { VisualEmployee } from "./office-state.ts";
import { activityLabelFor, statusColor, voicePlaceholder } from "./office-state.ts";
import { Button } from "@/components/ui/button.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { cn } from "@/lib/utils.ts";

/** Employee states treated as always available (24/7 online). */
const ONLINE_24_7: ReadonlySet<VisualEmployee["status"]> = new Set([
  "idle",
  "working",
  "thinking",
  "waiting",
  "queued",
]);

type Props = {
  employee: VisualEmployee | null;
  onClose: () => void;
  className?: string;
};

export function EmployeePanel({ employee, onClose, className }: Props) {
  const [chatOpen, setChatOpen] = useState(false);
  const [message, setMessage] = useState("");
  const [reply, setReply] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const closeRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    // Focus close control when panel opens (keyboard / screen-reader friendly)
    closeRef.current?.focus();
  }, [employee?.id]);

  if (!employee) return null;

  const voice = voicePlaceholder();
  const activity = activityLabelFor(employee.status);

  async function sendChat() {
    if (!employee || !message.trim()) return;
    setBusy(true);
    setError(null);
    setReply(null);
    try {
      const res = await fetch("/api/office/private-chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          employeeId: employee.id,
          message: message.trim().slice(0, 2000),
        }),
      });
      const data = (await res.json()) as {
        ok?: boolean;
        reply?: string;
        error?: string;
        unavailable?: boolean;
      };
      if (!res.ok || data.unavailable) {
        setError(data.error ?? "Private chat unavailable (configure provider or use mock)");
      } else {
        setReply(data.reply ?? "");
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Chat failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <aside
      className={cn(
        "flex flex-col gap-3 border border-slate-700 bg-slate-900/95 p-3 text-slate-100 shadow-xl backdrop-blur sm:p-4",
        "max-h-[min(42vh,320px)] w-full overflow-y-auto sm:max-h-[70vh] sm:max-w-sm",
        className,
      )}
      data-testid="employee-panel"
      role="dialog"
      aria-modal="true"
      aria-label={`Employee profile: ${employee.displayName}`}
    >
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <h2 className="truncate text-base font-semibold tracking-tight sm:text-lg">
            {employee.displayName}
          </h2>
          <p className="truncate text-sm text-slate-400">{employee.role}</p>
        </div>
        <Button
          ref={closeRef}
          type="button"
          variant="ghost"
          size="sm"
          onClick={onClose}
          aria-label="Close employee profile"
          data-testid="employee-panel-close"
        >
          Close
        </Button>
      </div>

      <div className="flex items-center gap-2 text-sm">
        <span
          className="inline-block h-2.5 w-2.5 rounded-full"
          style={{ background: statusColor(employee.status) }}
          aria-hidden
        />
        <span className="capitalize">{employee.status.replace("_", " ")}</span>
        {ONLINE_24_7.has(employee.status) ? (
          <span className="rounded-full bg-emerald-500/20 px-2 py-0.5 text-[10px] font-medium text-emerald-300">
            24/7 online
          </span>
        ) : null}
        {activity ? <span className="text-slate-500">· {activity}</span> : null}
      </div>

      <dl className="grid grid-cols-[auto_1fr] gap-x-3 gap-y-1 text-sm">
        <dt className="text-slate-500">Provider</dt>
        <dd>{employee.provider}</dd>
        <dt className="text-slate-500">Model</dt>
        <dd className="truncate">{employee.model}</dd>
        {employee.latestSummary ? (
          <>
            <dt className="text-slate-500">Latest</dt>
            <dd className="line-clamp-3 text-slate-300">{employee.latestSummary}</dd>
          </>
        ) : null}
        {employee.error ? (
          <>
            <dt className="text-slate-500">Error</dt>
            <dd className="text-red-400">{employee.error}</dd>
          </>
        ) : null}
      </dl>

      <div className="flex flex-wrap gap-2">
        <Button type="button" size="sm" onClick={() => setChatOpen((v) => !v)}>
          Private Chat
        </Button>
        <Button type="button" size="sm" variant="outline" disabled title={voice.message}>
          Voice (V1.3)
        </Button>
      </div>

      {chatOpen ? (
        <div className="flex flex-col gap-2 border-t border-slate-700 pt-3">
          <p className="text-xs text-slate-500">
            Direct chat with {employee.displayName} — does not alter the main task orchestrator.
          </p>
          <Textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder={`Ask ${employee.displayName}…`}
            rows={3}
            className="bg-slate-950"
          />
          <Button type="button" size="sm" disabled={busy || !message.trim()} onClick={() => void sendChat()}>
            {busy ? "Sending…" : "Send"}
          </Button>
          {error ? <p className="text-sm text-amber-400">{error}</p> : null}
          {reply ? (
            <div className="rounded-md bg-slate-950 p-2 text-sm text-slate-200 whitespace-pre-wrap">
              {reply}
            </div>
          ) : null}
        </div>
      ) : null}
    </aside>
  );
}
