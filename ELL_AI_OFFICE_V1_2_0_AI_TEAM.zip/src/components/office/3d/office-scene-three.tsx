/**
 * V1.1 Full 3D office — Three.js / WebGL presentation layer.
 * Backend state is authoritative; this only visualizes.
 */
"use client";

import { useEffect, useRef, useState } from "react";
import type { VisualOfficeState, VisualEmployee } from "./office-state.ts";
import {
  DESK_ORDER,
  DESK_POSITIONS,
  MEETING_TABLE_POS,
  poseForStatus,
  characterVisualFor,
  resolveEmployeeIdFromPick,
  isClickGesture,
  cameraLookTargetForSelection,
  cameraRadiusForSelection,
  lerp,
  lerpLookTarget,
  OVERVIEW_LOOK_AT,
  OVERVIEW_RADIUS,
  pickNearestEmployeeByScreenDistance,
  statusColor,
  type CameraLookTarget,
  type ScreenProjectedDesk,
} from "./office-state.ts";
import {
  type PerformanceSettings,
  type QualityLevel,
  qualityProfile,
  frameIntervalMs,
  FpsMeter,
  AdaptiveRenderController,
} from "./performance.ts";

type Props = {
  state: VisualOfficeState;
  onSelectEmployee: (id: string | null) => void;
  performance: PerformanceSettings;
  onMeasuredFps?: (fps: number) => void;
  /** Fires when the quality actually applied to the renderer changes. */
  onAppliedQuality?: (level: QualityLevel) => void;
  /** Canvas pixel size after layout (no secrets). */
  onCanvasMetrics?: (metrics: { width: number; height: number }) => void;
  onWebglFailed?: (reason: string) => void;
};

type ThreeModule = typeof import("three");

export function OfficeSceneThree({
  state,
  onSelectEmployee,
  performance,
  onMeasuredFps,
  onAppliedQuality,
  onCanvasMetrics,
  onWebglFailed,
}: Props) {
  const mountRef = useRef<HTMLDivElement>(null);
  const stateRef = useRef(state);
  const perfRef = useRef(performance);
  const selectRef = useRef(onSelectEmployee);
  const fpsRef = useRef(onMeasuredFps);
  const appliedRef = useRef(onAppliedQuality);
  const metricsRef = useRef(onCanvasMetrics);
  const webglFailedRef = useRef(onWebglFailed);
  const [error, setError] = useState<string | null>(null);

  stateRef.current = state;
  perfRef.current = performance;
  selectRef.current = onSelectEmployee;
  fpsRef.current = onMeasuredFps;
  appliedRef.current = onAppliedQuality;
  metricsRef.current = onCanvasMetrics;
  webglFailedRef.current = onWebglFailed;

  useEffect(() => {
    let cancelled = false;
    let cleanup: (() => void) | undefined;

    (async () => {
      try {
        const THREE = await import("three");
        if (cancelled || !mountRef.current) return;
        cleanup = bootScene(THREE, mountRef.current, {
          stateRef,
          perfRef,
          selectRef,
          onMeasuredFps: (fps: number) => fpsRef.current?.(fps),
          onAppliedQuality: (level: QualityLevel) => appliedRef.current?.(level),
          onCanvasMetrics: (m) => metricsRef.current?.(m),
        });
      } catch (e) {
        if (cancelled) return;
        const reason = e instanceof Error ? e.message : "WebGL unavailable";
        setError(reason);
        webglFailedRef.current?.(reason);
      }
    })();

    return () => {
      cancelled = true;
      cleanup?.();
    };
    // Boot once per mount — callbacks read via refs so parent re-renders do not tear down WebGL.
  }, []);

  // Rebuild quality when settings change is handled inside loop via perfRef

  if (error) {
    return (
      <div className="flex h-full items-center justify-center bg-slate-950 text-sm text-slate-400">
        3D unavailable: {error}. Use 2D view.
      </div>
    );
  }

  return (
    <div
      ref={mountRef}
      className="relative h-full w-full overflow-hidden rounded-xl bg-slate-950"
      data-testid="office-scene-three"
    />
  );
}

function bootScene(
  THREE: ThreeModule,
  mount: HTMLDivElement,
  ctx: {
    stateRef: React.MutableRefObject<VisualOfficeState>;
    perfRef: React.MutableRefObject<PerformanceSettings>;
    selectRef: React.MutableRefObject<(id: string | null) => void>;
    onMeasuredFps?: (fps: number) => void;
    onAppliedQuality?: (level: QualityLevel) => void;
    onCanvasMetrics?: (metrics: { width: number; height: number }) => void;
  },
) {
  const scene = new THREE.Scene();
  // P1: brighter office — readable on mobile screens
  scene.background = new THREE.Color(0xc8d4e4);
  scene.fog = new THREE.Fog(0xc8d4e4, 18, 36);

  const camera = new THREE.PerspectiveCamera(48, 1, 0.1, 80);
  camera.position.set(0, 9, 11);
  camera.lookAt(0, 0, 0);

  const renderer = new THREE.WebGLRenderer({
    antialias: true,
    alpha: false,
    powerPreference: "high-performance",
  });
  renderer.setClearColor(0xc8d4e4);
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.domElement.setAttribute("aria-label", "3D AI office — tap an avatar to select");
  renderer.domElement.setAttribute("role", "img");
  mount.appendChild(renderer.domElement);

  // Brighter, softer lighting (still no post-processing)
  const hemi = new THREE.HemisphereLight(0xf0f4fa, 0xb0bec8, 0.7);
  scene.add(hemi);
  const ambient = new THREE.AmbientLight(0xdde4ee, 0.45);
  scene.add(ambient);
  const dir = new THREE.DirectionalLight(0xfff8f0, 0.85);
  dir.position.set(5, 12, 4);
  dir.castShadow = true;
  dir.shadow.mapSize.set(512, 512);
  dir.shadow.camera.near = 1;
  dir.shadow.camera.far = 30;
  dir.shadow.camera.left = -10;
  dir.shadow.camera.right = 10;
  dir.shadow.camera.top = 10;
  dir.shadow.camera.bottom = -10;
  scene.add(dir);
  const fill = new THREE.DirectionalLight(0xa5b4fc, 0.3);
  fill.position.set(-7, 5, -3);
  scene.add(fill);
  const accent = new THREE.PointLight(0x38bdf8, 0.4, 12, 2);
  accent.position.set(0, 2.2, 2.2);
  scene.add(accent);

  // Floor — light office carpet
  const floor = new THREE.Mesh(
    new THREE.PlaneGeometry(16, 12),
    new THREE.MeshStandardMaterial({
      color: 0xe8eef5,
      roughness: 0.9,
      metalness: 0.02,
    }),
  );
  floor.rotation.x = -Math.PI / 2;
  floor.receiveShadow = true;
  scene.add(floor);
  const floorInset = new THREE.Mesh(
    new THREE.PlaneGeometry(5.5, 4.2),
    new THREE.MeshStandardMaterial({
      color: 0xd5dee9,
      roughness: 0.85,
      metalness: 0.04,
    }),
  );
  floorInset.rotation.x = -Math.PI / 2;
  floorInset.position.set(0, 0.01, 1.2);
  floorInset.receiveShadow = true;
  scene.add(floorInset);

  // Walls — soft light gray office
  const wallMat = new THREE.MeshStandardMaterial({
    color: 0xe2e8f0,
    roughness: 0.92,
    metalness: 0.02,
  });
  const back = new THREE.Mesh(new THREE.BoxGeometry(16, 4, 0.2), wallMat);
  back.position.set(0, 2, -6);
  back.receiveShadow = true;
  scene.add(back);
  const left = new THREE.Mesh(new THREE.BoxGeometry(0.2, 4, 12), wallMat);
  left.position.set(-8, 2, 0);
  scene.add(left);
  const right = new THREE.Mesh(new THREE.BoxGeometry(0.2, 4, 12), wallMat);
  right.position.set(8, 2, 0);
  scene.add(right);
  const baseboard = new THREE.Mesh(
    new THREE.BoxGeometry(15.6, 0.14, 0.08),
    new THREE.MeshStandardMaterial({ color: 0x94a3b8, roughness: 0.65, metalness: 0.08 }),
  );
  baseboard.position.set(0, 0.12, -5.88);
  scene.add(baseboard);
  // Window glow panels on back wall (cheap brightness cue)
  for (const wx of [-4.5, 0, 4.5]) {
    const win = new THREE.Mesh(
      new THREE.PlaneGeometry(2.2, 1.6),
      new THREE.MeshStandardMaterial({
        color: 0xf8fafc,
        emissive: 0xbdd6f0,
        emissiveIntensity: 0.35,
        roughness: 0.5,
      }),
    );
    win.position.set(wx, 2.1, -5.88);
    scene.add(win);
  }

  // Meeting table — light wood tone
  const meet = new THREE.Mesh(
    new THREE.BoxGeometry(3.2, 0.12, 1.6),
    new THREE.MeshStandardMaterial({ color: 0xc4a882, roughness: 0.55, metalness: 0.08 }),
  );
  meet.position.set(MEETING_TABLE_POS[0], 0.78, MEETING_TABLE_POS[1]);
  meet.castShadow = true;
  meet.receiveShadow = true;
  scene.add(meet);
  const meetEdge = new THREE.Mesh(
    new THREE.BoxGeometry(3.28, 0.04, 1.68),
    new THREE.MeshStandardMaterial({ color: 0xa8896a, roughness: 0.4, metalness: 0.12 }),
  );
  meetEdge.position.set(MEETING_TABLE_POS[0], 0.7, MEETING_TABLE_POS[1]);
  scene.add(meetEdge);

  // Employees + desks — P1 procedural stylized humanoids (not GLB anime)
  type EmpNode = {
    id: string;
    root: InstanceType<ThreeModule["Group"]>;
    body: InstanceType<ThreeModule["Mesh"]>;
    head: InstanceType<ThreeModule["Mesh"]>;
    monitor: InstanceType<ThreeModule["Mesh"]>;
    hit: InstanceType<ThreeModule["Mesh"]>;
    statusDot: InstanceType<ThreeModule["Mesh"]>;
    leftArm: InstanceType<ThreeModule["Mesh"]>;
    rightArm: InstanceType<ThreeModule["Mesh"]>;
    hairParts: InstanceType<ThreeModule["Mesh"]>[];
    secondaryParts: InstanceType<ThreeModule["Object3D"]>[];
    /** Procedural avatar meshes hidden when GLB pilot is active */
    avatarMeshes: InstanceType<ThreeModule["Object3D"]>[];
    bodyColor: number;
    gltfRoot: InstanceType<ThreeModule["Object3D"]> | null;
    mixer: InstanceType<ThreeModule["AnimationMixer"]> | null;
    actions: Record<string, InstanceType<ThreeModule["AnimationAction"]>>;
    activeClip: string | null;
    useGltf: boolean;
  };
  const employees: EmpNode[] = [];

  function mat(
    color: number,
    opts?: { roughness?: number; metalness?: number; emissive?: number; emissiveIntensity?: number },
  ) {
    return new THREE.MeshStandardMaterial({
      color,
      roughness: opts?.roughness ?? 0.65,
      metalness: opts?.metalness ?? 0.06,
      emissive: opts?.emissive ?? 0x000000,
      emissiveIntensity: opts?.emissiveIntensity ?? 0,
    });
  }

  for (let i = 0; i < DESK_POSITIONS.length; i++) {
    const [x, z] = DESK_POSITIONS[i]!;
    const seededId = DESK_ORDER[i] ?? `desk-${i}`;
    const vis = characterVisualFor(seededId);
    const group = new THREE.Group();
    group.position.set(x, 0, z);
    group.userData.employeeIndex = i;
    group.userData.employeeId = seededId;

    const secondaryParts: InstanceType<ThreeModule["Object3D"]>[] = [];

    // --- Workstation ---
    const deskTop = new THREE.Mesh(
      new THREE.BoxGeometry(1.55, 0.08, 0.9),
      mat(0xc4a574, { roughness: 0.55, metalness: 0.1 }),
    );
    deskTop.position.set(0, 0.74, 0);
    deskTop.castShadow = true;
    deskTop.receiveShadow = true;
    group.add(deskTop);

    // Desk legs
    for (const [lx, lz] of [
      [-0.65, -0.35],
      [0.65, -0.35],
      [-0.65, 0.35],
      [0.65, 0.35],
    ] as const) {
      const leg = new THREE.Mesh(
        new THREE.BoxGeometry(0.07, 0.72, 0.07),
        mat(0x8b7355, { roughness: 0.7 }),
      );
      leg.position.set(lx, 0.36, lz);
      leg.castShadow = true;
      group.add(leg);
      secondaryParts.push(leg);
    }

    // Chair: seat + back
    const seat = new THREE.Mesh(
      new THREE.BoxGeometry(0.5, 0.08, 0.48),
      mat(0x475569, { roughness: 0.75 }),
    );
    seat.position.set(0, 0.42, 0.62);
    seat.castShadow = true;
    group.add(seat);
    const backrest = new THREE.Mesh(
      new THREE.BoxGeometry(0.5, 0.55, 0.07),
      mat(0x334155, { roughness: 0.75 }),
    );
    backrest.position.set(0, 0.72, 0.84);
    backrest.castShadow = true;
    group.add(backrest);
    secondaryParts.push(backrest);

    // Monitor stand + bezel + screen
    const stand = new THREE.Mesh(
      new THREE.BoxGeometry(0.12, 0.28, 0.1),
      mat(0x64748b, { roughness: 0.4, metalness: 0.3 }),
    );
    stand.position.set(0, 0.9, -0.28);
    group.add(stand);
    secondaryParts.push(stand);
    const bezel = new THREE.Mesh(
      new THREE.BoxGeometry(0.78, 0.5, 0.05),
      mat(0x1e293b, { roughness: 0.35, metalness: 0.25 }),
    );
    bezel.position.set(0, 1.22, -0.28);
    group.add(bezel);
    const monitor = new THREE.Mesh(
      new THREE.BoxGeometry(0.7, 0.42, 0.03),
      mat(0x0f172a, { roughness: 0.3, metalness: 0.2, emissive: 0x000000, emissiveIntensity: 1 }),
    );
    monitor.position.set(0, 1.22, -0.25);
    group.add(monitor);

    // Keyboard + mouse
    const keyboard = new THREE.Mesh(
      new THREE.BoxGeometry(0.55, 0.03, 0.2),
      mat(0x334155, { roughness: 0.5 }),
    );
    keyboard.position.set(0, 0.8, 0.18);
    group.add(keyboard);
    secondaryParts.push(keyboard);
    const mouse = new THREE.Mesh(
      new THREE.BoxGeometry(0.08, 0.03, 0.12),
      mat(0x475569, { roughness: 0.45 }),
    );
    mouse.position.set(0.42, 0.8, 0.2);
    group.add(mouse);
    secondaryParts.push(mouse);

    // Nameplate / prop (brand-colored)
    const plate = new THREE.Mesh(
      new THREE.BoxGeometry(0.35, 0.04, 0.12),
      mat(vis.prop, { roughness: 0.45, metalness: 0.15 }),
    );
    plate.position.set(-0.5, 0.8, 0.28);
    group.add(plate);
    secondaryParts.push(plate);

    // --- Stylized humanoid (chibi proportions, distinct per ID) ---
    const bodyColor = vis.primary;
    // Torso (slightly wider shoulders)
    const body = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.26, 0.42, 6, 10),
      mat(bodyColor, { roughness: 0.55 }),
    );
    body.position.set(0, 1.02, 0.38);
    body.castShadow = true;
    body.userData.isEmployee = true;
    body.userData.deskIndex = i;
    body.userData.employeeId = seededId;
    group.add(body);

    // Collar / accent scarf strip
    const collar = new THREE.Mesh(
      new THREE.BoxGeometry(0.42, 0.08, 0.28),
      mat(vis.accent, { roughness: 0.5 }),
    );
    collar.position.set(0, 1.28, 0.4);
    group.add(collar);
    secondaryParts.push(collar);

    // Head (slightly larger — anime-ish proportion)
    const head = new THREE.Mesh(
      new THREE.SphereGeometry(0.22, 14, 14),
      mat(vis.skin, { roughness: 0.7 }),
    );
    head.position.set(0, 1.58, 0.38);
    head.castShadow = true;
    head.userData.isEmployee = true;
    head.userData.deskIndex = i;
    head.userData.employeeId = seededId;
    group.add(head);

    // Simple face markers (eyes + mouth) — readable at focus
    const eyeMat = mat(0x1e293b, { roughness: 0.4 });
    const eyeL = new THREE.Mesh(new THREE.SphereGeometry(0.035, 8, 8), eyeMat);
    eyeL.position.set(-0.07, 1.6, 0.55);
    group.add(eyeL);
    const eyeR = new THREE.Mesh(new THREE.SphereGeometry(0.035, 8, 8), eyeMat);
    eyeR.position.set(0.07, 1.6, 0.55);
    group.add(eyeR);
    secondaryParts.push(eyeL, eyeR);

    // Hair parts by style
    const hairParts: InstanceType<ThreeModule["Mesh"]>[] = [];
    const hairMat = mat(vis.hair, { roughness: 0.75 });
    if (vis.hairStyle === "side") {
      // CEO / PM / Jira: volume top + side sweep
      const top = new THREE.Mesh(new THREE.SphereGeometry(0.2, 10, 10), hairMat);
      top.scale.set(1.05, 0.7, 1.1);
      top.position.set(0, 1.72, 0.36);
      group.add(top);
      hairParts.push(top);
      const side = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.28, 0.18), hairMat);
      side.position.set(-0.2, 1.55, 0.38);
      group.add(side);
      hairParts.push(side);
    } else if (vis.hairStyle === "twin") {
      // Researcher: twin side volumes
      const top = new THREE.Mesh(new THREE.SphereGeometry(0.18, 10, 10), hairMat);
      top.position.set(0, 1.72, 0.36);
      group.add(top);
      hairParts.push(top);
      for (const sx of [-0.22, 0.22]) {
        const bun = new THREE.Mesh(new THREE.SphereGeometry(0.1, 8, 8), hairMat);
        bun.position.set(sx, 1.62, 0.32);
        group.add(bun);
        hairParts.push(bun);
      }
    } else if (vis.hairStyle === "spiky") {
      // Developer: spiky upright boxes
      const top = new THREE.Mesh(new THREE.SphereGeometry(0.17, 10, 10), hairMat);
      top.position.set(0, 1.7, 0.36);
      group.add(top);
      hairParts.push(top);
      for (const [sx, sy] of [
        [-0.1, 1.88],
        [0, 1.92],
        [0.1, 1.88],
      ] as const) {
        const spike = new THREE.Mesh(new THREE.ConeGeometry(0.05, 0.18, 5), hairMat);
        spike.position.set(sx, sy, 0.36);
        group.add(spike);
        hairParts.push(spike);
      }
    } else {
      // Automation: neat cap
      const top = new THREE.Mesh(new THREE.SphereGeometry(0.2, 10, 10), hairMat);
      top.scale.set(1.05, 0.55, 1.05);
      top.position.set(0, 1.72, 0.36);
      group.add(top);
      hairParts.push(top);
      const fringe = new THREE.Mesh(new THREE.BoxGeometry(0.32, 0.06, 0.12), hairMat);
      fringe.position.set(0, 1.62, 0.52);
      group.add(fringe);
      hairParts.push(fringe);
    }

    // Arms (for working gesture)
    const leftArm = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.06, 0.28, 4, 6),
      mat(bodyColor, { roughness: 0.55 }),
    );
    leftArm.position.set(-0.34, 1.05, 0.45);
    leftArm.rotation.z = 0.4;
    leftArm.castShadow = true;
    group.add(leftArm);
    const rightArm = new THREE.Mesh(
      new THREE.CapsuleGeometry(0.06, 0.28, 4, 6),
      mat(bodyColor, { roughness: 0.55 }),
    );
    rightArm.position.set(0.34, 1.05, 0.45);
    rightArm.rotation.z = -0.4;
    rightArm.castShadow = true;
    group.add(rightArm);

    // Status indicator
    const statusDot = new THREE.Mesh(
      new THREE.SphereGeometry(0.07, 10, 10),
      mat(0x64748b, { roughness: 0.4, emissive: 0x334155, emissiveIntensity: 0.6 }),
    );
    statusDot.position.set(0, 1.95, 0.38);
    group.add(statusDot);

    // Hit volume (unchanged pick contract)
    const hit = new THREE.Mesh(
      new THREE.CylinderGeometry(0.58, 0.58, 2.0, 12),
      new THREE.MeshBasicMaterial({
        transparent: true,
        opacity: 0,
        depthWrite: false,
      }),
    );
    hit.position.set(0, 1.0, 0.38);
    hit.userData.isEmployee = true;
    hit.userData.deskIndex = i;
    hit.userData.employeeId = seededId;
    hit.userData.isPickVolume = true;
    group.add(hit);

    // Procedural avatar parts (hidden if GLB pilot loads)
    const avatarOnly: InstanceType<ThreeModule["Object3D"]>[] = [
      body,
      head,
      collar,
      leftArm,
      rightArm,
      statusDot,
      eyeL,
      eyeR,
      ...hairParts,
    ];

    scene.add(group);
    employees.push({
      id: seededId,
      root: group,
      body,
      head,
      monitor,
      hit,
      statusDot,
      leftArm,
      rightArm,
      hairParts,
      secondaryParts,
      avatarMeshes: avatarOnly,
      bodyColor,
      gltfRoot: null,
      mixer: null,
      actions: {},
      activeClip: null,
      useGltf: false,
    });
  }

  // --- P2: async GLB pilot for CEO desk (procedural remains fallback) ---
  const PILOT_ID = "ceo";
  const PILOT_URL = "/office/characters/claude-pilot.glb";
  let pilotLoadGeneration = 0;

  function setProceduralAvatarVisible(node: EmpNode, visible: boolean) {
    for (const m of node.avatarMeshes) m.visible = visible;
  }

  function playPoseClip(node: EmpNode, pose: string, reducedMotion: boolean) {
    if (!node.mixer || !node.useGltf) return;
    const clipName =
      pose === "working"
        ? "working"
        : pose === "thinking"
          ? "thinking"
          : pose === "error"
            ? "error"
            : pose === "completed"
              ? "completed"
              : "idle";
    // Never play working unless pose is working (explicit)
    const safeName = pose === "working" ? "working" : clipName === "working" ? "idle" : clipName;
    if (node.activeClip === safeName) {
      node.mixer.timeScale = reducedMotion ? 0 : 1;
      return;
    }
    for (const a of Object.values(node.actions)) a.stop();
    const action = node.actions[safeName] ?? node.actions["idle"];
    if (action) {
      action.reset().play();
      node.activeClip = safeName;
    } else {
      node.activeClip = null;
    }
    node.mixer.timeScale = reducedMotion ? 0 : 1;
  }

  void (async () => {
    const gen = ++pilotLoadGeneration;
    const pilot = employees.find((e) => e.id === PILOT_ID);
    if (!pilot) return;
    try {
      const mod = await import("three/addons/loaders/GLTFLoader.js");
      const GLTFLoader = mod.GLTFLoader as new () => {
        loadAsync: (url: string) => Promise<{
          scene: InstanceType<ThreeModule["Group"]>;
          animations: InstanceType<ThreeModule["AnimationClip"]>[];
        }>;
      };
      const loader = new GLTFLoader();
      const gltf = await loader.loadAsync(PILOT_URL);
      if (gen !== pilotLoadGeneration) return;
      const model = gltf.scene;
      model.name = "ClaudePilotGltf";
      // Seat at desk — align with procedural avatar center
      model.position.set(0, 0.15, 0.35);
      model.scale.setScalar(1);
      model.traverse((obj) => {
        const mesh = obj as InstanceType<ThreeModule["Mesh"]>;
        if (mesh.isMesh) {
          mesh.castShadow = true;
          mesh.receiveShadow = true;
        }
      });
      pilot.root.add(model);
      pilot.gltfRoot = model;
      setProceduralAvatarVisible(pilot, false);
      pilot.useGltf = true;

      if (gltf.animations && gltf.animations.length > 0) {
        const mixer = new THREE.AnimationMixer(model);
        pilot.mixer = mixer;
        for (const clip of gltf.animations) {
          pilot.actions[clip.name] = mixer.clipAction(clip);
        }
      }
    } catch (err) {
      // Keep procedural avatar — do not leave desk empty
      console.warn("[office-3d] pilot GLB load failed, using procedural fallback", err);
      if (pilot) {
        setProceduralAvatarVisible(pilot, true);
        pilot.useGltf = false;
      }
    }
  })();

  // Raycaster for selection
  const raycaster = new THREE.Raycaster();
  const pointer = new THREE.Vector2();
  const selectionRing = new THREE.Mesh(
    new THREE.RingGeometry(0.52, 0.62, 32),
    new THREE.MeshBasicMaterial({
      color: 0x22d3ee,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.9,
    }),
  );
  selectionRing.rotation.x = -Math.PI / 2;
  selectionRing.position.y = 0.04;
  selectionRing.visible = false;
  scene.add(selectionRing);

  function projectDesksToScreen(): ScreenProjectedDesk[] {
    const rect = renderer.domElement.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return [];
    const out: ScreenProjectedDesk[] = [];
    const world = new THREE.Vector3();
    for (const node of employees) {
      if (!node.id) continue;
      world.set(
        node.root.position.x,
        node.root.position.y + 1.0,
        node.root.position.z,
      );
      world.project(camera);
      // Skip points behind the camera
      if (world.z > 1) continue;
      out.push({
        employeeId: node.id,
        screenX: (world.x * 0.5 + 0.5) * rect.width + rect.left,
        screenY: (-world.y * 0.5 + 0.5) * rect.height + rect.top,
      });
    }
    return out;
  }

  function pickEmployee(clientX: number, clientY: number): string | null {
    const rect = renderer.domElement.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return null;
    pointer.x = ((clientX - rect.left) / rect.width) * 2 - 1;
    pointer.y = -((clientY - rect.top) / rect.height) * 2 + 1;
    raycaster.setFromCamera(pointer, camera);
    const meshes = employees.flatMap((e) => [e.hit, e.body, e.head]);
    const hits = raycaster.intersectObjects(meshes, false);
    if (hits.length > 0) {
      const ud = hits[0]!.object.userData as {
        employeeId?: string;
        deskIndex?: number;
      };
      const fromRay = resolveEmployeeIdFromPick({
        employeeId: ud.employeeId,
        deskIndex: ud.deskIndex,
        employees: ctx.stateRef.current.employees,
      });
      if (fromRay) return fromRay;
    }
    // Fallback: nearest projected desk (reliable at overview distance)
    return pickNearestEmployeeByScreenDistance(
      clientX,
      clientY,
      projectDesksToScreen(),
    );
  }

  // Orbit + click-vs-drag; only gestures that *start* on the canvas can pick
  let canvasGesture = false;
  let dragging = false;
  let pointerMoved = false;
  let downX = 0;
  let downY = 0;
  let lastX = 0;
  let lastY = 0;
  let theta = 0.6;
  let phi = 0.85;
  let radius = OVERVIEW_RADIUS;
  let lookAtCurrent: CameraLookTarget = { ...OVERVIEW_LOOK_AT };
  let lookAtGoal: CameraLookTarget = { ...OVERVIEW_LOOK_AT };
  let radiusGoal = OVERVIEW_RADIUS;
  /** Only auto-set radiusGoal when this identity changes (not every frame). */
  let lastRadiusSelectionKey: string | null = null;
  const FOCUS_LERP = 0.08;

  const onDown = (ev: PointerEvent) => {
    if (ev.button !== 0) return;
    canvasGesture = true;
    dragging = true;
    pointerMoved = false;
    downX = lastX = ev.clientX;
    downY = lastY = ev.clientY;
    activePointerId = ev.pointerId;
    try {
      renderer.domElement.setPointerCapture(ev.pointerId);
    } catch {
      /* ignore — older browsers */
    }
  };
  const onMove = (ev: PointerEvent) => {
    if (!canvasGesture || !dragging) return;
    const dx = ev.clientX - lastX;
    const dy = ev.clientY - lastY;
    lastX = ev.clientX;
    lastY = ev.clientY;
    if (!isClickGesture(downX, downY, ev.clientX, ev.clientY)) {
      pointerMoved = true;
    }
    if (pointerMoved) {
      theta -= dx * 0.005;
      phi = Math.max(0.25, Math.min(1.35, phi + dy * 0.005));
    }
  };
  let activePointerId: number | null = null;
  const endCanvasGesture = () => {
    if (activePointerId != null) {
      try {
        if (renderer.domElement.hasPointerCapture?.(activePointerId)) {
          renderer.domElement.releasePointerCapture(activePointerId);
        }
      } catch {
        /* ignore */
      }
      activePointerId = null;
    }
    canvasGesture = false;
    dragging = false;
    pointerMoved = false;
  };
  const onUp = (ev: PointerEvent) => {
    if (ev.button !== 0) return;
    if (!canvasGesture) return;
    const wasClick = !pointerMoved && isClickGesture(downX, downY, ev.clientX, ev.clientY);
    const x = ev.clientX;
    const y = ev.clientY;
    endCanvasGesture();
    if (!wasClick) return;
    const id = pickEmployee(x, y);
    ctx.selectRef.current(id);
  };
  const onCancel = () => {
    endCanvasGesture();
  };
  const onWheel = (ev: WheelEvent) => {
    radius = Math.max(6, Math.min(22, radius + ev.deltaY * 0.01));
    radiusGoal = radius;
  };
  renderer.domElement.style.touchAction = "none";
  renderer.domElement.addEventListener("pointerdown", onDown);
  window.addEventListener("pointermove", onMove);
  window.addEventListener("pointerup", onUp);
  window.addEventListener("pointercancel", onCancel);
  renderer.domElement.addEventListener("wheel", onWheel, { passive: true });

  // Resize
  const resize = () => {
    const w = mount.clientWidth || 1;
    const h = mount.clientHeight || 1;
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    const q = qualityProfile(ctx.perfRef.current.quality);
    renderer.setPixelRatio(q.pixelRatio);
    renderer.setSize(w, h, false);
    renderer.shadowMap.enabled = q.shadows;
    dir.shadow.mapSize.set(q.shadowMapSize, q.shadowMapSize);
    ctx.onCanvasMetrics?.({ width: Math.round(w), height: Math.round(h) });
  };
  resize();
  const ro = new ResizeObserver(resize);
  ro.observe(mount);

  // Loop
  const meter = new FpsMeter();
  const adaptive = new AdaptiveRenderController(ctx.perfRef.current.quality);
  let lastUserQuality: QualityLevel = ctx.perfRef.current.quality;
  let lastAppliedQuality: QualityLevel = ctx.perfRef.current.quality;
  ctx.onAppliedQuality?.(lastAppliedQuality);
  let raf = 0;
  let lastFrame = 0;
  let accum = 0;

  function syncEmployees(st: VisualOfficeState) {
    for (let i = 0; i < employees.length; i++) {
      const visual = st.employees[i];
      const node = employees[i]!;
      if (!visual) {
        node.root.visible = false;
        continue;
      }
      node.root.visible = true;
      node.id = visual.id;
      node.body.userData.employeeId = visual.id;
      node.head.userData.employeeId = visual.id;
      node.hit.userData.employeeId = visual.id;
      node.body.userData.deskIndex = visual.deskIndex;
      node.head.userData.deskIndex = visual.deskIndex;
      node.hit.userData.deskIndex = visual.deskIndex;
      const pose = poseForStatus(visual.status);
      // Status dot from real dashboard state (not invented activity)
      const sc = statusColor(visual.status);
      const statusMat = node.statusDot.material as InstanceType<
        ThreeModule["MeshStandardMaterial"]
      >;
      statusMat.color.set(sc);
      statusMat.emissive.set(sc);
      statusMat.emissiveIntensity =
        visual.status === "working" || visual.status === "thinking" ? 0.85 : 0.45;

      // LOD: hide secondary desk/prop detail on low quality (keep face/hair readable)
      const detail = qualityProfile(ctx.perfRef.current.quality).deskDetail;
      const showSecondary = detail !== "minimal";
      for (const p of node.secondaryParts) p.visible = showSecondary;

      // Procedural pose offsets (subtle; skipped when reducedMotion)
      const t = performance.now() / 1000;
      let bob = 0;
      let lean = 0;
      let armPump = 0;
      const bodyMat = node.body.material as InstanceType<ThreeModule["MeshStandardMaterial"]>;
      const monMat = node.monitor.material as InstanceType<ThreeModule["MeshStandardMaterial"]>;
      if (pose === "working") {
        bob = Math.sin(t * 6) * 0.015;
        lean = 0.1;
        armPump = Math.sin(t * 8) * 0.12;
        monMat.emissive.setHex(0x0ea5e9);
        monMat.emissiveIntensity = 0.4;
        bodyMat.color.setHex(node.bodyColor);
      } else if (pose === "thinking") {
        bob = Math.sin(t * 2) * 0.012;
        lean = 0.04;
        monMat.emissive.setHex(0x6366f1);
        monMat.emissiveIntensity = 0.25;
        bodyMat.color.setHex(node.bodyColor);
      } else if (pose === "error") {
        bodyMat.color.setHex(0xf87171);
        monMat.emissive.setHex(0x000000);
        monMat.emissiveIntensity = 0;
      } else if (pose === "completed") {
        bodyMat.color.setHex(node.bodyColor);
        monMat.emissive.setHex(0x22c55e);
        monMat.emissiveIntensity = 0.18;
      } else {
        bodyMat.color.setHex(node.bodyColor);
        monMat.emissive.setHex(0x000000);
        monMat.emissiveIntensity = 0;
      }
      if (node.useGltf) {
        playPoseClip(node, pose, ctx.perfRef.current.reducedMotion);
      } else if (!ctx.perfRef.current.reducedMotion) {
        node.body.position.y = 1.02 + bob;
        node.head.position.y = 1.58 + bob;
        node.body.rotation.x = lean;
        // Typing gesture only when backend pose is working
        node.leftArm.rotation.x = pose === "working" ? armPump : 0;
        node.rightArm.rotation.x = pose === "working" ? -armPump * 0.8 : 0;
        node.statusDot.position.y = 1.95 + bob;
      } else {
        node.leftArm.rotation.x = 0;
        node.rightArm.rotation.x = 0;
      }
      // Collaborating / active task → nudge toward meeting table slightly
      if (st.hasActiveTask && (pose === "thinking" || visual.isSynthesizer)) {
        const [mx, mz] = MEETING_TABLE_POS;
        const [dx, dz] = DESK_POSITIONS[i]!;
        node.root.position.x = dx + (mx - dx) * 0.08;
        node.root.position.z = dz + (mz - dz) * 0.08;
      } else {
        const [dx, dz] = DESK_POSITIONS[i]!;
        node.root.position.x = dx;
        node.root.position.z = dz;
      }
    }
    // Selection ring
    if (st.selectedEmployeeId) {
      const idx = st.employees.findIndex((e) => e.id === st.selectedEmployeeId);
      if (idx >= 0) {
        selectionRing.visible = true;
        selectionRing.position.x = employees[idx]!.root.position.x;
        selectionRing.position.z = employees[idx]!.root.position.z;
      }
    } else {
      selectionRing.visible = false;
    }
  }

  function frame(now: number) {
    raf = requestAnimationFrame(frame);
    const perf = ctx.perfRef.current;
    const interval = frameIntervalMs(perf.fpsCap);
    const dt = lastFrame ? now - lastFrame : 16;
    lastFrame = now;
    accum += dt;
    if (interval > 0 && accum < interval) return;
    accum = 0;

    const fps = meter.tick(now);
    ctx.onMeasuredFps?.(fps);

    // User Quality control is authoritative ceiling; adaptive only lowers render cost.
    if (perf.quality !== lastUserQuality) {
      adaptive.setUserQuality(perf.quality);
      lastUserQuality = perf.quality;
    }
    const applied = adaptive.tick(fps, perf.fpsCap, now);
    if (applied !== lastAppliedQuality) {
      lastAppliedQuality = applied;
      const q = qualityProfile(applied);
      renderer.setPixelRatio(q.pixelRatio);
      renderer.shadowMap.enabled = q.shadows;
      dir.shadow.mapSize.set(q.shadowMapSize, q.shadowMapSize);
      // Re-apply size so pixel ratio takes effect without rebuilding the renderer
      const w = mount.clientWidth || 1;
      const h = mount.clientHeight || 1;
      renderer.setSize(w, h, false);
      ctx.onAppliedQuality?.(applied);
    }

    const st = ctx.stateRef.current;
    lookAtGoal = cameraLookTargetForSelection(st.selectedEmployeeId, st.employees);
    // Auto radius only when selected employee identity changes — preserves wheel zoom otherwise.
    const selectionKey = st.selectedEmployeeId;
    if (selectionKey !== lastRadiusSelectionKey) {
      lastRadiusSelectionKey = selectionKey;
      radiusGoal = cameraRadiusForSelection(selectionKey);
    }
    lookAtCurrent = lerpLookTarget(lookAtCurrent, lookAtGoal, FOCUS_LERP);
    radius = lerp(radius, radiusGoal, FOCUS_LERP);

    camera.position.x = lookAtCurrent.x + Math.sin(theta) * Math.sin(phi) * radius;
    camera.position.y = lookAtCurrent.y + Math.cos(phi) * radius;
    camera.position.z = lookAtCurrent.z + Math.cos(theta) * Math.sin(phi) * radius;
    camera.lookAt(lookAtCurrent.x, lookAtCurrent.y, lookAtCurrent.z);

    syncEmployees(st);
    const dtSec = (interval > 0 ? interval : dt) / 1000;
    for (const emp of employees) {
      if (emp.mixer && emp.useGltf) emp.mixer.update(dtSec);
    }
    renderer.render(scene, camera);
  }
  raf = requestAnimationFrame(frame);

  return () => {
    cancelAnimationFrame(raf);
    raf = 0;
    ro.disconnect();
    renderer.domElement.removeEventListener("pointerdown", onDown);
    window.removeEventListener("pointermove", onMove);
    window.removeEventListener("pointerup", onUp);
    window.removeEventListener("pointercancel", onCancel);
    renderer.domElement.removeEventListener("wheel", onWheel);
    endCanvasGesture();
    // Dispose GPU resources — geometries & materials
    scene.traverse((obj) => {
      const mesh = obj as InstanceType<ThreeModule["Mesh"]>;
      if (mesh.geometry) mesh.geometry.dispose?.();
      const mat = mesh.material as
        | InstanceType<ThreeModule["Material"]>
        | InstanceType<ThreeModule["Material"]>[]
        | undefined;
      if (Array.isArray(mat)) mat.forEach((m) => m.dispose?.());
      else mat?.dispose?.();
    });
    renderer.dispose();
    if (renderer.domElement.parentNode === mount) {
      mount.removeChild(renderer.domElement);
    }
  };
}
