/**
 * Pure 3D presentation state mapping from Phase 7 dashboard DTOs.
 * No WebGL / Three.js — safe to unit-test in Node.
 */

import type {
  DashboardEmployeeCard,
  DashboardEmployeeState,
  DashboardSnapshot,
} from "@/office/dashboard-api.ts";

export type VisualEmployeeState = DashboardEmployeeState;

export interface VisualEmployee {
  id: string;
  displayName: string;
  role: string;
  status: VisualEmployeeState;
  provider: string;
  model: string;
  isSynthesizer: boolean;
  activityLabel: string | null;
  latestSummary: string | null;
  error: string | null;
  /** Desk slot index 0..5 in the office floor plan. */
  deskIndex: number;
}

export interface VisualOfficeState {
  employees: VisualEmployee[];
  taskStatus: string | null;
  taskTitle: string | null;
  taskObjective: string | null;
  hasActiveTask: boolean;
  recentActivity: Array<{ id: string; label: string; employeeId: string | null }>;
  selectedEmployeeId: string | null;
  providersOnline: number;
  providersTotal: number;
  memoryEntryCount: number;
}

export const DESK_ORDER = [
  "ceo",
  "pm",
  "developer",
  "researcher",
  "automation",
  "jira",
] as const;

/** P1 procedural visual identity — not GLB anime; distinct silhouettes & palettes. */
export type CharacterId = (typeof DESK_ORDER)[number];

export interface CharacterVisual {
  id: CharacterId;
  /** Primary clothing / torso */
  primary: number;
  /** Secondary accent (scarf, panel, trim) */
  accent: number;
  /** Hair */
  hair: number;
  /** Skin */
  skin: number;
  /** Desk nameplate / small prop */
  prop: number;
  /** Hair style key for procedural mesh choice */
  hairStyle: "side" | "twin" | "spiky" | "neat";
}

export const CHARACTER_VISUAL: Record<CharacterId, CharacterVisual> = {
  ceo: {
    id: "ceo",
    primary: 0x0d9488, // teal blazer
    accent: 0xd4af37, // gold trim
    hair: 0x292524,
    skin: 0xf0d0b0,
    prop: 0xe3b341,
    hairStyle: "neat",
  },
  pm: {
    id: "pm",
    primary: 0x475569, // slate
    accent: 0x60a5fa, // blue accent
    hair: 0x1e293b,
    skin: 0xe8c4a8,
    prop: 0x93c5fd,
    hairStyle: "side",
  },
  developer: {
    id: "developer",
    primary: 0xd97757, // warm terracotta jacket
    accent: 0xf5e6d3,
    hair: 0x3d2914,
    skin: 0xf0c4a0,
    prop: 0xe8b89a,
    hairStyle: "spiky",
  },
  researcher: {
    id: "researcher",
    primary: 0x4f46e5, // indigo
    accent: 0xa78bfa, // violet split
    hair: 0x1e1b4b,
    skin: 0xe8c4a8,
    prop: 0x818cf8,
    hairStyle: "twin",
  },
  automation: {
    id: "automation",
    primary: 0x1f2937, // near-black
    accent: 0x22d3ee, // cyan edge
    hair: 0x111827,
    skin: 0xe5c4a8,
    prop: 0x67e8f9,
    hairStyle: "neat",
  },
  jira: {
    id: "jira",
    primary: 0x047857, // emerald
    accent: 0x99f6e4,
    hair: 0x1c1917,
    skin: 0xf0d0b0,
    prop: 0x5eead4,
    hairStyle: "side",
  },
};

export function characterVisualFor(id: string): CharacterVisual {
  if (id in CHARACTER_VISUAL) return CHARACTER_VISUAL[id as CharacterId];
  return CHARACTER_VISUAL.ceo;
}



export function activityLabelFor(status: VisualEmployeeState): string | null {
  switch (status) {
    case "idle":
      return null;
    case "queued":
      return "Queued";
    case "thinking":
      return "Thinking";
    case "working":
      return "Working";
    case "waiting":
      return "Waiting";
    case "completed":
      return "Done";
    case "failed":
      return "Failed";
    case "cancelled":
      return "Cancelled";
    case "rate_limited":
      return "Rate limited";
    case "unavailable":
      return "Unavailable";
    default:
      return null;
  }
}

/** Status color token for badges / avatar indicators. */
export function statusColor(status: VisualEmployeeState): string {
  switch (status) {
    case "working":
    case "thinking":
      return "#22d3ee";
    case "completed":
      return "#34d399";
    case "failed":
      return "#f87171";
    case "rate_limited":
    case "unavailable":
      return "#fbbf24";
    case "queued":
    case "waiting":
      return "#a78bfa";
    case "cancelled":
      return "#94a3b8";
    default:
      return "#64748b";
  }
}

export function mapEmployeeToVisual(
  card: DashboardEmployeeCard,
  deskIndex: number,
): VisualEmployee {
  return {
    id: card.id,
    displayName: card.displayName,
    role: card.role,
    status: card.status,
    provider: card.provider,
    model: card.model,
    isSynthesizer: card.isSynthesizer,
    activityLabel: activityLabelFor(card.status),
    latestSummary: card.latestSummary,
    error: card.error,
    deskIndex,
  };
}

/** Sanitize dynamic text for canvas/DOM labels (no HTML injection). */
export function safeLabel(raw: string | null | undefined, max = 80): string {
  if (!raw) return "";
  return String(raw)
    .replace(/[<>&"']/g, "")
    .replace(/Bearer\s+\S+/gi, "[REDACTED]")
    .replace(/secret-api-key-\S+/gi, "[REDACTED]")
    .slice(0, max);
}

export function mapDashboardToVisualOffice(
  snap: DashboardSnapshot | null | undefined,
  selectedEmployeeId: string | null = null,
): VisualOfficeState {
  if (!snap) {
    return {
      employees: [],
      taskStatus: null,
      taskTitle: null,
      taskObjective: null,
      hasActiveTask: false,
      recentActivity: [],
      selectedEmployeeId,
      providersOnline: 0,
      providersTotal: 0,
      memoryEntryCount: 0,
    };
  }

  const byId = new Map(snap.employees.map((e) => [e.id, e]));
  const employees: VisualEmployee[] = DESK_ORDER.map((id, index) => {
    const card = byId.get(id);
    if (card) return mapEmployeeToVisual(card, index);
    // Should not invent employees — only map known six if present
    return {
      id,
      displayName: id,
      role: "",
      status: "unavailable" as VisualEmployeeState,
      provider: "—",
      model: "—",
      isSynthesizer: id === "ceo",
      activityLabel: "Unavailable",
      latestSummary: null,
      error: null,
      deskIndex: index,
    };
  }).filter((e) => byId.has(e.id) || snap.employees.length === 0);

  // Prefer real cards order if backend returns subset
  const mapped =
    snap.employees.length > 0
      ? DESK_ORDER.map((id, index) => {
          const card = byId.get(id);
          return card ? mapEmployeeToVisual(card, index) : null;
        }).filter((e): e is VisualEmployee => e !== null)
      : [];

  const activeStatuses = new Set([
    "created",
    "planning",
    "assigned",
    "running",
    "synthesizing",
  ]);
  const task = snap.currentTask;

  return {
    employees: mapped,
    taskStatus: task?.status ?? null,
    taskTitle: task ? safeLabel(task.title, 60) : null,
    taskObjective: task ? safeLabel(task.objective, 120) : null,
    hasActiveTask: Boolean(task && activeStatuses.has(task.status)),
    recentActivity: snap.events.slice(0, 12).map((e) => ({
      id: e.id,
      label: safeLabel(e.message, 100),
      employeeId: e.employeeId,
    })),
    selectedEmployeeId,
    providersOnline: snap.providers.filter((p) => p.availability === "available").length,
    providersTotal: snap.providers.length,
    memoryEntryCount: snap.memory?.entryCount ?? 0,
  };
}

/** Desk positions in normalized office coordinates (0..1 floor). */
export const DESK_LAYOUT: Array<{ x: number; z: number; label: string }> = [
  { x: 0.2, z: 0.3, label: "ceo" },
  { x: 0.5, z: 0.3, label: "pm" },
  { x: 0.8, z: 0.3, label: "developer" },
  { x: 0.2, z: 0.7, label: "researcher" },
  { x: 0.5, z: 0.7, label: "automation" },
  { x: 0.8, z: 0.7, label: "jira" },
];

/** Animation / body pose derived from backend status only. */
export type EmployeePose =
  | "idle"
  | "sitting"
  | "working"
  | "thinking"
  | "standing"
  | "walking"
  | "completed"
  | "error";

export function poseForStatus(status: VisualEmployeeState): EmployeePose {
  switch (status) {
    case "working":
      return "working";
    case "thinking":
      return "thinking";
    case "queued":
    case "waiting":
      return "sitting";
    case "completed":
      return "completed";
    case "failed":
    case "cancelled":
      return "error";
    case "rate_limited":
    case "unavailable":
      return "standing";
    default:
      return "idle";
  }
}

/** Desk world positions (x, z) for six employees — used by 3D scene.
 * Two rows of three; meeting table sits at [0, 2.2] so the second-row
 * center desk at z=0.8 keeps clearance. */
export const DESK_POSITIONS: ReadonlyArray<readonly [number, number]> = [
  [-3.4, -1.8], // ceo
  [0, -1.8], // pm
  [3.4, -1.8], // developer
  [-3.4, 0.8], // researcher
  [0, 0.8], // automation
  [3.4, 0.8], // jira
];

export const MEETING_TABLE_POS: readonly [number, number] = [0, 2.2];


/** Resolve employee id from desk slot index (0..5). Safe for raycast hits. */
export function resolveEmployeeIdFromDeskIndex(
  employees: ReadonlyArray<{ id: string; deskIndex: number }>,
  deskIndex: number,
): string | null {
  if (!Number.isInteger(deskIndex) || deskIndex < 0) return null;
  const byDesk = employees.find((e) => e.deskIndex === deskIndex);
  if (byDesk) return byDesk.id;
  // Fallback: visual list is ordered by DESK_ORDER / deskIndex
  const byPos = employees[deskIndex];
  return byPos?.id ?? null;
}

/** Prefer explicit employeeId on mesh userData when present. */
export function resolveEmployeeIdFromPick(input: {
  employeeId?: string | null;
  deskIndex?: number | null;
  employees: ReadonlyArray<{ id: string; deskIndex: number }>;
}): string | null {
  const id = typeof input.employeeId === "string" ? input.employeeId.trim() : "";
  if (id) {
    const exists = input.employees.some((e) => e.id === id);
    if (exists) return id;
  }
  if (input.deskIndex == null || input.deskIndex === undefined) return null;
  return resolveEmployeeIdFromDeskIndex(input.employees, input.deskIndex);
}

/** Pointer movement (px) below this counts as a click, not an orbit drag. */
export const PICK_CLICK_THRESHOLD_PX = 8;

export function isClickGesture(
  downX: number,
  downY: number,
  upX: number,
  upY: number,
  thresholdPx = PICK_CLICK_THRESHOLD_PX,
): boolean {
  const dx = upX - downX;
  const dy = upY - downY;
  return dx * dx + dy * dy <= thresholdPx * thresholdPx;
}


/** Max screen-space distance (CSS px) for nearest-desk pick fallback. */
export const PICK_SCREEN_RADIUS_PX = 96;

export interface ScreenProjectedDesk {
  employeeId: string;
  screenX: number;
  screenY: number;
}

/**
 * Nearest projected desk within maxDistancePx, or null.
 * Used as fallback when WebGL raycast misses thin meshes at overview distance.
 */
export function pickNearestEmployeeByScreenDistance(
  clientX: number,
  clientY: number,
  projected: ReadonlyArray<ScreenProjectedDesk>,
  maxDistancePx = PICK_SCREEN_RADIUS_PX,
): string | null {
  let bestId: string | null = null;
  let bestD = maxDistancePx;
  for (const p of projected) {
    if (!p.employeeId) continue;
    const dx = clientX - p.screenX;
    const dy = clientY - p.screenY;
    const d = Math.hypot(dx, dy);
    if (d <= bestD) {
      bestD = d;
      bestId = p.employeeId;
    }
  }
  return bestId;
}

export interface CameraLookTarget {
  x: number;
  y: number;
  z: number;
}

export const OVERVIEW_LOOK_AT: CameraLookTarget = { x: 0, y: 0.5, z: 0 };
export const OVERVIEW_RADIUS = 14;
/** Closer orbit radius when focusing a selected employee. */
export const FOCUS_RADIUS = 9;

/** World-space look target for the selected desk, or overview when none. */
export function cameraLookTargetForSelection(
  selectedEmployeeId: string | null,
  employees: ReadonlyArray<{ id: string; deskIndex: number }>,
): CameraLookTarget {
  if (!selectedEmployeeId) return { ...OVERVIEW_LOOK_AT };
  const emp = employees.find((e) => e.id === selectedEmployeeId);
  if (!emp) return { ...OVERVIEW_LOOK_AT };
  const pos = DESK_POSITIONS[emp.deskIndex] ?? DESK_POSITIONS[0];
  if (!pos) return { ...OVERVIEW_LOOK_AT };
  return { x: pos[0], y: 0.9, z: pos[1] };
}

export function cameraRadiusForSelection(selectedEmployeeId: string | null): number {
  return selectedEmployeeId ? FOCUS_RADIUS : OVERVIEW_RADIUS;
}

/** Linear interpolate; t clamped 0..1. */
export function lerp(a: number, b: number, t: number): number {
  const u = t < 0 ? 0 : t > 1 ? 1 : t;
  return a + (b - a) * u;
}

export function lerpLookTarget(
  from: CameraLookTarget,
  to: CameraLookTarget,
  t: number,
): CameraLookTarget {
  return {
    x: lerp(from.x, to.x, t),
    y: lerp(from.y, to.y, t),
    z: lerp(from.z, to.z, t),
  };
}

export interface EmployeeInteraction {
  inspect: (employeeId: string) => void;
  privateChat: (employeeId: string, message: string) => Promise<string>;
  /** V1.3 voice — not implemented in V1.1 */
  voice: (employeeId: string) => { available: false; message: string };
}

export function voicePlaceholder(): { available: false; message: string } {
  return { available: false, message: "Voice arrives in V1.3" };
}
